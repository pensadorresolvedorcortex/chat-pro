( function( $ ) {
	"use strict";
    elementor.addControlView( 'loftocean-switcher-control', elementor.modules.controls.Switcher.extend( { } ) );
} ( jQuery ) );
