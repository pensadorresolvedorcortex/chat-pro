<div class="room-top-section">
    <div class="featured-img"><?php the_post_thumbnail(); ?></div>
</div>