<?php
namespace Elementor;

function kasuari_general_elementor_init(){
	Plugin::instance()->elements_manager->add_category(
		'kasuari-general-category',
		[
			'title'  => 'Main Elements',
			'icon' => 'font'
		],
		1
	);
}
add_action('elementor/init','Elementor\kasuari_general_elementor_init');
