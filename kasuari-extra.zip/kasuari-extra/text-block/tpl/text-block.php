<div class="kasuari-text clearfix">
<?php 
	echo balancetags($custom_text);
?>
</div>