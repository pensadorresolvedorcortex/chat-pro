<?php

add_action( 'elementor/element/kasuari-post-block/section_kasuari_post_block_post_setting/after_section_start', function( $element, $args ) {
	/** @var \Elementor\Element_Base $element */
	
	$element->add_control(
		'posts_per_page',
		[
			'label' => __( 'Post per Block', 'kasuari' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => '6',
			'title' => __( 'Enter some text', 'kasuari' ),
			'description' => __( 'This option allow you to set how much post display in this block.', 'kasuari' ),	
		]
	);

	$element->add_control(
		'offset',
		[
			'label' => __( 'Offset', 'kasuari' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => '',
			'title' => __( 'Enter some text', 'kasuari' ),
			'description' => __( 'Set the first post to display (start from 0 as the latest post in each order).', 'kasuari' ),
		]
	);

	$element->add_control(
		'category',
		[
			'label' => __( 'Category', 'kasuari' ),
			'type'    => \Elementor\Controls_Manager::SELECT2,
			'label_block' => true,
			'multiple'    => true,
			'default' => [],				
			'options' => kasuari_get_category(),
			'description' => __( 'Select category to display (default to All).', 'kasuari' ),
		]
	);

	$element->add_control(
		'orderby',
		[
			'label' => __( 'Order By', 'kasuari' ),
			'type' => \Elementor\Controls_Manager::SELECT,
			'default' => 'date',
			'options' => kasuari_order_by(),
			'description' => __( 'Select post order by (default to latest post).', 'kasuari' ),
		]
	);

}, 10, 2 );