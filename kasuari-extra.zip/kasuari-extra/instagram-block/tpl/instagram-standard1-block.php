<?php
wp_enqueue_script('kasuari-instafeed-js', KASUARI_EXTRA_URL.'inc/js/kasuari-instafeed.min.js', array('jquery', 'masonry'), true);
 ?>

	<div class="instagram-builder kasuari-instagram-feed <?php echo $no_caption; ?> <?php echo esc_attr($settings['kasuari_instafeed_columns'] ); ?> clearfix">
		<div id="kasuari-instagram-feed-<?php echo esc_attr($this->get_id()); ?>" class="kasuari-insta-grid">
		</div>
	</div>

	<script type="text/javascript">
	(function($) {
	'use strict';

		$(document).ready(function(){
			var feed = new Instafeed({
		    get: '<?php echo esc_attr($settings['kasuari_instafeed_source'] ); ?>',
		    tagName: '<?php echo esc_attr($settings['kasuari_instafeed_hashtag'] ); ?>',
		    userId: <?php echo esc_attr($settings['kasuari_instafeed_user_id'] ); ?>,
		    clientId: '<?php echo esc_attr($settings['kasuari_instafeed_client_id'] ); ?>',
		    accessToken: '<?php echo esc_attr($settings['kasuari_instafeed_access_token'] ); ?>',
		    limit: '<?php echo $image_limit['size']; ?>',
		    resolution: '<?php echo esc_attr($settings['kasuari_instafeed_image_resolution'] ); ?>',
		    sortBy: '<?php echo esc_attr($settings['kasuari_instafeed_sort_by'] ); ?>',
		    target: 'kasuari-instagram-feed-<?php echo esc_attr($this->get_id()); ?>',
		    template: '<div class="kasuari-insta-feed kasuari-insta-box"><div class="kasuari-insta-feed-inner"><div class="kasuari-insta-feed-wrap"><div class="kasuari-insta-img-wrap"><img src="{{image}}" /></div><div class="kasuari-insta-info-wrap"><div class="kasuari-insta-likes-comments"><p> <i class="fa fa-heart-o" aria-hidden="true"></i> {{likes}}</p> <p><i class="fa fa-comment-o" aria-hidden="true"></i> {{comments}}</p> </div><?php echo $show_caption; ?></div><?php echo $enable_link; ?></div></div></div>',
		    after: function() {
		      var el = document.getElementById('kasuari-instagram-feed-<?php echo esc_attr($this->get_id()); ?>');
		      if (el.classList)
		        el.classList.add('show');
		      else
		        el.className += ' ' + 'show';
		    }
		  });
		  feed.run();
		
		});

	})( jQuery );
	</script><!-- Portfolio Script End -->
	<script type="text/javascript">
	jQuery(document).ready(function($) {
		'use strict';
		  $(window).load(function(){

		    $('.kasuari-insta-grid').masonry({
		      itemSelector: '.kasuari-insta-feed',
		      percentPosition: true,
		      columnWidth: '.kasuari-insta-box'
		    });

		  });
	});
	</script>