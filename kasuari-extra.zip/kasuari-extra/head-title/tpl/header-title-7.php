<div class="head-title head-title-7 text-<?php echo esc_attr($align); ?> clearfix">
	<<?php echo $title_size; ?> class="the-title">
		<?php echo $the_title; ?>
		<?php if($head_use_subtitle == 'on') { ?>
		<span class="subtitle big-title">
			<?php echo $the_subtitle; ?>
		</span>
		<?php } ?>
	</<?php echo $title_size; ?>>
</div>