<div class="kasuari-menus clearfix">
	<?php

	if($menu_image_crop == 'on') {
		$crop = true;
	}
	else {
		$crop = false;
	}

	$menu_img_res = $menu_img['url'];
	if(!empty($menu_img_res)) {
		$menu_res_img 	= $menu_img_res;
		$menu_image		= aq_resize($menu_res_img, $width , $height, $crop, true, true);
	}
	else {
		$menu_image = get_template_directory_uri() .'/img/thumb-testi.jpg';
	}

	?>

	<?php if($use_image == 'on') { ?>
	<div class="menu-img<?php if($menu_image_radius == 'on') { ?> rounded<?php } ?>">
		<?php if(!empty($menu_img_res)) { ?>
			<img src="<?php echo esc_url( $menu_image ); ?>" alt="<?php echo esc_attr($menu_name); ?>">
		<?php }
		if(empty($menu_img_res)) { ?>
			<img src="<?php echo esc_url( $menu_res_img ); ?>" alt="<?php echo esc_attr($menu_name); ?>">
		<?php } ?>
	</div>
	<?php } ?>

	<?php if($use_image == 'on') { ?>
	<div class="texted-menu" style="width: calc(100% - <?php echo esc_attr($width); ?>px - 30px)">
	<?php }
	else { ?>
	<div class="texted-menu" style="width: 100%; float: left;">
	<?php } ?>
		<div class="menu-list__item">
			<h4 class="menu-list__item-title">
				<span class="item_title"><?php echo sanitize_text_field($menu_name); ?></span>
			</h4>

			<span class="dots"></span>

			<span class="menu-list__item-price"><?php echo sanitize_text_field($menu_price); ?></span>
		</div>
		<div class="resto-menus-desc">
			<?php echo htmlspecialchars_decode( esc_html($menu_desc)); ?>
		</div>
	</div>
</div>