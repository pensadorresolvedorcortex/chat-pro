#' @examples \donttest{
#' # Run smoking node-splitting example if not already available
#' if (!exists("smk_fit_RE_nodesplit")) example("example_smk_nodesplit", run.donttest = TRUE)
#' }
