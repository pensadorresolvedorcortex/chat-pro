#' @examples \donttest{
#' # Run smoking FE NMA example if not already available
#' if (!exists("smk_fit_FE")) example("example_smk_fe", run.donttest = TRUE)
#' }
