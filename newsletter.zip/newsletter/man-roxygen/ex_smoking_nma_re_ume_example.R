#' @examples \donttest{
#' # Run smoking UME NMA example if not already available
#' if (!exists("smk_fit_RE_UME")) example("example_smk_ume", run.donttest = TRUE)
#' }
