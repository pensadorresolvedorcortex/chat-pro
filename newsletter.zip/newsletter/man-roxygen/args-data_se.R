#' @param se column of `data` specifying the standard error for a continuous
#'   outcome
