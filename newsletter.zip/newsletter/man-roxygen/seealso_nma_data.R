#' @seealso [print.nma_data()] for the print method displaying details of the
#'   network, and [plot.nma_data()] for network plots.
