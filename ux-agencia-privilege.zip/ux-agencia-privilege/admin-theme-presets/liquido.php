<?php
/*
 * UX Agência Privilege
 * @author   Agência Privilége
 * @url     https://studioprivilege.com.br
*/

$wps_themes['Liquido'] = array (
  'h1_color' => '#1F2330',
  'h2_color' => '#2A2F3A',
  'h3_color' => '#343B48',
  'h4_color' => '#4A5160',
  'h5_color' => '#6C7385',
  'h6_color' => '#8E94A4',

  'pry_button_color' => '#886CC0',
  'pry_button_border_color' => '#886CC0',
  'pry_button_hover_color' => '#6F52B4',
  'pry_button_hover_border_color' => '#6F52B4',
  'pry_button_shadow_color' => '#A58BD6',
  'pry_button_text_color' => '#FFFFFF',
  'pry_button_hover_shadow_color' => '#8D76C9',
  'pry_button_hover_text_color' => '#FFFFFF',

  'sec_button_color' => '#EFEAF9',
  'sec_button_border_color' => '#EFEAF9',
  'sec_button_hover_color' => '#886CC0',
  'sec_button_hover_border_color' => '#886CC0',
  'sec_button_shadow_color' => '#FFFFFF',
  'sec_button_text_color' => '#6F52B4',
  'sec_button_hover_text_color' => '#FFFFFF',

  'metabox_h3_color' => '#FFFFFF',
  'metabox_h3_border_color' => '#EEEEEE',
  'metabox_handle_color' => '#595959',
  'metabox_handle_hover_color' => '#444444',
  'metabox_text_color' => '#565656',

  'admin_bar_color' => '#FFFFFF',
  'admin_bar_menu_bg_hover_color' => '#EAEFF4',
  'admin_bar_menu_color' => '#5B6472',
  'admin_bar_menu_hover_color' => '#3D4351',
  'admin_bar_sbmenu_link_color' => '#5B6472',
  'admin_bar_sbmenu_link_hover_color' => '#3D4351',

  'bg_color' => '#F8F9FB',

  'nav_wrap_color' => '#FFFFFF',
  'sub_nav_wrap_color' => '#FAFAFD',
  'sub_nav_hover_color' => '#EFEAF9',
  'nav_text_color' => '#717579',
  'menu_hover_text_color' => '#886CC0',
  'hover_menu_color' => '#EFEAF9',
  'active_menu_color' => '#ECE3FF',
  'menu_active_text_color' => '#886CC0',

  'addbtn_bg_color' => '#EFEAF9',
  'addbtn_hover_bg_color' => '#886CC0',
  'addbtn_text_color' => '#6F52B4',
  'addbtn_hover_text_color' => '#FFFFFF',

  'msg_box_color' => '#EEF1F6',
  'msgbox_text_color' => '#2C2F36',
  'msgbox_border_color' => '#EEF1F6',
  'msgbox_link_color' => '#886CC0',
  'msgbox_link_hover_color' => '#6F52B4',

  'notice_box_color' => '#FFF8E6',
  'notice_text_color' => '#C47A00',
  'notice_link_color' => '#886CC0',
  'notice_link_hover_color' => '#6F52B4',

  'menu_updates_count_bg' => '#2d2d2d',
  'menu_updates_count_text' => '#ffffff',
);
