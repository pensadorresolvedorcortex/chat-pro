<?php
/*
Plugin Name: Acmee Options Framework
Plugin URI: http://acmeedesign.com
Description: Options framework for WordPress themes and plugins.
version: 1.2.1
Author: AcmeeDesign Softwares and Solutions
Author URI: http://acmeedesign.com
 */

require_once ( AOF_PATH . 'inc/aof.class.php' );
