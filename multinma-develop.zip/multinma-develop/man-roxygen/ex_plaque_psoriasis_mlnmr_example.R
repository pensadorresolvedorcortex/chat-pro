#' @examples \donttest{
#' # Run plaque psoriasis ML-NMR example if not already available
#' if (!exists("pso_fit")) example("example_pso_mlnmr", run.donttest = TRUE)
#' }
