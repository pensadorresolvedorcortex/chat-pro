#' @param Surv column of `data` specifying a survival or time-to-event outcome,
#'   using the [Surv()] function. Right/left/interval censoring and left
#'   truncation (delayed entry) are supported.
