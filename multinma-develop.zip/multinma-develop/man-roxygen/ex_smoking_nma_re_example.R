#' @examples \donttest{
#' # Run smoking RE NMA example if not already available
#' if (!exists("smk_fit_RE")) example("example_smk_re", run.donttest = TRUE)
#' }
