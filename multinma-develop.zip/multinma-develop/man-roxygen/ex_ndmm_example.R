#' @examples \donttest{
#' # Run newly-diagnosed multiple myeloma example if not already available
#' if (!exists("ndmm_fit")) example("example_ndmm", run.donttest = TRUE)
#' }
