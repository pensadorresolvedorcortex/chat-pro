#' @param r column of `data` specifying a binary or Binomial outcome count
#' @param E column of `data` specifying the total time at risk for Poisson
#'   outcomes
