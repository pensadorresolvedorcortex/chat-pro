#' @param y column of `data` specifying a continuous outcome
