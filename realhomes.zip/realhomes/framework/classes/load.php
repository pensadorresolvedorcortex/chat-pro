<?php
/**
 * This file loads classes files necessary for the RealHomes theme functionality.
 *
 * @package realhomes/functions
 */

// Load main Realhomes helper class.
require_once INSPIRY_FRAMEWORK . 'classes/class-realhomes-helper.php';

// Custom sidebar generator.
require_once INSPIRY_FRAMEWORK . 'classes/class-custom-sidebar.php';

// SVG sanitation class.
require_once INSPIRY_FRAMEWORK . 'classes/class-svg-sanitation.php';

// Load RealHomes  Class
require_once INSPIRY_FRAMEWORK . 'classes/class-realhomes-cache.php';

// Load RealHomes Icons Class
require_once INSPIRY_FRAMEWORK . 'classes/class-render-icons.php';

// Load properties views limit class for guest visitors (non-logged-in)
require_once INSPIRY_FRAMEWORK . 'classes/class-properties-views-limit.php';