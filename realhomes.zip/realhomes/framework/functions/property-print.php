<?php
/**
 * RealHomes Print Functions
 *
 * @since       4.4.2
 * @subpackage  Print
 * @package     RealHomes
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue print script with localized data.
 *
 * @since   4.4.2
 */
add_action( 'wp_enqueue_scripts', 'realhomes_enqueue_print_script' );
function realhomes_enqueue_print_script() {
	if ( is_singular( 'property' ) ) {

		// Enqueue print script
		wp_enqueue_script(
			'print-property',
			get_theme_file_uri( '/common/js/print-property.js' ),
			[ 'jquery' ],
			INSPIRY_THEME_VERSION,
			true
		);

		// Localized strings + data
		wp_localize_script( 'print-property', 'printProperty', [
			'printUrl'    => get_permalink( get_the_ID() ) . '?print_view=1',
			'loadingText' => esc_html__( 'Loading print preview...', RH_TEXT_DOMAIN ),
		] );

		wp_enqueue_script( 'print-property' );
	}
}