<?php
/**
 * File Name: config-meta-boxes.php
 *
 * Registering meta boxes
 *
 * All the definitions of meta boxes are listed below with comments.
 * Please read them CAREFULLY.
 *
 *
 */

/********************* META BOX DEFINITIONS ***********************/

/**
 * Prefix of meta keys (optional)
 * Use underscore (_) at the beginning to make keys hidden
 * Alt.: You also can make prefix empty to disable it
 */
// Better has an underscore as last sign
$prefix = 'REAL_HOMES_';

global $meta_boxes;

$meta_boxes = array();


// Video Meta Box
$meta_boxes[] = array(
    // Meta box id, UNIQUE per meta box. Optional since 4.1.5
    'id' => 'video-meta-box',

    // Meta box title - Will appear at the drag and drop handle bar. Required.
    'title' => __('Video Embed Code','framework'),

    // Post types, accept custom post types as well - DEFAULT is array('post'). Optional.
    'pages' => array( 'post' ),

    // Where the meta box appear: normal (default), advanced, side. Optional.
    'context' => 'normal',

    // Order of meta box: high (default), low. Optional.
    'priority' => 'high',

    // List of meta fields
    'fields' => array(
        array(
            'name' => __('Video Embed Code','framework'),
            'desc' => __('If you are not using self hosted videos then please provide the video embed code and remove the width and height attributes.','framework'),
            'id'   => "{$prefix}embed_code",
            'type' => 'textarea',
            'cols' => '20',
            'rows' => '3'
        )
    )
);

// Gallery Meta Box
$meta_boxes[] = array(
    // Meta box id, UNIQUE per meta box. Optional since 4.1.5
    'id' => 'gallery-meta-box',

    // Meta box title - Will appear at the drag and drop handle bar. Required.
    'title' => __('Gallery Images','framework'),

    // Post types, accept custom post types as well - DEFAULT is array('post'). Optional.
    'pages' => array( 'post' ),

    // Where the meta box appear: normal (default), advanced, side. Optional.
    'context' => 'normal',

    // Order of meta box: high (default), low. Optional.
    'priority' => 'high',

    // List of meta fields
    'fields' => array(
        array(
            'name'             => __('Upload Gallery Images','framework'),
            'id'               => "{$prefix}gallery",
            'desc' => __('Images should have minimum width of 830px and minimum height of 323px, Bigger size images will be cropped automatically.','framework'),
            'type'             => 'image_advanced',
            'max_file_uploads' => 48
        )
    )
);

/* Agents */
$agents_array = array( -1 => __('None','framework') );
$agents_posts = get_posts( array( 'post_type' => 'agent', 'posts_per_page' => -1, 'suppress_filters' => 0 ) );
if(!empty($agents_posts)){
    foreach( $agents_posts as $agent_post ){
        $agents_array[$agent_post->ID] =$agent_post->post_title;
    }
}

// Property Details Meta Box
$meta_boxes[] = array(
    // Meta box id, UNIQUE per meta box. Optional since 4.1.5
    'id' => 'property_details',

    // Meta box title - Will appear at the drag and drop handle bar. Required.
    'title' => __('Property Details','framework'),

    // Post types, accept custom post types as well - DEFAULT is array('post'). Optional.
    'pages' => array( 'property' ),

    // Where the meta box appear: normal (default), advanced, side. Optional.
    'context' => 'normal',

    // Order of meta box: high (default), low. Optional.
    'priority' => 'high',

    // List of meta fields
    'fields' => array(
        array(
            'name'      => __( 'Tipo Galeria', 'framework' ),
            'desc'      => __('Selecione o tipo de galeria que você deseja usar para esta propriedade imagens', 'framework'),
            'id'        => "{$prefix}gallery_slider_type",
            'type'      => 'radio',
            'std'       => 'thumb-on-right',
            'options' => array(
                'thumb-on-right' => __( 'Galeria com miniaturas lado direito', 'framework' ),
                'thumb-on-bottom' => __( 'Galeria com miniaturas na parte inferior', 'framework' )
            )
        ),
        array(
            'name'             => __('Galeria de Imagens','framework'),
            'id'               => "{$prefix}property_images",
            'desc' => __('Fornecer imagens para galeria na página de detalhes de propriedade. As imagens devem ter tamanho mínimo de 770px por 386px de miniaturas na direita e 830px por 460px de miniaturas na parte inferior. (Imagens maiores serão cortadas automaticamente)','framework'),
            'type'             => 'image_advanced',
            'max_file_uploads' => 48
        ),
        array(
            'id'        => "{$prefix}property_price",
            'name'      => __('Preço do imóvel','framework'),
            'desc'      => __('Fornecer venda ou aluguel preço. (Só inserir dígitos) Exemplo: 435000','framework'),
            'type'      => 'text',
            'std'       => ""
        ),
        array(
            'id'        => "{$prefix}property_price_postfix",
            'name'      => __('Texto Pós-Preço','framework'),
            'desc'      => __('Texto fornecido aqui será apresentada depois de preço. (Você também pode deixá-lo vazio) Exemplo: Por Mês','framework'),
            'type'      => 'text',
            'std'       => ""
        ),
        array(
            'id'        => "{$prefix}property_size",
            'name'      => __('Tamanho da Propriedade','framework'),
            'desc'      => __('Só fornecer dígitos Exemplo: 2500','framework'),
            'type'      => 'text',
            'std'       => ""
        ),
        array(
            'id'        => "{$prefix}property_size_postfix",
            'name'      => __('Texto Pós-Tamanho','framework'),
            'desc'      => __('Texto fornecido aqui será apresentada depois do tamanho. Exemplo: M²','framework'),
            'type'      => 'text',
            'std'       => ""
        ),
        array(
            'id'        => "{$prefix}property_bedrooms",
            'name'      => __('Quartos','framework'),
            'desc'      => __('Fornecer número de quartos. Exemplo: 4','framework'),
            'type'      => 'text',
            'std'       => ""
        ),
        array(
            'id'        => "{$prefix}property_bathrooms",
            'name'      => __('Banheiros','framework'),
            'desc'      => __('Fornecer o número de banheiros. Exemplo: 2','framework'),
            'type'      => 'text',
            'std'       => ""
        ),
        array(
            'id'        => "{$prefix}property_garage",
            'name'      => __('Garagem','framework'),
            'desc'      => __('Fornecer número de garagens ou vagas. Exemplo Valor: 1','framework'),
            'type'      => 'text',
            'std'       => ""
        ),
        array(
            'id'        => "{$prefix}property_id",
            'name'      => __('Código do Imóvel','framework'),
            'desc'      => __('Texto fornecido aqui será usado para procurar o imóvel diretamente. (Você também pode deixá-lo vazio)','framework'),
            'type'      => 'text',
            'std'       => ""
        ),
        array(
            'id'        => "{$prefix}property_address",
            'name'      => __('Endereço do Imóvel','framework'),
            'desc'      => __('Forneça endereço do imóvel.','framework'),
            'type'      => 'text',
            'std'       => 'Rua Santo Antonio 66 centro Juiz de Fora'
        ),
        array(
            'id'            => "{$prefix}property_location",
            'name'          => __('Localização do Imovel no Mapa','framework'),
            'desc'          => __('Arraste o marcador de mapa google para apontar o seu local de estabelecimento. Você também pode usar o campo de endereço acima para procurar o seu imóvel.','framework'),
            'type'          => 'map',
            'std'           => '26.011812,-80.14524499999999,15',   // 'latitude,longitude[,zoom]' (zoom is optional)
            'style'         => 'width: 600px; height: 400px',
            'address_field' => "{$prefix}property_address",         // Name of text field where address is entered. Can be list of text fields, separated by commas (for ex. city, state)
        ),
        array(
            'id'        => "{$prefix}tour_video_url",
            'name'      => __('Virtual Tour Video URL','framework'),
            'desc'      => __('Fornecer virtual URL do vídeo tour. Tema suporta YouTube, Vimeo, arquivo SWF e MOV Arquivo','framework'),
            'type'      => 'text'
        ),
        array(
            'name'      => __('Tour Virtual Vídeo Imagem','framework'),
            'id'        => "{$prefix}tour_video_image",
            'desc'      => __('Fornecer a imagem que será exibido como suporte do lugar e quando um usuário clica sobre ele o vídeo será aberto em uma mesa de luz. Você deve fornecer essa imagem como caso contrário, o vídeo não será exibido na página de detalhes de propriedade. Imagem deve ter largura mínima de 818px e 417px de altura mínima. Imagens em tamanho maior será cortada automaticamente.','framework'),
            'type'      => 'image_advanced',
            'max_file_uploads' => 1
        ),
        array(
            'name'	    => __('Marcar imóvel como Destaque?', 'framework'),
            'desc'      => __('Marcando imóvel como destaque vai exibi-lo em seções propriedades existentes em todo o site.', 'framework'),
            'id'		=> "{$prefix}featured",
            'type'		=> 'checkbox',
            'std'		=> 1
        ),
        array(
            'name'      => __( 'Adicionar no Banner Principal?', 'framework' ),
            'desc'      => __('Você quer adicionar este imóvel no Banner Principal, então você também precisará fornecer uma imagem abaixo.', 'framework'),
            'id'        => "{$prefix}add_in_slider",
            'type'      => 'radio',
            'std'       => 'no',
            'options' => array(
                'yes' => __( 'Sim ', 'framework' ),
                'no' => __( 'Não', 'framework' )
            )
        ),
        array(
            'name'      => __('Banner Pricipal imagem','framework'),
            'id'        => "{$prefix}slider_image",
            'desc'      => __('Fornecer a imagem que será exibido no Banner Principal. O tamanho da imagem recomendada é de 2000px por 700px. Você pode usar a imagem maior ou pouco menor, mas tente manter a mesma altura a relação largura e usar exatamente os mesmos imagens de tamanho para todos os imóveis que irão para o Banner Principal.','framework'),
            'type'      => 'image_advanced',
            'max_file_uploads' => 1
        ),
        array(
            'name'      => __( 'Exibir a caixa de informações do Consultor?', 'framework' ),
            'desc'      => __('Selecione um Consultor na caixa de seleção abaixo, obviamente se escolheu exibir informações de um consultor', 'framework'),
            'id'        => "{$prefix}agent_display_option",
            'type'      => 'radio',
            'std'       => 'none',
            'options' => array(
                'none' => __( 'Não exibir', 'framework' ),
                'my_profile_info' => __( 'Informação do Autor', 'framework' ),
                'agent_info' => __( 'Informação do Consultor', 'framework' )
            )
        ),
        /* Agents */
        array(
            'name'    => __( 'Consultor', 'framework' ),
            'id'      => "{$prefix}agents",
            'desc'      => __('Selecione um Consultor.','framework'),
            'type' => 'select',
            'options' => $agents_array
        ),
        array(
            'id'        => "{$prefix}attachments",
            'name'      => __('Anexos','framework'),
            'desc'      => __('Você pode anexar arquivos PDF, Mapa imagens ou outros documentos a fornecer mais pormenores relativos à propriedade.','framework'),
            'type'      => 'file_advanced',
            'mime_type' => ''
        ),
        array(
            'id'        => "{$prefix}property_private_note",
            'name'      => __( 'Nota Pessoal', 'framework' ),
            'desc'      => __( 'Neste textarea, você pode escrever sua nota confidencial sobre esta propriedade. Este campo não será exibido em qualquer outro lugar.', 'framework' ),
            'type'      => 'textarea',
            'std'       => ""
        )
    )
);


// Partners Meta Box
$meta_boxes[] = array(
    // Meta box id, UNIQUE per meta box. Optional since 4.1.5
    'id' => 'partners-meta-box',

    // Meta box title - Will appear at the drag and drop handle bar. Required.
    'title' => __('Featured Patners Meta','framework'),

    // Post types, accept custom post types as well - DEFAULT is array('post'). Optional.
    'pages' => array( 'partners' ),

    // Where the meta box appear: normal (default), advanced, side. Optional.
    'context' => 'normal',

    // Order of meta box: high (default), low. Optional.
    'priority' => 'high',

    // List of meta fields
    'fields' => array(
        array(
            'name'             => __('Url do Parceiro','framework'),
            'id'               => "{$prefix}partner_url",
            'desc' => __('Cole o link do site do parceiro','framework'),
            'type'             => 'text',
        )
    )
);




// Agent Meta Box
$meta_boxes[] = array(
    // Meta box id, UNIQUE per meta box. Optional since 4.1.5
    'id' => 'agent-meta-box',

    // Meta box title - Will appear at the drag and drop handle bar. Required.
    'title' => __('Fornecer Informações relacionadas','framework'),

    // Post types, accept custom post types as well - DEFAULT is array('post'). Optional.
    'pages' => array( 'agent' ),

    // Where the meta box appear: normal (default), advanced, side. Optional.
    'context' => 'normal',

    // Order of meta box: high (default), low. Optional.
    'priority' => 'expressa',

    // List of meta fields
    'fields' => array(
        array(
            'name'      => __('Endereço de e-mail','framework'),
            'id'        => "{$prefix}agent_email",
            'desc'      => __("Fornecer do consultor e-mail.","framework"),
            'type'      => 'text'
        ),
        array(
            'name'      => __('Número de Telefone','framework'),
            'id'        => "{$prefix}mobile_number",
            'desc'      => __("Fornecer número de celular do Consultor","framework"),
            'type'      => 'text'
        ),
        array(
            'name'      => __('Número do Escritório','framework'),
            'id'        => "{$prefix}office_number",
            'desc'      => __("Fornecer número do Escritório","framework"),
            'type'      => 'text'
        ),
        array(
            'name'      => __('Número de Fax','framework'),
            'id'        => "{$prefix}fax_number",
            'desc'      => __("Fornecer Número de Fax","framework"),
            'type'      => 'text'
        ),
        array(
            'name'      => __('Facebook URL','framework'),
            'id'        => "{$prefix}facebook_url",
            'desc'      => __("Fornecer link do Perfil do Consultor","framework"),
            'type'      => 'text'
        ),
        array(
            'name'      => __('Twitter URL','framework'),
            'id'        => "{$prefix}twitter_url",
            'desc'      => __("Fornecer link do Perfil do Consultor","framework"),
            'type'      => 'text'
        ),
        array(
            'name'      => __('Google Plus URL','framework'),
            'id'        => "{$prefix}google_plus_url",
            'desc'      => __("Fornecer link do Perfil do Consultor","framework"),
            'type'      => 'text'
        ),
        array(
            'name'      => __('LinkedIn URL','framework'),
            'id'        => "{$prefix}linked_in_url",
            'desc'      => __("Fornecer link do Perfil do Consultor","framework"),
            'type'      => 'text'
        )
    )
);


// Banner Meta Box
$meta_boxes[] = array(
    // Meta box id, UNIQUE per meta box. Optional since 4.1.5
    'id' => 'banner-meta-box',

    // Meta box title - Will appear at the drag and drop handle bar. Required.
    'title' => __('Configurações do Banner Principal','framework'),

    // Post types, accept custom post types as well - DEFAULT is array('post'). Optional.
    'pages' => array( 'page','agent' ),

    // Where the meta box appear: normal (default), advanced, side. Optional.
    'context' => 'normal',

    // Order of meta box: high (default), low. Optional.
    'priority' => 'default',

    // List of meta fields
    'fields' => array(
        array(
            'name'      => __('Título do Banner','framework'),
            'id'        => "{$prefix}banner_title",
            'desc'      => __('Por favor, forneça o Título do Banner, Caso contrário, o título da página será exibida em seu lugar.','framework'),
            'type'      => 'text'
        ),
        array(
            'name'      => __('Banner Sub Título','framework'),
            'id'        => "{$prefix}banner_sub_title",
            'desc'      => __('Por favor, forneça o Sub Título','framework'),
            'type'      => 'textarea',
            'cols'      => '20',
            'rows'      => '2'
        ),
        array(
            'name'      => __('Banner Imagem','framework'),
            'id'        => "{$prefix}page_banner_image",
            'desc'      => __('Por favor envie a imagem do Banner. Caso contrário, a imagem do banner padrão de opções do site será exibido.','framework'),
            'type'      => 'image_advanced',
            'max_file_uploads' => 1
        ),
        array(
            'name'      => __('- Banner Principal -','framework'),
            'id'        => "{$prefix}rev_slider_alias",
            'desc'      => __('Selecione a imagem do Banner.','framework'),
            'type'      => 'text'
        )
    )
);

// Property Banner Meta Box
$meta_boxes[] = array(
    // Meta box id, UNIQUE per meta box. Optional since 4.1.5
    'id' => 'property-banner-meta-box',

    // Meta box title - Will appear at the drag and drop handle bar. Required.
    'title' => __('Banner Principal','framework'),

    // Post types, accept custom post types as well - DEFAULT is array('post'). Optional.
    'pages' => array( 'property' ),

    // Where the meta box appear: normal (default), advanced, side. Optional.
    'context' => 'normal',

    // Order of meta box: high (default), low. Optional.
    'priority' => 'default',

    // List of meta fields
    'fields' => array(
        array(
            'name'      => __('Banner Imagem','framework'),
            'id'        => "{$prefix}page_banner_image",
            'desc'      => __('Por favor envie a imagem do Banner. Caso contrário, a imagem do banner padrão de opções de tema será exibida.','framework'),
            'type'      => 'image_advanced',
            'max_file_uploads' => 1
        )
    )
);

// Page title show or hide
$meta_boxes[] = array(
    'id' => 'page-title-meta-box',
    'title' => __('Título da Página','framework'),
    'pages' => array( 'page' ),
    'context' => 'normal',
    'priority' => 'default',
    'fields' => array(
        array (
            'name'      => __('Título da página de status de exibição','framework'),
            'id'        => "{$prefix}page_title_display",
            'type'      => 'radio',
            'std'       => 'show',
            'options'   => array (
                'show' => __( 'Mostrar', 'framework' ),
                'hide' => __( 'Ocultar', 'framework' )
            )
        )
    )
);


/********************* META BOX REGISTERING ***********************/

/**
 * Register meta boxes
 *
 * @return void
 */
function REAL_HOMES_register_meta_boxes()
{
    // Make sure there's no errors when the plugin is deactivated or during upgrade
    if ( !class_exists( 'RW_Meta_Box' ) )
        return;

    global $meta_boxes;
    $meta_boxes = apply_filters('framework_theme_meta',$meta_boxes);
    foreach ( $meta_boxes as $meta_box ){
        new RW_Meta_Box( $meta_box );
    }
}
// Hook to 'admin_init' to make sure the meta box class is loaded before
// (in case using the meta box class in another plugin)
// This is also helpful for some conditionals like checking page template, categories, etc.
add_action( 'admin_init', 'REAL_HOMES_register_meta_boxes' );

?>