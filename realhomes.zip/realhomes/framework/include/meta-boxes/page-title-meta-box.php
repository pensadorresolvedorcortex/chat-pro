<?php
if ( 'ultra' === INSPIRY_DESIGN_VARIATION ) {
	$tabs['page_head_content'] = array(
		'label' => esc_html__( 'Page Head Content', RH_TEXT_DOMAIN ),
		'icon'  => 'dashicons-welcome-write-blog',
	);

	$fields[] = array(
		'name'    => esc_html__( 'Content Display', RH_TEXT_DOMAIN ),
		'id'      => 'realhomes_page_head_content',
		'type'    => 'radio',
		'std'     => 'show',
		'options' => array(
			'show' => esc_html__( 'Show', RH_TEXT_DOMAIN ),
			'hide' => esc_html__( 'Hide', RH_TEXT_DOMAIN ),
		),
		'tab'     => 'page_head_content',
	);
	$fields[] = array(
		'name'    => esc_html__( 'Page Title', RH_TEXT_DOMAIN ),
		'id'      => 'realhomes_page_title',
		'type'    => 'text',
		'visible' => array( 'realhomes_page_head_content', '=', 'show' ),
		'columns' => 6,
		'tab'     => 'page_head_content',
	);
	$fields[] = array(
		'name'    => esc_html__( 'Page Description', RH_TEXT_DOMAIN ),
		'id'      => 'realhomes_page_description',
		'type'    => 'text',
		'visible' => array( 'realhomes_page_head_content', '=', 'show' ),
		'columns' => 6,
		'tab'     => 'page_head_content',
	);

} else {
	$tabs['page_title_tab'] = array(
		'label' => esc_html__( 'Page Title', RH_TEXT_DOMAIN ),
		'icon'  => 'dashicons-welcome-write-blog',
	);

	$fields[] = array(
		'name'    => esc_html__( 'Page Title Display Status', RH_TEXT_DOMAIN ),
		'id'      => 'REAL_HOMES_page_title_display',
		'type'    => 'radio',
		'std'     => 'show',
		'options' => array(
			'show' => esc_html__( 'Show', RH_TEXT_DOMAIN ),
			'hide' => esc_html__( 'Hide', RH_TEXT_DOMAIN ),
		),
		'tab'     => 'page_title_tab',
	);
}