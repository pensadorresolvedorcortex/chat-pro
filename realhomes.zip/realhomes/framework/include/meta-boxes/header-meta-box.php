<?php
$tabs['custom_header'] = array(
	'label' => esc_html__( 'Header', RH_TEXT_DOMAIN ),
	'icon'  => 'dashicons-admin-settings',
);

$fields[] = array(
	'name'    => esc_html__( 'Select Template For Custom Header', RH_TEXT_DOMAIN ),
	'id'      => 'REAL_HOMES_custom_header_display',
	'type'    => 'select',
	'std'     => 'default',
	'options' => realhomes_get_elementor_library(),
	'columns' => 6,
	'tab'     => 'custom_header',
);
$fields[] = array(
	'name'    => esc_html__( 'Custom Header Position', RH_TEXT_DOMAIN ),
	'id'      => 'REAL_HOMES_custom_header_position',
	'type'    => 'radio',
	'std'     => 'relative',
	'options' => array(
		'relative' => esc_html__( 'Relative', RH_TEXT_DOMAIN ),
		'absolute' => esc_html__( 'Absolute', RH_TEXT_DOMAIN ),
	),
	'tab'     => 'custom_header',
);