<?php
if ( 'ultra' !== INSPIRY_DESIGN_VARIATION ) {
	$tabs['banner'] = array(
		'label' => esc_html__( 'Banner', RH_TEXT_DOMAIN ),
		'icon'  => 'dashicons-flag',
	);
}

if ( 'classic' === INSPIRY_DESIGN_VARIATION ) {
	$fields[] = array(
		'name'             => esc_html__( 'Banner Image', RH_TEXT_DOMAIN ),
		'id'               => 'REAL_HOMES_page_banner_image',
		'desc'             => esc_html__( 'Please upload the Banner Image. Otherwise the default banner image from theme options will be displayed.', RH_TEXT_DOMAIN ),
		'type'             => 'image_advanced',
		'max_file_uploads' => 1,
		'tab'              => 'banner',
	);
	$fields[] = array(
		'name'    => esc_html__( 'Banner Title and Sub Title Display Status', RH_TEXT_DOMAIN ),
		'id'      => 'REAL_HOMES_banner_title_display',
		'type'    => 'radio',
		'std'     => 'show',
		'options' => array(
			'show' => esc_html__( 'Show', RH_TEXT_DOMAIN ),
			'hide' => esc_html__( 'Hide', RH_TEXT_DOMAIN ),
		),
		'tab'     => 'banner',
	);
	$fields[] = array(
		'name'    => esc_html__( 'Banner Title', RH_TEXT_DOMAIN ),
		'id'      => 'REAL_HOMES_banner_title',
		'desc'    => esc_html__( 'Please provide the Banner Title, Otherwise the Page Title will be displayed in its place.', RH_TEXT_DOMAIN ),
		'type'    => 'text',
		'columns' => 6,
		'tab'     => 'banner',
	);
	$fields[] = array(
		'name'    => esc_html__( 'Banner Sub Title', RH_TEXT_DOMAIN ),
		'id'      => 'REAL_HOMES_banner_sub_title',
		'desc'    => esc_html__( 'Please provide the Banner Sub Title.', RH_TEXT_DOMAIN ),
		'type'    => 'textarea',
		'cols'    => '20',
		'rows'    => '2',
		'columns' => 6,
		'tab'     => 'banner',
	);
	$fields[] = array(
		'name'    => esc_html__( 'Revolution Slider Alias', RH_TEXT_DOMAIN ),
		'id'      => 'REAL_HOMES_rev_slider_alias',
		'desc'    => esc_html__( 'If you want to replace banner with revolution slider then provide its alias here.', RH_TEXT_DOMAIN ),
		'type'    => 'text',
		'columns' => 6,
		'tab'     => 'banner',
	);

} else if ( 'modern' === INSPIRY_DESIGN_VARIATION ) {
	$fields[] = array(
		'name'             => esc_html__( 'Banner Image', RH_TEXT_DOMAIN ),
		'id'               => 'REAL_HOMES_page_banner_image',
		'desc'             => esc_html__( 'Please upload the Banner Image. Otherwise the default banner image from theme options will be displayed.', RH_TEXT_DOMAIN ),
		'type'             => 'image_advanced',
		'max_file_uploads' => 1,
		'tab'              => 'banner',
	);
	$fields[] = array(
		'name'    => esc_html__( 'Banner Title Display Status', RH_TEXT_DOMAIN ),
		'id'      => 'REAL_HOMES_banner_title_display',
		'type'    => 'radio',
		'std'     => 'show',
		'options' => array(
			'show' => esc_html__( 'Show', RH_TEXT_DOMAIN ),
			'hide' => esc_html__( 'Hide', RH_TEXT_DOMAIN ),
		),
		'tab'     => 'banner',
	);
	$fields[] = array(
		'name'    => esc_html__( 'Banner Title', RH_TEXT_DOMAIN ),
		'id'      => 'REAL_HOMES_banner_title',
		'desc'    => esc_html__( 'Please provide the Banner Title, Otherwise the Page Title will be displayed in its place.', RH_TEXT_DOMAIN ),
		'type'    => 'text',
		'columns' => 6,
		'tab'     => 'banner',
	);
	$fields[] = array(
		'name'    => esc_html__( 'Revolution Slider Alias', RH_TEXT_DOMAIN ),
		'id'      => 'REAL_HOMES_rev_slider_alias',
		'desc'    => esc_html__( 'If you want to replace banner with revolution slider then provide its alias here.', RH_TEXT_DOMAIN ),
		'type'    => 'text',
		'columns' => 6,
		'tab'     => 'banner',
	);
}