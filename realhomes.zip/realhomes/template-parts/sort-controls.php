<div class="sort-controls">
    <strong><?php _e('Filtrar','framework');?>:</strong>
    &nbsp;
    <select name="sort-properties" id="sort-properties">
        <option value="default"><?php _e('Relevantes','framework');?></option>
        <option value="price-asc" <?php echo ( isset($_GET['sortby']) && ($_GET['sortby']=='price-asc') )?'selected':''; ?>><?php _e('Preço Menor para Maior','framework');?></option>
        <option value="price-desc" <?php echo ( isset($_GET['sortby']) && ($_GET['sortby']=='price-desc') )?'selected':''; ?>><?php _e('Preço Maior para Menor','framework');?></option>
        <option value="date-asc" <?php echo ( isset($_GET['sortby']) && ($_GET['sortby']=='date-asc') )?'selected':''; ?>><?php _e('Mais Recentes','framework');?></option>
        <option value="date-desc" <?php echo ( isset($_GET['sortby']) && ($_GET['sortby']=='date-desc') )?'selected':''; ?>><?php _e('Mais Antigos','framework');?></option>
    </select>
</div>