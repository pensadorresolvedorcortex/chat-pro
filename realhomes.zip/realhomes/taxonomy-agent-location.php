<?php
/**
 * Taxonomy: Agent Location
 *
 * @since   4.0.0
 * @package realhomes
 */

get_template_part( 'assets/' . INSPIRY_DESIGN_VARIATION . '/partials/agent/taxonomy/agent-location' );
