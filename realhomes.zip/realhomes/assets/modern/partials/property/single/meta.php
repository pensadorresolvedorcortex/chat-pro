<?php
/**
 * Property meta of single property template.
 *
 * @package    realhomes
 * @subpackage modern
 */

global $post;
$property_id      = get_the_ID();
$post_meta_data   = get_post_custom( $property_id );
$size_postfix     = realhomes_get_area_unit( $property_id );
$lot_size_postfix = realhomes_get_lot_unit( $property_id );

// Meta config
$meta_fields = [
	'REAL_HOMES_property_bedrooms'   => ['inspiry_bedrooms_field_label', 'Bedrooms', '/images/icons/icon-bed.svg'],
	'REAL_HOMES_property_bathrooms'  => ['inspiry_bathrooms_field_label', 'Bathrooms', '/images/icons/icon-shower.svg'],
	'REAL_HOMES_property_garage'     => ['inspiry_garages_field_label', 'Garage', '/images/icons/icon-garage.svg'],
	'REAL_HOMES_property_year_built' => ['inspiry_year_built_field_label', 'Year Built', '/images/icons/icon-calendar.svg'],
	'REAL_HOMES_property_size'       => ['inspiry_area_field_label', 'Area', '/images/icons/icon-area.svg', $size_postfix],
	'REAL_HOMES_property_lot_size'   => ['inspiry_lot_size_field_label', 'Lot Size', '/images/icons/icon-lot.svg', $lot_size_postfix],
];

// Add RVR fields if enabled
if ( inspiry_is_rvr_enabled() ) {
	$meta_fields += [
		'rvr_guests_capacity' => ['inspiry_rvr_guests_field_label', 'Capacity', 'images/guests-icons.svg'],
		'rvr_min_stay'        => ['inspiry_rvr_min_stay_label', 'Min Stay', '/images/icons/icon-min-stay.svg'],
	];
}

// Reusable meta renderer
function realhomes_render_property_meta_field( $meta_key, $meta_value, $label_option, $default_label, $icon_path, $postfix = '' ) {
	if ( empty( $meta_value ) ) {
		return;
	}

	$label = get_option( $label_option );
	$label = ! empty( $label ) ? esc_html( $label ) : esc_html__( $default_label, RH_TEXT_DOMAIN );
	?>
    <div class="rh_property__meta prop_<?php echo esc_attr( str_replace( 'REAL_HOMES_property_', '', $meta_key ) ); ?>">
        <span class="rh_meta_titles"><?php echo $label; ?></span>
        <div>
	        <?php
	        if ( 'rvr_guests_capacity' === $meta_key ) {
		        realhomes_property_meta_icon( $meta_key, $icon_path, '/common/' );
	        } else {
		        realhomes_property_meta_icon( $meta_key, $icon_path );
	        }
	        ?>
            <span class="figure"><?php echo esc_html( $meta_value ); ?></span>
			<?php if ( ! empty( $postfix ) ) : ?>
                <span class="label"><?php echo esc_html( $postfix ); ?></span>
			<?php endif; ?>
        </div>
    </div>
	<?php
}
?>
<div class="rh_property__row rh_property__meta_wrap">
	<?php
	foreach ( $meta_fields as $meta_key => $config ) {
		$label_option  = $config[0];
		$default_label = $config[1];
		$icon_path     = $config[2];
		$postfix       = $config[3] ?? '';
		$meta_value    = $post_meta_data[ $meta_key ][0] ?? '';

		realhomes_render_property_meta_field( $meta_key, $meta_value, $label_option, $default_label, $icon_path, $postfix );
	}

	/**
	 * This hook can be used to display more property meta fields
	 */
	do_action( 'inspiry_additional_property_meta_fields', $property_id );

	/**
	 * Custom property fields
	 */
	if ( is_singular( 'property' ) ) {
		$custom_fields  = apply_filters(
			'inspiry_property_custom_fields', array(
				array(
					'tab'    => array(),
					'fields' => array(),
				),
			)
		);

		if ( isset( $custom_fields['fields'] ) && ! empty( $custom_fields['fields'] ) ) {
			$prefix    = 'REAL_HOMES_';
			$icons_dir = INSPIRY_THEME_DIR . '/icons/';
			$icons_uri = INSPIRY_DIR_URI . '/icons/';

			foreach ( $custom_fields['fields'] as $field ) {
				if ( isset( $field['display'] ) && true === $field['display'] ) {

					$meta_key = $prefix . inspiry_backend_safe_string( $field['id'] );

					if ( isset( $post_meta_data[ $meta_key ] ) && ! empty( $post_meta_data[ $meta_key ][0] ) ) {

						$field_label = ( ! empty( $field['postfix'] ) ) ? $field['postfix'] : '';
						?>
                        <div class="rh_property__meta <?php echo esc_attr( $meta_key ); ?>">
                            <span class="rh_meta_titles"><?php echo esc_html( $field['name'] ); ?></span>
                            <div>
								<?php
								if ( file_exists( $icons_dir . $field['icon'] . '.png' ) ) {

									$data_rjs = ( file_exists( $icons_dir . $field['icon'] . '@2x.png' ) ) ? '2' : '';

									echo '<img src="' . esc_url( $icons_uri . $field['icon'] ) . '.png" alt="icon" data-rjs="' . esc_attr( $data_rjs ) . '">';
								}
								?>

                                <span class="figure">
									<?php echo esc_html( $post_meta_data[ $meta_key ][0] ); ?>
								</span>
								<?php if ( ! empty( $field_label ) ) : ?>
                                    <span class="label">
										<?php echo esc_html( $field_label ); ?>
									</span>
								<?php endif; ?>
                            </div>
                        </div>
						<?php
					}
				}
			}
		}
	}
	?>
</div>
