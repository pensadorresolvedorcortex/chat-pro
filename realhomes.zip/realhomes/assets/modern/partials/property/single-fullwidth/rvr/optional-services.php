<?php
/**
 * Property optional services of single property.
 *
 * @package    realhomes
 * @subpackage modern
 */
if ( inspiry_is_rvr_enabled() && 'true' === get_option( 'realhomes_rvr_services', 'true' ) ) {
	?>
    <div class="features-content-wrapper single-property-section <?php realhomes_printable_section( 'rvr/optional-services' ); ?>">
        <div class="container">
            <?php get_template_part( 'assets/modern/partials/property/single/rvr/optional-services' ); ?>
        </div>
    </div>
	<?php
}