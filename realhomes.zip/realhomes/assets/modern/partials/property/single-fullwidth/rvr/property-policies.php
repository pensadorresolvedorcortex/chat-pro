<?php
/**
 * Property policies of single property.
 *
 * @package    realhomes
 * @subpackage modern
 */
if ( inspiry_is_rvr_enabled() && 'true' === get_option( 'realhomes_rvr_property_policies', 'true' ) ) {
	?>
    <div class="features-content-wrapper single-property-section <?php realhomes_printable_section( 'rvr/property-policies' ); ?>">
        <div class="container">
            <?php get_template_part( 'assets/modern/partials/property/single/rvr/property-policies' ); ?>
        </div>
    </div>
	<?php
}