<?php
/**
 * Sort Controls
 *
 * Properties sort controls.
 *
 * @since       3.0.0
 * @package     realhomes
 * @subpackage  modern
 */

realhomes_generate_sort_control_option( array(
	'select_classes' => 'inspiry_bs_default_mod inspiry_bs_listing inspiry_bs_green',
	'show_title'     => false
) );
?>