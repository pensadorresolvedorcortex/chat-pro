<div class="rh_added_sty">
	<?php
	?>
    <span><?php esc_html_e( 'Added: ', RH_TEXT_DOMAIN ); ?></span>
	<?php
	$inspiry_property_date_format = get_option( 'inspiry_property_date_format', 'dashboard' );
	if ( 'dashboard' === $inspiry_property_date_format || ( is_array( $inspiry_property_date_format ) && in_array( 'dashboard', $inspiry_property_date_format ) ) ) {
		the_date();
	} else {
		echo human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ) );
		echo ' ' . esc_html__( 'Ago ', RH_TEXT_DOMAIN );
	}
	?>
</div>