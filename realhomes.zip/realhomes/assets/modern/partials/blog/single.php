<?php
/**
 * Single Blog Post
 *
 * @package    realhomes
 * @subpackage modern
 */

get_header();

get_template_part( 'assets/modern/partials/blog/post/single-contents' );

get_footer();
