<?php
/**
 * Containing dynamic css gallery style options
 *
 * @since      4.4.0
 * @package    realhomes
 * @subpackage modern
 */

$gallery_styles_keys = array(
	'inspiry_gallery_hover_color'
);

$gallery_style_options = realhomes_get_options( $gallery_styles_keys );

$gallery_hover_color = $gallery_style_options['inspiry_gallery_hover_color'];
$gallery_hover_color = inspiry_hex_to_rgba( $gallery_hover_color, 0.9 );

return array(
	array(
		'elements' => '.rh_gallery__wrap .rh_gallery__item .media_container',
		'property' => 'background',
		'value'    => $gallery_hover_color,
	)
);