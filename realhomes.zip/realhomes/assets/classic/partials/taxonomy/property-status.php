<?php
/**
 * Taxonomy: Property Status
 *
 * @package realhomes
 * @subpackage classic
 */

// Use Common Taxonomy Template.
get_template_part( 'assets/classic/partials/taxonomy/common' );
