<?php
/**
 * Views count for property listing
 *
 * @since 4.4.2
 *
 * @package realhomes
 * @subpackages classic
 */

realhomes_display_property_views_counter( get_the_ID() );