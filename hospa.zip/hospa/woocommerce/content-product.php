<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 9.4.0
 */

defined( 'ABSPATH' ) || exit;

global $product;
global $hospa_opt;

$product_sidebar    = isset( $hospa_opt['product_sidebar']) ? $hospa_opt['product_sidebar'] : '';

$rating_count = $product->get_rating_count();
$review_count = $product->get_review_count();
$average      = $product->get_average_rating();
$terms = get_the_terms( get_the_ID() , 'product_cat' );

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
} ?>
<li <?php wc_product_class( '', $product ); ?>>
    <div class="shop-item">
        <div class="shop-image">
            <a href="<?php the_permalink(); ?>">
                <?php the_post_thumbnail( 'hospa_standard_card' ); ?>
            </a>

            <?php if($product->is_on_sale()): ?>
                <div class="off"><?php esc_html_e( 'Sale', 'hospa' ); ?></div>
            <?php endif; ?>
        </div>
        <div class="shop-content">
            <div class="top">
        
                <?php 
                if ( is_array( $terms ) && ! is_wp_error( $terms ) ) { ?>
                    <a href="<?php echo esc_url( get_category_link( $terms[0]->term_id ) ); ?>"><?php echo esc_html($terms[0]->name); ?></a>
                <?php } ?>
                <?php if( $rating_count == 0 ){?>
                    <div class="rating">
                        <i class="ti ti-star-filled"></i>
                        <span><?php esc_html_e('(0)', 'hospa'); ?></span>
                    </div>
                <?php } else{ ?>
                    <div class="rating">
                        <i class="ti ti-star-filled"></i>
                        <?php esc_html_e('(', 'hospa'); ?><?php echo esc_html($average); ?><?php esc_html_e(')', 'hospa'); ?>
                    </div>
                <?php } ?>
            </div>
            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

            <div class="price">
                <?php woocommerce_template_loop_price(); ?>
            </div>
        </div>
        <div class="shop-hover-content">
            <div class="top">
                <?php 
                if ( is_array( $terms ) && ! is_wp_error( $terms ) ) { ?>
                    <a href="<?php echo esc_url( get_category_link( $terms[0]->term_id ) ); ?>"><?php echo esc_html($terms[0]->name); ?></a>
                <?php } ?>
                
                <?php if( $rating_count == 0 ){?>
                    <div class="rating">
                        <i class="ti ti-star-filled"></i>
                        <span><?php esc_html_e('(0)', 'hospa'); ?></span>
                    </div>
                <?php } else{ ?>
                    <div class="rating">
                        <i class="ti ti-star-filled"></i>
                        <?php echo esc_html($average); ?>
                    </div>
                <?php } ?>

            </div>
            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
            <div class="price">
                <?php woocommerce_template_loop_price(); ?>
            </div>
            <?php woocommerce_template_loop_add_to_cart(); ?>
        </div>
    </div>
</li>