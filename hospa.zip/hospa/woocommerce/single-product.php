<?php
/**
 * The Template for displaying all single products
 *
 * This template can be overridden by copying it to hospa/woocommerce/single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */
global $hospa_opt;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_header( 'shop' );
if ( class_exists( 'Header_Footer_Elementor' ) ) { 
    hospa_preloader();
}

include get_template_directory() . '/inc/banner/product-single-header.php';

remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
?>

<?php if( $hide_banner == false ) { ?>
    <div class="page-banner-area">
        <div class="container-fluid">
            <?php if( $enable_pb_img == false ): ?>
                <?php if( $banner_image != '' ): ?>
                    <div class="page-banner-image">
                        <img src="<?php echo esc_url( $banner_image ); ?>" alt="<?php esc_attr_e( 'banner img', 'hospa' ); ?>">
                    </div>
                    <div class="page-banner-inner">
                <?php else: ?>
                    <div class="page-banner-inner without-image">
                <?php endif; ?>
            <?php else: ?>
                <div class="page-banner-inner without-image">
            <?php endif; ?>
                <div class="row justify-content-center align-items-center">
                    <div class="col-lg-8 col-md-12">
                        <div class="content">
                            <?php if( $custom_title == true && get_field( 'cus_pagetitle' ) != '' ) { ?>
                                <<?php echo esc_attr( $tag ); ?>>
                                    <?php echo wp_kses( get_field( 'cus_pagetitle' ), 'hospaallowedhtml' ); ?>
                                </<?php echo esc_attr( $tag ); ?>>
                            <?php } else { ?>
                                <<?php echo esc_attr( $tag ); ?>><?php the_title(); ?> </<?php echo esc_attr( $tag ); ?>>
                            <?php } ?>

                            <?php if( $hide_breadcrumb == false ) : ?>
                                <?php if ( function_exists('yoast_breadcrumb') ) {
                                    yoast_breadcrumb( '<p class="hospa-seo-breadcrumbs" id="breadcrumbs">','</p>' );
                                } else { ?>
                                <ul class="list">
                                    <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'hospa' ); ?></a></li>
                                    <li><?php the_title(); ?></li>
                                </ul>
                            <?php } endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-md-12">
                        <ul class="information">
                            <?php if($custom_desc != ' ' || $phn_num != ' '): ?>
                                <li>
                                    <div class="phone-btn">

                                        <?php if($header_phnicon != ' '): ?>
                                        <div class="icon">
                                            <i class="<?php echo esc_attr($header_phnicon); ?>"></i>
                                        </div>
                                        <?php endif; ?>
                                        <span>
                                            <?php echo wp_kses( $custom_desc, 'hospaallowedhtml' ); ?>

                                            <?php if($phn_num_link != ''): ?>
                                            <a href="<?php echo esc_url($phn_num_link); ?>">
                                            <?php endif; ?>
                                                
                                                <?php echo  esc_html($phn_num); ?>
                                                
                                            <?php if($phn_num_link != ''): ?>
                                            </a>
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                </li>
                            <?php endif; ?>

                            <?php if( $hide_banner_meta == false ) : ?>
                            <li>
                                <ul class="info-list">
                                    <li>
                                        <button onclick="window.print()">
                                            <i class="ti ti-printer"></i>
                                        </button>
                                    </li>
                                
                                    <?php if($page_mail_link != ' '): ?>
                                        <li>
                                            <a href="<?php echo esc_url($page_mail_link); ?>"><i class="ti ti-mail-opened"></i></a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if( $is_social_share == '1' ):
                                        $share_url      = get_the_permalink();
                                        $share_title    = get_the_title();
                                        $share_desc     = get_the_excerpt();
                                    ?>
                                    <li>
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="ti ti-share"></i>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <?php if( $hospa_opt['enable_product_fb'] == '1' ): ?>
                                                    <li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url($share_url); ?>" onclick="window.open(this.href, 'facebook-share','width=580,height=296'); return false;" target="_blank"><i class="ti ti-brand-facebook"></i></a></li>
                                                <?php endif; ?>

                                                <?php if( $hospa_opt['enable_product_tw'] == '1' ): ?>
                                                    <li><a href="https://twitter.com/share?text=<?php echo urlencode($share_title); ?>&url=<?php echo esc_url($share_url); ?>" target="_blank"><i class="ti ti-brand-x"></i></a></li>
                                                <?php endif; ?>

                                                <?php if( $hospa_opt['enable_product_ld'] == '1' ): ?>
                                                    <li><a href="https://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo esc_url($share_url); ?>&amp;title=<?php echo urlencode($share_title); ?>&amp;summary=&amp;source=<?php bloginfo('name'); ?>" onclick="window.open(this.href, 'linkedin','width=580,height=296'); return false;" target="_blank"><i class="ti ti-brand-linkedin"></i></a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>

<div class="products_details product-details-area pb-100">
    <div class="container-fluid">
        <div class="row">                
            <?php if ( is_active_sidebar( 'shop' ) ): ?>
                <?php if ( isset( $_GET['shop'] ) ): ?>
                    <?php  $hospa_shop_cat_sidebar = $_GET['shop']; ?>
                    <?php if ( $hospa_shop_cat_sidebar == 'none' ): ?>
                        <div class="col-lg-12 col-md-12">
                    <?php elseif ( $hospa_shop_cat_sidebar == 'left' ): ?>
                        <?php do_action( 'woocommerce_sidebar' ); ?>
                        <div class="col-lg-8 col-md-12">
                    <?php elseif ( $hospa_shop_cat_sidebar == 'right' ): ?>
                        <div class="col-lg-8 col-md-12">
                    <?php endif; ?>
                <?php else: ?>
                    <?php if( $product_sidebar == 'left-sidebar' ): ?>
                        <?php do_action( 'woocommerce_sidebar' ); ?>
                        <div class="col-lg-8 col-md-12">
                    <?php elseif ( $product_sidebar == 'right-sidebar' ): ?>
                        <div class="col-lg-8 col-md-12">
                    <?php else: ?>
                        <div class="col-lg-12 col-md-12">
                    <?php endif; ?>
                <?php endif; ?>
            <?php else: ?>
                <div class="col-lg-12 col-md-12">
            <?php endif; ?>

                <?php
                /**
                 * woocommerce_before_main_content hook.
                 *
                 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
                 * @hooked woocommerce_breadcrumb - 20
                 */

                do_action( 'woocommerce_before_main_content' );

                    while ( have_posts() ) : the_post();

                        wc_get_template_part( 'content', 'single-product' );

                    endwhile;

                    /**
                     * woocommerce_after_main_content hook.
                     *
                     * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
                     */
                    do_action( 'woocommerce_after_main_content' );
                ?>
            </div>
            <?php 
            if ( isset( $_GET['shop'] ) ):
                if ( $hospa_shop_cat_sidebar == 'right' ) :
                    do_action( 'woocommerce_sidebar' );
                endif; 
            else:
                if ( $product_sidebar == 'right-sidebar' ):
                    do_action( 'woocommerce_sidebar' );
                endif; 
            endif; 
            ?>
        </div>
    </div>
</div>

<?php 
if ( class_exists( 'Header_Footer_Elementor' ) ) { 
    hospa_backtotop();
}
get_footer( 'shop' );
/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
?>
           
