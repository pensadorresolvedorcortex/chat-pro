<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package hospa
*/

get_header();
hospa_preloader();

	hospa_error_content();

hospa_backtotop();
get_footer();