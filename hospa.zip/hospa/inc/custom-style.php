<?php
/**
 * Register custom style.
 */

if ( ! function_exists( 'hospa_custom_style' ) ) {
    function hospa_custom_style(){
        
        $custom_style ='';
        global $hospa_opt;

        // Banner One BG
        if( isset ($hospa_opt['process_arrow']['url']) ):
            if( $hospa_opt['process_arrow']['url'] != '' ):
                $custom_style .="
                .working-process-desc .process-card::before {
                    background-image: url(" . esc_url( $hospa_opt['process_arrow']['url'] ) . ");
                }
                ";
            endif;
        endif;
        if( isset ($hospa_opt['ser_card_hicon']['url']) ):
            if( $hospa_opt['ser_card_hicon']['url'] != '' ):
                $custom_style .="
                .services-card::after {
                    background-image: url(" . esc_url( $hospa_opt['ser_card_hicon']['url'] ) . ");
                }
                ";
            endif;
        endif;

        // Custom Css
        if( isset($hospa_opt['css_code'] ) && !empty($hospa_opt['css_code']) ):
            $custom_style .= $hospa_opt['css_code'];
        endif;

        if( !is_user_logged_in() ){ 
            $custom_style .=' #wpadminbar {
                display: none;
            }';
        }

        // Pre-loader image
        $is_preloader       = !empty($hospa_opt['enable_preloader']) ? $hospa_opt['enable_preloader'] : '';
        $preloader_image    = isset( $hospa_opt['preloader_image']['url'] ) ? $hospa_opt['preloader_image']['url'] : '';
        $preloader_style = !empty( $hospa_opt['preloader_style'] ) ? $hospa_opt['preloader_style'] : 'text';
        if ( $preloader_style == 'image' && $is_preloader == '1' ) {
            $custom_style .= "
            .preloader-area {
                background-image: url(" . esc_url( $preloader_image ) . ");
                background-repeat: no-repeat;
                background-position: center;
            }";
        }

        wp_add_inline_style('hospa-main', $custom_style);

        // Custom Js
        $custom_script ='';
        if( isset($hospa_opt['js_code'] )){
            $custom_script .= $hospa_opt['js_code'];
        }

        // Custom JS
        $custom_script .='
        jQuery(document).on("ready", function () {
            jQuery(".Main__Container-sc-1w4nyzp-0 a").remove();
        });
        ';

        $enable_scroll_cue  = !empty($hospa_opt['enable_scroll_cue']) ? $hospa_opt['enable_scroll_cue'] : '';

        if($enable_scroll_cue == '1'){ $custom_script .='
            (function($){
                "use strict";
                jQuery(document).on("ready", function () {
                    scrollCue.init();
                });
            }(jQuery));';
        }

        if($is_preloader == '1'){ $custom_script .='
            (function($){
                "use strict";
                jQuery(document).on("ready", function () {
                    const getPreloaderId = document.getElementById("preloader");
                    if (getPreloaderId) {
                        getPreloaderId.style.display = "none";
                    }
                });
            }(jQuery));';
        }

        // Hide Sticky Header
        if(isset($hospa_opt['enable_sticky_header']) && $hospa_opt['enable_sticky_header'] == true){ $custom_script .='
            (function($){
                "use strict";
                jQuery(document).on("ready", function () {
                    const getHeaderId = document.querySelector(".navbar");
                    if (getHeaderId) {
                        window.addEventListener("scroll", event => {
                            const height = 150;
                            const { scrollTop } = event.target.scrollingElement;
                            document.querySelector("#navbar").classList.toggle("is-sticky", scrollTop >= height);
                        });
                    }
                });
            }(jQuery));';
        }
        
        wp_add_inline_script( 'hospa-main', $custom_script );
    }
}
add_action( 'wp_enqueue_scripts', 'hospa_custom_style' );