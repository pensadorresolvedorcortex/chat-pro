<?php
/**
 * Enqueue scripts and styles.
 */
if ( ! function_exists( 'hospa_scripts' ) ) :

	function hospa_scripts() { 

		global $hospa_opt;

		$enable_scroll_cue  = !empty($hospa_opt['enable_scroll_cue']) ? $hospa_opt['enable_scroll_cue'] : '';

		wp_enqueue_style( 'hospa-style', get_stylesheet_uri() );

		wp_style_add_data( 'hospa-style', 'rtl', 'replace' );

		wp_enqueue_style( 'magnific-popup', 		HOSPA_CSS . '/magnific-popup.min.css', null, HOSPA_VERSION );
		// wp_enqueue_style( 'swiper-bundle', 			HOSPA_CSS . '/swiper-bundle.min.css', null, HOSPA_VERSION );

		wp_enqueue_style( 'flaticon-hospa',         HOSPA_CSS . '/flaticon_hospa.css', null, HOSPA_VERSION );
		wp_enqueue_style( 'tabler-icons',           HOSPA_CSS . '/tabler-icons.min.css', null, HOSPA_VERSION );

		if($enable_scroll_cue == '1'):
			wp_enqueue_style( 'scrollcue',              HOSPA_CSS . '/scrollCue.min.css', null, HOSPA_VERSION );
		endif;

		wp_enqueue_style( 'owl-carousel', 			HOSPA_CSS . '/owl.carousel.min.css', null, HOSPA_VERSION );
		wp_enqueue_style( 'owl-theme-default', 		HOSPA_CSS . '/owl.theme.default.min.css', null, HOSPA_VERSION );

		if( hospa_rtl() == true ):
			wp_enqueue_style( 'hospa-main',         get_template_directory_uri() . '/assets/css/rtl-style.css', null, HOSPA_VERSION);
			wp_enqueue_style( 'hospa-new-main',     get_template_directory_uri() . '/assets/css/rtl-new-style.css', null, HOSPA_VERSION);
			wp_enqueue_style( 'hospa-blog',         get_template_directory_uri() . '/assets/css/rtl/rtl-blog.css', null, HOSPA_VERSION);

			if ( class_exists( 'WooCommerce' ) ):
				wp_enqueue_style( 'hospa-woocommerce',  get_template_directory_uri() . '/assets/css/rtl/rtl-woocommerce.css', null, HOSPA_VERSION);
		   	endif;

			wp_enqueue_style( 'hospa-mobile-navbar',      get_template_directory_uri() . '/assets/css/rtl/rtl-mobile-navbar.css', null, HOSPA_VERSION);
			wp_enqueue_style( 'hospa-responsive',         get_template_directory_uri() . '/assets/css/rtl/rtl-responsive.css', null, HOSPA_VERSION);

			wp_enqueue_style( 'hospa-rtl', get_template_directory_uri() . '/style-rtl.css' );
		else:
			wp_enqueue_style( 'hospa-main', 	        HOSPA_CSS . '/hospa-main.css', null, HOSPA_VERSION );
			wp_enqueue_style( 'hospa-new-demo', 	    HOSPA_CSS . '/hospa-new-demo.css', null, HOSPA_VERSION );
			wp_enqueue_style( 'hospa-blog', 	        HOSPA_CSS . '/hospa-blog.css', null, HOSPA_VERSION );
			if( class_exists( 'WooCommerce' ) ):
				wp_enqueue_style( 'hospa-woocommerce',  get_template_directory_uri() . '/assets/css/hospa-woocommerce.css', null, HOSPA_VERSION);
			endif;
			wp_enqueue_style( 'hospa-mobile-navbar', 	HOSPA_CSS . '/hospa-mobile-navbar.css', null, HOSPA_VERSION );
			wp_enqueue_style( 'hospa-responsive', 	    HOSPA_CSS . '/hospa-responsive.css', null, HOSPA_VERSION );
		endif;
		
		/**
         * Enqueueing JavaScript Files
        */
		wp_enqueue_script( 'bootstrap-bundle', 	    HOSPA_JS . '/bootstrap.bundle.min.js', array('jquery'), HOSPA_VERSION );
		wp_enqueue_script( 'magnific-popup', 	    HOSPA_JS . '/magnific-popup.min.js', array('jquery'), HOSPA_VERSION );
		// wp_enqueue_script( 'swiper-bundle', 	    HOSPA_JS . '/swiper-bundle.min.js', array('jquery'), HOSPA_VERSION );
		wp_enqueue_script( 'owl-carousel', 		    HOSPA_JS . '/owl.carousel.min.js', array('jquery'), HOSPA_VERSION );
		
		if($enable_scroll_cue == '1'):
			wp_enqueue_script( 'scrollcue', 	        HOSPA_JS . '/scrollCue.min.js', array('jquery'), HOSPA_VERSION );
		endif;

		wp_enqueue_script( 'ajaxchimp', 	        HOSPA_JS . '/ajaxchimp.min.js', array('jquery'), HOSPA_VERSION );
		wp_enqueue_script( 'hospa-main', 			HOSPA_JS . '/hospa-main.js', array('jquery'), HOSPA_VERSION );
		
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}
	
endif;
add_action( 'wp_enqueue_scripts', 'hospa_scripts' );