<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package Hospa
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */

function hospa_body_classes( $classes ) {
	global $hospa_opt;

	$enable_product_meta     = !empty( $hospa_opt['enable_product_meta'] ) ? $hospa_opt['enable_product_meta'] : '';
	$enable_product_review   = !empty( $hospa_opt['enable_product_review'] ) ? $hospa_opt['enable_product_review'] : '';


	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if ( ! is_active_sidebar( 'article-sidebar' ) ) {
		$classes[] = 'no-sidebar';
	}
	
	if( $enable_product_meta == '1' ){ }else{
		$classes[] = 'hide-shop-meta';
	}
	if( $enable_product_review == '1' ){ }else{
		$classes[] = 'hide-shop-review';
	}

	if( function_exists('acf_add_options_page') ) {
		$choose_body_color		= get_field( 'choose_body_color' );
		if( is_home() ) {
			$post_page_id   = get_option( 'page_for_posts' );
			$choose_body_color   = get_field( 'choose_body_color' , $post_page_id );
		}
	} else {
		$choose_body_color		= '';
	}
	if( $choose_body_color == 'bg_one' ){
		$classes[] = 'bg_one';
	}elseif( $choose_body_color == 'bg_two' ){
		$classes[] = 'bg_two';
	}elseif( $choose_body_color == 'bg_four' ){
		$classes[] = 'bg_four';
	}else {
		$classes[] = 'bg_three';
	}
	return $classes;
}
add_filter( 'body_class', 'hospa_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function hospa_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'hospa_pingback_header' );

 /*
 * Pagination
 */
if ( ! function_exists( 'hospa_pagination' ) ) :
    function hospa_pagination() {
		global $wp_query;
		if ( $wp_query->max_num_pages <= 1 ) {
			return;
		}
    ?>
        <div class="pagination-area text-center">
			<nav aria-label="navigation">
			<?php echo paginate_links( array(
				'format' => '?paged=%#%',
				'prev_text' => '<i class="ti ti-chevron-left"></i>',
				'next_text' => '<i class="ti ti-chevron-right"></i>',
					)
				) ?>
			</nav>
		</div>
    <?php
    }
endif;

/**
 * If page edited by elementor
 */
if ( ! function_exists( 'hospa_is_elementor' ) ) :
	function hospa_is_elementor(){
		if ( function_exists( 'elementor_fail_php_version' ) ):
			global $post;
			return \Elementor\Plugin::$instance->documents->get( $post->ID )->is_built_with_elementor();
		endif;
	}
endif;

/**
 * hospa Main Logo
*/
if ( ! function_exists( 'main_logo' ) ) :
	function main_logo(){
		global $hospa_opt;
		// hospa Logo
		if ( isset( $hospa_opt['main_logo']['url'] ) && $hospa_opt['main_logo']['url'] !='' ) :
			$main_logo = $hospa_opt['main_logo']['url'];
		else :
			$main_logo = 'null';
		endif;
		?>
			<?php if ( $main_logo != 'null' ) : ?>
				<img class="black-logo" src="<?php echo esc_url( $main_logo ); ?>" alt="<?php bloginfo( 'name' ); ?>">
			<?php else : ?>
				<h2 class="headlogo"><?php bloginfo( 'name' ); ?> </h2>
			<?php endif; ?>
		<?php
	}
endif;

/**
 * Hospa Mobile Logo
*/
if ( ! function_exists( 'mobile_logo' ) ) :
	function mobile_logo(){
		global $hospa_opt;
		// Hospa Logo
		if ( isset( $hospa_opt['mobile_logo']['url']) && $hospa_opt['mobile_logo']['url'] !='' ) :
			$hospa_logo = $hospa_opt['mobile_logo']['url'];
		else :
			$hospa_logo = 'null';
		endif;
		?>
			<?php if ( $hospa_logo != 'null' ) : ?>
				<img class="logo-light" src="<?php echo esc_url($hospa_logo); ?>" alt="<?php bloginfo( 'name' ); ?>">
			<?php else : ?>
				<h2 class="mobile-logo"><?php bloginfo( 'name' ); ?> </h2>
			<?php endif; ?>
		<?php
	}
endif;

/**
 * Estimated Reading Time
 */
if ( ! function_exists( 'hospa_reading_time' ) ) :
	function hospa_reading_time() {
		global $post;
		$thecontent  = get_post_field( 'post_content', $post->ID );
		$words 		 = str_word_count( strip_tags( $thecontent ) );
		$readingtime = ceil( $words / 200 );
		$output 	 = $readingtime;
		return $output;
	}
endif;

//Single Services Sidebar Title Active Class
if ( ! function_exists( 'hospa_if_current' ) ) {
	function hospa_if_current($active) {
		global $wp_query,$post;
		$current    = $wp_query->get_queried_object_id();
		$post_id    = $post->ID;
		if($current==$post_id){echo esc_attr($active, 'hospa');}
	}
}

// Navbar Area
if ( ! function_exists( 'hospa_nav_area' ) ) {
	function hospa_nav_area() {

		global $hospa_opt;
	
		if( function_exists('acf_add_options_page') ) {
			$navbar_style		= get_field( 'choose_navigation_style' );
			if( is_home() ) {
				$post_page_id   = get_option( 'page_for_posts' );
				$navbar_style   = get_field( 'choose_navigation_style' , $post_page_id );
			}
		} else {
			$navbar_style		= 1;
		}

		if( $navbar_style == 3){
			get_template_part('template-parts/header/style','3'); 
		}elseif($navbar_style == 2){
			get_template_part('template-parts/header/style','2'); 
		}else {
			get_template_part('template-parts/header/style','1'); 
		}
	}
}
// Footer Area
if ( ! function_exists( 'hospa_footer_area' ) ) {
	function hospa_footer_area() {
		global $hospa_opt;
	
		get_template_part('template-parts/footer/style','one');
	
	}
}

if ( ! function_exists( 'hospa_backtotop' ) ) :
	function hospa_backtotop() {
		global $hospa_opt;

		$enable_back_to_top = isset( $hospa_opt['enable_back_to_top']) ? $hospa_opt['enable_back_to_top'] : '1';

		if( $enable_back_to_top == true ) : ?>
			<button type="button" id="backtotop" class="position-fixed text-center border-0 p-0">
				<i class="ti ti-arrow-up"></i>
			</button>
		<?php endif;
	}

endif;


/**
 * Hospa Allowed HTML
 */
if ( ! function_exists( 'hospa_kses_allowed_html' ) ) {
	function hospa_kses_allowed_html($tags, $context) {
		$allowed_atts = array(
			'align'      => array(),
			'class'      => array(),
			'type'       => array(),
			'id'         => array(),
			'dir'        => array(),
			'lang'       => array(),
			'style'      => array(),
			'xml:lang'   => array(),
			'src'        => array(),
			'alt'        => array(),
			'href'       => array(),
			'rel'        => array(),
			'rev'        => array(),
			'target'     => array(),
			'novalidate' => array(),
			'value'      => array(),
			'name'       => array(),
			'tabindex'   => array(),
			'action'     => array(),
			'method'     => array(),
			'for'        => array(),
			'width'      => array(),
			'height'     => array(),
			'data'       => array(),
			'title'      => array(),
			'data-plugin-action'	=> array(),
		);
		switch($context) {
		case 'hospaallowedhtml':
			$tags = array(
				'form'    => $allowed_atts,
				'label'   => $allowed_atts,
				'input'   => $allowed_atts,
				'textarea'=> $allowed_atts,
				'iframe'  => $allowed_atts,
				'script'  => $allowed_atts,
				'style'   => $allowed_atts,
				'strong'  => $allowed_atts,
				'small'   => $allowed_atts,
				'table'   => $allowed_atts,
				'span'    => $allowed_atts,
				'abbr'    => $allowed_atts,
				'code'    => $allowed_atts,
				'pre'     => $allowed_atts,
				'div'     => $allowed_atts,
				'img'     => $allowed_atts,
				'h1'      => $allowed_atts,
				'h2'      => $allowed_atts,
				'h3'      => $allowed_atts,
				'h4'      => $allowed_atts,
				'h5'      => $allowed_atts,
				'h6'      => $allowed_atts,
				'ol'      => $allowed_atts,
				'ul'      => $allowed_atts,
				'li'      => $allowed_atts,
				'em'      => $allowed_atts,
				'hr'      => $allowed_atts,
				'br'      => $allowed_atts,
				'tr'      => $allowed_atts,
				'td'      => $allowed_atts,
				'p'       => $allowed_atts,
				'a'       => $allowed_atts,
				'b'       => $allowed_atts,
				'i'       => $allowed_atts,
				'del'     => $allowed_atts,
				'bdi'     => $allowed_atts,
				'button'  => $allowed_atts,
			);
			return $tags;
		default:
			return $tags;
		}
	}
}
add_filter( 'wp_kses_allowed_html', 'hospa_kses_allowed_html', 10, 2);

/**
 * Preloader
*/
if ( ! function_exists( 'hospa_preloader' ) ) :
	function hospa_preloader() {
		global $hospa_opt;
        $is_preloader       = !empty($hospa_opt['enable_preloader']) ? $hospa_opt['enable_preloader'] : '';
        $preloader_style    = !empty($hospa_opt['preloader_style']) ? $hospa_opt['preloader_style'] : 'circle-spin';
		$loading_texts = !empty($hospa_opt['loading_text']) ? $hospa_opt['loading_text'] : '';
		$loading_texts = explode(',', $loading_texts);

        if( $is_preloader == '1' ):
            if ( defined( 'ELEMENTOR_VERSION' ) ) :
                if (\Elementor\Plugin::$instance->preview->is_preview_mode()) :
                    echo '';
                else:
                    if ( $preloader_style == 'text' ) : ?>
						<div class="preloader-area text-center position-fixed top-0 bottom-0 start-0 end-0" id="preloader">
							<div class="loader position-absolute start-0 end-0">
								<div class="waviy position-relative">
									<?php foreach($loading_texts as $text): ?>
										<span class="d-inline-block"><?php echo esc_html($text); ?></span>
									<?php endforeach; ?>
								</div>
							</div>
						</div>
                    <?php elseif( $preloader_style == 'circle-spin' ) : ?>
						<div class="preloader-area text-center position-fixed top-0 bottom-0 start-0 end-0" id="preloader">
							<div class="loader position-absolute start-0 end-0">
								<div class="waviy position-relative">
									<div class="sbl-half-circle-spin">
										<div></div>
									</div>
								</div>
							</div>
                        </div>
                    <?php else: ?>
						<div class="preloader-area text-center position-fixed top-0 bottom-0 start-0 end-0" id="preloader">
							<div class="loader position-absolute start-0 end-0">
								<div class="waviy position-relative">
								</div>
							</div>
						</div>
                    <?php endif;
                endif;
            else:
                if ( $preloader_style == 'text' ) : ?>
					<div class="preloader-area text-center position-fixed top-0 bottom-0 start-0 end-0" id="preloader">
						<div class="loader position-absolute start-0 end-0">
							<div class="waviy position-relative">
								<?php foreach($loading_texts as $text): ?>
									<span class="d-inline-block"><?php echo esc_html($text); ?></span>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
                <?php elseif( $preloader_style == 'circle-spin' ) :
                    ?>
               		<div class="preloader-area text-center position-fixed top-0 bottom-0 start-0 end-0" id="preloader">
						<div class="loader position-absolute start-0 end-0">
							<div class="waviy position-relative">
								<div class="sbl-half-circle-spin">
									<div></div>
								</div>
							</div>
						</div>
                    </div>
                <?php else : ?>
					<div class="preloader-area text-center position-fixed top-0 bottom-0 start-0 end-0" id="preloader">
						<div class="loader position-absolute start-0 end-0">
							<div class="waviy position-relative">
							</div>
						</div>
                    </div>
                    <?php
                endif;
            endif;
        endif;
	}
endif;

// Error 404
if ( ! function_exists( 'hospa_error_content' ) ) :
	function hospa_error_content() { 
		global $hospa_opt;
		$fc_error_shortcode = !empty($hospa_opt['fc_error_shortcode']) ? $hospa_opt['fc_error_shortcode'] : '';
		$content_not_found = !empty($hospa_opt['content_not_found']) ? $hospa_opt['content_not_found'] : '';
		$img_404 = !empty($hospa_opt['img_404']['url']) ? $hospa_opt['img_404']['url'] : '';
	?>

		<div class="not-found-area ptb-100">
            <div class="container">
                <div class="not-found-content text-center">
					<?php if( $img_404 != '' ): ?>
						<img src="<?php echo esc_url( $img_404 ); ?> " alt="<?php esc_attr_e( '404 Image', 'hospa' ); ?>">
					<?php endif; ?>
					<h3><?php echo esc_html($content_not_found ); ?></h3>
					<?php if( isset( $hospa_opt['button_not_found'] ) ): ?>
						<?php if( $hospa_opt['button_not_found'] != '' ): ?>
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="default-btn">
								<i class="ti ti-circle-arrow-right-filled"></i>
								<?php echo esc_html( $hospa_opt['button_not_found'] ); ?>
							</a>
						<?php endif; ?>
					<?php else: ?>
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="default-btn">
							<i class="ti ti-circle-arrow-right-filled"></i>
							<?php esc_html_e( 'Back to Home', 'hospa' ); ?>
						</a>
					<?php endif; ?>
                </div>
            </div>
        </div>
		
		<?php 
		if($fc_error_shortcode != ''):
			echo do_shortcode($fc_error_shortcode);
		endif; ?>

	<?php }
endif;


/**
 * Hospa RTL
*/
if( ! function_exists( 'hospa_rtl' ) ):
	function hospa_rtl() {
		global $hospa_opt;

		if(	isset( $hospa_opt['hospa_enable_rtl'])  ):
			$hospa_rtl_opt = $hospa_opt['hospa_enable_rtl'];
		else:
			$hospa_rtl_opt = 'disable';
		endif;

		if ( isset( $_GET['rtl'] ) ) {
			$hospa_rtl_opt = $_GET['rtl'];
		}

		if ( $hospa_rtl_opt == 'enable' ) :
			$hospa_rtl = true;
		else:
			$hospa_rtl = false;
		endif;

		return $hospa_rtl;
	}
endif;