<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 * @package Hospa
 */

/**
 * Filter the categories archive widget to add a span around post count
 */
if ( ! function_exists( 'hospa_cat_count_span' ) ) {
	function hospa_cat_count_span( $links ) {
		$links = str_replace( '</a> (', '</a><span class="post-count">(', $links );
		$links = str_replace( ')', ')</span>', $links );
		return $links;
	}
}
add_filter( 'wp_list_categories', 'hospa_cat_count_span' );

/**
 * Filter the archives widget to add a span around post count
 */
if ( ! function_exists( 'hospa_archive_count_span' ) ) {
	function hospa_archive_count_span( $links ) {
		$links = str_replace( '</a>&nbsp;(', '</a><span class="post-count">(', $links );
		$links = str_replace( ')', ')</span>', $links );
		return $links;
	}
}
add_filter( 'get_archives_link', 'hospa_archive_count_span' );

/**
 * Excerpt more text
 */
if ( ! function_exists( 'hospa_excerpt_more' ) ) :
	function hospa_excerpt_more( $more ) {
		return ' ';
	}
endif;
add_filter('excerpt_more', 'hospa_excerpt_more');

/**
 * Menu Registration
*/
if ( ! function_exists( 'hospa_register_primary_menus' ) ) :
	function hospa_register_primary_menus(){
		register_nav_menus(
			array(
				'primary'    => esc_html__('Main Menu', 'hospa'),
			)
		);
	}
endif;
add_action('init', 'hospa_register_primary_menus');

// Remove auto p from Contact Form 7 shortcode output
if ( ! function_exists( 'hospa_remove_wpcf7_extra_p' ) ) {
	function hospa_remove_wpcf7_extra_p() {
		return false;
	}
}
add_filter('wpcf7_autop_or_not', 'hospa_remove_wpcf7_extra_p');