<?php
/**
 * Register Theme Widget
 * @package Hospa
*/

// Theme Sidebar
if ( ! function_exists( 'hospa_widgets_init' ) ) {
    function hospa_widgets_init() {
        register_sidebar( array(
            'name'          => esc_html__( 'Blog Sidebar', 'hospa' ),
            'id'            => 'article-sidebar',
            'description'   => esc_html__( 'Add widgets here.', 'hospa' ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h3 class="widget-title">',
            'after_title'   => '</h3>',
        ) );
        // Shop Sidebar
        register_sidebar( array( 
            'name'          => esc_html__( 'Shop Sidebar', 'hospa' ),
            'id'            => 'shop',
            'description'   => esc_html__( 'Add widgets here.', 'hospa' ),
            'before_widget' => '<div class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h3 class="widget-title">',
            'after_title'   => '</h3>',
        ) );
    }
}
add_action( 'widgets_init', 'hospa_widgets_init' );