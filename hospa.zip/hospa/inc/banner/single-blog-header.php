<?php global $hospa_opt;
/**
 * Blog Header
 */

if( isset( $hospa_opt['hospa_single_blog_sidebar'] ) ) {
    if( $hospa_opt['hospa_single_blog_sidebar'] == 'hospa_without_sidebar_center' ) :
        $hospa_sidebar_class = 'col-lg-8 col-md-12 offset-lg-2';
    elseif( $hospa_opt['hospa_single_blog_sidebar'] == 'hospa_without_sidebar' ) :
        $hospa_sidebar_class = 'col-lg-12 col-md-12';
    else:
        if( is_active_sidebar( 'article-sidebar' ) ):
            $hospa_sidebar_class = 'col-lg-8 col-md-12';
        else:
            $hospa_sidebar_class = 'col-lg-8 col-md-12 offset-lg-2';
        endif;
    endif;
    $sidebar_hide = $hospa_opt['hospa_single_blog_sidebar'];
} else {
    if( is_active_sidebar( 'article-sidebar' ) ):
        $hospa_sidebar_class = 'col-lg-8 col-md-12';
        $sidebar_hide       = 'hospa_with_sidebar_right';
    else:
        $hospa_sidebar_class = 'col-lg-8 col-md-12 offset-lg-2';
        $sidebar_hide       = 'hospa_without_sidebar';
    endif;
}

$default_hide_banner = isset($hospa_opt['enable_page_banner']) ? $hospa_opt['enable_page_banner'] : false;
$acf_hide_banner = function_exists('get_field') ? get_field('enable_page_banner') : null;

if($acf_hide_banner == '0'){
	$acf_hide_banner = false;
}elseif($acf_hide_banner == '1'){
	$acf_hide_banner = true;
}else {
	$acf_hide_banner = null;
}

$hide_banner = !is_null($acf_hide_banner) ? $acf_hide_banner : $default_hide_banner;

$tag               = !empty($hospa_opt['page_title_tag']) ? $hospa_opt['page_title_tag'] : 'h2';
$is_social_share   = !empty( $hospa_opt['enable_banner_share'] ) ? $hospa_opt['enable_banner_share'] : '';
$title          = get_the_title();
$next_label		= isset($hospa_opt['next_post_txt']) ? $hospa_opt['next_post_txt'] : 'Next Post';
$previous_label	= isset($hospa_opt['previous_post_txt']) ? $hospa_opt['previous_post_txt'] : 'Previous Post';
$is_post_meta	= isset($hospa_opt['is_post_meta']) ? $hospa_opt['is_post_meta'] : true;
$is_post_social_share   = !empty($hospa_opt['enable_blog_post_share']) ? $hospa_opt['enable_blog_post_share'] : '';
$share_text   = !empty( $hospa_opt['share_text'] ) ? $hospa_opt['share_text'] : '';

if(hospa_reading_time() > 1){
    $min_text     = isset($hospa_opt['min_text']) && $hospa_opt['min_text'] != '' ? $hospa_opt['min_text'] : esc_html__('MINS READ', 'hospa');
}else {
    $min_text     = isset($hospa_opt['min_text']) && $hospa_opt['min_text'] != '' ? $hospa_opt['min_text'] : esc_html__('MIN READ', 'hospa');
}
$header_phnicon   = !empty( $hospa_opt['header_phnicon'] ) ? $hospa_opt['header_phnicon'] : 'ti ti-phone-call';

$enable_page_call   = !empty($hospa_opt['enable_page_call']) ? $hospa_opt['enable_page_call'] : false;
$enable_pb_img     =  isset($hospa_opt['enable_page_bannerimg']) ? $hospa_opt['enable_page_bannerimg'] : 1;

if( function_exists('acf_add_options_page') ){
	$custom_title 	    = get_field( 'enable_cus_pagetitle' );
	$banner_image 	    = get_field( 'banner_image' );
    $hide_breadcrumb    = get_field( 'hide_breadcrumb');
    $hide_banner_meta   = get_field( 'hide_banner_meta');
    $custom_desc 	    = get_field( 'cus_pagedesc');
    $phn_num_link 	    = get_field( 'page_phn_num_link');
    $page_mail_link 	= get_field( 'page_mail_link');
}else {
	$custom_title 	    = false;
	$banner_image 	    = get_template_directory_uri() .'/assets/img/bg-banner.jpg';
    $hide_breadcrumb    = false;
    $hide_banner_meta   = false;
    $custom_desc 	    = '';
    $phn_num_link 	    = '';
    $page_mail_link 	= '';
}

if(!empty($hospa_opt['enable_page_breadcrumb']) && $hospa_opt['enable_page_breadcrumb'] == true){
	$hide_breadcrumb        =  $hospa_opt['enable_page_breadcrumb'] ;
}
if(!empty($hospa_opt['enable_page_meta']) && $hospa_opt['enable_page_meta'] == true){
	$hide_banner_meta        =  $hospa_opt['enable_page_meta'] ;
}
$phn_num          = !empty( $hospa_opt['header_call_num'] ) ? $hospa_opt['header_call_num'] : '';
$phn_num_link     = !empty( $hospa_opt['header_call_num_link'] ) ? $hospa_opt['header_call_num_link'] : '';

$page_mail_link     = !empty( $hospa_opt['header_mail_link'] ) ? $hospa_opt['header_mail_link'] : '';

