<?php global $hospa_opt;
/**
 * Blog Header
 */

$post_page_id       = get_option( 'page_for_posts' );

if( isset( $hospa_opt['hospa_blog_sidebar'] ) ) {
    if( $hospa_opt['hospa_blog_sidebar'] == 'hospa_without_sidebar_center' ) :
        $hospa_sidebar_class = 'col-lg-8 col-md-12 offset-lg-2';
    elseif( $hospa_opt['hospa_blog_sidebar'] == 'hospa_without_sidebar' ) :
        $hospa_sidebar_class = 'col-lg-12 col-md-12';
    else:
        if( is_active_sidebar( 'article-sidebar' ) ):
            $hospa_sidebar_class = 'col-lg-8 col-md-12';
        else:
            $hospa_sidebar_class = 'col-lg-8 col-md-12 offset-lg-2';
        endif;
    endif;
    $sidebar_hide = $hospa_opt['hospa_blog_sidebar'];
} else {
    if( is_active_sidebar( 'article-sidebar' ) ):
        $hospa_sidebar_class = 'col-lg-8 col-md-12';
        $sidebar_hide       = 'hospa_with_sidebar_right';
    else:
        $hospa_sidebar_class = 'col-lg-8 col-md-12 offset-lg-2';
        $sidebar_hide       = 'hospa_without_sidebar';
    endif;
}

$tag                = !empty($hospa_opt['page_title_tag']) ? $hospa_opt['page_title_tag'] : 'h2';
$is_social_share    = !empty( $hospa_opt['enable_banner_share'] ) ? $hospa_opt['enable_banner_share'] : '';
$header_phnicon     = !empty( $hospa_opt['header_phnicon'] ) ? $hospa_opt['header_phnicon'] : 'ti ti-phone-call';
$enable_page_call   = !empty($hospa_opt['enable_page_call']) ? $hospa_opt['enable_page_call'] : false;

if( function_exists('acf_add_options_page') ){
    $custom_title 	    = get_field( 'enable_cus_pagetitle' , $post_page_id);
	$banner_image 	    = get_field( 'banner_image', $post_page_id);
    $hide_breadcrumb   = !empty(get_field( 'hide_breadcrumb', $post_page_id));
    $hide_banner_meta   = !empty(get_field( 'hide_banner_meta' , $post_page_id));
    $custom_desc 	    = get_field( 'cus_pagedesc', $post_page_id);
    $phn_num 	        = get_field( 'page_phn_num',  $post_page_id);
    $phn_num_link 	    = get_field( 'page_phn_num_link', $post_page_id);
    $page_mail_link 	= get_field( 'page_mail_link', $post_page_id);
}else {
	$custom_title 	    = false;
	$banner_image 	    = get_template_directory_uri() .'/assets/img/bg-banner.jpg';
    $hide_breadcrumb    = false;
    $hide_banner_meta   = false;
    $custom_desc 	    = '';
    $phn_num 	        = '';
    $phn_num_link 	    = '';
    $page_mail_link 	= '';
}

$banner_image =  isset($hospa_opt['blog_bg']['url']) ? $hospa_opt['blog_bg']['url'] : '';

$default_hide_banner = isset($hospa_opt['enable_page_banner']) ? $hospa_opt['enable_page_banner'] : false;
$acf_hide_banner = function_exists('get_field') ? get_field('enable_page_banner' , $post_page_id) : null;

if($acf_hide_banner == '0'){
	$acf_hide_banner = false;
}elseif($acf_hide_banner == '1'){
	$acf_hide_banner = true;
}else {
	$acf_hide_banner = null;
}

$hide_banner = !is_null($acf_hide_banner) ? $acf_hide_banner : $default_hide_banner;

if(!empty($hospa_opt['enable_page_breadcrumb']) && $hospa_opt['enable_page_breadcrumb'] == true){
	$hide_breadcrumb        =  $hospa_opt['enable_page_breadcrumb'] ;
}
if(!empty($hospa_opt['enable_page_meta']) && $hospa_opt['enable_page_meta'] == true){
	$hide_banner_meta        =  $hospa_opt['enable_page_meta'] ;
}


$custom_desc     = !empty( $hospa_opt['header_call_text'] ) ? $hospa_opt['header_call_text'] : '';
$phn_num     = !empty( $hospa_opt['header_call_num'] ) ? $hospa_opt['header_call_num'] : '';
$phn_num_link     = !empty( $hospa_opt['header_call_num_link'] ) ? $hospa_opt['header_call_num_link'] : '';
$page_mail_link     = !empty( $hospa_opt['header_mail_link'] ) ? $hospa_opt['header_mail_link'] : '';

$lab_post_title  = !empty( $hospa_opt['lab_post_title'] ) ? $hospa_opt['lab_post_title'] : 'Labtest';
$car_post_title  = !empty( $hospa_opt['car_post_title'] ) ? $hospa_opt['car_post_title'] : 'Career';
$event_post_title  = !empty( $hospa_opt['event_post_title'] ) ? $hospa_opt['event_post_title'] : 'Event';
$ser_post_title  = !empty( $hospa_opt['ser_post_title'] ) ? $hospa_opt['ser_post_title'] : 'Services';
$doc_post_title  = !empty( $hospa_opt['doc_post_title'] ) ? $hospa_opt['doc_post_title'] : 'Doctor';
$ser_post_rm     = !empty( $hospa_opt['ser_post_rm'] ) ? $hospa_opt['ser_post_rm'] : 'Read More';
$lt_post_rm     = !empty( $hospa_opt['lt_post_rm'] ) ? $hospa_opt['lt_post_rm'] : 'Read More';
$doc_post_rm     = !empty( $hospa_opt['doc_post_rm'] ) ? $hospa_opt['doc_post_rm'] : 'Read More';

$enable_pb_img     =  isset($hospa_opt['enable_page_bannerimg']) ? $hospa_opt['enable_page_bannerimg'] : 1;