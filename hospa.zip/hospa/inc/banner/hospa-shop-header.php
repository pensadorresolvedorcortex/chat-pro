<?php

global $hospa_opt;

$post_page_id       = get_option( 'woocommerce_shop_page_id' );
$product_sidebar    = isset( $hospa_opt['product_sidebar']) ? $hospa_opt['product_sidebar'] : '';

if( function_exists('acf_add_options_page') ){
    $custom_title 	    = get_field( 'enable_cus_pagetitle' , $post_page_id);
	$banner_image 	    = get_field( 'banner_image', $post_page_id);
}else {
	$custom_title 	    = false;
	$banner_image 	    = get_template_directory_uri() .'/assets/img/bg-banner.jpg';
}

$tag               = !empty($hospa_opt['page_title_tag']) ? $hospa_opt['page_title_tag'] : 'h2';
$is_social_share   = !empty( $hospa_opt['enable_banner_share'] ) ? $hospa_opt['enable_banner_share'] : '';
$header_phnicon   = !empty( $hospa_opt['header_phnicon'] ) ? $hospa_opt['header_phnicon'] : 'ti ti-phone-call';

$enable_page_call   = !empty($hospa_opt['enable_page_call']) ? $hospa_opt['enable_page_call'] : false;

// Hide Banner
$default_hide_banner = isset($hospa_opt['enable_page_banner']) ? $hospa_opt['enable_page_banner'] : false;
$acf_hide_banner = function_exists('get_field') ? get_field( 'enable_page_banner', $post_page_id) : null;

if($acf_hide_banner == '0'){
	$acf_hide_banner = false;
}elseif($acf_hide_banner == '1'){
	$acf_hide_banner = true;
}else {
	$acf_hide_banner = null;
}
$hide_banner = !is_null($acf_hide_banner) ? $acf_hide_banner : $default_hide_banner;

$hide_breadcrumb   = !empty(get_field( 'hide_breadcrumb', $post_page_id)) ? get_field( 'hide_breadcrumb', $post_page_id) : false;
if(!empty($hospa_opt['enable_page_breadcrumb']) && $hospa_opt['enable_page_breadcrumb'] == true){
	$hide_breadcrumb        =  $hospa_opt['enable_page_breadcrumb'] ;
}

$hide_banner_meta   = !empty(get_field( 'hide_banner_meta' , $post_page_id)) ? get_field( 'hide_banner_meta' , $post_page_id) : false;
if(!empty($hospa_opt['enable_page_meta']) && $hospa_opt['enable_page_meta'] == true){
	$hide_banner_meta        =  $hospa_opt['enable_page_meta'] ;
}

$custom_desc     = !empty( $hospa_opt['header_call_text'] ) ? $hospa_opt['header_call_text'] : '';
if( function_exists('acf_add_options_page') && get_field( 'cus_pagedesc', $post_page_id) != '' ){
    $custom_desc 	    = get_field( 'cus_pagedesc', $post_page_id);
}
$phn_num     = !empty( $hospa_opt['header_call_num'] ) ? $hospa_opt['header_call_num'] : '';
if( function_exists('acf_add_options_page') && get_field( 'page_phn_num', $post_page_id) != '' ){
    $phn_num 	        = get_field( 'page_phn_num',  $post_page_id);
}
$phn_num_link     = !empty( $hospa_opt['header_call_num_link'] ) ? $hospa_opt['header_call_num_link'] : '';
if( function_exists('acf_add_options_page') && get_field( 'page_phn_num_link', $post_page_id) != '' ){
    $phn_num_link 	    = get_field( 'page_phn_num_link', $post_page_id);
}

$page_mail_link     = !empty( $hospa_opt['header_mail_link'] ) ? $hospa_opt['header_mail_link'] : '';
if( function_exists('acf_add_options_page') && get_field( 'page_mail_link', $post_page_id) != '' ){
    $page_mail_link 	= get_field( 'page_mail_link', $post_page_id);
}

$enable_pb_img     =  isset($hospa_opt['enable_page_bannerimg']) ? $hospa_opt['enable_page_bannerimg'] : 1;