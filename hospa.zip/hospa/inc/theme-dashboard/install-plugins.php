<?php
/**
 * Hospa Dashboard - Install Plugins Page
 *
 * @package hospa
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div class="wrap about-wrap et-admin-wrap">

    <?php hospa_admin_navigation_tabs( 'hospa-admin-plugins' ); ?>

    <div id="hospa-dashboard" class="wrap about-wrap">
        <div class="welcome-content w-clearfix extra">
            <div class="hospa-plugins hospa-theme-browser-wrap">
                <div class="theme-browser rendered">
                    
                    <!-- Plugin Installation Heading & Button -->
                    <div class="whi-install-plugins-wrap">
                        <h3><?php echo esc_html__( 'The following plugins are recommended', 'hospa' ); ?></h3>
                        <a href="#" class="hospa-admin-btn whi-install-plugins">
                            <?php echo esc_html__( 'Activate All Plugins', 'hospa' ); ?>
                        </a>
                    </div>

                    <div class="hospa-plugins-wrap hospa-plugins">
                        <?php
                        // Initialize TGM Plugin Activation List Table
                        $tgmpa_list_table = new TGMPA_List_Table();
                        $plugins          = TGM_Plugin_Activation::$instance->plugins;

                        foreach ( $plugins as $plugin ) :
                            $plugin_status = '';

                            // Ensure 'type' is set
                            $plugin['type'] = isset( $plugin['type'] ) ? sanitize_text_field( $plugin['type'] ) : 'recommended';
                            $plugin['sanitized_plugin'] = sanitize_text_field( $plugin['name'] );

                            // Get plugin action buttons
                            $plugin_action = $tgmpa_list_table->actions_plugin( $plugin );

                            // Check if plugin is active
                            if ( strpos( $plugin_action, 'deactivate' ) !== false ) {
                                $plugin_status = 'active';
                                $plugin_action = '<div class="row-actions visible active">
                                    <span class="activate">
                                        <a class="button hospa-admin-btn">' . esc_html__( 'Activated', 'hospa' ) . '</a>
                                    </span>
                                </div>';
                            }
                        ?>
                            <!-- Plugin Box -->
                            <div class="hospa-plugin wp-clearfix <?php echo esc_attr( $plugin_status ); ?>" 
                                data-plugin-name="<?php echo esc_attr( $plugin['sanitized_plugin'] ); ?>">
                                <h4><?php echo esc_html( $plugin['sanitized_plugin'] ); ?></h4>
                                <?php echo wp_kses($plugin_action, 'hospaallowedhtml'); ?>
                            </div> 
                        <?php endforeach; ?>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div> <!-- End Wrap -->