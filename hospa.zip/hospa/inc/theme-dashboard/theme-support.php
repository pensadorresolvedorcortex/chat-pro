<?php
/**
 * Hospa Dashboard Support Page
 *
 * @package hospa
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div class="wrap about-wrap et-admin-wrap">

	<?php hospa_admin_navigation_tabs( 'hospa-support' ); ?>

    <div id="hospa-dashboard" class="wrap about-wrap">
        <div class="welcome-content w-clearfix extra">
            <ul class="support-sub-menu">
                <li><a href="#support"><?php esc_html_e('Support', 'hospa'); ?></a></li>
                <li><a href="#child-theme"><?php esc_html_e('Child Theme', 'hospa'); ?></a></li>
                <li><a href="#theme-update"><?php esc_html_e('Theme Update', 'hospa'); ?></a></li>
                <li><a href="#pro-plugin-update"><?php esc_html_e('Pro Plugins Update', 'hospa'); ?></a></li>
                <li><a href="#error-404"><?php esc_html_e('404 Error', 'hospa'); ?></a></li>
                <li><a href="#elementor-issue"><?php esc_html_e('Elementor Edit Page Not Loading', 'hospa'); ?></a></li>
            </ul>

            <!-- Support Section -->
            <div id="support" class="et-support-section">
                <div class="et-section-title"><?php esc_html_e('👨🏻‍💻 Support', 'hospa'); ?></div>
                <div class="et-support-content">
                    <p><?php printf(
                        esc_html__('Hospa comes with %s and %s. Once your initial support period ends, you can extend it for an additional %s.', 'hospa'),
                        '<strong>' . esc_html__('6 months of support', 'hospa') . '</strong>',
                        '<strong>' . esc_html__('free lifetime updates', 'hospa') . '</strong>',
                        '<strong>' . esc_html__('6 or 12 months', 'hospa') . '</strong>'
                    ); ?></p>
                    
                    <p><?php esc_html_e('Even if you choose not to extend support, you can still submit', 'hospa'); ?>
                        <strong><?php esc_html_e('bug reports', 'hospa'); ?></strong>
                        <?php 
                        printf(
                            esc_html__('via email at %s or item comments.', 'hospa'),
                            '<a href="mailto:' . esc_attr('hello@hibootstrap.com') . '">hello@hibootstrap.com</a>'
                        ); 
                        ?>
                    </p>

                    <br>

                    <p><?php esc_html_e( 'If you encounter any issues, please submit a ticket through our support system. Our dedicated support team is highly enthusiastic and committed to resolving your concerns as quickly as possible—just give them the opportunity.', 'hospa' ); ?> <a href="<?php echo esc_url( 'https://support.hibootstrap.com/' ); ?>" target="_blank" rel="noopener noreferrer"><i class="wp-menu-image dashicons-before dashicons-tag et-sat-icon"></i> <?php esc_html_e( 'Submit a ticket here', 'hospa' ); ?></a></p>

                    <div class="w-row">
                        <div class="w-col-sm-6"><h3>
                            <?php esc_html_e("🔹 What's Included in Support?", 'hospa'); ?></h3>
                            <ul>
                                <li><?php esc_html_e('Assistance with theme features and issues related to the theme.', 'hospa'); ?></li>
                                <li><?php esc_html_e('Bug fixes and guidance on using the theme.', 'hospa'); ?></li>
                            </ul>
                        </div>
                        <div class="w-col-sm-6 not-included">
                            <h3><?php esc_html_e("🚫 What's Not Included?", 'hospa'); ?></h3>
                            <ul>
                                <li><?php esc_html_e('Custom coding or modifications.', 'hospa'); ?></li>
                                <li><?php esc_html_e('Support for third-party plugins.', 'hospa'); ?></li>
                            </ul>
                        </div>
                    </div>

                    <p><?php esc_html_e('➤ For more details, please check', 'hospa'); ?>
                        <a href="<?php echo esc_url('https://themeforest.net/page/item_support_policy'); ?>" target="_blank" rel="noopener noreferrer">
                            <?php esc_html_e("Envato’s Item Support Policy", 'hospa'); ?>
                        </a>
                    </p>

                    <p><?php esc_html_e('➤ If you need advanced customization or custom work, we recommend', 'hospa'); ?>
                        <a href="<?php echo esc_url('https://hibootstrap.com/submit-your-service-order/'); ?>"  target="_blank" rel="noopener noreferrer"> 
                            <?php esc_html_e('submitting your order here', 'hospa'); ?>
                        </a>
                    </p>
                </div>
            </div>

            <!-- Child Theme Section -->
            <div id="child-theme" class="et-support-section">
            <div class="et-section-title"><?php esc_html_e('📝 Child Theme', 'hospa'); ?></div>
                <div class="et-support-content">
                    <div class="hospa-install-guide">
                        <ol>
                            <li>
                                <strong><?php esc_html_e('Find Hospa Child Theme', 'hospa'); ?></strong><br>
                                <?php esc_html_e('You will find the Hospa Child Theme inside the theme bundle after purchasing.', 'hospa'); ?><br>
                                <?php esc_html_e('Ensure that you have downloaded the full theme package from', 'hospa'); ?>
                                <a href="<?php echo esc_url('https://themeforest.net/downloads'); ?>" target="_blank" rel="noopener noreferrer">
                                    <?php esc_html_e('ThemeForest.', 'hospa'); ?>
                                </a>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Prepare the Child Theme', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Extract the downloaded ZIP file and locate the', 'hospa'); ?> 
                                <strong><?php esc_html_e('hospa-child.zip', 'hospa'); ?></strong> 
                                <?php esc_html_e('file.', 'hospa'); ?>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Install the Child Theme', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Go to', 'hospa'); ?> 
                                <strong><?php esc_html_e('Dashboard', 'hospa'); ?> → <?php esc_html_e('Appearance', 'hospa'); ?> → <?php esc_html_e('Themes', 'hospa'); ?> → <?php esc_html_e('Add New', 'hospa'); ?> → <?php esc_html_e('Upload Theme.', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Click "Choose File", select', 'hospa'); ?> 
                                <strong><?php esc_html_e('hospa-child.zip', 'hospa'); ?></strong>, 
                                <?php esc_html_e('and click "Install Now".', 'hospa'); ?>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Activate the Child Theme', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Once installed, click', 'hospa'); ?> 
                                <strong><?php esc_html_e('"Activate"', 'hospa'); ?></strong> 
                                <?php esc_html_e('to start using the Hospa Child Theme.', 'hospa'); ?>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Verify Theme Installation', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Ensure that Hospa Parent Theme is installed and active before using the child theme.', 'hospa'); ?><br>
                                <?php esc_html_e('You can check this in', 'hospa'); ?> 
                                <strong><?php esc_html_e('Dashboard', 'hospa'); ?> → <?php esc_html_e('Appearance', 'hospa'); ?> → <?php esc_html_e('Themes.', 'hospa'); ?></strong>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Customize Hospa Theme with Child Theme', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Use the child theme to customize your website without affecting parent theme updates.', 'hospa'); ?><br>
                                <?php esc_html_e('For more details on using child themes, visit the', 'hospa'); ?> 
                                <a href="<?php echo esc_url('https://developer.wordpress.org/themes/advanced-topics/child-themes/'); ?>" target="_blank" rel="noopener">
                                    <?php esc_html_e('WordPress Child Theme Documentation.', 'hospa'); ?>
                                </a>
                            </li>
                        </ol>

                    </div>
                </div>
            </div>

            <!-- Theme Update Section -->
            <div id="theme-update" class="et-support-section">
            <div class="et-section-title"><?php esc_html_e('🔄 Theme Update', 'hospa'); ?></div>
                <div class="et-support-content">
                    <div class="hospa-install-guide">
                        <ol>
                            <li>
                                <strong><?php esc_html_e('Download the Hospa Files', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Log in to your', 'hospa'); ?> 
                                <a href="<?php echo esc_url('https://themeforest.net/downloads'); ?>" target="_blank" rel="noopener noreferrer">
                                    <?php esc_html_e('ThemeForest account.', 'hospa'); ?>
                                </a> 
                                <?php esc_html_e('Navigate to the Downloads tab and locate Hospa.', 'hospa'); ?>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Choose the Correct File', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Select', 'hospa'); ?> 
                                <em><?php esc_html_e('"All files and documentation" (full ZIP folder).', 'hospa'); ?></em>
                                <?php esc_html_e('Extract the ZIP file and locate the', 'hospa'); ?> 
                                <strong><?php esc_html_e('hospa.zip', 'hospa'); ?></strong> 
                                <?php esc_html_e('file.', 'hospa'); ?>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Install the Theme', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Go to', 'hospa'); ?> 
                                <strong><?php esc_html_e('Dashboard', 'hospa'); ?> → <?php esc_html_e('Appearance', 'hospa'); ?> → <?php esc_html_e('Themes', 'hospa'); ?> → <?php esc_html_e('Add New', 'hospa'); ?> → <?php esc_html_e('Upload Theme.', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Click "Choose File", select', 'hospa'); ?> 
                                <strong><?php esc_html_e('hospa.zip', 'hospa'); ?></strong>, 
                                <?php esc_html_e('and click "Install Now".', 'hospa'); ?>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Update the Hospa Toolkit Plugin', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Delete the old Hospa Toolkit plugin.', 'hospa'); ?><br>
                                <?php esc_html_e('Install the updated version from:', 'hospa'); ?>
                                <strong><?php esc_html_e('Dashboard', 'hospa'); ?> → <?php esc_html_e('Hospa Theme', 'hospa'); ?> → <?php esc_html_e('Plugins.', 'hospa'); ?></strong>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Updating the Theme', 'hospa'); ?></strong><br>
                                <?php esc_html_e('For different update methods and detailed instructions, please check the', 'hospa'); ?>
                                <a href="<?php echo esc_url('https://docs.hibootstrap.com/envydoc/hospa-theme-documentation/'); ?>" target="_blank" rel="noopener noreferrer">
                                    <?php esc_html_e('Hospa Theme Documentation.', 'hospa'); ?>
                                </a>
                            </li>
                        </ol>
                    </div>
                </div>
            </div>

            <!-- Pro Plugins Update Section -->
            <div id="pro-plugin-update" class="et-support-section">
                <div class="et-section-title"><?php esc_html_e('🔄 Pro Plugins Update', 'hospa'); ?></div>
                <div class="et-support-content">
                    <div class="hospa-install-guide">
                        <ol>
                            <li>
                                <strong><?php esc_html_e('Note:', 'hospa'); ?></strong><br>
                                <?php esc_html_e("We do not provide licenses for Pro plugins, so automatic updates are not available.", "hospa"); ?>
                                <?php esc_html_e("To receive automatic updates directly from the dashboard, you will need to purchase the Pro plugin separately.", "hospa"); ?>
                                <?php esc_html_e("However, we provide the latest plugin files. Please follow the steps below to update Pro plugins:", "hospa"); ?>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Step 1:', 'hospa'); ?></strong>
                                <?php esc_html_e('Delete the old Pro plugin from your Dashboard.', 'hospa'); ?>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Step 2:', 'hospa'); ?></strong>
                                <?php esc_html_e('Install the updated version from:', 'hospa'); ?>
                                <strong><?php esc_html_e('Dashboard → Hospa Theme → Plugins.', 'hospa'); ?></strong>
                            </li>
                        </ol>
                    </div>
                </div>
            </div>

            <!-- 404 Error Section -->
            <div id="error-404" class="et-support-section">
                <div class="et-section-title"><?php esc_html_e('🛠 Fix 404 Page Not Found Issue', 'hospa'); ?></div>
                <div class="et-support-content">
                    <div class="hospa-install-guide">
                        <ol>
                            <li>
                                <strong><?php esc_html_e('Step 1: Reset Permalinks(Most Common Fix)', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Go to', 'hospa'); ?>
                                <strong><?php esc_html_e('Dashboard → Settings → Permalinks', 'hospa'); ?></strong>.<br>
                                <?php esc_html_e('Select', 'hospa'); ?>
                                <strong><?php esc_html_e('Post name', 'hospa'); ?></strong>
                                <?php esc_html_e('(or your preferred permalink structure).', 'hospa'); ?><br>
                                <?php esc_html_e('Click', 'hospa'); ?>
                                <strong><?php esc_html_e('Save Changes', 'hospa'); ?></strong>
                                <?php esc_html_e('(even if it was already selected).', 'hospa'); ?><br>
                                <?php esc_html_e('Refresh your website and check if the issue is resolved.', 'hospa'); ?>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Step 2:', 'hospa'); ?></strong>
                                <?php esc_html_e('If the issue persists, ensure your .htaccess file is correctly configured. You may need to update or reset it.', 'hospa'); ?>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Step 3:', 'hospa'); ?></strong>
                                <?php esc_html_e('Deactivate all plugins to check for conflicts, then reactivate them one by one.', 'hospa'); ?>
                            </li>
                        </ol>
                    </div>
                </div>
            </div>

            <!-- Elementor Page Not Loading Issue Section -->
            <div id="elementor-issue" class="et-support-section">
                <div class="et-section-title"><?php esc_html_e('⏳ Fix Elementor Page Not Loading Issue', 'hospa'); ?></div>
                <div class="et-support-content">
                    <div class="hospa-install-guide">
                        <ol>

                            <li>
                                <strong><?php esc_html_e('Step 1: Increase PHP Memory Limit(Most Common Fix)', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Elementor may require more memory. Increase it by adding the following line to your wp-config.php file:', 'hospa'); ?>
                                <code>define( 'WP_MEMORY_LIMIT', '256M' );</code>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Step 2: Enable Switch Editor Loader(Most Common Fix)', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Go to', 'hospa'); ?>
                                <strong><?php esc_html_e('Elementor → Settings → Advanced', 'hospa'); ?></strong>.<br>
                                <?php esc_html_e('Enable', 'hospa'); ?>
                                <strong><?php esc_html_e('"Switch Editor Loader Method"', 'hospa'); ?></strong>
                                <?php esc_html_e('option and save changes.', 'hospa'); ?>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Step 3: Reset Permalinks', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Go to', 'hospa'); ?>
                                <strong><?php esc_html_e('Dashboard → Settings → Permalinks', 'hospa'); ?></strong>.<br>
                                <?php esc_html_e('Select', 'hospa'); ?>
                                <strong><?php esc_html_e('Post name', 'hospa'); ?></strong>
                                <?php esc_html_e('(or your preferred permalink structure).', 'hospa'); ?><br>
                                <?php esc_html_e('Click', 'hospa'); ?>
                                <strong><?php esc_html_e('Save Changes', 'hospa'); ?></strong>
                                <?php esc_html_e('(even if it was already selected).', 'hospa'); ?><br>
                                <?php esc_html_e('Refresh your website and check if the issue is resolved.', 'hospa'); ?>
                            </li>

                            <li>
                                <strong><?php esc_html_e('Step 4: Plugin Conflict Check', 'hospa'); ?></strong><br>
                                <?php esc_html_e('Deactivate all plugins except Elementor to check for conflicts, then reactivate them one by one.', 'hospa'); ?>
                            </li>
                        </ol>
                    </div>
                </div>
            </div>

            <div class="more-et-theme-doc"></div>

        </div>
    </div>

</div> <!-- end wrap -->
