<?php
/**
 * Hospa Dashboard - More Themes Page
 *
 * @package Hospa
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

?>

<div class="wrap about-wrap et-admin-wrap">

    <!-- Navigation Tabs -->
    <?php hospa_admin_navigation_tabs( 'hospa-more-themes' ); ?>

    <div id="hospa-dashboard" class="wrap about-wrap">
        <div class="welcome-content w-clearfix extra">

            <!-- HiBootstrap.com Items -->
            <div class="etd-more-themes">
                <div class="w-row middle">
                    <div class="w-col-sm-6">
                        <div class="et-profile">
                            <h3><?php esc_html_e( 'HiBootstrap Popular Items', 'hospa' ); ?></h3>
                            <span><?php esc_html_e( 'Buy Premium Quality Themes, Templates for Your Website!', 'hospa' ); ?></span>
                        </div>
                    </div>

                    <div class="w-col-sm-6 text-right">
                        <a target="_blank" class="more-btn" href="https://hibootstrap.com/" rel="noopener noreferrer">
                            <?php esc_html_e( 'Browse All', 'hospa' ); ?>
                        </a>
                    </div>
                </div>
                <div class="et-com-themes w-row"></div>
            </div>

            <!-- Hire Us Section -->
            <div class="etd-more-themes etd-more-themes-2 et-hire-us">
                <div class="et-profile">
                    <h3><?php esc_html_e( 'Need Custom Project Work?', 'hospa' ); ?></h3>
                    <p>
                        <?php esc_html_e( 'We provide full-depth web, mobile, and eCommerce project work, including UX/UI design, development, customization, maintenance, and management.', 'hospa' ); ?>
                        <?php esc_html_e( 'If you have a project and need our services, feel free to send an email for a quote with your project details:', 'hospa' ); ?>
                        <strong>
                            <a href="mailto:hello@hibootstrap.com"><u><?php esc_html_e( 'Click to Email', 'hospa' ); ?></u></a>
                        </strong>
                    </p>
                    <a target="_blank" class="more-btn" href="mailto:hello@hibootstrap.com">
                        <?php esc_html_e( 'Hire Us', 'hospa' ); ?>
                    </a>
                </div>
            </div>

            <!-- Social Media Links -->
            <div class="hospa-social-section">
                <div class="hospa-social-box">
                    <h3 class="hospa-section-title"><?php esc_html_e( 'Follow Us On:', 'hospa' ); ?></h3>
                    <div class="hospa-social-networks">
                        <a href="https://twitter.com/HiBootstrap" rel="noopener noreferrer" title="Twitter" target="_blank" class="twitter">
                            <img src="<?php echo esc_url( get_template_directory_uri() . '/inc/theme-dashboard/images/social/twitter-x.svg' ); ?>" alt="Twitter">
                        </a>
                       
                        <a href="https://www.facebook.com/HiBootstrap" rel="noopener noreferrer" title="Facebook" target="_blank" class="facebook">
                            <img src="<?php echo esc_url( get_template_directory_uri() . '/inc/theme-dashboard/images/social/facebook.svg' ); ?>" alt="Facebook">
                        </a>
                       
                        <a href="https://www.youtube.com/@HiBootstrap" rel="noopener noreferrer" title="YouTube" target="_blank" class="youtube">
                            <img src="<?php echo esc_url( get_template_directory_uri() . '/inc/theme-dashboard/images/social/youtube.svg' ); ?>" alt="YouTube">
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div> <!-- end wrap -->
