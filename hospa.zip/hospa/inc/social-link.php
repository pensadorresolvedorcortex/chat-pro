<?php
/**
 * Social Link
 * @package WordPress
 * @subpackage hospa
*/

if ( ! function_exists( 'hospa_social_link' ) ) :
    function hospa_social_link(){
        global $hospa_opt;

        if( isset( $hospa_opt['hospa_social_target'] ) ) {
            $target = $hospa_opt['hospa_social_target'];
        }else {
            $target = '_blank';
        }
        ?>

            <?php if (isset($hospa_opt['facebook_url'] ) && $hospa_opt['facebook_url']) { ?>
                <li>
                    <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($hospa_opt['facebook_url']); ?>" class="facebook"> <i class="ri-facebook-fill"></i></a>
                </li>
            <?php  } ?>

            <?php if (isset($hospa_opt['twitter_url'] ) && $hospa_opt['twitter_url']) { ?>
                <li>
                    <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($hospa_opt['twitter_url']);?>" class="twitter" ><i class="ri-twitter-x-line"></i></a>
                </li>
            <?php  } ?>

            <?php if (isset($hospa_opt['instagram_url'] ) && $hospa_opt['instagram_url'] ) { ?>
                <li>
                    <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($hospa_opt['instagram_url']); ?>" class="instagram"> <i class="ri-instagram-line"></i></a>
                </li>
            <?php  } ?>

            <?php
            if (isset($hospa_opt['linkedin_url'] ) && $hospa_opt['linkedin_url'] ) { ?>
            <li>
                <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($hospa_opt['linkedin_url']);?>" > <i class="ri-linkedin-fill"></i></a>
            </li>
            <?php  } ?>

            <?php
            if (isset($hospa_opt['pinterest_url'] ) && $hospa_opt['pinterest_url'] ) { ?>
            <li>
                <a target="<?php echo esc_attr($target); ?>" href="<?php echo esc_url($hospa_opt['pinterest_url']);?>" > <i class="ri-pinterest-fill"></i></a>
            </li>
            <?php  } ?>

            <?php if (isset($hospa_opt['dribbble_url'] ) && $hospa_opt['dribbble_url'] ) { ?>
                <li>
                    <a target="<?php echo esc_attr($target); ?>" href="<?php echo esc_url($hospa_opt['dribbble_url']);?>" > <i class="ri-dribbble-fill"></i></a>
                </li>
            <?php } ?>

            <?php if (isset($hospa_opt['tumblr_url'] ) && $hospa_opt['tumblr_url'] ) { ?>
                <li>
                    <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($hospa_opt['tumblr_url']);?>" ><i class="ri-tumblr-line"></i></a>
                </li>
            <?php } ?>

            <?php
            if (isset($hospa_opt['youtube_url'] ) && $hospa_opt['youtube_url'] ) { ?>
            <li>
                <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($hospa_opt['youtube_url']);?>" > <i class="ri-youtube-fill"></i></a>
            </li>
            <?php  } ?>

            <?php if (isset($hospa_opt['flickr_url'] ) && $hospa_opt['flickr_url'] ) { ?>
                <li>
                    <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($hospa_opt['flickr_url']);?>" > <i class="ri-flickr-fill"></i></a>
                </li>
            <?php } ?>

            <?php if (isset($hospa_opt['behance_url'] ) && $hospa_opt['behance_url'] ) { ?>
                <li>
                    <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($hospa_opt['behance_url']);?>" > <i class="ri-behance-line"></i></a>
                </li>
            <?php } ?>

            <?php if (isset($hospa_opt['github_url'] ) &&  $hospa_opt['github_url'] ) { ?>
                <li>
                    <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($hospa_opt['github_url']);?>" ><i class="ri-github-fill"></i></a>
                </li>
            <?php } ?>

            <?php if (isset($hospa_opt['skype_url'] ) && $hospa_opt['skype_url'] ) { ?>
                <li>
                    <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($hospa_opt['skype_url']);?>" > <i class="ri-skype-fill"></i></a>
                </li>
            <?php } ?>

            <?php if (isset($hospa_opt['rss_url'] ) && $hospa_opt['rss_url'] ) { ?>
                <li>
                    <a target="<?php echo esc_attr($target); ?>" href="<?php  echo esc_url($hospa_opt['rss_url']);?>" > <i class="ri-rss-fill"></i></a>
                </li>
            <?php } ?>
    <?php
    }
endif; 


// Shortcode to return the output of hospa_social_link()

if ( ! function_exists( 'hospa_social_link_shortcode' ) ) :
    function hospa_social_link_shortcode() {
        ?>
        <ul class="ft-social-link">
            <?php hospa_social_link(); ?>
        </ul>
    <?php
     
    }

    // Register the shortcode
    add_shortcode('hospa_social_link', 'hospa_social_link_shortcode');
endif; 
