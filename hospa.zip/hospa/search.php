<?php
/**
 * The archive fileΩ
 * @package hospa
 */
get_header();
if ( class_exists( 'Header_Footer_Elementor' ) ) { 
    hospa_preloader();
}

include get_template_directory() . '/inc/banner/blog-header.php';
?>
    <!-- Start Page Title Area -->
    <?php if( $hide_banner == false ) : ?>
        <div class="page-banner-area">
            <div class="container-fluid">
                <?php if( $enable_pb_img == false ): ?>
					<?php if( $banner_image != '' ): ?>
						<div class="page-banner-image">
							<img src="<?php echo esc_url( $banner_image ); ?>" alt="<?php esc_attr_e( 'banner img', 'hospa' ); ?>">
						</div>
						<div class="page-banner-inner">
					<?php else: ?>
						<div class="page-banner-inner without-image">
					<?php endif; ?>
				<?php else: ?>
					<div class="page-banner-inner without-image">
				<?php endif; ?>
                    <div class="row justify-content-center align-items-center">
                        <div class="col-lg-8 col-md-12">
                            <div class="content">
                                <<?php echo esc_attr( $tag ); ?>> <?php printf( esc_html__( 'Search Results for: %s', 'hospa' ), '<span>' . get_search_query() . '</span>' ); ?> </<?php echo esc_attr( $tag ); ?>>

                                <?php if( $hide_breadcrumb == false ) : ?>
                                    <ul class="list">
                                        <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'hospa' ); ?></a></li>
                                        <li><?php printf( esc_html__( 'Search Results for: %s', 'hospa' ), '<span>' . get_search_query() . '</span>' ); ?></li>
                                    </ul>
                                <?php endif; ?>
                            </div>
                        </div>
						
                        <div class="col-lg-4 col-md-12">
                            <ul class="information">
                                <?php if($custom_desc != ' ' || $phn_num != ' '): ?>
									<li>
										<div class="phone-btn">

											<?php if($header_phnicon != ' '): ?>
											<div class="icon">
												<i class="<?php echo esc_attr($header_phnicon); ?>"></i>
											</div>
											<?php endif; ?>
											<span>
												<?php echo wp_kses( $custom_desc, 'hospaallowedhtml' ); ?>

												<?php if($phn_num_link != ''): ?>
                                                <a href="<?php echo esc_url($phn_num_link); ?>">
                                                <?php endif; ?>
                                                    
                                                    <?php echo  esc_html($phn_num); ?>
                                                    
                                                <?php if($phn_num_link != ''): ?>
                                                </a>
                                                <?php endif; ?>
											</span>
										</div>
									</li>
								<?php endif; ?>

								<?php if( $hide_banner_meta == false ) : ?>
                                <li>
                                    <ul class="info-list">
                                        <li>
                                            <button onclick="window.print()">
                                                <i class="ti ti-printer"></i>
                                            </button>
                                        </li>
									
										<?php if($page_mail_link != ' '): ?>
											<li>
												<a href="<?php echo esc_url($page_mail_link); ?>"><i class="ti ti-mail-opened"></i></a>
											</li>
										<?php endif; ?>

										<?php if( $is_social_share == '1' ):
											$share_url      = get_the_permalink();
											$share_title    = get_the_title();
											$share_desc     = get_the_excerpt();
										?>
                                        <li>
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="ti ti-share"></i>
                                                </button>
                                                <ul class="dropdown-menu">
													<?php if( $hospa_opt['enable_product_fb'] == '1' ): ?>
														<li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url($share_url); ?>" onclick="window.open(this.href, 'facebook-share','width=580,height=296'); return false;" target="_blank"><i class="ti ti-brand-facebook"></i></a></li>
													<?php endif; ?>

													<?php if( $hospa_opt['enable_product_tw'] == '1' ): ?>
														<li><a href="https://twitter.com/share?text=<?php echo urlencode($share_title); ?>&url=<?php echo esc_url($share_url); ?>" target="_blank"><i class="ti ti-brand-x"></i></a></li>
													<?php endif; ?>

													<?php if( $hospa_opt['enable_product_ld'] == '1' ): ?>
														<li><a href="https://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo esc_url($share_url); ?>&amp;title=<?php echo urlencode($share_title); ?>&amp;summary=&amp;source=<?php bloginfo('name'); ?>" onclick="window.open(this.href, 'linkedin','width=580,height=296'); return false;" target="_blank"><i class="ti ti-brand-linkedin"></i></a></li>
													<?php endif; ?>
                                                </ul>
                                            </div>
                                        </li>
										<?php endif; ?>
                                    </ul>
                                </li>
								<?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Start Blog Area -->
    <div class="blog-area ptb-100">
        <div class="container">
            <div class="row">
                <?php if( $sidebar_hide == 'hospa_with_sidebar_left' ): ?>
                    <?php get_sidebar(); ?>
                <?php endif; ?>
                <!-- Start Blog Content -->
                <div class="<?php echo esc_attr( $hospa_sidebar_class ); ?>">
                    <div class="blog-left-sidebar">
                        <div class="row">
                            <?php
                            if ( have_posts() ) :
                                while ( have_posts() ) :
                                    the_post();
                                    get_template_part( 'template-parts/content', get_post_format());
                                endwhile;
                            else :
                                get_template_part( 'template-parts/content', 'none' );
                            endif;
                            ?>
                    
                            <!-- Stat Pagination -->
                            <?php hospa_pagination(); ?>
                        </div>
                    </div>
                </div>
                <!-- End Blog Content -->
                
                <?php if( $sidebar_hide == 'hospa_with_sidebar_right' ): ?>
                    <?php get_sidebar(); ?>
                <?php endif; ?>
            </div>   
        </div>
    </div>

<?php
if ( class_exists( 'Header_Footer_Elementor' ) ) { 
    hospa_backtotop();
}
get_footer();