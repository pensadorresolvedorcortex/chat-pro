<?php
/**
 * The single template file
 * @package Hospa
*/

get_header();
if ( class_exists( 'Header_Footer_Elementor' ) ) { 
	hospa_preloader();
}

include get_template_directory() . '/inc/banner/single-blog-header.php';
?>
	<?php if( $hide_banner == false ) { ?>
		<div class="page-banner-area">
            <div class="container-fluid">
				<?php if( $enable_pb_img == false ): ?>
					<?php if( $banner_image != '' ): ?>
						<div class="page-banner-image">
							<img src="<?php echo esc_url( $banner_image ); ?>" alt="<?php esc_attr_e( 'banner img', 'hospa' ); ?>">
						</div>
						<div class="page-banner-inner">
					<?php else: ?>
						<div class="page-banner-inner without-image">
					<?php endif; ?>
				<?php else: ?>
					<div class="page-banner-inner without-image">
				<?php endif; ?>

                    <div class="row justify-content-center align-items-center">
                        <div class="col-lg-8 col-md-12">
                            <div class="content">
								<?php if( $custom_title == true && get_field( 'cus_pagetitle') != '' ) : ?>
									<<?php echo esc_attr( $tag ); ?>>
										<?php echo wp_kses( get_field( 'cus_pagetitle' ), 'hospaallowedhtml' ); ?>
									</<?php echo esc_attr( $tag ); ?>>
								<?php elseif( $title != '' ): ?>
									<<?php echo esc_attr( $tag ); ?>><?php the_title(); ?></<?php echo esc_attr( $tag ); ?>>
								<?php else: ?>
									<<?php echo esc_attr( $tag ); ?>><?php esc_html_e('No Title', 'hospa'); ?></<?php echo esc_attr( $tag ); ?>>
								<?php endif; ?> 

								<?php if( $hide_breadcrumb == false ) : ?>
									<?php if ( function_exists('yoast_breadcrumb') ) {
										yoast_breadcrumb( '<p class="hospa-seo-breadcrumbs" id="breadcrumbs">','</p>' );
									} else { ?>
					  				<ul class="list">
										<li>
											<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'hospa' ); ?></a>
										</li>

										<?php
										$post_type = get_post_type();

										// If it's a blog post, get the blog page
										if ( $post_type === 'post' ) {
											$blog_page_id = get_option( 'page_for_posts' );
											if ( $blog_page_id ) { ?>
												<li><a href="<?php echo esc_url( get_permalink( $blog_page_id ) ) ?>"> <?php echo esc_html( get_the_title( $blog_page_id ) ) ?> </a></li>
											<?php }
										}
										?>

										<?php if ( $title != ' ' ){ ?>
											<li><?php the_title(); ?></li>
										<?php } else { ?>
											<li><?php esc_html_e('No Title', 'hospa'); ?></li>
										<?php } ?>
									</ul>
								<?php } endif; ?>
                            </div>
                        </div>
						
                        <div class="col-lg-4 col-md-12">
                            <ul class="information">
								<?php if($custom_desc != ' ' || $phn_num != ' '): ?>
									<li>
										<div class="phone-btn">

											<?php if($header_phnicon != ' '): ?>
											<div class="icon">
												<i class="<?php echo esc_attr($header_phnicon); ?>"></i>
											</div>
											<?php endif; ?>
											<span>
												<?php echo wp_kses( $custom_desc, 'hospaallowedhtml' ); ?>

												<?php if($phn_num_link != ''): ?>
                                                <a href="<?php echo esc_url($phn_num_link); ?>">
                                                <?php endif; ?>
                                                    
                                                    <?php echo esc_html($phn_num); ?>
                                                    
                                                <?php if($phn_num_link != ''): ?>
                                                </a>
                                                <?php endif; ?>
											</span>
										</div>
									</li>
								<?php endif; ?>

								<?php if( $hide_banner_meta == false ) : ?>
                                <li>
                                    <ul class="info-list">
                                        <li>
                                            <button onclick="window.print()">
                                                <i class="ti ti-printer"></i>
                                            </button>
                                        </li>
									
										<?php if($page_mail_link != ' '): ?>
											<li>
												<a href="<?php echo esc_url($page_mail_link); ?>"><i class="ti ti-mail-opened"></i></a>
											</li>
										<?php endif; ?>

										<?php if( $is_social_share == '1' ):
											$share_url      = get_the_permalink();
											$share_title    = get_the_title();
											$share_desc     = get_the_excerpt();
										?>
                                        <li>
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="ti ti-share"></i>
                                                </button>
                                                <ul class="dropdown-menu">
													<?php if( $hospa_opt['enable_product_fb'] == '1' ): ?>
														<li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url($share_url); ?>" onclick="window.open(this.href, 'facebook-share','width=580,height=296'); return false;" target="_blank"><i class="ti ti-brand-facebook"></i></a></li>
													<?php endif; ?>

													<?php if( $hospa_opt['enable_product_tw'] == '1' ): ?>
														<li><a href="https://twitter.com/share?text=<?php echo urlencode($share_title); ?>&url=<?php echo esc_url($share_url); ?>" target="_blank"><i class="ti ti-brand-x"></i></a></li>
													<?php endif; ?>

													<?php if( $hospa_opt['enable_product_ld'] == '1' ): ?>
														<li><a href="https://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo esc_url($share_url); ?>&amp;title=<?php echo urlencode($share_title); ?>&amp;summary=&amp;source=<?php bloginfo('name'); ?>" onclick="window.open(this.href, 'linkedin','width=580,height=296'); return false;" target="_blank"><i class="ti ti-brand-linkedin"></i></a></li>
													<?php endif; ?>
                                                </ul>
                                            </div>
                                        </li>
										<?php endif; ?>
                                    </ul>
                                </li>
								<?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	<?php } ?>

	<!-- Start Blog Area -->
	<div class="blog-details-area ptb-100">
		<div class="container">
			<div class="row">
				<?php if( $sidebar_hide == 'hospa_with_sidebar_left' ): ?>
                    <?php get_sidebar(); ?>
                <?php endif; ?>

				<?php 
				while ( have_posts() ) : the_post(); 
					$categories = get_the_category();
					$user       = get_the_author_meta('ID');
					$user_image  = get_avatar_url($user, ['size' => '51']); 
					?>
					<div class="<?php echo esc_attr( $hospa_sidebar_class ); ?>">
						<div class="blog-details blog-left-sidebar"> 
							<div class="blog-details-meta">
								<?php if( has_post_thumbnail() ): ?>
									<div class="image">
										<img src="<?php the_post_thumbnail_url('full') ?>" alt="<?php the_title_attribute(); ?>">
									</div>
								<?php endif; ?>

								<?php if( $is_post_meta ): ?>
									<ul class="meta">
										<?php if($categories): ?>
										<li>
											<a href="<?php echo esc_url(get_category_link( $categories[0]->term_id )) ?>" class="tag-btn"><?php echo esc_html($categories[0]->name); ?></a>
										</li>
										<?php endif; ?>
										<li><?php echo esc_html(get_the_date()) ?></li>
										<li><?php echo hospa_reading_time(); ?> <?php echo esc_html( $min_text );?></li>
									</ul>
								<?php endif; ?>
							</div>

							<div class="blog-details-content">

								<?php the_content(); ?>
								
								<?php wp_link_pages( array(
									'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'hospa' ),
									'after'  => '</div>',
								) );
								?>

								<?php
									global $hospa_opt;
								
									if( $is_post_social_share == '1' ):
									$share_url      = get_the_permalink();
									$share_title    = get_the_title();
								?>
									<div class="article-social">
										<?php if($share_text != ''): ?>
											<span><?php echo esc_html($share_text); ?></span>
										<?php endif; ?>
										<ul class="social">
											<?php if( $hospa_opt['enable_blog_post_fb'] == '1' ): ?>

												<li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url($share_url); ?>" onclick="window.open(this.href, 'facebook-share','width=580,height=296'); return false;"  target="_blank"><i class="flaticon-facebook"></i></a></li>

											<?php endif; ?>

											<?php if( $hospa_opt['enable_blog_post_twit'] == '1' ): ?>
												<li><a href="https://twitter.com/share?text=<?php echo urlencode($share_title); ?>&url=<?php echo esc_url($share_url); ?>"  target="_blank"><i class="flaticon-twitter"></i></a></li>
											<?php endif; ?>

											<?php if( $hospa_opt['enable_blog_post_linked'] == '1' ): ?>
												<li><a href="https://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo esc_url($share_url); ?>&amp;title=<?php echo urlencode($share_title); ?>&amp;summary=&amp;source=<?php bloginfo('name'); ?>" onclick="window.open(this.href, 'linkedin','width=580,height=296'); return false;"  target="_blank"><i class="flaticon-linkedin"></i></a></li>
											<?php endif; ?>
										</ul>
									</div>
								<?php endif; ?>

								<?php if(get_previous_post() || get_next_post()): ?>
									<?php if($previous_label || $next_label): ?>
										<div class="article-pnext-post">
											<div class="row justify-content-center">
												<div class="col-lg-6 col-md-6">
													<div class="previous-post">
														<?php $prev_post = get_previous_post(); ?>
														<?php if (!empty($prev_post)) : ?>
															<a href="<?php echo get_permalink($prev_post->ID); ?>" class="previous-title">
																<i class="ti ti-arrow-narrow-left"></i>
																<?php echo esc_html($previous_label); ?>
															</a>
															<div class="item">
																<?php if( has_post_thumbnail($prev_post->ID) ): ?>
																	<div class="image">
																		<a href="<?php echo get_permalink($prev_post->ID); ?>" class="thumb">
																			<span class="fullimage" role="img"><?php echo get_the_post_thumbnail($prev_post->ID, 'thumbnail'); ?></span>
																		</a>
																	</div>
																<?php endif; ?>

																<div class="info">
																	<h4 class="title usmall">
																		<a href="<?php echo get_permalink($prev_post->ID); ?>"><?php echo esc_html($prev_post->post_title); ?></a>
																	</h4>
																	<a href="<?php echo get_permalink($prev_post->ID); ?>" class="blog-btn"><i class="ti ti-arrow-right"></i> <?php esc_html_e('Read More', 'hospa'); ?></a>
																</div>
															</div>
														<?php endif; ?>
													</div>
												</div>
												<div class="col-lg-6 col-md-6">
													<div class="next-post">
														<?php $next_post = get_next_post(); ?>
														<?php if (!empty($next_post)) : ?>
															<a href="<?php echo get_permalink($next_post->ID); ?>" class="next-title">
																<?php echo esc_html($next_label); ?>
																<i class="ti ti-arrow-narrow-right"></i>
															</a>
															<div class="item">
																<div class="info">
																	<h4 class="title usmall">
																		<a href="<?php echo get_permalink($next_post->ID); ?>"><?php echo esc_html($next_post->post_title); ?></a>
																	</h4>
																	<a href="<?php echo get_permalink($next_post->ID); ?>" class="blog-btn"><i class="ti ti-arrow-right"></i><?php esc_html_e('Read More', 'hospa'); ?></a>
																</div>

																<?php if( has_post_thumbnail($next_post->ID) ): ?>
																	<div class="image">
																		<a href="<?php echo get_permalink($next_post->ID); ?>" class="thumb">
																			<span class="fullimage" role="img"><?php echo get_the_post_thumbnail($next_post->ID, 'thumbnail'); ?></span>
																		</a>
																	</div>
																<?php endif; ?>
															</div>
														<?php endif; ?>
													</div>
												</div>
											</div>
										</div>
										
									<?php endif; ?>
								<?php endif; ?>

							</div>
						</div>
					
						<?php
						// If comments are open or we have at least one comment, load up the comment template.
						if ( comments_open() || get_comments_number() ) :
							comments_template();
						endif;
						?>
					</div> <?php 
				endwhile; // End of the loop.
				?>
				
				<?php if( $sidebar_hide == 'hospa_with_sidebar_right' ): ?>
					<?php get_sidebar(); ?>
				<?php endif; ?>

			</div>
		</div>
	</div>

<?php
if ( class_exists( 'Header_Footer_Elementor' ) ) { 
	hospa_backtotop();
}
get_footer();
