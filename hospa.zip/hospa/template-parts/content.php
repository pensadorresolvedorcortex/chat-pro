<?php global $hospa_opt;
/**
 * @package Hospa
 */


$read_more     = isset($hospa_opt['read_more']) && $hospa_opt['read_more'] != '' ? $hospa_opt['read_more'] : esc_html__('Read More', 'hospa');
$thumb_size     = isset($hospa_opt['hospa_blog_sidebar']) && $hospa_opt['hospa_blog_sidebar'] == 'hospa_without_sidebar' ? 'full' : 'hospa_standard_card';
$is_post_meta   = isset( $hospa_opt['is_post_meta']) ? $hospa_opt['is_post_meta'] : true;
$hospa_blog_grid = !empty($hospa_opt['hospa_blog_grid']) ? $hospa_opt['hospa_blog_grid'] : 'col-lg-12 col-md-12';
$categories = get_the_category();

if(hospa_reading_time() > 1){
    $min_text     = isset($hospa_opt['min_text']) && $hospa_opt['min_text'] != '' ? $hospa_opt['min_text'] : esc_html__('MINS READ', 'hospa');
}else {
    $min_text     = isset($hospa_opt['min_text']) && $hospa_opt['min_text'] != '' ? $hospa_opt['min_text'] : esc_html__('MIN READ', 'hospa');
}

?>
<div <?php post_class($hospa_blog_grid); ?>>
    <div class="blog-card single-blog-card">
        <?php if(has_post_thumbnail()) { ?>
            <div class="blog-image">
                <a href="<?php the_permalink(); ?>" class="blog-img d-block">
                    <img src="<?php the_post_thumbnail_url($thumb_size) ?>" alt="<?php the_title_attribute(); ?>">
                </a>
                <?php if($categories): ?>
                <a href="<?php echo esc_url(get_category_link( $categories[0]->term_id )) ?>" class="tag-btn"><?php echo esc_html($categories[0]->name); ?></a>
                <?php endif; ?>
            </div>
            <div class="blog-content with-img">
        <?php } else { ?>
            <div class="blog-content">
        <?php } ?>
            <ul class="meta">
                <li><?php echo esc_html(get_the_date()) ?></li>
                <li><?php echo hospa_reading_time(); ?> <?php echo esc_html( $min_text );?></li>
            </ul>
            <h3>
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </h3>
            <a href="<?php the_permalink(); ?>" class="blog-btn"><i class="ti ti-arrow-right"></i><?php echo esc_html( $read_more );?></a>
        </div>
    </div>

</div>