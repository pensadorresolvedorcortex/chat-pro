<?php global $hospa_opt;
/**
 * @package Hospa
*/

$hide_top_header        = !empty($hospa_opt['hide_top_header']) ? $hospa_opt['hide_top_header'] : false;
$top_header_text        = !empty($hospa_opt['top_header_text']) ? $hospa_opt['top_header_text'] : '';
$top_header_link_text   = !empty($hospa_opt['top_header_link_text']) ? $hospa_opt['top_header_link_text'] : '';
$th_btn_link_type 	  = !empty($hospa_opt['th_linktext_link_type']) ? $hospa_opt['th_linktext_link_type'] : 'internal_link';
if( $th_btn_link_type == 'internal_link') {
    $top_header_link  = !empty($hospa_opt['top_header_link']) ? $hospa_opt['top_header_link'] : '';
} else {
    $top_header_link  = !empty($hospa_opt['th_btn_link_external']) ? $hospa_opt['th_btn_link_external'] : '#';
}
$th_arrow_icon          = !empty($hospa_opt['th_arrow_icon']) ? $hospa_opt['th_arrow_icon'] : 'ti ti-arrow-right';

$top_header_btn_icon    = !empty($hospa_opt['top_header_btn_icon']) ? $hospa_opt['top_header_btn_icon'] : '';
$top_header_btn         = !empty($hospa_opt['top_header_btn']) ? $hospa_opt['top_header_btn'] : '';
$th_appbtn_link_type 	  = !empty($hospa_opt['th_appbtn_link_type']) ? $hospa_opt['th_appbtn_link_type'] : 'internal_link';
if( $th_appbtn_link_type == 'internal_link') {
    $top_header_btn_link    = !empty($hospa_opt['top_header_btn_link']) ? $hospa_opt['top_header_btn_link'] : '';
} else {
    $top_header_btn_link  = !empty($hospa_opt['th_appbtn_link_external']) ? $hospa_opt['th_appbtn_link_external'] : '#';
}

$enable_search 	  = !empty($hospa_opt['enable_search']) ? $hospa_opt['enable_search'] : false;
$search_ph_text   = !empty($hospa_opt['search_ph_text']) ? $hospa_opt['search_ph_text'] : '';
$search_icon      = !empty($hospa_opt['search_icon']) ? $hospa_opt['search_icon'] : 'ti ti-search';

$header_btn_icon  = !empty($hospa_opt['header_btn_icon']) ? $hospa_opt['header_btn_icon'] : 'ti ti-alarm-plus-filled';
$header_btn_text  = !empty($hospa_opt['header_btn_text']) ? $hospa_opt['header_btn_text'] : '';
$btn_link_type 	  = !empty($hospa_opt['hbtn_link_type']) ? $hospa_opt['hbtn_link_type'] : 'internal_link';
if( $btn_link_type == 'internal_link') {
    $header_btn_link  = !empty($hospa_opt['header_btn_link']) ? $hospa_opt['header_btn_link'] : '';
} else {
    $header_btn_link  = !empty($hospa_opt['hbtn_link_external']) ? $hospa_opt['hbtn_link_external'] : '#';
}


if( function_exists('acf_add_options_page') ) {
    $nav_width          = get_field( 'choose_nav_width' );
    if( is_home() ) {
        $post_page_id   = get_option( 'page_for_posts' );
        $nav_width      = get_field( 'choose_nav_width' , $post_page_id );
    }
    if ( class_exists( 'WooCommerce' ) ){
        if( is_shop() ) {
            $post_page_id  = get_option( 'woocommerce_shop_page_id' );
            $nav_width      = get_field( 'choose_nav_width' , $post_page_id );
        }
    }
    if($nav_width == ''){
        $nav_width   = 'container-fluid';
    }
} else {
    $nav_width   = 'container-fluid';
}

$th_res_text  = !empty($hospa_opt['th_res_text']) ? $hospa_opt['th_res_text'] : '';

$nav_btn_social          = !empty($hospa_opt['nav_btn_social']) ? $hospa_opt['nav_btn_social'] : 'btn_display';
$social_icon_shortcode   = !empty($hospa_opt['social_icon_shortcode']) ? $hospa_opt['social_icon_shortcode'] : '';
// WP admin bar
$hide_wp_nav = 'hide-wp-nav'; ?>



    <?php if( $hide_top_header == true ): ?>
        <div class="top-header-area">
            <div class="container-fluid">
                <div class="row justify-content-center align-items-center">
                    <?php if($top_header_text != '' || $top_header_link_text != ''): ?>
                        <div class="col-lg-8 col-md-12">
                            <div class="top-header-info">
                                <p><?php echo esc_html($top_header_text); ?> 
                                    <?php if($th_btn_link_type == 'internal_link'): ?>
                                    <a href="<?php echo esc_url( home_url( $top_header_link ) ); ?>">
                                    <?php else: ?>
                                    <a href="<?php echo esc_url( $top_header_link ); ?>" target="_blank">
                                    <?php endif; ?>
                                    
                                        <?php echo esc_html($top_header_link_text); ?>
                                        <?php if( $th_arrow_icon != '' ): ?>
                                        <i class="<?php echo esc_attr($th_arrow_icon); ?>"></i>
                                        <?php endif; ?>
                                    </a>
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($top_header_btn != ''): ?>
                        <div class="col-lg-4 col-md-12">
                            <div class="top-header-btn">
                                <?php if($th_appbtn_link_type == 'internal_link'): ?>
                                <a href="<?php echo esc_url(home_url($top_header_btn_link));?>">
                                <?php else: ?>
                                <a href="<?php echo esc_url( $top_header_btn_link ); ?>" target="_blank">
                                <?php endif; ?>
                                    <i class="<?php echo esc_attr($top_header_btn_icon);?>"></i>
                                    <?php echo esc_html($top_header_btn);?>
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="main-header-area <?php if ( is_user_logged_in() ) { echo esc_attr( $hide_wp_nav ); } ?>">
        <nav class="navbar navbar-expand-xl navbar-area-with-transparent-color <?php if ( is_user_logged_in() ) { echo esc_attr( $hide_wp_nav ); } ?>" id="navbar">
            <div class="<?php echo esc_attr($nav_width); ?>">
                <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                    <?php main_logo(); ?>
                    <?php mobile_logo(); ?>
                </a>
                <button class="navbar-toggler" data-bs-toggle="offcanvas" data-bs-target="#navbarOffcanvas">
                    <span class="burger-menu">
                        <span class="top-bar"></span>
                        <span class="middle-bar"></span>
                        <span class="bottom-bar"></span>
                    </span>
                </button>
                <div class="collapse navbar-collapse">
                    <?php
                        if(has_nav_menu('top-menu')){
                            wp_nav_menu( array(
                                'theme_location'  => 'top-menu',
                                'depth'           => 1,
                                'fallback_cb'     => false,
                                'menu_class'      => 'top-navbar-list',
                            ) );
                        } 
                    ?>
                    <div class="navbar-inner d-flex align-items-center justify-content-between">
                        <?php $primary_nav_arg = [
                            'menu'            => 'primary',
                            'theme_location'  => 'primary',
                            'container'       => null,
                            'menu_class'      => 'navbar-nav ms-auto',
                            'depth'           => 3,
                            'walker'          => new Hospa_Bootstrap_Navwalker(),
                            'fallback_cb'     => 'Hospa_Bootstrap_Navwalker::fallback',
                        ];
                
                            if ( has_nav_menu('primary') ) :
                                wp_nav_menu( $primary_nav_arg );
                            endif;
                        ?>

                        <div class="others-option d-flex align-items-center">
                            <?php if( $enable_search == true  ) : ?>
                                <div class="option-item">
                                    <div class="search-bar main-menu__search search-toggler">
                                        <i class="<?php echo esc_attr($search_icon) ?>"></i>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <?php if($nav_btn_social == 'btn_display'): ?>
                                <?php if( $header_btn_text != ''  ) : ?>
                                    <div class="option-item">
                                        <?php if($btn_link_type == 'internal_link'): ?>
                                        <a href="<?php echo esc_url(home_url($header_btn_link) ); ?>" class="default-btn">
                                        <?php else: ?>
                                        <a href="<?php echo esc_url($header_btn_link); ?>" target="_blank" class="default-btn">
                                        <?php endif; ?>
                                            <i class="<?php echo esc_attr($header_btn_icon) ?>"></i>
                                            <?php echo esc_html(  $header_btn_text ); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="option-item">
                                    <?php echo do_shortcode($social_icon_shortcode);?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div> 
            </div>
        </nav>
    </div>

    <?php if( $enable_search == true  ) : ?>
    <div class="search-popup">
        <div class="search-popup-overlay search-toggler"></div>
        <div class="search-popup-content">
            <form class="search-popup-form" method="get" action="<?php echo site_url( '/' ); ?>">
                <input type="text" value="" name="s" class="form-control" placeholder="<?php echo esc_attr( $search_ph_text ); ?>">

                <button type="submit" aria-label="search submit">
                    <i class="<?php echo esc_attr($search_icon) ?>"></i>
                </button>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <div class="mobile-navbar offcanvas offcanvas-end border-0 <?php if ( is_user_logged_in() ) { echo esc_attr( $hide_wp_nav ); } ?>" data-bs-backdrop="static" tabindex="-1" id="navbarOffcanvas">
        <div class="offcanvas-header">
            <a class="logo d-inline-block" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                <?php mobile_logo(); ?>
            </a>

            <button type="button" class="close-btn bg-transparent position-relative lh-1 p-0 border-0" data-bs-dismiss="offcanvas" aria-label="Close">
                <i class="ti ti-x"></i>
            </button>
        </div>

        <div class="offcanvas-body">
            <?php if(has_nav_menu('top-menu')){ ?>
            <div class="additional-pages">
                <button class="top-navbar-btn" type="button" data-bs-toggle="collapse" data-bs-target="#topNavbar" aria-expanded="false" aria-controls="topNavbar">
                    <span><?php echo esc_html($th_res_text); ?></span>
                    <i class="ti ti-chevron-down"></i>
                </button>
                <div class="collapse" id="topNavbar">
                    <div class="card card-body">
                        <?php
                            if(has_nav_menu('top-menu')){
                                wp_nav_menu( array(
                                    'theme_location'  => 'top-menu',
                                    'depth'           => 1,
                                    'fallback_cb'     => false,
                                    'menu_class'      => 'top-navbar-list',
                                ) );
                            } 
                        ?>
                    </div>
                </div>
            </div>
            <?php } ?>

            <?php 
                if ( has_nav_menu('mobile-menu') ) :
                    wp_nav_menu( 
                        array(
                            'menu'            => 'mobile-menu',
                            'theme_location'  => 'mobile-menu',
                            'menu_class'      => 'responsive-menu mobile-menu',
                            'container'       => null,
                            'depth'           => 3,
                        )
                    );
                else:
                    wp_nav_menu( 
                        array(
                            'menu'            => 'primary',
                            'theme_location'  => 'primary',
                            'menu_class'      => 'responsive-menu mobile-menu',
                            'container'       => null,
                            'depth'           => 3,
                        )
                    );
                endif;
            ?>

            <div class="others-option d-flex align-items-center">
                <?php if( $enable_search == true  ) : ?>
                    <div class="option-item">
                        <div class="search-bar main-menu__search search-toggler">
                            <i class="<?php echo esc_attr($search_icon) ?>"></i>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($nav_btn_social == 'btn_display'): ?>
                    <?php if( $header_btn_text != ''  ) : ?>
                        <div class="option-item">
                            <?php if($btn_link_type == 'internal_link'): ?>
                            <a href="<?php echo esc_url(home_url($header_btn_link) ); ?>" class="default-btn">
                            <?php else: ?>
                            <a href="<?php echo esc_url($header_btn_link); ?>" target="_blank" class="default-btn">
                            <?php endif; ?>
                                <i class="<?php echo esc_attr($header_btn_icon) ?>"></i>
                                <?php echo esc_html(  $header_btn_text ); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="option-item">
                        <?php echo do_shortcode($social_icon_shortcode);?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>          