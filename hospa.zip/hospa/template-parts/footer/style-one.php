<?php global $hospa_opt;
/**
 * 	The template for displaying the footer
 * 	@package hospa
 */

if( function_exists('acf_add_options_page') ) {
    $footer_content        = get_field( 'footer_content' );
    $fc_shortcode          = get_field( 'fc_shortcode' );
    if( is_home() ) {
        $post_page_id       = get_option( 'page_for_posts' );
        $footer_content     = get_field( 'footer_content' , $post_page_id );
        $fc_shortcode       = get_field( 'fc_shortcode' , $post_page_id );
    }
    if ( class_exists( 'WooCommerce' ) ){
        if( is_shop() ) {
            $post_page_id  = get_option( 'woocommerce_shop_page_id' );
            $footer_content     = get_field( 'footer_content' , $post_page_id );
            $fc_shortcode       = get_field( 'fc_shortcode' , $post_page_id );
        }
    }
} else {
    $footer_content        = 'block';
    $fc_shortcode          = '';
}
?>

<?php 
if($footer_content == 'block' && $fc_shortcode != ''):
	echo do_shortcode($fc_shortcode);
endif; ?>