<?php
/**
 * The template for displaying the footer
 * @package Hospa
*/

        hospa_footer_area();

		hospa_backtotop();
		
		wp_footer(); ?>

	</body>
</html>