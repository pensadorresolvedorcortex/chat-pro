Please visit: https://github.com/RedukFramework/RedukFramework/wiki/Translate for details on how you can help.
