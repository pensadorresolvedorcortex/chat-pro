<?php

// Exit if accessed directly
    if ( ! defined( 'ABSPATH' ) ) {
        die;
    }

    if ( ! class_exists( 'RedukFramework_extension_vendor_support' ) ) {
        if ( file_exists( dirname( __FILE__ ) . '/vendor_support/extension_vendor_support.php' ) ) {
            require dirname( __FILE__ ) . '/vendor_support/extension_vendor_support.php';
            new RedukFramework_extension_vendor_support();
        }
    }

?>