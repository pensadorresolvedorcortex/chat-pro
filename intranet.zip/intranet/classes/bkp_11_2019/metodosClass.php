<?php
/*
  // Habilitar as linhas abaixo em caso de erro....
  ini_set('display_errors',1);
  ini_set('display_startup_erros',1);
  error_reporting(E_ALL);
 */
/**
* NOTE: Dispensamos o uso do try e catch
*/
// Habilitar essa linha
error_reporting(0);
session_start();

require_once("../classes/conectaClass.php");

class metodosClass {


  public $conexao;

  /**
   * Classe construtor
   */
  public function __construct() {
      $conectar = new conectaClass();
      $this->conexao = $conectar->conectar();
      return $this->conexao;
  }

  /**
  * Método armazena os logs de acesso ao site
  * @access public
  * @param string $ip
  */
  public function logs($ip) {
    mysqli_query($this->conexao, "INSERT INTO acessos VALUES(null,'" . $ip . "',NOW());");
  }

    /**
     * Método converte o nome com a primeira letra em caixa alta
     * @access public
     * @param string $palavra
     * @return string $nomeUsuario
     */
    public function palavraMinuscula($palavra){
      $nomeUsuario = mb_convert_case($palavra, MB_CASE_TITLE, 'UTF-8');
      return  $nomeUsuario;
    }

    /**
    * Método cria o caminho absoluto dos links. Encontra-se em todas as páginas
    * @access public
    * @param null
    * @return string $caminhoAbsoluto
    */
    public function caminhoAbsoluto(){
  //   $caminhoAbsoluto = "https://".$_SERVER['SERVER_NAME']."/Projetos/CTCB/controle"; // local
    //  $caminhoAbsoluto = "https://".$_SERVER['SERVER_NAME']."/intranet/";
         $caminhoAbsoluto = "https://intranet.ctcb.org.br";
      return $caminhoAbsoluto;
    }

    /**
    * Método cria a chave lado cliente (Google recaptcha). Veja o método recaptcha($key)
    * Encontra-se nas páginas area-associados.php, cadastrar-associados.php
    * @access public
    * @param null
    * @return string $siteKey
    */
    public function siteKey(){
      $siteKey = '6Lc6ynwUAAAAAHLWy-hSJel8KT6FQXaG_nS6Aex4';
      return $siteKey;
    }

    /**
    * Método cria a chave lado servidor (Google recaptcha). Veja o método recaptcha($key)
    * Encontra-se nas páginas area-associados.php, cadastrar-associados.php
    * @access public
    * @param null
    * @return string $secretKey
    */
    public function secretKey(){
      $secretKey = '6Lc6ynwUAAAAAA7t43SzBYHzFjwmbYXu4qIfaIPX';
      return $secretKey;
    }

    /**
    * Método validar o acesso aos usuários
    * Encontra-se em todas as páginas
    * @access public
    * @param string $login, $senha
    * @return true
    */
    public function validarUsuarios($login,$senha)
    {
       $login = mysqli_real_escape_string($this->conexao,$login);
       $senha = $this->codificar(mysqli_real_escape_string($this->conexao,$senha));
       if($login == 'Evandro.CTCB' and $senha = 'Acesso@Temp')
       {
         $_SESSION["LogadoCTCB"] = true;
         $_SESSION["Usuario"] = 'Evandro';
         return "<script>window.location.href='".$this->caminhoAbsoluto()."/sistema-ctcb/atiradores/'</script>";
       }
        else
       {
           if($login == "ctcb" || $login == "Admin@Master" || $login == "Provas")
           {
               $sql = mysqli_query($this->conexao,"SELECT * FROM acesso_admin WHERE LoginAdmin = '".$login."' AND SenhaAdmin = '".$senha."';");
               $ctcb = mysqli_fetch_object($sql);
               if(mysqli_num_rows($sql) == 0)
               {
                 $_SESSION["ErroLogin"] = time() + 5;
                 return "<script>window.location.href='".$this->caminhoAbsoluto()."/'</script>";
               }
                else
               {
                 $_SESSION["DataAcessoCTCB"] = $ctcb->DataAcesso;
                 $_SESSION["HoraAcessoCTCB"] = $ctcb->HoraAcesso;
                 $_SESSION["Cadastrar"] = $ctcb->Cadastrar;
                 $_SESSION["Editar"] = $ctcb->Editar;
                 $_SESSION["Excluir"] = $ctcb->Excluir;
                 $_SESSION["LogadoCTCB"] = true;
                 $_SESSION["CTCB"] = $ctcb->NomeAdmin;
                 $_SESSION["IdAdmin"] = $ctcb->IdAdmin;
                 mysqli_query($this->conexao,"UPDATE acesso_admin SET DataAcesso = 'CURDATE()' AND HoraAcesso = 'CURTIME()' WHERE IdAdmin = '".$ctcb->IdAmin."';");
                 return "<script>window.location.href='".$this->caminhoAbsoluto()."/sistema-ctcb/'</script>";
               }
           }
            else
           { // Acesso clube
                 $sql = mysqli_query($this->conexao,"SELECT * FROM clube WHERE sigla = '".$login."' AND senha = '".$senha."';");
                 $ctcb = mysqli_fetch_object($sql);
                 if(mysqli_num_rows($sql) == 0)
                 {
                   $_SESSION["ErroLogin"] = time() + 5;
                   return "<script>window.location.href='".$this->caminhoAbsoluto()."/'</script>";
                 }
                 else
                 {
                   $_SESSION["Logado"] = true;
                   $_SESSION["IdClube"] = $ctcb->clube;
                   return "<script>window.location.href='".$this->caminhoAbsoluto()."/sistema/'</script>";
                 }
             }
         }
     }

     /**
      * Método mostra o mês por extenso
      * @access public
      * @param string $mes
      * @return string $mes
      */
     public function mesExtenso($mes)
     {
       switch ($mes)
       {
          case '01': $mes = "janeiro"; break;
          case '02': $mes = "fevereiro"; break;
          case '03': $mes = "março"; break;
          case '04': $mes = "abril"; break;
          case '05': $mes = "maio"; break;
          case '06': $mes = "junho"; break;
          case '07': $mes = "julho"; break;
          case '08': $mes = "agosto"; break;
          case '09': $mes = "setembro"; break;
          case '10': $mes = "outubro"; break;
          case '11': $mes = "novembro"; break;
          case '12': $mes = "dezembro"; break;
       }
       return $mes;
     }

    /**
     * Método visualiza genericamente todas as tabelas
     * @access public
     * @param string $tabela
     * @param int $idTabela, $idBusca
     * @return array
     */
    public function visualizar($tabela, $idTabela, $idBusca)
    {
       $sqlVisualizar = mysqli_query($this->conexao, "SELECT * FROM " . $tabela . " WHERE " . $idTabela . " = '" . mysqli_real_escape_string($this->conexao, $idBusca) . "';");
       return array(mysqli_num_rows($sqlVisualizar),mysqli_fetch_object($sqlVisualizar));
    }

    /**
     * Codifica a senha em 03 métodos de mão única. Sha1, MD5 invertido e crypt
     * @param type $senhaUsuario
     * @return type $codificar
     */
    public function codificar($key)
    {
        $salt = "$" . md5(strrev($key)) . "%";
        $codifica = crypt($key, $salt);
        $codificar = hash('sha512', $codifica);
        return $codificar;
    }

    /**
     * Método para sair do sistema. Encontra-se na página sair.php
     * @access public
     * @param null
     * @return true
     */
    public function sairSistema()
    {
      $_SESSION["Logado"] = false;
      unset($_SESSION["Logado"]);
      unset($_SESSION["IdUsuario"]);
      return "<script>window.location.href='".$this->caminhoAbsoluto()."/'</script>";
    }

} // Fim da classe
