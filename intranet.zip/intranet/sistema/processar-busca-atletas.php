<?php
error_reporting(0);
session_start();
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$assunto = filter_input(INPUT_GET, 'term', FILTER_SANITIZE_STRING);
$tipoBusca = $_SESSION["TipoAtleta"];
$evento = $_SESSION["Evento"];
$prova = $_SESSION["Prova"];
echo $metodos->buscarAtletas($assunto,$tipoBusca = $tipoBusca,$evento,$prova);
?>
