<?php
error_reporting(0);
session_start();
if($_SESSION["Logado"] == false){
  echo "<script>window.location.href='../index.php';</script>";
  exit();
}
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
if(!isset($_SESSION["Evento"]) || !isset($_SESSION["Prova"]))
{
  echo "<script>window.location.href='".$caminhoAbsoluto."/'</script>";
  exit();
}
if($_SESSION["ErroNotas"] < time())
{
  unset($_SESSION["ErroNotas"]);
}
if($_SESSION["SucessoNotas"] < time())
{
  unset($_SESSION["SucessoNotas"]);
}
$tabela = "clube";
$idTabela = "clube";
$idBusca = $_SESSION["IdClube"];
$visualizar = $metodos->visualizar($tabela,$idTabela,$idBusca);
$tabelaE = "evento";
$idTabelaE = "evento";
$idBuscaE = $_SESSION["Evento"];
$visualizarE = $metodos->visualizar($tabelaE,$idTabelaE,$idBuscaE);
$tabelaP = "prova";
$idTabelaP = "prova";
$idBuscaP = $_SESSION["Prova"];
$visualizarP = $metodos->visualizar($tabelaP,$idTabelaP,$idBuscaP);
list($anoE,$mesE,$diaE) = explode("-",$visualizarE[1]->data_inicio);
$dataEvento = $diaE."/".$mesE;
if($_POST){
  $eventoAtirador = $_POST["EventoAtirador"];
  $notas1 = $_POST["LancarNotas1"];
  $notas2 = $_POST["LancarNotas2"];
  $notas3 = $_POST["LancarNotas3"];
  $notas4 = $_POST["LancarNotas4"];
  $notas5 = $_POST["LancarNotas5"];

  $sigma1 = $_POST["sigma1"];
  $disparos1 = $_POST["disparos1"];
  $dataHora1 = $_POST["dataHora1"];
  $calibre1 = $_POST["calibre1"];

  $sigma2 = $_POST["sigma2"];
  $disparos2 = $_POST["disparos2"];
  $dataHora2 = $_POST["dataHora2"];
  $calibre2 = $_POST["calibre2"];

  $sigma3 = $_POST["sigma3"];
  $disparos3 = $_POST["disparos3"];
  $dataHora3 = $_POST["dataHora3"];
  $calibre3 = $_POST["calibre3"];

  $sigma4 = $_POST["sigma4"];
  $disparos4 = $_POST["disparos4"];
  $dataHora4 = $_POST["dataHora4"];
  $calibre4 = $_POST["calibre4"];

  $sigma5 = $_POST["sigma5"];
  $disparos5 = $_POST["disparos5"];
  $dataHora5 = $_POST["dataHora5"];
  $calibre5 = $_POST["calibre5"];


  $calibres = array();

if (!empty($calibre1)) {
    $calibres[] = $calibre1;
}

if (!empty($calibre2)) {
    $calibres[] = $calibre2;
}

if (!empty($calibre3)) {
    $calibres[] = $calibre3;
}

if (!empty($calibre4)) {
    $calibres[] = $calibre4;
}

if (!empty($calibre5)) {
    $calibres[] = $calibre5;
}

$calibre = implode(', ', $calibres);

$simas = array();

if (!empty($sigma1)) {
    $simas[] = $sigma1;
}

if (!empty($sigma2)) {
    $simas[] = $sigma2;
}

if (!empty($sigma3)) {
    $simas[] = $sigma3;
}

if (!empty($sigma4)) {
    $simas[] = $sigma4;
}

if (!empty($sigma5)) {
    $simas[] = $sigma5;
}

$simasTotais = implode(', ', $simas);

$dataHoraA = array();

if (!empty($dataHora1)) {
    $dataHoraA[] = $dataHora1;
}

if (!empty($dataHora2)) {
    $dataHoraA[] = $dataHora2;
}

if (!empty($dataHora3)) {
    $dataHoraA[] = $dataHora3;
}

if (!empty($dataHora4)) {
    $dataHoraA[] = $dataHora4;
}

if (!empty($dataHora5)) {
    $dataHoraA[] = $dataHora5;
}

$dataHora = implode(', ', $dataHoraA);

$disparosA = array();

if (!empty($disparos1)) {
    $disparos[] = $disparos1;
}

if (!empty($disparos2)) {
    $disparos[] = $disparos2;
}

if (!empty($disparos3)) {
    $disparos[] = $disparos3;
}

if (!empty($disparos4)) {
    $disparos[] = $disparos4;
}

if (!empty($disparos5)) {
    $disparos[] = $disparos5;
}

$disparos = implode(', ', $disparosA);






 // $simasTotais = $sigma1 . ", " . $sigma2 . ", " . $sigma3 . ", " . $sigma4 . ", " . $sigma5;
  $disparosTotais = intval($disparos1) + intval($disparos2) + intval($disparos3) + intval($disparos4) + intval($disparos5);
  //$dataHoraA = $dataHora1 . ", " . $dataHora2 . ", " . $dataHora3 . ", " . $dataHora4 . ", " . $dataHora5;
  $total_string = strval($disparosTotais);
 // $calibre = $calibre1 . ", " . $calibre2 . ", " . $calibre3 . ", " . $calibre4 . ", " . $calibre5;

  
  echo $metodos->cadastrarNotas($eventoAtirador,$notas1,$notas2,$notas3,$notas4,$notas5,$sigma1,$sigma2,$sigma3,$sigma4,$sigma5,$total_string,$disparos1,$disparos2,$disparos3,$disparos4,$disparos5,$dataHora1,$dataHora2,$dataHora3,$dataHora4,$dataHora5,$calibre1,$calibre2,$calibre3,$calibre4,$calibre5);
}
?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/css/style.css">
    <style type="text/css">
			.carregando{
				color:#ff0000;
				display:none;
			}
		</style>
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
       <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  </head>
  <body>
   <div class="container">
     <div class="row header">
          <div class="col-md-6">
            <img src="<?php echo $caminhoAbsoluto; ?>/imagens/logo.png" alt="" class="logo">
         </div>
         <div class="col-md-6 text-right">
           <h3>SISTEMA DE GESTÃO | CLUBES</h3>
           <a href="<?php echo $caminhoAbsoluto; ?>/sair/" style="color: #000" alt="Sair do sistema" title="Sair do sistema"><i class="fas fa-power-off"></i> Sair do sistema</a>
         </div>
     </div>
     <div class="row conteudo">
        <div class="nomeClube">
           <?php echo $visualizar[1]->nome; ?><br>
           <span style="font-size: 14px"><?php echo $dataEvento ?> - <?php echo $visualizarE[1]->nome; ?> - <?php echo  $visualizarP[1]->nome; ?></span>
        </div>
      <div class="container" style="margin-top: 10px">
        <div class="col-md-12 text-right"><button class="btn btn-info" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/conteudo/'"><i class="fas fa-home"></i> Voltar</button></div>
      <div class="row" style="margin-top: 10px">
        <div class="subTitulo">
           LANÇAMENTO DE RESULTADOS
        </div>
  </div>
<div class="row" style="margin-top: 10px;">
 <div class="col-md-12">
   <?php if($_SESSION["SucessoNotas"]){ ?>
   <div class="alert alert-success" style="font-weight: bold"><i class="fas fa-check fa-lg"></i> Nota lançada com sucesso!</div>
 <?php } ?>
 <?php if($_SESSION["ErroNotas"]){ ?>
   <div class="alert alert-danger" style="font-weight: bold"><i class="fas fa-check fa-lg"></i> Os valores não podem ser superiores a 18!</div>
  <?php } ?>
  
    <!--<div class="text-center"><h5 style="color: #FFF; font-weight: bold; margin-top: 10px">Estamos em manutenção. Prazo de normalização: 04/04/2019.<br><br>Agradecemos a compreensão!</h5></div>-->
  
  <form class="" action="#!" method="post">
    
    <?php echo $metodos->lancarResultados($_SESSION["IdClube"],$_SESSION["Evento"],$_SESSION["Prova"]); ?>
  </form>
</div>
</div>
      </div>
     </div>
    </div>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>
   <script>
   $(document).ready(function(){
          $("div.alert").fadeIn( 300 ).delay( 3000 ).fadeOut( 400 );
         });
   </script>
  </body>
</html>
