<?php
error_reporting(0);
session_start();
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
$_SESSION["Evento"] = $_POST["Eventos"];
$_SESSION["Prova"] = $_POST["Provas"];
echo "<script>window.location.href='".$caminhoAbsoluto."/conteudo/'</script>";
?>
