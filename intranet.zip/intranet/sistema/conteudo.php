<?php
error_reporting(0);
session_start();
if($_SESSION["Logado"] == false){
  echo "<script>window.location.href='../index.php';</script>";
  exit();
}
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
if(!isset($_SESSION["Evento"]) || !isset($_SESSION["Prova"]))
{
  echo "<script>window.location.href='".$caminhoAbsoluto."/'</script>";
  exit();
}
if($_SESSION["SucessoExcluir"] < time())
{
  unset($_SESSION["SucessoExcluir"]);
}
$tabela = "clube";
$idTabela = "clube";
$idBusca = $_SESSION["IdClube"];
$visualizar = $metodos->visualizar($tabela,$idTabela,$idBusca);
$tabelaE = "evento";
$idTabelaE = "evento";
$idBuscaE = $_SESSION["Evento"];
$visualizarE = $metodos->visualizar($tabelaE,$idTabelaE,$idBuscaE);
$tabelaP = "prova";
$idTabelaP = "prova";
$idBuscaP = $_SESSION["Prova"];
$visualizarP = $metodos->visualizar($tabelaP,$idTabelaP,$idBuscaP);
list($anoE,$mesE,$diaE) = explode("-",$visualizarE[1]->data_inicio);
$dataEvento = $diaE."/".$mesE;
?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Controle de Gestão | Clubes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/css/style.css">
    <style type="text/css">
			.carregando{
				color:#ff0000;
				display:none;
			}
		</style>
       <script src="<?php echo $caminhoAbsoluto; ?>/js/jquery.min.js"></script>
  </head>
  <body>
   <div class="container">
     <div class="row header">
          <div class="col-md-6">
            <img src="<?php echo $caminhoAbsoluto; ?>/imagens/logo.png" alt="" class="logo">
         </div>
         <div class="col-md-6 text-right">
           <h3>SISTEMA DE GESTÃO | CLUBES</h3>
           <a href="<?php echo $caminhoAbsoluto; ?>/sair/" style="color: #df5400" alt="Sair do sistema" title="Sair do sistema"><i class="fas fa-power-off"></i></a>
         </div>
     </div>
     <div class="row conteudo">
        <div class="nomeClube">
           <?php echo $visualizar[1]->nome; ?><br>
           <span style="font-size: 14px"><?php echo $dataEvento ?> - <?php echo $visualizarE[1]->nome; ?> - <?php echo $visualizarP[1]->nome; ?></span>
        </div>
      <div class="container" style="margin-top: 50px">
      <div class="row">
        <div class="col-md-9" style="border-right: 2px solid #FFF">
        <div class="row seven-cols">
        <div class="col-lg-1 col-md-3 col-sm-4 col-xs-6" style="text-align: center; cursor: pointer" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/cadastrar-atirador/'">
         <script src="https://cdn.lordicon.com/lordicon.js"></script>
<lord-icon
    src="https://cdn.lordicon.com/xzalkbkz.json"
    trigger="hover"
    colors="primary:#121331,secondary:#00a859"
    style="width:60px;height:60px">
</lord-icon><br>
          Cadastrar Atirador
        </div>
        <div class="col-lg-1 col-md-3 col-sm-4 col-xs-6" style="text-align: center; cursor: pointer" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/atleta-nacional/'">
          <script src="https://cdn.lordicon.com/lordicon.js"></script>
<lord-icon
    src="https://cdn.lordicon.com/kndkiwmf.json"
    trigger="hover"
    colors="primary:#121331,secondary:#00a859"
    style="width:60px;height:60px">
</lord-icon><br>
           Inscrever Atleta<br>
           <small>(nacional)</small>
        </div>
        <div class="col-lg-1 col-md-3 col-sm-4 col-xs-6" style="text-align: center; cursor: pointer" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/atleta-estadual/'">
          <script src="https://cdn.lordicon.com/lordicon.js"></script>
<lord-icon
    src="https://cdn.lordicon.com/kndkiwmf.json"
    trigger="hover"
    colors="primary:#121331,secondary:#00a859"
    style="width:60px;height:60px">
</lord-icon><br>
           Inscrever Atleta<br>
           <small>(estadual)</small>
        </div>
        <div class="col-lg-1 col-md-3 col-sm-4 col-xs-6" style="text-align: center; cursor: pointer" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/cadastrar-resultados/'">
          <script src="https://cdn.lordicon.com/lordicon.js"></script>
<lord-icon
    src="https://cdn.lordicon.com/ghhwiltn.json"
    trigger="hover"
    colors="primary:#121331,secondary:#00a859"
    style="width:60px;height:60px">
</lord-icon><br>
          Inserir Resultados
        </div>

        <div class="col-lg-1 col-md-3 col-sm-4 col-xs-6" style="text-align: center; cursor: pointer" onclick="#!" data-toggle="modal" data-target="#modalProvas">
          <script src="https://cdn.lordicon.com/lordicon.js"></script>
          <lord-icon
              src="https://cdn.lordicon.com/wzwygmng.json"
              trigger="hover"
              colors="primary:#121331,secondary:#00a859"
              style="width:60px;height:60px">
          </lord-icon><br>
        Resultado das Provas
        </div>
        
        
        <div class="col-lg-1 col-md-3 col-sm-4 col-xs-6" style="text-align: center; cursor: pointer" onclick="#!" data-toggle="modal" data-target="#modalEventos">
          <script src="https://cdn.lordicon.com/lordicon.js"></script>
<lord-icon
    src="https://cdn.lordicon.com/vistbkts.json"
    trigger="hover"
    colors="primary:#121331,secondary:#00a859"
    style="width:60px;height:60px">
</lord-icon><br>
             Resultado do Evento
        </div>


        <div class="col-lg-1 col-md-3 col-sm-4 col-xs-6" style="text-align: center; cursor: pointer"  onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/listar_resultado_anterior.php'">
          <script src="https://cdn.lordicon.com/lordicon.js"></script>
          <lord-icon
              src="https://cdn.lordicon.com/wzwygmng.json"
              trigger="hover"
              colors="primary:#121331,secondary:#00a859"
              style="width:60px;height:60px">
          </lord-icon><br>
        Editar resultados anteriores
        </div>


        <div class="col-lg-1 col-md-3 col-sm-4 col-xs-6" style="text-align: center; cursor: pointer" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/'">
          <script src="https://cdn.lordicon.com/lordicon.js"></script>
<script src="https://cdn.lordicon.com/lordicon.js"></script>
<lord-icon
    src="https://cdn.lordicon.com/iawrhwdo.json"
    trigger="hover"
    colors="primary:#121331,secondary:#00a859"
    style="width:60px;height:60px">
</lord-icon> <br>
        Trocar Prova
        </div>
  </div>
</div>
    <div class="col-md-3">
      <span>Provas realizadas pelo clube:</span><br>
      <?php echo $metodos->provasRealizadas($_SESSION["IdClube"],$_SESSION["Evento"]); ?>
    </div>
</div>
<div class="nomeClube" style="margin-top: 50px; text-transform: none">
  <?php $contarInscricoes = $metodos->contabilizarInscricoes($_SESSION["IdClube"],$_SESSION["Evento"],$_SESSION["Prova"]); ?>
  <span style="font-weight: bold;">NO BRASIL</span> | Inscrições: <?php echo $contarInscricoes; ?>   Participantes: <?php echo $contarInscricoes; ?> |
  <span style="font-weight: bold">NESTE LOCAL</span> | Inscrições: <?php echo $contarInscricoes; ?>  Participantes: <?php echo $contarInscricoes; ?> |
</div>
<div class="row" style="margin-top: 50px">
  <h4 style="font-weight: bold; color:#00a121;">INSCRIÇÕES</h4><br><br>
  <?php if($_SESSION["SucessoExcluir"]){ ?>
    <div class="alert alert-success col-md-12" style="font-weight: bold"><i class="fas fa-check fa-lg"></i> Inscrição excluída com sucesso!</div>
  <?php } ?>
  <?php echo $metodos->listarInscricoes($_SESSION["IdClube"],$_SESSION["Evento"],$_SESSION["Prova"]); ?>
</div>
      </div>
     </div>
    </div>
   <!-- Modal Provas -->
   <div class="modal fade bd-example-modal-lg" id="modalProvas" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true" data-backdrop="static">
       <div class="modal-dialog modal-lg">
         <div class="modal-content">
         <div class="modal-header bg-primary text-white">
           <h5 class="modal-title" id="exampleModalLabel" style="font-weight: bold"><i class="fas fa-file-alt"></i> RESULTADO DAS PROVAS</h5>
           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
         </div>
         <div class="modal-body">
              <?php echo $metodos->resultadoProvas($_SESSION["IdClube"],$_SESSION["Evento"],$_SESSION["Prova"]); ?>
         </div>
         <div class="modal-footer">
           <button type="button" class="btn btn-default fechar" data-dismiss="modal">Fechar</button>
            <button type="button" class="btn btn-primary" onClick="window.open('<?php echo $caminhoAbsoluto; ?>/imprimir-provas.php', '_blank', ''); window.close();" ><i class="fas fa-print"></i> Imprimir</button>
          </div>
         </div>
       </div>
    </div>

     <!-- Modal Eventos -->
     <div class="modal fade bd-example-modal-lg" id="modalEventos" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true" data-backdrop="static">
         <div class="modal-dialog modal-lg">
           <div class="modal-content">
           <div class="modal-header bg-success text-white">
             <h5 class="modal-title" id="exampleModalLabel" style="font-weight: bold"><i class="fas fa-copy"></i> RESULTADO DO EVENTO</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
             </button>
           </div>
           <div class="modal-body">
                  <?php echo $metodos->resultadoEventos($_SESSION["IdClube"],$_SESSION["Evento"]); ?>
           </div>
           <div class="modal-footer">
             <button type="button" class="btn btn-default fechar" data-dismiss="modal">Fechar</button>
              <button type="button" class="btn btn-success" onClick="window.open('<?php echo $caminhoAbsoluto; ?>/imprimir-eventos.php', '_blank', ''); window.close();" ><i class="fas fa-print"></i> Imprimir</button>
            </div>
           </div>
         </div>
      </div>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>
  </body>
</html>
