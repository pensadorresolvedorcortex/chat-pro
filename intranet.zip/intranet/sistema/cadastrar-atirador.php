<?php
error_reporting(0);
session_start();
if ($_SESSION["Logado"] == false)
{
  echo "<script>window.location.href='../index.php';</script>";
  exit();
}
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
if(!isset($_SESSION["Evento"]) || !isset($_SESSION["Prova"]))
{
  echo "<script>window.location.href='".$caminhoAbsoluto."/'</script>";
  exit();
}
if(isset($_SESSION["CPF"]))
{
  unset($_SESSION["CPF"]);
}
if ($_SESSION["Sucesso"] < time())
{
  unset($_SESSION["Sucesso"]);
}
if ($_SESSION["ErroCPF"] < time())
{
  unset($_SESSION["ErroCPF"]);
}
if ($_SESSION["CPFCadastrado"] < time())
{
  unset($_SESSION["CPFCadastrado"]);
}
$tabela = "clube";
$idTabela = "clube";
$idBusca = $_SESSION["IdClube"];
$visualizar = $metodos->visualizar($tabela,$idTabela,$idBusca);
$tabelaE = "evento";
$idTabelaE = "evento";
$idBuscaE = $_SESSION["Evento"];
$visualizarE = $metodos->visualizar($tabelaE,$idTabelaE,$idBuscaE);
$tabelaP = "prova";
$idTabelaP = "prova";
$idBuscaP = $_SESSION["Prova"];
$visualizarP = $metodos->visualizar($tabelaP,$idTabelaP,$idBuscaP);
list($anoE,$mesE,$diaE) = explode("-",$visualizarE[1]->data_inicio);
$dataEvento = $diaE."/".$mesE;
if ($_POST)
{
  function validaCPF($cpf = null)
  {
  	if(empty($cpf))
    {
  		return false;
  	}
    $cpf = preg_replace("/[^0-9]/", "", $cpf);
	  $cpf = str_pad($cpf, 11, '0', STR_PAD_LEFT);
  	if(strlen($cpf) != 11)
    {
		   return false;
	  }
    else if(
      $cpf == '00000000000' ||
  		$cpf == '11111111111' ||
  		$cpf == '22222222222' ||
  		$cpf == '33333333333' ||
  		$cpf == '44444444444' ||
  		$cpf == '55555555555' ||
  		$cpf == '66666666666' ||
  		$cpf == '77777777777' ||
  		$cpf == '88888888888' ||
  		$cpf == '99999999999'){
		return false;
	  }
    else{
  		for ($t = 9; $t < 11; $t++)
      {
  			  for ($d = 0, $c = 0; $c < $t; $c++)
          {
  				     $d += $cpf{$c} * (($t + 1) - $c);
  			  }
  			  $d = ((10 * $d) % 11) % 10;
  			  if($cpf{$c} != $d)
          {
  				    return false;
  			  }
  	  }
		return true;
 	 }
 } // fim da função
 $cpf = $_POST["CPF"];
 if(validaCPF($cpf) == false)
 {
    $_SESSION["ErroCPF"] = time() + 5;
 }
 else {
   echo $metodos->validarCadastro($cpf);
 }
}
?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/css/style.css">
    <style type="text/css">
			.carregando{
				color:#ff0000;
				display:none;
			}
		</style>
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
       <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  </head>
  <body>
   <div class="container">
     <div class="row header">
          <div class="col-md-6">
            <img src="<?php echo $caminhoAbsoluto; ?>/imagens/logo.png" alt="" class="logo">
         </div>
         <div class="col-md-6 text-right">
           <h3>SISTEMA DE GESTÃO | CLUBES</h3>
           <a href="<?php echo $caminhoAbsoluto; ?>/sair/" style="color: #000" alt="Sair do sistema" title="Sair do sistema"><i class="fas fa-power-off"></i> Sair do sistema</a>
         </div>
     </div>
     <div class="row conteudo">
        <div class="nomeClube">
           <?php echo $visualizar[1]->nome; ?><br>
           <span style="font-size: 14px"><?php echo $dataEvento ?> - <?php echo $visualizarE[1]->nome; ?> - <?php echo $visualizarP[1]->nome; ?></span>
        </div>
      <div class="container" style="margin-top: 10px">
        <div class="text-right"><button class="btn btn-info" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/conteudo/'"><i class="fas fa-home"></i> Voltar</button></div>
      <div class="row" style="margin-top: 10px">
        <div class="subTitulo">
          CADASTRAR ATIRADOR
        </div>
  </div>
<div class="row" style="margin-top: 10px;">
 <div class="col-md-12">
  <?php if($_SESSION["Sucesso"]){ ?>
     <div class="alert alert-success" style="font-weight: bold"><i class="fas fa-check fa-lg"></i> Atirador cadastrado com sucesso!</div>
  <?php } ?>
  <?php if($_SESSION["ErroCPF"]){ ?>
     <div class="alert alert-danger" style="font-weight: bold"><i class="fas fa-exclamation-triangle fa-lg"></i> Favor digitar um CPF válido!</div>
  <?php } ?>
  <?php if($_SESSION["CPFCadastrado"]){ ?>
     <div class="alert alert-danger" style="font-weight: bold"><i class="fas fa-exclamation-triangle fa-lg"></i> Esse CPF já se encontra cadastrado!</div>
  <?php } ?>
</div>


  <div class="col-md-4"></div>
 <div class="col-md-4">
  <form class="" action="#!" method="post">
      <div class="form-group">
      <label>Digite o CPF abaixo:</label>
      <input type="text" name="CPF" id="cpf" class="form-control">
    </div>
    <div class="form-group" align="center">
      <button type="submit" class="btn btn-primary" name="btnBuscar">Validar</button>
    </div>
  </form>
</div>
<div class="col-md-4"></div>
</div>
      </div>
     </div>
    </div>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/jquery.maskedinput-master/dist/jquery.maskedinput.js" type="text/javascript"></script>
   <script type="text/javascript">
       $(function() {
           $.mask.definitions['~'] = "[+-]";
           $("#cpf").mask("999.999.999-99");
       });
   </script>
   <script>
   $(document).ready(function(){
          $("div.alert").fadeIn( 300 ).delay( 3000 ).fadeOut( 400 );
         });
   </script>
  </body>
</html>
