<?php
error_reporting(0);
session_start();
if ($_SESSION["Logado"] == false)
{
  echo "<script>window.location.href='../index.php';</script>";
  exit();
}
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
if(!isset($_SESSION["CPFCadastrar"]))
{
  echo "<script>window.location.href='".$caminhoAbsoluto."/cadastrar-atirador/';</script>";
  exit();
}
if(!isset($_SESSION["Evento"]) || !isset($_SESSION["Prova"]))
{
  echo "<script>window.location.href='".$caminhoAbsoluto."/'</script>";
  exit();
}
if ($_SESSION["Sucesso"] < time())
{
  unset($_SESSION["Sucesso"]);
}
if ($_SESSION["Erro"] < time())
{
  unset($_SESSION["Erro"]);
}
$tabela = "clube";
$idTabela = "clube";
$idBusca = $_SESSION["IdClube"];
$visualizar = $metodos->visualizar($tabela,$idTabela,$idBusca);
$tabelaE = "evento";
$idTabelaE = "evento";
$idBuscaE = $_SESSION["Evento"];
$visualizarE = $metodos->visualizar($tabelaE,$idTabelaE,$idBuscaE);
$tabelaP = "prova";
$idTabelaP = "prova";
$idBuscaP = $_SESSION["Prova"];
$visualizarP = $metodos->visualizar($tabelaP,$idTabelaP,$idBuscaP);
list($anoE,$mesE,$diaE) = explode("-",$visualizarE[1]->data_inicio);
$dataEvento = $diaE."/".$mesE;
if ($_POST)
{
  $cpf = $_SESSION["CPF"];
  $nome = filter_input(INPUT_POST, 'NomeAtleta', FILTER_SANITIZE_STRING);
  $dataNascimento = $_POST["DataNascimento"];
  $genero = filter_input(INPUT_POST, 'Genero', FILTER_SANITIZE_STRING);
  $estado = filter_input(INPUT_POST, 'Naturalidade', FILTER_SANITIZE_STRING);
  $email = filter_input(INPUT_POST, 'Email', FILTER_VALIDATE_EMAIL);
  if(strlen($nome) < 5)
  {
    $erro = "O nome não pode ser inferior a 5 caracteres.";
  }
  else if($email == false) {
    $erro = "Favor colocar um e-mail válido";
  }
  else{
    echo $metodos->cadastrarAtirador($nome,$cpf,$dataNascimento,$genero,$estado,$email);
  }
}
?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Controle de Gestão | Clubes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/css/style.css">
    <style type="text/css">
			.carregando{
				color:#ff0000;
				display:none;
			}
		</style>
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
       <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  </head>
  <body>
   <div class="container">
     <div class="row header">
          <div class="col-md-6">
            <img src="<?php echo $caminhoAbsoluto; ?>/imagens/logo.png" alt="" class="logo">
         </div>
         <div class="col-md-6 text-right">
           <h3>SISTEMA DE GESTÃO | CLUBES</h3>
           <a href="<?php echo $caminhoAbsoluto; ?>/sair/" style="color: #000" alt="Sair do sistema" title="Sair do sistema"><i class="fas fa-power-off"></i> Sair do sistema</a>
         </div>
     </div>
     <div class="row conteudo">
        <div class="nomeClube">
           <?php echo $visualizar[1]->nome; ?><br>
           <span style="font-size: 14px"><?php echo $dataEvento ?> - <?php echo $visualizarE[1]->nome; ?> - <?php echo $visualizarP[1]->nome; ?></span>
        </div>
      <div class="container" style="margin-top: 10px">
        <div class="text-right"><button class="btn btn-info" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/conteudo/'"><i class="fas fa-home"></i> Voltar</button></div>
      <div class="row" style="margin-top: 10px">
        <div class="subTitulo">
          INSCRIÇÃO DO ATLETA ESTADUAL
        </div>
  </div>
<div class="row" style="margin-top: 10px;">
 <div class="col-md-12">
  <?php if($_SESSION["Sucesso"]){ ?>
     <div class="alert alert-success" style="font-weight: bold"><i class="fas fa-check fa-lg"></i> Atleta cadastrado com sucesso!</div>
  <?php } ?>
  <?php if($_SESSION["Erro"]){ ?>
     <div class="alert alert-danger" style="font-weight: bold"><i class="fas fa-exclamation-triangle fa-lg"></i> Erro ao cadastrar o atleta!</div>
  <?php } ?>
  <?php if($erro){ ?>
     <div class="alert alert-danger" style="font-weight: bold"><i class="fas fa-exclamation-triangle fa-lg"></i> <?php echo $erro; ?>!</div>
  <?php } ?>
</div>
  <div class="col-md-8">
  <form class="" action="#!" method="post">
    <div class="form-group">
    <h5>CPF: <?php echo $_SESSION["CPF"]; ?></h5>
  </div>
      <div class="form-group">
      <label for="nome">Nome do(a) atleta:</label>
      <input type="text" name="NomeAtleta" id="nome" class="form-control" required value="<?php echo $_POST["NomeAtleta"]; ?>">
    </div>
    <div class="form-group">
    <label for="dataNascimento">Data de nascimento:</label>
    <input type="text" name="DataNascimento" id="dataNascimento" class="form-control" value="<?php echo $_POST["DataNascimento"]; ?>">
  </div>
  <div class="form-group">
  <label for="genero">Gênero:</label><br>
  <input type="radio" name="Genero" value="M" checked <?php if($_POST["Genero"] == "M") echo "checked"; ?>> Masculino
  <input type="radio" name="Genero" value="F"  <?php if($_POST["Genero"] == "F") echo "checked"; ?>> Feminino
</div>
<div class="form-group">
<label for="estado">Estado:</label>
  <?php echo $metodos->listarNaturalidade($buscar = $_POST["Naturalidade"]); ?>
</div>
<div class="form-group">
<label for="email">E-mail: <small>O e-mail será o login do(a) atleta e a senha será gerada e enviada para o e-mail de cadastro</small></label>
<input type="email" name="Email" id="email" class="form-control" required value="<?php echo $_POST["Email"]; ?>">
</div>
  <div class="form-group" align="center">
    <button type="submit" class="btn btn-primary" name="btnBuscar"><i class="fas fa-save"></i> Salvar</button>
  </div>
</form>
</div>
</div>
      </div>
     </div>
    </div>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/jquery.maskedinput-master/dist/jquery.maskedinput.js" type="text/javascript"></script>
   <script type="text/javascript">
       $(function() {
           $.mask.definitions['~'] = "[+-]";
           $("#dataNascimento").mask("99/99/9999");
       });
   </script>
   <script>
   $(document).ready(function(){
          $("div.alert").fadeIn( 300 ).delay( 3000 ).fadeOut( 400 );
         });
   </script>
  </body>
</html>
