<?php
/*
  // Habilitar as linhas abaixo em caso de erro....
  ini_set('display_errors',1);
  ini_set('display_startup_erros',1);
  error_reporting(E_ALL);
 */
/**
* NOTE: Dispensamos o uso do try e catch
*/
// Habilitar essa linha
error_reporting(0);
session_start();

require_once("../../classes/conectaClass.php");
//require_once("../../site/classes/conectaClass.php");

class metodosClass
{

  public $conexao;

  /**
   * Classe construtor
   */
  public function __construct()
  {
      $conectar = new conectaClass();
      $this->conexao = $conectar->conectar();
      return $this->conexao;
  }

  /**
  * Método armazena os logs de acesso ao site
  * @access public
  * @param string $ip
  */
  public function logs($ip)
  {
    mysqli_query($this->conexao, "INSERT INTO acessos VALUES(null,'" . $ip . "',NOW());");
  }

  /**
   * Método converte o nome com a primeira letra em caixa alta
   * @access public
   * @param string $palavra
   * @return string $nomeUsuario
   */
  public function palavraMinuscula($palavra)
  {
    $nomeUsuario = mb_convert_case($palavra, MB_CASE_TITLE, 'UTF-8');
    return  $nomeUsuario;
  }

  /**
  * Método cria o caminho absoluto dos links. Encontra-se em todas as páginas
  * @access public
  * @param null
  * @return string $caminhoAbsoluto
  */
  public function caminhoAbsoluto()
  {
  //  $caminhoAbsoluto = "https://".$_SERVER['SERVER_NAME']."/Projetos/CTCB/controle/sistema"; // local
    $caminhoAbsoluto = "https://intranet.ctcb.org.br/sistema"; // remoto
    return $caminhoAbsoluto;
  }

  /**
  * Método cria a chave lado cliente (Google recaptcha). Veja o método recaptcha($key)
  * Encontra-se nas páginas area-associados.php, cadastrar-associados.php
  * @access public
  * @param null
  * @return string $siteKey
  */
  public function siteKey()
  {
    $siteKey = '6Lc6ynwUAAAAAHLWy-hSJel8KT6FQXaG_nS6Aex4';
    return $siteKey;
  }

  /**
  * Método cria a chave lado servidor (Google recaptcha). Veja o método recaptcha($key)
  * Encontra-se nas páginas area-associados.php, cadastrar-associados.php
  * @access public
  * @param null
  * @return string $secretKey
  */
  public function secretKey()
  {
    $secretKey = '6Lc6ynwUAAAAAA7t43SzBYHzFjwmbYXu4qIfaIPX';
    return $secretKey;
  }

  /**
  * Método validar o acesso aos usuários
  * Encontra-se em todas as páginas
  * @access public
  * @param string $login, $senha
  * @return true
  */
  public function validarUsuarios($login,$senha)
  {
     $login = mysqli_real_escape_string($this->conexao,$login);
     $senha = $this->codificar(mysqli_real_escape_string($this->conexao,$senha));
     $sql = mysqli_query($this->conexao,"SELECT * FROM clube WHERE email = '".$login."' AND senha = '".$senha."';");
     $ctcb = mysqli_fetch_object($sql);
     if(mysqli_num_rows($sql) == 0)
     {
       $_SESSION["ErroLogin"] = time() + 5;
       return "<script>window.location.href='".$this->caminhoAbsoluto()."/'</script>";
     }
     else
     {
       $_SESSION["Logado"] = true;
       $_SESSION["IdClube"] = $ctcb->clube;
       return "<script>window.location.href='".$this->caminhoAbsoluto()."/sistema/'</script>";
     }
   }

   public function listarEventosCombox()
   {
     $sqlClubes = mysqli_query($this->conexao,"SELECT * FROM evento_local WHERE clube = '".$_SESSION["IdClube"]."';");
     if(mysqli_num_rows($sqlClubes) > 0)
     {
        $visualizar = "<div class=\"form-group\">";
        $visualizar .= "<label>Eventos:</label>";
        $visualizar .= "<select class=\"form-control\" id='id_categoria' name=\"Eventos\">";
        $visualizar .= "<option value=\"\">Selecione uma opção</option>";
        $dataInicio = mktime(23, 59, 59, date('m'), date('d')-date('j'), date('Y') - 2);
        $data = date("Y-m-d",$dataInicio);
        while($sqlEventosClubes = mysqli_fetch_object($sqlClubes))
        {            
          $sqlEventos = mysqli_query($this->conexao,"SELECT evento,idcodevento,nome,data_inicio, data_termino, DATE_FORMAT(data_inicio,'%d/%m') AS DataInicio, DATE_FORMAT(data_termino,'%d/%m/%Y') AS DataTermino FROM evento WHERE evento = '".$sqlEventosClubes->evento."';");
          $ctcb = mysqli_fetch_object($sqlEventos);
          if($ctcb->data_termino > $data)
          {
              $visualizar .= "<option value='".$ctcb->evento."'>".$ctcb->DataTermino." - ".$ctcb->nome."</option>";
          }    
        }        
        $visualizar .= "</select>";
        $visualizar .= "</div>";
        $visualizar .= "<div class=\"form-group\">
                          <label>Provas:</label>
                          <span class=\"carregando\">Aguarde, carregando...</span>
                          <select class=\"form-control\" name=\"Provas\" id='id_sub_categoria'>
                            <option value=\"\">Selecione uma opção acima</option>
                          </select>
                        </div>";
     }else{
         $visualizar = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> Ainda não existem provas lançadas para o seu clube. Favor entrar em contato com o telefone (21) 2292-0888</div>';
     }
   return $visualizar;
   }

  public function listarSubCategoriaCombox($idCategoria)
  {
     //$sqlSubCategoria = mysqli_query($this->conexao,"SELECT * FROM evento EVENTO INNER JOIN evento_prova EVPROVA ON EVENTO.evento = EVPROVA.evento INNER JOIN prova PROVA ON PROVA.prova = EVPROVA.prova WHERE EVPROVA.evento = '".$idCategoria."';");
     $sqlSubCategoria = mysqli_query($this->conexao,"SELECT * FROM evento_prova PROVA INNER JOIN evento_local EVLOCAL ON PROVA.evento = EVLOCAL.evento WHERE PROVA.evento = '".$idCategoria."' AND EVLOCAL.clube = '".$_SESSION["IdClube"]."';");
     while($ctcb = mysqli_fetch_assoc($sqlSubCategoria))
     {
       $sqlProva = mysqli_query($this->conexao, "SELECT * FROM prova WHERE prova = '".$ctcb['prova']."';"); 
       $ctcbProva = mysqli_fetch_assoc(($sqlProva));
       $sub_categorias_post[] = array(
        'id'	=> $ctcbProva['prova'],
        'nomeProva' => $ctcbProva['nome'],
      );
     }
    return (json_encode($sub_categorias_post));
  }

  public function listarInscricoes($clube,$evento,$prova)
  {
     $sql = mysqli_query($this->conexao,"SELECT *,ATIRADOR.nome AS NomeAtirador
                                         FROM atirador ATIRADOR
                                         INNER JOIN evento_atirador EVATIRADOR ON ATIRADOR.atirador = EVATIRADOR.atirador
                                         INNER JOIN evento_local EVLOCAL ON EVLOCAL.evento_local = EVATIRADOR.evento_local
                                         INNER JOIN evento_prova EVPROVA ON EVPROVA.evento_prova = EVATIRADOR.evento_prova
                                         WHERE EVLOCAL.clube = '".$clube."'
                                         AND EVATIRADOR.evento = '".$evento."'
                                         AND EVPROVA.prova = '".$prova."';");
      $sqlProva = mysqli_query($this->conexao,"SELECT * FROM prova WHERE prova = '".$prova."';");
      $ctcbProva = mysqli_fetch_object($sqlProva);
      $prova = $ctcbProva->nome;
      $visualizar = '<table class="table table-bordered" style="background: #FFF">
                      <thead class="thead-dark">
                        <tr>
                          <th scope="col">Cód</th>
                          <th scope="col">Nome</th>
                          <th scope="col">Prova</th>
                          <th scope="col">Qtd.</th>
                          <th scope="col">Estadual</th>
                          <th scope="col">Nacional</th>
                          <th scope="col">Excluir</th>
                        </tr>
                      </thead>
                      <tbody>';
      if(mysqli_num_rows($sql) == 0)
      {
        $visualizar .= "<td colspan='7' style='color: #00a121; font-weight: bold; text-align: center'>Ainda não existem inscrições efetuadas!</td>";
      }
      else
      {
        while($ctcb = mysqli_fetch_object($sql))
        {
           $sqlContar = mysqli_query($this->conexao,"SELECT * FROM evento_atirador WHERE atirador = '".$ctcb->atirador."' AND evento = '".$evento."';");
           $contar = mysqli_num_rows($sqlContar);
           $visualizar .= "<tr>";
           $visualizar .= "<td>".$ctcb->atirador."</td>";
           $visualizar .= "<td>".$ctcb->NomeAtirador."</td>";
           $visualizar .= "<td>".$prova."</td>";
           $visualizar .= "<td style='text-align: center'>".$contar."</td>";
           if($ctcb->tipo == 'R'){ $checkE = '<i class="fas fa-check"></i>'; }else{ $checkE = ''; }
           if($ctcb->tipo == 'N'){ $checkN = '<i class="fas fa-check"></i>'; }else{ $checkN = ''; }
           $visualizar .= "<td style='text-align: center'>".$checkE."</td>";
           $visualizar .= "<td style='text-align: center'>".$checkN."</td>";
           $visualizar .= "<td style='text-align: center'><a href='#!' id=\"btnVisualizarCasas\" data-id='".$ctcb->evento_atirador."' data-toggle=\"modal-3\" title=\"Excluir a inscrição do(a) atirador(a)  ".$ctcb->NomeAtirador."\" style='color: #000'><i class=\"far fa-trash-alt\"></i></a></td>";
           $visualizar .= "</tr>";
        }
      }
      $visualizar .= " <div class=\"modal fade\" id=\"casasRegionais\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"\" aria-hidden=\"true\">
                       <div class=\"modal-dialog\">
                           <div>
                               <div id=\"tela\">
                               </div>
                           </div>
                       </div>
                   </div>";
      $visualizar .= "<script>
                      $(\"table\").on('click',\"#btnVisualizarCasas\", function(){
                          var posts = $(this).attr('data-id');
                          $.post('".$this->caminhoAbsoluto()."/excluir-inscricao/', {key: posts}, function(retorno){
                           // console.log(retorno);
                                 $(\"#casasRegionais\").modal({ backdrop: 'static' });
                                 $(\"#tela\").html(retorno);
                          });
                      });
                      </script>";
      $visualizar .= "</tbody>";
      $visualizar .= "</table>";
    return $visualizar;
  }

  public function provasRealizadas($clube,$evento){
    $sqlProvas = mysqli_query($this->conexao,"SELECT * FROM evento_atirador EVATIRADOR
                                              INNER JOIN evento_local EVLOCAL ON EVATIRADOR.id_evento_local = EVLOCAL.evento_local
                                              WHERE EVLOCAL.evento <> '".$evento."'
                                              AND EVLOCAL.clube = '".$clube."';");
    if(mysqli_num_rows($sqlProvas) == 0)
    {
      $visualizar = '<p style="margin-top: 10px; color: #a6a7c5">Não existem outras provas efetuadas pelo clube!</p>';
    }
    else
    {
      $visualizar = "";
      while($ctcb = mysqli_fetch_object($sqlProvas))
      {
        $sqlProva = mysqli_query($this->conexao,"SELECT * FROM evento_prova EVPROVA INNER JOIN prova PROV ON EVPROVA.prova = PROV.prova WHERE EVPROVA.evento_prova = '".$ctcb->evento_prova."' LIMIT 3;");
        $ctcbProva = mysqli_fetch_object($sqlProva);
        $visualizar .= $ctcbProva->nome."<br>";
      }
    }
    return $visualizar;
  }

  public function excluirInscricao($key)
  {
    $id = mysqli_real_escape_string($this->conexao,$key);
    $sql = mysqli_query($this->conexao,"DELETE FROM evento_atirador WHERE evento_atirador = '".$id."';");
    $_SESSION["SucessoExcluir"] = time() + 5;
    return "<script>window.location.href='".$this->caminhoAbsoluto()."/conteudo/'</script>";
  }

  /**
  * Resultado PROVAS
  */
  public function resultadoProvas($clube,$evento,$prova)
  {
    $visualizar = '<div class="row">';
    $visualizar .= '<div class="col-md-4"><img src="'.$this->caminhoAbsoluto().'/imagens/logo.png" class="logo"></div>';
    $visualizar .= '<div class="col-md-8 text-right">
                       <small>
                       Confederação de Tiro e Caça do Brasil<br>
                       https://www.ctcb.org.br - atendimento@ctcb.org.br
                       </small>
                    </div>';
    $sqlEvento = mysqli_query($this->conexao,"SELECT * FROM evento WHERE evento = '".$evento."';");
    $ctcbEvento = mysqli_fetch_object($sqlEvento);
    list($anoI,$mesI,$diaI) = explode("-",$ctcbEvento->data_inicio);
    $dataInicio = $diaI."/".$mesI."/".$anoI;
    list($anoF,$mesF,$diaF) = explode("-",$ctcbEvento->data_termino);
    $dataFinal = $diaF."/".$mesF."/".$anoF;
    $sqlClube = mysqli_query($this->conexao,"SELECT * FROM clube WHERE clube = '".$clube."';");
    $ctcbClube = mysqli_fetch_object($sqlClube);
    $visualizar .= '<p style="text-transform: uppercase; margin-top: 10px; padding: 10px; color: #000080">'.$ctcbEvento->nome.' - '.$dataInicio.' a '.$dataFinal.'<br><span style="font-size: 13px">'.$ctcbClube->nome.'</span></p>';
    $sqlProva = mysqli_query($this->conexao,"SELECT * FROM prova WHERE prova = '".$prova."';");
    $ctcbProva = mysqli_fetch_object($sqlProva);
    $visualizar .= '<p style="padding: 10px; margin-top: -10px; font-size: 18px; text-transform: uppercase; font-weight: bold"><i class="fas fa-caret-right"></i>  '.$ctcbProva->nome.'</span></p>';
    $visualizar .= '<table class="table table-sm table-bordered table-striped">
                      <thead>
                        <tr>
                          <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">CL</th>
                          <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Cód.</th>
                          <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Nome</th>
                          <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">R1</th>
                          <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">R2</th>
                          <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">R3</th>
                          <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">R4</th>
                          <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">R5</th>
                          <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">RF</th>
                        </tr>
                      </thead>
                      <tbody>';
   /* 
    $sqlResultados = mysqli_query($this->conexao,"SELECT *,ATIRADOR.nome AS NomeAtirador,GREATEST(EVATIRADOR.serie1, EVATIRADOR.serie2, EVATIRADOR.serie3, EVATIRADOR.serie4, EVATIRADOR.serie5) AS MaiorNota
                                        FROM atirador ATIRADOR
                                        INNER JOIN evento_atirador EVATIRADOR ON ATIRADOR.atirador = EVATIRADOR.atirador
                                        INNER JOIN evento_local EVLOCAL ON EVLOCAL.evento_local = EVATIRADOR.id_evento_local
                                        WHERE  EVATIRADOR.evento = '".mysqli_real_escape_string($this->conexao,$evento)."'
                                        AND EVLOCAL.clube = '".$clube."' ORDER BY MaiorNota DESC;");
    */
    $sqlResultados = mysqli_query($this->conexao,"SELECT *,ATIRADOR.nome AS NomeAtirador, GREATEST(EVATIRADOR.serie1, EVATIRADOR.serie2, EVATIRADOR.serie3, EVATIRADOR.serie4, EVATIRADOR.serie5) AS MaiorNota
                                         FROM atirador ATIRADOR
                                         INNER JOIN evento_atirador EVATIRADOR ON ATIRADOR.atirador = EVATIRADOR.atirador
                                         INNER JOIN evento_local EVLOCAL ON EVLOCAL.evento_local = EVATIRADOR.evento_local
                                         INNER JOIN evento_prova EVPROVA ON EVPROVA.evento_prova = EVATIRADOR.evento_prova
                                         WHERE EVLOCAL.clube = '".$clube."'
                                         AND EVATIRADOR.evento = '".$evento."'
                                         AND EVPROVA.prova = '".$prova."';");
    $c = 1;
    while($ctcbResultados = mysqli_fetch_object($sqlResultados))
    {
      $visualizar .= '<tr>';
      $visualizar .= '<td>'.$c.'º</td>';
      $visualizar .= '<td>'.$ctcbResultados->atirador.'</td>';
      $visualizar .= '<td>'.$ctcbResultados->NomeAtirador.'</td>';
      $visualizar .= '<td>'.$ctcbResultados->serie1.'</td>';
      $visualizar .= '<td>'.$ctcbResultados->serie2.'</td>';
      $visualizar .= '<td>'.$ctcbResultados->serie3.'</td>';
      $visualizar .= '<td>'.$ctcbResultados->serie4.'</td>';
      $visualizar .= '<td>'.$ctcbResultados->serie5.'</td>';
      $visualizar .= '<td>'.$ctcbResultados->MaiorNota.'</td>';
      $c++;
    }
    $visualizar .= '</tbody>';
    $visualizar .= '</table>';
    $visualizar .= '</div>';
   return $visualizar;
  }

  public function resultadoEventos($clube,$evento)
  {
    $visualizar = '<div class="row">';
    $visualizar .= '<div class="col-md-4"><img src="'.$this->caminhoAbsoluto().'/imagens/logo.png" class="logo"></div>';
    $visualizar .= '<div class="col-md-8 text-right">
                       <small>
                       Confederação de Tiro e Caça do Brasil<br>
                       https://www.ctcb.org.br - atendimento@ctcb.org.br
                       </small>
                    </div>';
    $sqlEvento = mysqli_query($this->conexao,"SELECT * FROM evento WHERE evento = '".$evento."';");
    $ctcbEvento = mysqli_fetch_object($sqlEvento);
    list($anoI,$mesI,$diaI) = explode("-",$ctcbEvento->data_inicio);
    $dataInicio = $diaI."/".$mesI."/".$anoI;
    list($anoF,$mesF,$diaF) = explode("-",$ctcbEvento->data_termino);
    $dataFinal = $diaF."/".$mesF."/".$anoF;
    $sqlClube = mysqli_query($this->conexao,"SELECT * FROM clube WHERE clube = '".$clube."';");
    $ctcbClube = mysqli_fetch_object($sqlClube);
    $visualizar .= '<p style="text-transform: uppercase; margin-top: 10px; padding: 10px; color: #000080">'.$ctcbEvento->nome.' - '.$dataInicio.' a '.$dataFinal.'<br><span style="font-size: 13px">'.$ctcbClube->nome.'</span></p>';
    $sqlProva = mysqli_query($this->conexao,"select * from prova PROVA
                                              inner join evento_prova EVPROVA
                                              on EVPROVA.prova = PROVA.prova
                                              inner join evento_local EVLOCAL
                                              on EVLOCAL.evento = EVPROVA.evento
                                              where EVPROVA.evento = '".$evento."' AND EVLOCAL.clube = '".$clube."';");
    while($ctcbProva = mysqli_fetch_object($sqlProva))
    {
      $sqlEvAtirador = mysqli_query($this->conexao,"SELECT *,GREATEST(serie1, serie2, serie3, serie4, serie5) AS MaiorNota FROM evento_atirador WHERE evento_prova = '".$ctcbProva->evento_prova."' AND evento_local = '".$ctcbProva->evento_local."' ORDER BY MaiorNota DESC;");
      if(mysqli_num_rows($sqlEvAtirador) > 0){
      $visualizar .= '<p style="padding: 10px; margin-top: -10px; font-size: 18px; text-transform: uppercase; font-weight: bold"><i class="fas fa-caret-right"></i>  '.$ctcbProva->nome.'</span></p>';
      $visualizar .= '<table class="table table-sm table-bordered table-striped">
                        <thead>
                          <tr>
                            <th scope="col" style="text-align: center" class="bg-success text-white">CL</th>
                            <th scope="col" style="text-align: center" class="bg-success text-white">Cód.</th>
                            <th scope="col" style="text-align: center" class="bg-success text-white">Nome</th>
                            <th scope="col" style="text-align: center" class="bg-success text-white">R1</th>
                            <th scope="col" style="text-align: center" class="bg-success text-white">R2</th>
                            <th scope="col" style="text-align: center" class="bg-success text-white">R3</th>
                            <th scope="col" style="text-align: center" class="bg-success text-white">R4</th>
                            <th scope="col" style="text-align: center" class="bg-success text-white">R5</th>
                            <th scope="col" style="text-align: center" class="bg-success text-white">RF</th>
                          </tr>
                        </thead>
                        <tbody>';
/*      $sqlResultados = mysqli_query($this->conexao,"select * from prova PROVA
		                                            inner join evento_prova EVPROVA
		                                            on EVPROVA.prova = PROVA.prova
		                                            inner join evento_local EVLOCAL
		                                            on EVLOCAL.evento = EVPROVA.evento
                                                   where EVPROVA.evento = '".$evento."' AND EVLOCAL.clube = '".$clube."';");

     // $c = 1;
$ctcbResultados = mysqli_fetch_object($sqlResultados);
 */
    // while($ctcbResultados = mysqli_fetch_object($sqlResultados))
      //{
$c = 1;
while($ctcbEvAtirador = mysqli_fetch_object($sqlEvAtirador)){
      
        $sqlAtirador = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE atirador = '".$ctcbEvAtirador->atirador."';");
        $ctcbAtirador = mysqli_fetch_object($sqlAtirador);
        if($ctcbAtirador->nome != "")
        {
        $visualizar .= '<tr>';
        $visualizar .= '<td>'.$c.'º</td>';
        $visualizar .= '<td>'.$ctcbAtirador->codigo.'</td>';
        $visualizar .= '<td>'.$ctcbAtirador->nome.'</td>';
        $visualizar .= '<td>'.$ctcbEvAtirador->serie1.'</td>';
        $visualizar .= '<td>'.$ctcbEvAtirador->serie2.'</td>';
        $visualizar .= '<td>'.$ctcbEvAtirador->serie3.'</td>';
        $visualizar .= '<td>'.$ctcbEvAtirador->serie4.'</td>';
        $visualizar .= '<td>'.$ctcbEvAtirador->serie5.'</td>';
        $visualizar .= '<td>'.$ctcbEvAtirador->MaiorNota.'</td>';
        }
        $c++;
      }
      $visualizar .= '</tbody>';
      $visualizar .= '</table>';
      }
    }
    $visualizar .= '</div>';
   return $visualizar;
  }

  public function validarCadastro($cpf)
  {
    $cpf = mysqli_real_escape_string($this->conexao,$cpf);
    $cpf = $this->limpaCPF_CNPJ($cpf);
    $sqlValidar = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE cpf = '".$cpf."';");
    if(mysqli_num_rows($sqlValidar) > 0)
    {
      $_SESSION["CPFCadastrado"] = time() + 5;
    }
    else
    {
      $_SESSION["CPF"] = $cpf;
      $_SESSION["CPFCadastrar"] = true;
      return "<script>window.location.href='".$this->caminhoAbsoluto()."/cadastro-atirador/'</script>";
    }
  }

   /**
    * Método mostra o mês por extenso
    * @access public
    * @param string $mes
    * @return string $mes
    */
   public function mesExtenso($mes)
   {
     switch ($mes)
     {
        case '01': $mes = "janeiro"; break;
        case '02': $mes = "fevereiro"; break;
        case '03': $mes = "março"; break;
        case '04': $mes = "abril"; break;
        case '05': $mes = "maio"; break;
        case '06': $mes = "junho"; break;
        case '07': $mes = "julho"; break;
        case '08': $mes = "agosto"; break;
        case '09': $mes = "setembro"; break;
        case '10': $mes = "outubro"; break;
        case '11': $mes = "novembro"; break;
        case '12': $mes = "dezembro"; break;
     }
     return $mes;
   }

   public function buscarAtletas($assunto,$tipoBusca,$evento,$prova)
   {
      if ($tipoBusca == "estadual")
      {
        $sqlClubes = mysqli_query($this->conexao,"SELECT * FROM clube WHERE clube = '".$_SESSION["IdClube"]."';");
        $ctcbClubes = mysqli_fetch_object($sqlClubes);
        $estado = $ctcbClubes->id_estado;
        $sql = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE nome LIKE '" . $assunto. "%' AND id_estado = '".$estado."' ORDER BY nome ASC LIMIT 7");
      }
      if ($tipoBusca == "nacional")
      {
         $sql = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE nome LIKE '" . $assunto. "%' ORDER BY nome ASC LIMIT 7");
      }
      while ($ctcb = mysqli_fetch_assoc($sql))
      {
          $sqlEventoProva = mysqli_query($this-> conexao, "SELECT * FROM evento_atirador EVATIRADOR INNER JOIN evento_prova EVPROVA ON EVATIRADOR.evento_prova = EVPROVA.evento_prova WHERE EVATIRADOR.atirador = '".$ctcb['atirador']."' AND EVPROVA.prova = '".$prova."' AND EVPROVA.evento = '".$evento."';");
          if (mysqli_num_rows($sqlEventoProva) == 0)
          {
           $visualizar[] = $ctcb['nome'];
          }
      }
    return json_encode($visualizar);
   }

   public function inscricaoAtletas($clube,$atleta,$evento,$prova,$tipoCadastro)
   {
     $atleta = mysqli_real_escape_string($this->conexao,$atleta);
     $evento = mysqli_real_escape_string($this->conexao,$evento);
     $prova = mysqli_real_escape_string($this->conexao,$prova);
     $eventoLocal = mysqli_query($this->conexao,"SELECT * FROM evento_local WHERE evento = '".$evento."' AND clube = '".$clube."';");
     $ctcbLocal = mysqli_fetch_object($eventoLocal);
     $idLocal = $ctcbLocal->evento_local;
     $eventoProva = mysqli_query($this->conexao,"SELECT * FROM evento_prova WHERE evento = '".$evento."' AND prova = '".$prova."';");
     $ctcbProva = mysqli_fetch_object($eventoProva);
     $idProva = $ctcbProva->evento_prova;
     $sqlAtleta = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE nome = '".trim($atleta)."';");
     $ctcbAtleta = mysqli_fetch_object($sqlAtleta);
     $idAtleta = $ctcbAtleta->atirador;
     $tipo = ($tipoCadastro == 'estadual')?'R':'N';
     $sqlCadastrar = mysqli_query($this->conexao,"INSERT INTO evento_atirador(evento,atirador,categoria,evento_prova,evento_local,tipo)
                     VALUES('".$evento."','".$idAtleta."','8','".$idProva."','".$idLocal."','".$tipo."');");
     if (mysqli_affected_rows($this->conexao) > 0)
     {
       $_SESSION["Sucesso"] = time() + 10;
       $link = ($tipoCadastro == "estadual")?'atleta-estadual':'atleta-nacional';
       return "<script>window.location.href='".$this->caminhoAbsoluto()."/".$link."/';</script>";
     }
     else
     {
       $_SESSION["Erro"] = time() + 10;
     }
   }

  public function contabilizarInscricoes($clube,$evento,$prova){
      $sqlContar = mysqli_query($this->conexao,"SELECT *,ATIRADOR.nome AS NomeAtirador
                                                FROM atirador ATIRADOR
                                                INNER JOIN evento_atirador EVATIRADOR ON ATIRADOR.atirador = EVATIRADOR.atirador
                                                INNER JOIN evento_local EVLOCAL ON EVLOCAL.evento_local = EVATIRADOR.id_evento_local
                                                WHERE  EVATIRADOR.evento = '".mysqli_real_escape_string($this->conexao,$evento)."'
                                                AND EVLOCAL.clube = '".$clube."';");
      $contar = mysqli_num_rows($sqlContar);
      return $contar;
   }

   public function lancarResultados($clube,$evento,$prova)
   {
      $sql = mysqli_query($this->conexao,"SELECT *,ATIRADOR.nome AS NomeAtirador
                                         FROM atirador ATIRADOR
                                         INNER JOIN evento_atirador EVATIRADOR ON ATIRADOR.atirador = EVATIRADOR.atirador
                                         INNER JOIN evento_local EVLOCAL ON EVLOCAL.evento_local = EVATIRADOR.evento_local
                                         INNER JOIN evento_prova EVPROVA ON EVPROVA.evento_prova = EVATIRADOR.evento_prova
                                         WHERE EVLOCAL.clube = '".$clube."'
                                         AND EVATIRADOR.evento = '".$evento."'
                                         AND EVPROVA.prova = '".$prova."';");
      if(mysqli_num_rows($sql) == 0)
      {
       $visualizar = '<div style="text-align: center;"><span style="color: #FFF; font-weight: bold">Não existem atiradores cadastrados nessa prova!</span></div>';
      }
      else
      {
        $visualizar = "";
        $c = 0;
        while($ctcb = mysqli_fetch_object($sql))
        {
          $visualizar .= '<input type="hidden" name="EventoAtirador[]" value="'.$ctcb->evento_atirador.'">';
          $visualizar .= '<div class="form-group">';
          $visualizar .= '<label><i class="fas fa-user"></i> '.$ctcb->NomeAtirador.'</label>';
          $visualizar .= '<div class="row">';
          $visualizar .= '<div class="col-md-2"><input type="text" name="LancarNotas1[]" step="0.1" max="200" class="form-control" value="'.$ctcb->serie1.'"></div>';
          $visualizar .= '<div class="col-md-2"><input type="text" name="LancarNotas2[]" step="0.1" max="200" class="form-control" value="'.$ctcb->serie2.'"></div>';
          $visualizar .= '<div class="col-md-2"><input type="text" name="LancarNotas3[]" step="0.1" max="200" class="form-control" value="'.$ctcb->serie3.'"></div>';
          $visualizar .= '<div class="col-md-2"><input type="text" name="LancarNotas4[]" step="0.1" max="200" class="form-control" value="'.$ctcb->serie4.'"></div>';
          $visualizar .= '<div class="col-md-2"><input type="text" name="LancarNotas5[]" step="0.1" max="200" class="form-control" value="'.$ctcb->serie5.'"></div>';
          $visualizar .= '</div>';
          $visualizar .= '</div>';
          $c++;
        }
        $visualizar .= '<div class="form-group" align="center">
                          <button type="submit" class="btn btn-primary" name="btnBuscar">Lançar Resultados</button>
                        </div>';
      }
      return $visualizar;
   }

  public function cadastrarNotas($eventoAtirador,$notas1,$notas2,$notas3,$notas4,$notas5)
  {
      for($a = 0; $a < count($eventoAtirador); $a++)
      {
         mysqli_query($this->conexao,"UPDATE evento_atirador SET serie1 = '".$notas1[$a]."',serie2 = '".$notas2[$a]."',serie3 = '".$notas3[$a]."',serie4 = '".$notas4[$a]."',serie5 = '".$notas5[$a]."' WHERE evento_atirador = '".$eventoAtirador[$a]."';");
         
      }
    //  if(mysqli_affected_rows($this->conexao) > 0)
     // {
          $_SESSION["SucessoNotas"] = time() + 5;         
          return "<script>window.location.href='".$this->caminhoAbsoluto()."/cadastrar-resultados/';</script>";
     // }
  }

  /**
   * Método cadastra os atiradores
   * @param string $nome
   * @param string $cpf
   * @param string $dataNascimento
   * @param string $genero
   * @param string $estado
   * @param string $email
   * @return true
   */      
  public function cadastrarAtirador($nome,$cpf,$dataNascimento,$genero,$estado,$email){
    $senha = $this->generatePassword($qtyCaraceters = 8);
    $codificar = $this->codificar($senha);
    list($dia,$mes,$ano) = explode("/",$dataNascimento);
    $dataNascimento = $ano."-".$mes."-".$dia;
    $sqlEstado = mysqli_query($this->conexao,"SELECT * FROM estado WHERE sigla = '".$estado."';");
    $ctcbEstado = mysqli_fetch_object($sqlEstado);
    $estado = $ctcbEstado->estado;
    $sql = mysqli_query($this->conexao,"INSERT INTO atirador (anuidade_tipo, data_cadastro, nome, data_nascimento, email, cpf, sexo, nacionalidade, naturalidade, status, eh_atleta, eh_instrutor, eh_arbitro, eh_colecionador, eh_cacador, eh_recarga, senha, para_atleta) VALUES('1',CURDATE(),'".$nome."','".$dataNascimento."','".$email."','".$cpf."','".$genero."','1', '".$estado."', 'A', 'S', 'N', 'N', 'N', 'N', 'N','".$codificar."','N');");
    if(mysqli_affected_rows($this->conexao) > 0)
    {
      require 'phpmailer/PHPMailerAutoload.php';
      require 'phpmailer/class.phpmailer.php';
      $mailer = new PHPMailer;
      $mailer->isSMTP();
      $mailer->SMTPOptions = array(
          'ssl' => array(
              'verify_peer' => false,
              'verify_peer_name' => false,
              'allow_self_signed' => true
          )
      );
      $assunto = "Dados de Acesso - Confederação de Tiro e Caça do Brasil";
      $mailer->Host = 'mail.ctcb.org.br';
      $mailer->SMTPAuth = true;
      $mailer->IsSMTP();
      $mailer->isHTML(true);
      $mailer->Port = 587;
      $mailer->CharSet = 'UTF-8';
      $mailer->Username = 'naoexclua@ctcb.org.br';
      $mailer->Password = 'confeder@c@o';
      $address = $email;
      $mensagem = '<table width="100%" border="0">';
      $mensagem .= '<tr>';
      $mensagem .= '<td style="text-align: left"><img src="https://www.ctcb.org.br/images/logo.png" alt="Logomarca da CTCB em letras azuis e partes da arma em verde" title="" class="logo img-fluid" style="width: 150px"></td>';
      $mensagem .= '<td style="text-align: right"><small>https://www.ctcb.org.br<br>atendimento@ctcb.org.br</small></td>';
      $mensagem .= '</tr>';
      $mensagem .=  '</table>';
      $mensagem .= '<br>';
      $mensagem .= '<p>Olá <strong>'.$nome.'</strong>.<br>
                    Segue  abaixo seus novos dados para o acesso ao sistema da CTCB:<br><br>
                    https://www.ctcb.org.br<br><br>
                    <strong>E-mail:</strong> '.$email.'<br>
                    <strong>Senha:</strong> '.$senha.'<br><br>
                    Em caso de dúvidas utilize o nosso formulário de Contato no site.</p>';
      $mailer->AddAddress($address, "CTCB - Confederação de Tiro e Caça do Brasil");
      $mailer->From = 'atendimento@ctcb.org.br';
      $mailer->FromName = "CTCB - Confederação de Tiro e Caça do Brasil";
      $mailer->Subject = $assunto;
      $mailer->MsgHTML($mensagem);
      $mailer->Send();
      $idAtirador = mysqli_insert_id($this->conexao);
      $idCodAtirador = $this->codificar($idAtirador);
      $codigo = sprintf("%05d", $idAtirador);
      mysqli_query($this->conexao,"UPDATE atirador SET id_cod_atirador = '".$idCodAtirador."', codigo = '".$codigo."' WHERE atirador = '".$idAtirador."';");
      $_SESSION["Sucesso"] = time() + 10;
      unset($_SESSION["CPF"]);
      $_SESSION["CPFLogado"] = false;
      unset($_SESSION["CPFLogado"]);
      return "<script>window.location.href='".$this->caminhoAbsoluto()."/cadastrar-atirador/'</script>";
    }
  }

  /**
 * Método lista em uma combox na Naturalidade
 * Encontra-se na página cadastrar-associado.php
 * @access public
 * @param null
 * @return $visualizar
 */
public function listarNaturalidade($buscar)
{
  $visualizar = "<select name='Naturalidade' class='form-control'>";
  $visualizar .= "<option>Selecione uma opção</option>";
  $sqlNaturalidade = mysqli_query($this->conexao,"SELECT * FROM estado;");
  while($listar = mysqli_fetch_object($sqlNaturalidade))
  {
        if($buscar != null)
        {
           if($listar->sigla == $buscar)
           {
              $selected = 'selected';
           }
           else{
              $selected = "";
           }
        }
    $visualizar .= "<option value='".$listar->sigla."' ".$selected.">".$listar->nome."</option>";
  }
  $visualizar .= "</select>";
  return $visualizar;
}

  /**
   * Método visualiza genericamente todas as tabelas
   * @access public
   * @param string $tabela
   * @param int $idTabela, $idBusca
   * @return array
   */
  public function visualizar($tabela, $idTabela, $idBusca)
  {
     $sqlVisualizar = mysqli_query($this->conexao, "SELECT * FROM " . $tabela . " WHERE " . $idTabela . " = '" . mysqli_real_escape_string($this->conexao, $idBusca) . "';");
     return array(mysqli_num_rows($sqlVisualizar),mysqli_fetch_object($sqlVisualizar));
  }

  /**
 * Método retira os caracteres do CPF e CNPJ
 * Encontra-se na página cadastro-associado.php
 * @access public
 * @param string $valor
 * @return true
 */
  public function limpaCPF_CNPJ($valor)
  {
    $valor = trim($valor);
    $valor = str_replace(".", "", $valor);
    $valor = str_replace(",", "", $valor);
    $valor = str_replace("-", "", $valor);
    $valor = str_replace("/", "", $valor);
    return $valor;
  }

  /**
 * Gera senhas aleatórias *
 * @param int $qtyCaraceters quantidade de caracteres na senha, por padrão 8
 * @author Método criado pelo colega Carlos Ferreira carlos@especializati.com.br
 * @return String
*/
function generatePassword($qtyCaraceters = 8)
{
    $smallLetters = str_shuffle('abcdefghijklmnopqrstuvwxyz');
    $capitalLetters = str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ');
    $numbers = (((date('Ymd') / 12) * 24) + mt_rand(800, 9999));
    $numbers .= 1234567890;
    $specialCharacters = str_shuffle('!@#$%');
    $characters = $capitalLetters.$smallLetters.$numbers.$specialCharacters;
    $password = substr(str_shuffle($characters), 0, $qtyCaraceters);
    return $password;
}

  /**
   * Codifica a senha em 03 métodos de mão única. Sha1, MD5 invertido e crypt
   * @param type $senhaUsuario
   * @return type $codificar
   */
  public function codificar($key)
  {
      $salt = "$" . md5(strrev($key)) . "%";
      $codifica = crypt($key, $salt);
      $codificar = hash('sha512', $codifica);
      return $codificar;
  }

  /**
   * Método para sair do sistema. Encontra-se na página sair.php
   * @access public
   * @param null
   * @return true
   */
  public function sairSistema()
  {
    $_SESSION["Logado"] = false;
    unset($_SESSION["Logado"]);
    unset($_SESSION["IdClube"]);
   // $caminhoAbsoluto = "https://".$_SERVER['SERVER_NAME']."/Projetos/CTCB/controle";
    $caminhoAbsoluto = "https://intranet.ctcb.org.br/sistema"; 
    return "<script>window.location.href='".$caminhoAbsoluto."/'</script>";
  }

} // Fim da classe
