<?php
error_reporting(0);
session_start();
if($_SESSION["Logado"] == false){
  echo "<script>window.location.href='../index.php';</script>";
  exit();
}
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
if(!isset($_SESSION["Evento"]) || !isset($_SESSION["Prova"]))
{
  echo "<script>window.location.href='".$caminhoAbsoluto."/'</script>";
  exit();
}
if($_SESSION["SucessoExcluir"] < time())
{
  unset($_SESSION["SucessoExcluir"]);
}
$tabela = "clube";
$idTabela = "clube";
$idBusca = $_SESSION["IdClube"];
$visualizar = $metodos->visualizar($tabela,$idTabela,$idBusca);
$tabelaE = "evento";
$idTabelaE = "evento";
$idBuscaE = $_SESSION["Evento"];
$visualizarE = $metodos->visualizar($tabelaE,$idTabelaE,$idBuscaE);
$tabelaP = "prova";
$idTabelaP = "prova";
$idBuscaP = $_SESSION["Prova"];
$visualizarP = $metodos->visualizar($tabelaP,$idTabelaP,$idBuscaP);
list($anoE,$mesE,$diaE) = explode("-",$visualizarE[1]->data_inicio);
$dataEvento = $diaE."/".$mesE;


if(isset($_GET['atleta'])) {
  $atleta = $_GET['atleta'];
  echo $atleta;
} else {
  $atleta = "nenhum";
}

if ($_POST)
{
  $clube = $_SESSION["IdClube"];
  $atleta = filter_input(INPUT_POST, 'Atleta', FILTER_SANITIZE_STRING);
  $evento = $_SESSION["Evento"];
  $prova = $_SESSION["Prova"];

     // Construir a URL com o parâmetro GET $atleta
     $urlRedirecionamento = $caminhoAbsoluto . "/listar_resultado_anterior.php?atleta=" . urlencode($atleta);
    
     // Redirecionar para a página com a variável $atleta
     header("Location: " . $urlRedirecionamento);
     exit(); // Certifique-se de terminar o script depois do redirecionamento
}



?>



<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Controle de Gestão | Clubes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/css/style.css">
    <style type="text/css">
			.carregando{
				color:#ff0000;
				display:none;
			}
		</style>
       <script src="<?php echo $caminhoAbsoluto; ?>/js/jquery.min.js"></script>
       <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
       <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  </head>
  <body>
   <div class="container">
     <div class="row header">
          <div class="col-md-6">
            <img src="<?php echo $caminhoAbsoluto; ?>/imagens/logo.png" alt="" class="logo">
         </div>
         <div class="col-md-6 text-right">
           <h3>SISTEMA DE GESTÃO | CLUBES</h3>
           <a href="<?php echo $caminhoAbsoluto; ?>/sair/" style="color: #df5400" alt="Sair do sistema" title="Sair do sistema"><i class="fas fa-power-off"></i></a>
         </div>
     </div>
     <div class="row conteudo">
        <div class="nomeClube">
           <?php echo $visualizar[1]->nome; ?><br>
           <span style="font-size: 14px"><?php echo $dataEvento ?> - <?php echo $visualizarE[1]->nome; ?> - <?php echo $visualizarP[1]->nome; ?></span>
        </div>
     
        <?php echo "Total de registros a serem atualizados: " . $metodos->calculaRegistrosDesatualizados(); ?><br><br>
<div class="row" style="margin-top: 50px">
  <h4 style="font-weight: bold; color:#00a121;">Registros incompletos disponíveis para alteração</h4><br><br>
  
  <div class="row" style="margin-top: 10px;">
  <div class="col-md-12">
   
 </div>


  <div class="col-md-4">
    <form class="" action="#!" method="post">
        <div class="form-group">
          <label>Buscar atleta:</label>
          <input type="text" name="Atleta" id="assunto" class="form-control">
      </div>
      <div class="form-group" align="center">
        <?php 
          $tabelaB = 'bloqueio_clubes';
          $idTabelaB = 'IdClubes';
          $idBuscaB = $_SESSION["IdClube"];
          $bloquearB = $metodos->visualizar($tabelaB,$idTabelaB,$idBuscaB);
          if($bloquearB[0] > 0 and $bloquearB[1]->IdEventos == $_SESSION["Evento"]){
        ?> 
            <button type="submit" class="btn btn-primary" name="btnBuscar" disabled>Buscar</button>
          <?php }else{ ?>
            <button type="submit" class="btn btn-primary" name="btnBuscar">Buscar</button>
          <?php  } ?>   
      </div>
    </form>
  </div>
  
  
  
  <?php if($_SESSION["SucessoExcluir"]){ ?>

    <div class="alert alert-success col-md-12" style="font-weight: bold"><i class="fas fa-check fa-lg"></i> Inscrição excluída com sucesso!</div>
  <?php } ?>

  <?php echo $metodos->listarInscricoesAnteriores($_SESSION["IdClube"],$_SESSION["Evento"],$_SESSION["Prova"],$atleta); ?>

</div>


      </div>
     </div>
    </div>
   <!-- Modal Provas -->
   <div class="modal fade bd-example-modal-lg" id="modalProvas" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true" data-backdrop="static">
       <div class="modal-dialog modal-lg">
         <div class="modal-content">
         <div class="modal-header bg-primary text-white">
           <h5 class="modal-title" id="exampleModalLabel" style="font-weight: bold"><i class="fas fa-file-alt"></i> RESULTADO DAS PROVAS</h5>
           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
         </div>
         <div class="modal-body">
              <?php echo $metodos->resultadoProvas($_SESSION["IdClube"],$_SESSION["Evento"],$_SESSION["Prova"]); ?>
         </div>
         <div class="modal-footer">
           <button type="button" class="btn btn-default fechar" data-dismiss="modal">Fechar</button>
            <button type="button" class="btn btn-primary" onClick="window.open('<?php echo $caminhoAbsoluto; ?>/imprimir-provas.php', '_blank', ''); window.close();" ><i class="fas fa-print"></i> Imprimir</button>
          </div>
         </div>
       </div>
    </div>

     <!-- Modal Eventos -->
     <div class="modal fade bd-example-modal-lg" id="modalEventos" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true" data-backdrop="static">
         <div class="modal-dialog modal-lg">
           <div class="modal-content">
           <div class="modal-header bg-success text-white">
             <h5 class="modal-title" id="exampleModalLabel" style="font-weight: bold"><i class="fas fa-copy"></i> RESULTADO DO EVENTO</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
             </button>
           </div>
           <div class="modal-body">
                  <?php echo $metodos->resultadoEventos($_SESSION["IdClube"],$_SESSION["Evento"]); ?>
           </div>
           <div class="modal-footer">
             <button type="button" class="btn btn-default fechar" data-dismiss="modal">Fechar</button>
              <button type="button" class="btn btn-success" onClick="window.open('<?php echo $caminhoAbsoluto; ?>/imprimir-eventos.php', '_blank', ''); window.close();" ><i class="fas fa-print"></i> Imprimir</button>
            </div>
           </div>
         </div>
      </div>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>
   <script>
            $(function () {
                $("#assunto").autocomplete({
                    source: '<?php echo $caminhoAbsoluto; ?>/processar-busca-atletas.php'
                });
            });
        </script>
   <script>
   $(document).ready(function(){
          $("div.alert").fadeIn( 300 ).delay( 3000 ).fadeOut( 400 );
         });
   </script>
  </body>
</html>
