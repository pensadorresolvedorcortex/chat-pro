<?php
error_reporting(0);
session_start();
if($_SESSION["Logado"] == false){
  echo "<script>window.location.href='../index.php';</script>";
  exit();
}
if(isset($_SESSION["Evento"]))
{
  unset($_SESSION["Evento"]);
}
if(isset($_SESSION["Prova"]))
{
  unset($_SESSION["Prova"]);
}
if(isset($_SESSION["TipoAtleta"]))
{
  unset($_SESSION["TipoAtleta"]);
}
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
$tabela = "clube";
$idTabela = "clube";
$idBusca = $_SESSION["IdClube"];
$visualizar = $metodos->visualizar($tabela,$idTabela,$idBusca);

//verificando o conteúdo da variável

?>

<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Controle de Gestão | Clubes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <style type="text/css">
			.carregando{
				color:#ff0000;
				display:none;
			}
		</style>
  </head>
  <body>
   <div class="container">
     <div class="row header">
          <div class="col-md-6">
            <img src="imagens/logo.png" alt="" class="logo">
         </div>
         <div class="col-md-6 text-right">
           <h3>SISTEMA DE GESTÃO | CLUBES</h3>
         </div>
      </div>
     <div class="row conteudo">
        <div class="nomeClube">
           <?php echo $visualizar[1]->nome; ?>
        </div>
      <div class="select">
        <form  action="<?php echo $caminhoAbsoluto; ?>/acessar/" method="post">
            <?php echo $metodos->listarEventosCombox(); ?>
        <div class="form-group">
             <div id="botaoImprimir"></div>
          </div>
        </form>
      </div>
      <div style="height: 380px"></div>
        </div>
      </div>

  <!--  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>-->
  <script src="<?php echo $caminhoAbsoluto; ?>/js/jquery.min.js"></script>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>
   <script type="text/javascript">
 		$(function(){
 			$('#id_categoria').change(function(){
         if( $(this).val() ) {
 					$('#id_sub_categoria').hide();
 					$('.carregando').show();
          $.getJSON('<?php echo $caminhoAbsoluto; ?>/selecionar-subcategoria.php?search=',{id_categoria: $(this).val(), ajax: 'true'}, function(j){
 	  var options = '';
          for (var i = 0; i < j.length; i++) {
                options += '<option value="' + j[i].id + '">' + j[i].nomeProva + '</option>';
           }
             $('#id_sub_categoria').html(options).show();
             $('.carregando').hide();
            });
           $('#botaoImprimir').html('<div align="center"> <button type="submit" name="button" class="btn btn-secondary" title="Avançar para a próxima etapa">Continuar <i class="fas fa-angle-double-right"></i></button> </div>');
 				} else {
 					$('#id_sub_categoria').html('<option value="">– Escolha Subcategoria –</option>');
 				}
    	      });
        
         });
    </script>
  </body>
</html>
