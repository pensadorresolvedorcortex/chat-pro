<?php
error_reporting(0);
session_start();
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
if($_POST){
	$login = $_POST["Login"];
	$senha = $_POST["Senha"];
	echo $metodos->validarUsuarios($login,$senha);
}
if($_SESSION["ErroLogin"] < time()){
	unset($_SESSION["ErroLogin"]);
}
    $caminhoAbsoluto = "https://".$_SERVER['SERVER_NAME'];
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link href="<?php echo $caminhoAbsoluto; ?>/css/style.css" rel="stylesheet">
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
		<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
		<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
	</head>
	<body style="background:#BA3A37">
			<div class="container">
			<div class="col-md-10 col-md-offset-1 main" >
			<div class="col-md-6 left-side" style="margin-top: 120px" align="center">
			<img src="<?php echo $caminhoAbsoluto; ?>/imagens/logo.png" alt="" class="img-responsive">
			</div><!--col-sm-6-->
			<div class="col-md-6 right-side">
			<h3 style="font-weight: bold"><i class="fas fa-lock"></i> Lembrar senha</h3>
			<div class="form">
				<?php if($_SESSION["ErroLogin"]){ ?>
				<div class="alert alert-danger" style="font-weight: bold"><i class="fas fa-exclamation-triangle fa-lg"></i> Login ou senha inválidos</div>
			<?php } ?>
				<form class="" action="#" method="post">
					<span>Esqueceu a senha? Isso acontece! Digite seu e-mail abaixo que enviaremos as instruções para a recuperação.</span>
			<div class="form-group" style="margin-top: 18px">
			<label for="login">Email:</label>
			<input type="text" name="Email" id="login" class="form-control input-lg">
			</div>
			<div class="text-right">
			<a href="<?php echo $caminhoAbsoluto; ?>/" style="color:#FFF" title="Esqueceu a senha?">Lembrou?</a>
			</div>
		</form>
	    <div style="padding: 50px"></div>
			</div>
			</div><!--col-sm-6-->
			</div><!--col-sm-8-->
			</div><!--container-->
			<script>
	    $(document).ready(function(){
	           $("div.alert").fadeIn( 300 ).delay( 3000 ).fadeOut( 400 );
	          });
	    </script>
	</body>
</html>
