<?php
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
$dados = array_filter($_POST);
$imagem = $_FILES['Imagem']['name'];
$temp = $_FILES['Imagem']['tmp_name'];
$arquivos = $_FILES['Arquivos']['name'];
$tempA = $_FILES['Arquivos']['tmp_name'];
echo $metodos->cadastrarNoticias($dados,$imagem,$temp,$arquivos,$tempA);
