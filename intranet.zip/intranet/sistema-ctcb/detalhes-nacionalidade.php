<?php
error_reporting(0);
session_start();
if($_SESSION["LogadoCTCB"] == false){
  echo "<script>window.location.href='../index.php';</script>";
  exit();
}
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
$tabela = "nacionalidade";
$idTabela = "nacionalidade";
$idBusca = $_SERVER["QUERY_STRING"];
$visualizar = $metodos->visualizar($tabela,$idTabela,$idBusca);
if($_POST["Submit"] == "Alterar"){
  $dados = array_filter($_POST);
  echo $metodos->alterarDadosAtirador($dados);
}
?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/css/style.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script src="<?php echo $caminhoAbsoluto; ?>/js/validar-cep.js"></script>
  </head>
  <body>
   <div class="container">
     <div class="row header">
          <div class="col-md-6">
            <a href="<?php echo $caminhoAbsoluto; ?>/"><img src="<?php echo $caminhoAbsoluto; ?>/imagens/logo.png" alt="Logo da CTCB" class="logo"></a>
         </div>
         <div class="col-md-6 text-right">
           <h3>SISTEMA DE GESTÃO | CTCB</h3>
           <a href="<?php echo $caminhoAbsoluto; ?>/sair/" style="color: #000" alt="Sair do sistema" title="Sair do sistema"><i class="fas fa-power-off"></i> Sair do sistema</a>
         </div>
     </div>
     <div class="row conteudo">
       <nav class="col-md-12 navbar navbar-expand-lg navbar-light bg-light">
         <div class="collapse navbar-collapse navbar-right" id="navbarSupportedContent">
           <ul class="navbar-nav mr-auto">
             <li class="nav-item">
               <a class="nav-link" href="<?php echo $caminhoAbsoluto; ?>/">Principal <span class="sr-only">(current)</span></a>
             </li>
             <li class="nav-item dropdown active">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Cadastro
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/atiradores/"><i class="fas fa-caret-right"></i> Atirador</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/categorias/"><i class="fas fa-caret-right"></i> Categoria</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/clubes/"><i class="fas fa-caret-right"></i> Clube</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/despachantes/"><i class="fas fa-caret-right"></i> Despachante</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/estados/"><i class="fas fa-caret-right"></i> Estado</a>
                 <a class="dropdown-item active" href="<?php echo $caminhoAbsoluto; ?>/nacionalidade/"><i class="fas fa-caret-right"></i> Nacionalidade</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/modalidades/"><i class="fas fa-caret-right"></i> Modalidade</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/provas/"><i class="fas fa-caret-right"></i> Prova</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Diários
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/noticias/"><i class="fas fa-caret-right"></i> Notícias</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/enviar-emails/"><i class="fas fa-caret-right"></i> Envia E-mail</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/galeria-fotos/"><i class="fas fa-caret-right"></i> Galeria de Fotos</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/videos/"><i class="fas fa-caret-right"></i> Vídeo</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Campeonatos
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/eventos/"><i class="fas fa-caret-right"></i> Evento</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Escritório
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/extensoes/"><i class="fas fa-caret-right"></i> Extensão</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/acesso/"><i class="fas fa-caret-right"></i> Acesso</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Utilitários
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/cadastrar-usuarios/"><i class="fas fa-caret-right"></i> Usuários</a>
               </div>
             </li>
           </ul>
         </div>
       </nav>
      <div class="container" style="margin-top: 10px">
   <div class="row" style="margin-top: 10px">
     <div class="col-md-12">
       <div class="tituloCaixa">
         <?php echo $visualizar[1]->nome; ?>
       </div>
       <div style="margin-top:10px">

  <div class="row">
     <div class="col-md-8">
         <form method="post" action="#!">
             <div class="form-group">
              <label for="nome">Nome:</label>
              <input type="text" name="Nome" class="form-control" id="nome" value="<?php echo $visualizar[1]->nome; ?>">
            </div>
       <div class="form-group">
        <div align="center">
        <button type="submit" name="Submit" value="Cadastrar" class="btn btn-primary"><i class="fas fa-save"></i> Salvar</button>
      </div>
    </div>
   </form>
   </div>
    <div class="col-md-4">
      <div class="card">
        <div class="card-header">
          <i class="fas fa-users fa-lg"></i> Últimas nacionalidades cadastradas
        </div>
        <div class="card-body">
         <?php echo $metodos->listarNacionalidadeLimite($limite = 10); ?>
           <div class="text-center">
              <a href="<?php echo $caminhoAbsoluto; ?>/nacionalidade/" class="btn btn-primary btn-sm">Ver todos</a>
           </div>
        </div>
      </div>
    </div>
  </div>
        </div>
     </div>
   </div>
 </div>
</div>
</div>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/jquery.maskedinput-master/dist/jquery.maskedinput.js" type="text/javascript"></script>
   <script type="text/javascript">
       $(function() {
           $.mask.definitions['~'] = "[+-]";
           $("#cpf").mask("999.999.999-99");
           $("#cep").mask("99999-999");
           $("#telefone").mask("(99)9999-9999");
           $("#celular").mask("(99)99999-9999");
           $("#telefoneEmpresa").mask("(99)9999-9999");
           $("#dataEmissao").mask("99/99/9999");
           $("#crValidade").mask("99/99/9999");
       });
   </script>

  </body>
</html>
