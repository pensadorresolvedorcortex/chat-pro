<?php
error_reporting(0);
session_start();
if($_SESSION["LogadoCTCB"] == false){
  echo "<script>window.location.href='../index.php';</script>";
  exit();
}
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
if($_SESSION["SucessoExcluir"] < time())
{
  unset($_SESSION["SucessoExcluir"]);
}
if($_SESSION["SucessoEnvio"] < time())
{
  unset($_SESSION["SucessoEnvio"]);
}
if($_SESSION["DetalhesAtirador"])
{
  unset($_SESSION["DetalhesAtirador"]);
}
?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>CTCB | Gestão de Controle</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/css/style.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script>
     function mostrar(valor)
     {
       var valor;
       if(valor == 0)
       {
         document.getElementById('buscarNome').style.display='block';
         document.getElementById('buscarCPF').style.display='none';
         document.getElementById('buscarMatricula').style.display='none';
         document.getElementById('buscarEmail').style.display='none';
         document.getElementById('buscarEstado').style.display='none';
       }
       if(valor == 1)
       {
         document.getElementById('buscarCPF').style.display='block';
         document.getElementById('buscarNome').style.display='none';
         document.getElementById('buscarMatricula').style.display='none';
         document.getElementById('buscarEmail').style.display='none';
         document.getElementById('buscarEstado').style.display='none';
       }
       if(valor == 2)
       {
         document.getElementById('buscarMatricula').style.display='block';
         document.getElementById('buscarCPF').style.display='none';
         document.getElementById('buscarNome').style.display='none';
         document.getElementById('buscarEmail').style.display='none';
         document.getElementById('buscarEstado').style.display='none';
         document.getElementById('buscarSemEmail').style.display='none';
       }
       if(valor == 3)
       {
         document.getElementById('buscarEmail').style.display='block';
         document.getElementById('buscarMatricula').style.display='none';
         document.getElementById('buscarCPF').style.display='none';
         document.getElementById('buscarNome').style.display='none';
         document.getElementById('buscarEstado').style.display='none';
         document.getElementById('buscarSemEmail').style.display='none';
       }
       if(valor == 4)
       {
        document.getElementById('buscarEstado').style.display='block';
         document.getElementById('buscarEmail').style.display='none';
         document.getElementById('buscarMatricula').style.display='none';
         document.getElementById('buscarCPF').style.display='none';
         document.getElementById('buscarNome').style.display='none';
         document.getElementById('buscarSemEmail').style.display='none';
       }
       if(valor == 5)
       {
        document.getElementById('buscarSemEmail').style.display='block';
         document.getElementById('buscarEstado').style.display='none';
         document.getElementById('buscarEmail').style.display='none';
         document.getElementById('buscarMatricula').style.display='none';
         document.getElementById('buscarCPF').style.display='none';
         document.getElementById('buscarNome').style.display='none';
       }
     }
    </script>
  </head>
  <body>
   <div class="container">
     <div class="row header">
          <div class="col-md-6">
            <a href="<?php echo $caminhoAbsoluto; ?>/"><img src="<?php echo $caminhoAbsoluto; ?>/imagens/logo.png" alt="Logo da CTCB" class="logo"></a>
         </div>
         <div class="col-md-6 text-right">
           <h3>SISTEMA DE GESTÃO | CTCB</h3>
           <a href="<?php echo $caminhoAbsoluto; ?>/sair/" style="color: #000" alt="Sair do sistema" title="Sair do sistema"><i class="fas fa-power-off"></i> Sair do sistema</a>
         </div>
     </div>
     <div class="row conteudo">
       <nav class="col-md-12 navbar navbar-expand-lg navbar-light bg-light">
         <?php if($_SESSION["Usuario"] != 'Evandro'){ ?>
         <div class="collapse navbar-collapse navbar-right" id="navbarSupportedContent">
           <ul class="navbar-nav mr-auto">
             <li class="nav-item">
               <a class="nav-link" href="<?php echo $caminhoAbsoluto; ?>/">Principal <span class="sr-only">(current)</span></a>
             </li>
             <li class="nav-item dropdown active">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Cadastro
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item active" href="<?php echo $caminhoAbsoluto; ?>/atiradores/"><i class="fas fa-caret-right"></i> Atirador</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/categorias/"><i class="fas fa-caret-right"></i> Categoria</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/clubes/"><i class="fas fa-caret-right"></i> Clube</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/despachantes/"><i class="fas fa-caret-right"></i> Despachante</a>
                 <!--
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/estados/"><i class="fas fa-caret-right"></i> Estado</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/nacionalidade/"><i class="fas fa-caret-right"></i> Nacionalidade</a>
               -->
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/modalidades/"><i class="fas fa-caret-right"></i> Modalidade</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/provas/"><i class="fas fa-caret-right"></i> Prova</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Diários
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/noticias/"><i class="fas fa-caret-right"></i> Notícias</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/enviar-emails/"><i class="fas fa-caret-right"></i> Envia E-mail</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/galeria-fotos/"><i class="fas fa-caret-right"></i> Galeria de Fotos</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/videos/"><i class="fas fa-caret-right"></i> Vídeo</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Campeonatos
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/eventos/"><i class="fas fa-caret-right"></i> Evento</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Financeiro
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pagos/"><i class="fas fa-caret-right"></i> Pagos</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pendentes/"><i class="fas fa-caret-right"></i> Pendentes</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pagos/"><i class="fas fa-caret-right"></i> Valor Mensalidade</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Utilitários
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/cadastrar-usuarios/"><i class="fas fa-caret-right"></i> Usuários</a>
               </div>
             </li>
           </ul>
         </div>
       <?php }else{ ?>
         <div class="collapse navbar-collapse navbar-right" id="navbarSupportedContent">
           <ul class="navbar-nav mr-auto">
             <li class="nav-item">
               <a class="nav-link" href="#!">Você não tem permissão de acesso como administrador!</a>
             </li>
           </ul>
         </div>
       <?php } ?>

       </nav>
      <div class="container" style="margin-top: 10px">
   <div class="row" style="margin-top: 10px">
     <div class="col-md-12">
       <div class="tituloCaixa">
         <i class="fas fa-hand-holding-usd fa-lg"></i> Atiradores
       </div>
       <div class="row" style="margin-top: 10px">
         <div class="col-md-6">
          <input type="radio" name="Busca" value="Nome" checked onclick="mostrar(0)"> Nome
          <input type="radio" name="Busca" value="CPF" onclick="mostrar(1)"> CPF
          <input type="radio" name="Busca" value="Matricula" onclick="mostrar(2)"> Matrícula
          <input type="radio" name="Busca" value="Matricula" onclick="mostrar(3)"> E-mail
          <input type="radio" name="Busca" value="Estado" onclick="mostrar(4)"> Estado
          <input type="radio" name="Busca" value="Estado" onclick="mostrar(5)"> Sem e-mail
          <div id="buscarNome">
            <form class="" action="#!" method="post">
            <div class="input-group">
             <input type="hidden" name="TipoBusca" value="Nome">
             <input type="text" name="Atirador" class="form-control" placeholder="Buscar por nome" id="atirador" aria-label="Buscar por nome" aria-describedby="btnGroupAddon2">
             <div class="input-group-prepend">
             <button type="submit" class="input-group-text" id="btnBuscar" style="cursor: pointer"><i class="fas fa-search"></i></button>
            </div>
            </div>
            </form>
          </div>
          <div id="buscarCPF" style="display: none">
            <form class="" action="#!" method="post">
            <input type="hidden" name="TipoBusca" value="CPF">
            <div class="input-group">
             <input type="text" name="Atirador" class="form-control" placeholder="Buscar por CPF" id="cpf" aria-label="Buscar por CPF" aria-describedby="btnGroupAddon2">
             <div class="input-group-prepend">
             <button type="submit" class="input-group-text" id="btnBuscar" style="cursor: pointer"><i class="fas fa-search"></i></button>
            </div>
            </div>
            </form>
          </div>
          <div id="buscarMatricula" style="display: none">
            <form class="" action="#!" method="post">
            <input type="hidden" name="TipoBusca" value="Matricula">
            <div class="input-group">
             <input type="text" name="Atirador" class="form-control" placeholder="Buscar por Matricula" id="matricula" aria-label="Buscar por Matricula" aria-describedby="btnGroupAddon2">
             <div class="input-group-prepend">
             <button type="submit" class="input-group-text" id="btnBuscar" style="cursor: pointer"><i class="fas fa-search"></i></button>
            </div>
            </div>
            </form>
          </div>
          <div id="buscarEmail" style="display: none">
            <form class="" action="#!" method="post">
            <input type="hidden" name="TipoBusca" value="Email">
            <div class="input-group">
             <input type="text" name="Atirador" class="form-control" placeholder="Buscar por Email" id="email" aria-label="Buscar por Email" aria-describedby="btnGroupAddon2">
             <div class="input-group-prepend">
             <button type="submit" class="input-group-text" id="btnBuscar" style="cursor: pointer"><i class="fas fa-search"></i></button>
            </div>
            </div>
            </form>
          </div>
          <div id="buscarEstado" style="display: none">
            <form class="" action="#!" method="post">
            <input type="hidden" name="TipoBusca" value="Estado">
            <div class="input-group">
             <select name="Atirador" class="form-control">
               <option value="">Selecione o estado</option>
               <?php echo $metodos->listarEstadoAtiradores(); ?>
             </select>
             <div class="input-group-prepend">
             <button type="submit" class="input-group-text" id="btnBuscar" style="cursor: pointer"><i class="fas fa-search"></i></button>
            </div>
            </div>
            </form>
          </div>
          <div id="buscarSemEmail" style="display: none">
            <form class="" action="#!" method="post">
            <input type="hidden" name="TipoBusca" value="SemEmail">
            <div class="input-group">
             <div class="input-group-prepend">
             <button type="button" class="btn btn-primary" class="input-group-text" id="btnBuscar" style="cursor: pointer" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/exportar-csv/?tipo=sememail&estado=';"><i class="fas fa-file-csv fa-lg"></i> Exportar</button>
            </div>
            </div>
            </form>
          </div>
        </div>
       <div class="col-md-6 text-right">
         <?php if($_SESSION["Cadastrar"] == '1' and $_SESSION["Usuario"] != 'Evandro'){ ?>
         <button type="button" class="btn btn-success" name="button" title="Cadastrar novo atirador" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/novo-atirador/'"><i class="fas fa-user-plus"></i> Novo Atirador</button>
       <?php } ?>
       </div>
     </div>
       <div style="margin-top:10px">
       <?php if($_SESSION["SucessoExcluir"]){ ?>
         <div class="alert alert-success"><i class="fas fa-check"></i> Atirador excluído com sucesso!</div>
       <?php } ?>
         <div align="center">
            <div id="loading"><img src="<?php echo $caminhoAbsoluto; ?>/imagens/ajax-loader.gif"><br>Aguarde, carregando...</div>
         </div>
         <span id="conteudo"></span>
         <?php //$pagina = $_REQUEST["pag"]; $busca = $_POST["Atirador"]; echo $metodos->listarPendentes($pagina,$busca); ?>
       </div>
     </div>
   </div>
 </div>
</div>
</div>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>













<?php //if($_POST["Submit"] == "Buscar Atirador"){ ?>
   <script>
      var busca = "<?php echo $_POST["Atirador"]; ?>";
      var tipo_busca = "<?php echo $_POST["TipoBusca"]; ?>";
      var qnt_result_pg = 20;
			var pagina = 1;
			$(document).ready(function () {
        listar_usuario(pagina, qnt_result_pg, busca,tipo_busca);
			});
			function listar_usuario(pagina, qnt_result_pg, busca,tipo_busca){
        $('#loading').show();
        $('#conteudo').hide();
      var dados = {
					pagina: pagina,
          busca: busca,
          tipo_busca: tipo_busca,
					qnt_result_pg: qnt_result_pg
				}
				$.post('<?php echo $caminhoAbsoluto; ?>/listar-atiradores.php', dados , function(retorna){
          $('#loading').hide();
          $('#conteudo').show();
					$("#conteudo").html(retorna);
				});
			}
		</script>
<?php //} ?>





    <script>
    $(document).ready(function(){
           $("div.alert").fadeIn( 300 ).delay( 3000 ).fadeOut( 400 );
          });
    </script>

    <!-- Busca por nome -->
    <script>
       $(document).ready(function() {
         $( "#atirador" ).autocomplete({
             source: function(request, response){
             $('#loading_data_icon').html('<i class="fa fa-spinner fa-pulse fa-2x fa-fw"></i>');    // showing loading icon
             $.ajax({
                url: '<?php echo $caminhoAbsoluto; ?>/processar-busca-atiradores.php',
                dataType: "json",
                data: {
                      'term' : request.term,
                      'empSearch' : 1
                      },
                      success: function(data) {
                       response(data);
                       $('#loading_data_icon').html('');
                      }
                  });
              }
         });
       });
       </script>

      <!-- Busca por CPF -->
       <script>
          $(document).ready(function() {
            $( "#cpf" ).autocomplete({
                source: function(request, response){
                $('#loading_data_icon').html('<i class="fa fa-spinner fa-pulse fa-2x fa-fw"></i>');    // showing loading icon
                $.ajax({
                   url: '<?php echo $caminhoAbsoluto; ?>/processar-busca-atiradores-cpf.php',
                   dataType: "json",
                   data: {
                         'term' : request.term,
                         'empSearch' : 1
                         },
                         success: function(data) {
                          response(data);
                          $('#loading_data_icon').html('');
                         }
                     });
                 }
            });
          });
          </script>

          <!-- Busca por matrícula -->
          <script>
             $(document).ready(function() {
               $( "#matricula" ).autocomplete({
                   source: function(request, response){
                   $('#loading_data_icon').html('<i class="fa fa-spinner fa-pulse fa-2x fa-fw"></i>');    // showing loading icon
                   $.ajax({
                      url: '<?php echo $caminhoAbsoluto; ?>/processar-busca-atiradores-matricula.php',
                      dataType: "json",
                      data: {
                            'term' : request.term,
                            'empSearch' : 1
                            },
                            success: function(data) {
                             response(data);
                             $('#loading_data_icon').html('');
                            }
                        });
                    }
               });
             });
             </script>

          <!-- Busca por email -->
           <script>
             $(document).ready(function() {
               $( "#email" ).autocomplete({
                   source: function(request, response){
                   $('#loading_data_icon').html('<i class="fa fa-spinner fa-pulse fa-2x fa-fw"></i>');    // showing loading icon
                   $.ajax({
                      url: '<?php echo $caminhoAbsoluto; ?>/processar-busca-atiradores-email.php',
                      dataType: "json",
                      data: {
                            'term' : request.term,
                            'empSearch' : 1
                            },
                            success: function(data) {
                             response(data);
                             $('#loading_data_icon').html('');
                            }
                        });
                    }
               });
             });
             </script>



  </body>
</html>
