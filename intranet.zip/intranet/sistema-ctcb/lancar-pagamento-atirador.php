<?php
error_reporting(0);
session_start();
if($_SESSION["LogadoCTCB"] == false){
  echo "<script>window.location.href='../index.php';</script>";
  exit();
}
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
$tabela = "atirador";
$idTabela = "atirador";
$idBusca = $_SERVER["QUERY_STRING"];
$visualizar = $metodos->visualizar($tabela, $idTabela, $idBusca);
if($visualizar[0] == 0)
{
  echo "<script>window.location.href='".$caminhoAbsoluto."/';</script>";
  exit();
}
if(!isset($_SESSION["IdAtiradorPagamento"]))
{
  $_SESSION["IdAtiradorPagamento"] = $_SERVER["QUERY_STRING"];
}
echo $_SESSION["IdAtiradorPagamento"];
if($_POST["Submit"] == "Salvar")
{
  $dados = array_filter($_POST);
  echo $metodos->lancarPagamentoAtirador($dados);
}
if($_SESSION["Sucesso"] < time())
{
  unset($_SESSION["Sucesso"]);
}
?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>CTCB | Controle de Gestão</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/css/style.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    </head>
  <body>
   <div class="container">
     <div class="row header">
          <div class="col-md-6">
            <img src="<?php echo $caminhoAbsoluto; ?>/imagens/logo.png" alt="" class="logo">
         </div>
         <div class="col-md-6 text-right">
           <h3>SISTEMA DE GESTÃO | CTCB</h3>
           <a href="<?php echo $caminhoAbsoluto; ?>/sair/" style="color: #000" alt="Sair do sistema" title="Sair do sistema"><i class="fas fa-power-off"></i> Sair do sistema</a>
         </div>
     </div>
     <div class="row conteudo">
       <nav class="col-md-12 navbar navbar-expand-lg navbar-light bg-light">
         <div class="collapse navbar-collapse navbar-right" id="navbarSupportedContent">
           <ul class="navbar-nav mr-auto">
             <li class="nav-item active">
               <a class="nav-link" href="<?php echo $caminhoAbsoluto; ?>/">Principal <span class="sr-only">(current)</span></a>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Cadastro
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/atiradores/"><i class="fas fa-caret-right"></i> Atirador</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/categorias/"><i class="fas fa-caret-right"></i> Categoria</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/clubes/"><i class="fas fa-caret-right"></i> Clube</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/despachantes/"><i class="fas fa-caret-right"></i> Despachante</a>
              <!--   <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/estados/"><i class="fas fa-caret-right"></i> Estado</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/nacionalidade/"><i class="fas fa-caret-right"></i> Nacionalidade</a>
               --><a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/modalidades/"><i class="fas fa-caret-right"></i> Modalidade</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/provas/"><i class="fas fa-caret-right"></i> Prova</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Diários
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/noticias/"><i class="fas fa-caret-right"></i> Notícias</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/enviar-emails/"><i class="fas fa-caret-right"></i> Envia E-mail</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/galeria-fotos/"><i class="fas fa-caret-right"></i> Galeria de Fotos</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/videos/"><i class="fas fa-caret-right"></i> Vídeo</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Campeonatos
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/eventos/"><i class="fas fa-caret-right"></i> Evento</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Financeiro
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pagos/"><i class="fas fa-caret-right"></i> Pagos</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pendentes/"><i class="fas fa-caret-right"></i> Pendentes</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pagos/"><i class="fas fa-caret-right"></i> Valor Mensalidade</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Utilitários
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/cadastrar-usuarios/"><i class="fas fa-caret-right"></i> Usuários</a>
               </div>
             </li>
           </ul>
         </div>
       </nav>
      <div class="container" style="margin-top: 10px">
   <div class="row">
     <div class="col-md-6">

     </div>
     <div class="col-md-6 text-right" style="margin-top: 10px"><button class="btn btn-primary btn-sm" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/'"><i class="fas fa-reply"></i> Voltar</button></div>


     <div class="col-md-12 bg-white" style="margin-top: 10px">
       <div class="tituloCaixa">
         <i class="fas fa-hand-holding-usd fa-lg"></i> Lançar Pagamento
       </div>
       <div style="margin-top:20px">
         <div class="text-center">
             <h5 style="font-weight: bold; text-transform: uppercase"><i class="fas fa-user"></i> <?php echo $visualizar[1]->nome; ?></h5>
        </div>
             <form class="" action="#!" method="post">
               <input type="hidden" name="AtiradorPagamento" value="<?php echo $visualizarPagto[1]->atirador_pagamento; ?>">
               <div class="form-group">
                 <label for="ano">Anuidade:</label>
                 <select class="form-control col-md-4" name="Anuidade" id="ano">
                 <?php
                   for ($anuidade = date("Y") - 1; $anuidade < date("Y") + 3; $anuidade++)
                   {
                      $selectedData = ($anuidade == $visualizarPagto[1]->anuidade || $anuidade == date("Y"))?'selected':null;
                      echo '<option value="'.$anuidade.'" '.$selectedData.'>'.$anuidade.'</option>';
                    }
                  ?>
                </select>
               </div>
               <div class="form-group">
                 <label for="validade">Validade:</label>
                 <select class="form-control col-md-4" name="Validade" id="validade">
                 <?php
                   for ($validade = 1; $validade <= 24; $validade++)
                   {
                     $selectedValidade = ($validade == 12)?'selected':null;
                      echo '<option value="'.$validade.'" '.$selectedValidade.'>'.$validade.'</option>';
                    }
                  ?>
                </select>
               </div>
               <div class="form-group">
                 <label for="dataVencimento">Data de Vencimento:</label>
                 <?php
                 list($anoV,$mesV,$diaV) = explode("-",$visualizarPagto[1]->data_vencimento);
                 $dataVencimento = $diaV."/".$mesV."/".$anoV;
                 ?>
                 <input type="text" class="form-control col-md-4" name="DataVencimento" value="<?php echo date("d/m/Y"); ?>" id="dataVencimento">
               </div>
               <div class="form-group">
                 <label for="valorCobranca">Valor da cobrança:</label>
                 <input type="text" class="form-control col-md-4" name="ValorCobranca" value="R$ 230,00" id="valorCobranca" maxlength="12">
               </div>
               <div class="form-group">
                 <label for="dataVencimento">Data do Pagamento:</label>
                 <?php
                 list($anoP,$mesP,$diaP) = explode("-",$visualizarPagto[1]->data_pagamento);
                 $dataPagamento = $diaP."/".$mesP."/".$anoP;
                 ?>
                 <input type="text" class="form-control col-md-4" name="DataPagamento" value="<?php echo date("d/m/Y"); ?>" id="dataPagamento">
               </div>
               <div class="form-group">
                 <label for="valorCobranca">Valor Pago:</label>
                 <input type="text" class="form-control col-md-4" name="ValorPagamento" value="R$ 230,00" id="valorPago" maxlength="12">
               </div>
               <div class="form-group text-center">
                 <button type="submit" name="Submit" value="Salvar" class="btn btn-primary"><i class="fas fa-save"></i> Salvar</button>
               </div>
             </form>
         </div>
     </div>
     </div>
 </div>
</div>
</div>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>

  <script src="<?php echo $caminhoAbsoluto; ?>/js/jquery.maskedinput-master/dist/jquery.maskedinput.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(function() {
            $.mask.definitions['~'] = "[+-]";
              $("#dataVencimento").mask("99/99/9999");
              $("#dataPagamento").mask("99/99/9999");
        });
    </script>
    <script src="<?php echo $caminhoAbsoluto; ?>/js/jquery.maskMoney.js" type="text/javascript"></script>
    <script type="text/javascript">
       $("#valorCobranca").maskMoney({symbol:'R$ ', thousands:'.', decimal:',', symbolStay: true});
       $("#valorPago").maskMoney({symbol:'R$ ', thousands:'.', decimal:',', symbolStay: true});
    </script>

    <script>
    $(document).ready(function(){
           $("div.alert").fadeIn( 300 ).delay( 3000 ).fadeOut( 400 );
          });
    </script>

    <script>
         $(function () {
             $("#atirador").autocomplete({
                 source: '<?php echo $caminhoAbsoluto; ?>/processar-pagamento-pendentes.php'
             });
         });
     </script>
  </body>
</html>
