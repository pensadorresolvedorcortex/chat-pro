<?php
error_reporting(0);
session_start();
unset($_SESSION["NomeAlbum"]);
echo "<script>window.location.href='index.php';</script>";
?>
