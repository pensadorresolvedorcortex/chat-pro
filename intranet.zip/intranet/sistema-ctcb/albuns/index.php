<?php
error_reporting(0);
$conexao = mysqli_connect('ctcb_confedera.mysql.dbaas.com.br','ctcb_confedera','b@nc0Confeder@','ctcb_confedera');
mysqli_set_charset($conexao, "utf8");
 $caminhoAbsoluto = "https://".$_SERVER['SERVER_NAME']."/Projetos/CTCB/controle/sistema-ctcb";
?>
<!DOCTYPE HTML>
<!--
/*
 * jQuery File Upload Plugin Demo
 * https://github.com/blueimp/jQuery-File-Upload
 *
 * Copyright 2010, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * https://www.opensource.org/licenses/MIT
 */
-->
<html lang="pt-br">
<head>
<!-- Force latest IE rendering engine or ChromeFrame if installed -->
<!--[if IE]>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<![endif]-->
<meta charset="utf-8">
<title>Álbum de fotos CTCB</title>
<meta name="description" content="File Upload widget with multiple file selection, drag&amp;drop support, progress bars, validation and preview images, audio and video for jQuery. Supports cross-domain, chunked and resumable file uploads and client-side image resizing. Works with any server-side platform (PHP, Python, Ruby on Rails, Java, Node.js, Go etc.) that supports standard HTML form file uploads.">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Bootstrap styles -->

<!-- Generic page styles -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">

<!-- blueimp Gallery styles -->
<link rel="stylesheet" href="//blueimp.github.io/Gallery/css/blueimp-gallery.min.css">
<!-- CSS to style the file input field as button and adjust the Bootstrap progress bars -->
<link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/albuns/css/jquery.fileupload.css">
<link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/albuns/css/jquery.fileupload-ui.css">
<!-- CSS adjustments for browsers with JavaScript disabled -->
<noscript><link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/albuns/css/jquery.fileupload-noscript.css"></noscript>
<noscript><link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/albuns/css/jquery.fileupload-ui-noscript.css"></noscript>
<link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/css/style.css">
</head>
<body>

<div class="container">
  <div class="row header">
       <div class="col-md-6">
         <img src="<?php echo $caminhoAbsoluto; ?>/imagens/logo.png" alt="" class="logo">
      </div>
      <div class="col-md-6 text-right">
        <h3>SISTEMA DE GESTÃO | CTCB</h3>
        <a href="<?php echo $caminhoAbsoluto; ?>/sair/" style="color: #000" alt="Sair do sistema" title="Sair do sistema"><i class="fas fa-power-off"></i> Sair do sistema</a>
      </div>
  </div>
  <div class="row conteudo">
    <nav class="col-md-12 navbar navbar-expand-lg navbar-light bg-light">
      <div class="collapse navbar-collapse navbar-right" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a class="nav-link" href="#">Principal <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Cadastro
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/atiradores/"><i class="fas fa-caret-right"></i> Atirador</a>
              <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/categorias/"><i class="fas fa-caret-right"></i> Categoria</a>
              <a class="dropdown-item" href="https://central.ctcb.org.br/clubes"><i class="fas fa-caret-right"></i> Clube</a>
              <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/despachantes/"><i class="fas fa-caret-right"></i> Despachante</a>
              <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/estados/"><i class="fas fa-caret-right"></i> Estado</a>
              <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/nacionalidade/"><i class="fas fa-caret-right"></i> Nacionalidade</a>
              <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/modalidades/"><i class="fas fa-caret-right"></i> Modalidade</a>
              <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/provas/"><i class="fas fa-caret-right"></i> Prova</a>
            </div>
          </li>
          <li class="nav-item dropdown active">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Diários
            </a>
            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="https://central.ctcb.org.br/noticias"><i class="fas fa-caret-right"></i> Notícias</a>
              <a class="dropdown-item active" href="<?php echo $caminhoAbsoluto; ?>/enviar-emails/"><i class="fas fa-caret-right"></i> Envia E-mail</a>
              <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/galeria-fotos/"><i class="fas fa-caret-right"></i> Galeria de Fotos</a>
              <a class="dropdown-item" href="https://central.ctcb.org.br/videos"><i class="fas fa-caret-right"></i> Vídeo</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Campeonatos
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/eventos/"><i class="fas fa-caret-right"></i> Evento</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Escritório
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/extensoes/"><i class="fas fa-caret-right"></i> Extensão</a>
              <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/acesso/"><i class="fas fa-caret-right"></i> Acesso</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Utilitários
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/cadastrar-usuarios/"><i class="fas fa-caret-right"></i> Usuários</a>
            </div>
          </li>
        </ul>
      </div>
    </nav>
    <!-- The file upload form used as target for the file upload widget -->
    <form action="albuns.php" method="POST">
        <!-- Redirect browsers with JavaScript disabled to the origin page -->
        <!-- The fileupload-buttonbar contains buttons to add/delete files and start/cancel the upload -->
        <div class="row fileupload-buttonbar">

            <div class="col-lg-12">
              <h1>Galeria de Imagens</h1><br>
               <h3>Qual o nome da galeria?</h3>
               <div class="form-group">
                 <input type="text" name="NomeAlbum" class="form-control">
               </div>
               <div align="center">
                <button type="submit" class="btn btn-primary">Avançar</button>
              </div>
            </div>
            <!-- The global progress state -->
        </div>
        <div class="row fileupload-buttonbar">
          <h3>Álbuns criados</h3>
          <?php
           $sql = mysqli_query($conexao,"SELECT * FROM pe_album_fotos WHERE IdEscola = '1' GROUP BY NomeAlbum;");

           while($jm = mysqli_fetch_object($sql)){
                 echo "<a href='ver-albuns.php?key=".$jm->NomeAlbum."'>" .$jm->NomeAlbum . "</a> ";
           }
           ?>
        </div>

    </form>
</div>
</div>
<!-- The blueimp Gallery widget -->

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<!-- The jQuery UI widget factory, can be omitted if jQuery UI is already included -->
   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>

<script src="<?php echo $caminhoAbsoluto; ?>/albuns/js/vendor/jquery.ui.widget.js"></script>
<!-- The Templates plugin is included to render the upload/download listings -->
<script src="//blueimp.github.io/JavaScript-Templates/js/tmpl.min.js"></script>
<!-- The Load Image plugin is included for the preview images and image resizing functionality -->
<script src="//blueimp.github.io/JavaScript-Load-Image/js/load-image.all.min.js"></script>
<!-- The Canvas to Blob plugin is included for image resizing functionality -->
<script src="//blueimp.github.io/JavaScript-Canvas-to-Blob/js/canvas-to-blob.min.js"></script>
<!-- Bootstrap JS is not required, but included for the responsive demo navigation -->
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<!-- blueimp Gallery script -->
<script src="//blueimp.github.io/Gallery/js/jquery.blueimp-gallery.min.js"></script>
<!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
<script src="<?php echo $caminhoAbsoluto; ?>/albuns/js/jquery.iframe-transport.js"></script>
<!-- The basic File Upload plugin -->
<script src="<?php echo $caminhoAbsoluto; ?>/albuns/js/jquery.fileupload.js"></script>
<!-- The File Upload processing plugin -->
<script src="<?php echo $caminhoAbsoluto; ?>/albuns/js/jquery.fileupload-process.js"></script>
<!-- The File Upload image preview & resize plugin -->
<script src="<?php echo $caminhoAbsoluto; ?>/albuns/js/jquery.fileupload-image.js"></script>
<!-- The File Upload audio preview plugin -->
<script src="<?php echo $caminhoAbsoluto; ?>/albuns/js/jquery.fileupload-audio.js"></script>
<!-- The File Upload video preview plugin -->
<script src="<?php echo $caminhoAbsoluto; ?>/albuns/js/jquery.fileupload-video.js"></script>
<!-- The File Upload validation plugin -->
<script src="<?php echo $caminhoAbsoluto; ?>/albuns/js/jquery.fileupload-validate.js"></script>
<!-- The File Upload user interface plugin -->
<script src="<?php echo $caminhoAbsoluto; ?>/albuns/js/jquery.fileupload-ui.js"></script>
<!-- The main application script -->
<script src="<?php echo $caminhoAbsoluto; ?>/albuns/js/main.js"></script>
<!-- The XDomainRequest Transport is included for cross-domain file deletion for IE 8 and IE 9 -->
<!--[if (gte IE 8)&(lt IE 10)]>
<script src="js/cors/jquery.xdr-transport.js"></script>
<![endif]-->
</body>
</html>
