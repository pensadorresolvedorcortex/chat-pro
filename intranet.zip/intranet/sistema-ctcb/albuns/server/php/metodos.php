<?php
/*
ini_set('display_errors',1);
ini_set('display_startup_erros',1);
error_reporting(E_ALL);
*/
error_reporting(0);
session_start();

include("conectaClass.php");
class metodos{

  public function __construct() {
      $conectar = new conectaClass();
      $this->conexao = $conectar->conectar();
      return $this->conexao;
  }
  public function mostrarFotos(){
      $sql = mysqli_query($this->conexao,"SELECT Fotos FROM pe_album_fotos WHERE Idescola = '".$_SESSION["Idescola"]."' AND NomeAlbum = '".$_SESSION["NomeAlbum"]."'");
      $array = array();
      while($jm = mysqli_fetch_assoc($sql)){
            array_push($array,$jm["Fotos"]);
      }
      return $array;
  }
  public function deletarFotos($foto){
      $sql = mysqli_query($this->conexao,"DELETE FROM pe_album_fotos WHERE Fotos = '".$foto."';");
  }
  public function cadastrarFotos($foto){
      $sql = mysqli_query($this->conexao,"INSERT INTO galeria_fotos VALUES('1','0','".$foto."','','N');");
  }
}
?>
