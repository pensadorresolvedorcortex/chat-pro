<?php
include("metodos.php");
$metodos = new metodos();
$mostrar = $metodos->mostrarFotos();
print_r($mostrar);
?>
