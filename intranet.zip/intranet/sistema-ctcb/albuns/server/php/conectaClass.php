<?php
/*
  ini_set('display_errors',1);
  ini_set('display_startup_erros',1);
  error_reporting(E_ALL);
*/
error_reporting(0);


class conectaClass {

// Servidor remoto

  private $servidor = 'ctcb_confedera.mysql.dbaas.com.br';
  private $usuario = 'ctcb_confedera';
  private $senha = 'b@nc0Confeder@';
  private $banco = 'ctcb_confedera';

/*
    private $servidor = 'localhost';
    private $usuario = 'root';
    private $senha = 'sucesso';
    private $banco = 'pertutti_plataforma';
*/
// Protegido
    protected $conecta;

    /**
     * Classe faz a conexão ao banco de dados
     * @return $this->conecta
     */
    public function conectar() {

        $this->conecta = mysqli_connect($this->servidor, $this->usuario, $this->senha, $this->banco);
        mysqli_set_charset($this->conecta, "utf8");

        try {
            if (mysqli_connect_errno() != 0) {
                $e = $this->erro(mysqli_connect_error());
                throw new Exception($e);
            } else {
                return $this->conecta;
            }
        } catch (Exception $e) {
            $this->conecta = 'Erro ao conectar. Se o erro persistir, entre em contato com suporte@pertuttigestao.com.br e informe o erro: CODPT_I: 0001';
            return $this->conecta;
            // return "<script>window.location.href='index.php';</script>";
            // exit();
        }
    }

// Fim do método conectar()

    /**
     *  A classe gera um erro caso a conexão não seja efetuada
     * @param string $erroValor é o erro da conexão
     */
    private function erro($erroValor) {

        // Gera um arquivo log no diretório log/erro.log
        error_log(filter_input(INPUT_SERVER, "PHP_SELF") . " - CON: 0001: (" . @date("d/m/Y") . " às " . @date("H:i") . " IP: " .$_SERVER['REMOTE_ADDR']. ") - " . $erroValor . "\r\n", 3, "/home/pertutti/public_html/plataforma/classes/log/erro.log");
        // Envia um e-mail para mim com o log do erro. Dessa forma fico sabendo se o sistema deu algum erro de conexão ou acesso ao BD. Caso queira receber esse log, coloque seu e-mail
        error_log("IP: ".$_SERVER['REMOTE_ADDR']." Erro no sistema de conexão da Plataforma PerTutti Gestão. CODPT 00011: " . $erroValor, 1, "j.marcostavares@gmail.com");

        // Caso o error_log() não funcione, faça a chamada do método erroLog($erro,$arquivo) abaixo:
        //  $this->erroLog(filter_input(INPUT_SERVER,"PHP_SELF")." - CODPT 0001 (".@date("d/m/Y") ." às ".@date("H:i").") - ".$erro_valor."\r\n","log/erro.log");
        //     return true;
    }

    /*
      private function erroLog($erro,$arquivo){
      $abrir = fopen($arquivo,"a");
      fwrite($abrir,$erro);
      fclose($abrir);
      return true;
      }
     */
    /*
      // Caso a conexão seja persistente
      public function fechar(){
      mysqli_close($this->Conecta);
      }
     */
}
