<?php
error_reporting(0);
session_start();
$_SESSION["NomeAlbum"] = $_REQUEST["key"];
$_SESSION["IdEscola"] = '1';
echo "Mostrar o álbum e um botão para cadastrar novas fotos direcionando para álbuns.php";
?>
