<?php
error_reporting(0);
session_start();
if($_SESSION["LogadoCTCB"] == false){
  echo "<script>window.location.href='../index.php';</script>";
  exit();
}
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
//$caminhoAbsoluto = $metodos->caminhoAbsoluto();
$id = $_SERVER["QUERY_STRING"];
echo $metodos->enviarSenhaClube($id);
?>
