//*******************
function mascara(o,f)
//*******************
{
  v_obj=o
  v_fun=f
  setTimeout("execmascara()",1)
}

//********************
function execmascara()
//********************
{
  v_obj.value=v_fun(v_obj.value)
}

//**********************
function valida_leech(v)
//**********************
{
		v=v.replace(/o/gi,"0")
		v=v.replace(/i/gi,"1")
		v=v.replace(/z/gi,"2")
		v=v.replace(/e/gi,"3")
		v=v.replace(/a/gi,"4")
		v=v.replace(/s/gi,"5")
		v=v.replace(/t/gi,"7")
		return v
}

//************************
function valida_numeros(v)
//************************
{
		return v.replace(/\D/g,"")
}

//*************************
function valida_telefone(v)
//*************************
{
  v=v.replace(/\D/g,"")                 //Remove tudo o que não é dígito
		v=v.replace(/^(\d\d)(\d)/g,"($1) $2") //Coloca parênteses em volta dos dois primeiros dígitos
		v=v.replace(/(\d{4})(\d)/,"$1-$2")    //Coloca hífen entre o quarto e o quinto dígitos
		return v
}

//*************************
function valida_telefone_novo(v)
//*************************
{
  v=v.replace(/\D/g,"")                 //Remove tudo o que não é dígito
		v=v.replace(/^(\d\d)(\d)/g,"($1) $2") //Coloca parênteses em volta dos dois primeiros dígitos
		return v
}

//********************
function valida_cpf(v)
//********************
{
		v=v.replace(/\D/g,"")                    //Remove tudo o que não é dígito
		v=v.replace(/(\d{3})(\d)/,"$1.$2")       //Coloca um ponto entre o terceiro e o quarto dígitos
		v=v.replace(/(\d{3})(\d)/,"$1.$2")       //Coloca um ponto entre o terceiro e o quarto dígitos
																																											//de novo (para o segundo bloco de números)
		v=v.replace(/(\d{3})(\d{1,2})$/,"$1-$2") //Coloca um hífen entre o terceiro e o quarto dígitos
		return v
}

//*********************
function valida_cnpj(v)
//*********************
{
		v=v.replace(/\D/g,"")                           //Remove tudo o que não é dígito
		v=v.replace(/^(\d{2})(\d)/,"$1.$2")             //Coloca ponto entre o segundo e o terceiro dígitos
		v=v.replace(/^(\d{2})\.(\d{3})(\d)/,"$1.$2.$3") //Coloca ponto entre o quinto e o sexto dígitos
		v=v.replace(/\.(\d{3})(\d)/,".$1/$2")           //Coloca uma barra entre o oitavo e o nono dígitos
		v=v.replace(/(\d{4})(\d)/,"$1-$2")              //Coloca um hífen depois do bloco de quatro dígitos
		return v
}

//********************
function valida_cep(v)
//********************
{
		v=v.replace(/D/g,"")                //Remove tudo o que não é dígito
		v=v.replace(/^(\d{5})(\d)/,"$1-$2") //Esse é tão fácil que não merece explicações
		return v
}

//************************
function valida_romanos(v)
//************************
{
		v=v.toUpperCase()             //Maiúsculas
		v=v.replace(/[^IVXLCDM]/g,"") //Remove tudo o que não for I, V, X, L, C, D ou M
		//Essa é complicada! Copiei daqui: https://www.diveintopython.org/refactoring/refactoring.html
		while(v.replace(/^M{0,4}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})$/,"")!="")
						v=v.replace(/.$/,"")
		return v
}

//*********************
function valida_site(v)
//*********************
{
		//Esse sem comentarios para que você entenda sozinho ;-)
		v=v.replace(/^http:\/\/?/,"")
		dominio=v
		caminho=""
		if(v.indexOf("/")>-1)
						dominio=v.split("/")[0]
						caminho=v.replace(/[^\/]*/,"")
		dominio=dominio.replace(/[^\w\.\+-:@]/g,"")
		caminho=caminho.replace(/[^\w\d\+-@:\?&=%\(\)\.]/g,"")
		caminho=caminho.replace(/([\?&])=/,"$1")
		if(caminho!="")dominio=dominio.replace(/\.+$/,"")
		v="https://"+dominio+caminho
		return v
}

//**********************
function confirma_item()
//**********************
{
		if (confirm("Deseja excluir este item?"))
				{	document.oform.submit();	}
		else
				{	return false;	}
}

//************************
function confirma_figura()
//************************
{
		if (confirm("Deseja excluir esta figura?"))
				{	document.oform.submit();	}
		else
				{	return false;	}
}

//**************************
function MM_reloadPage(init)
//**************************
{
		if (init==true) with (navigator)
		{
				if ((appName=="Netscape")&&(parseInt(appVersion)==4))
				{
						document.MM_pgW=innerWidth;
						document.MM_pgH=innerHeight; onresize=MM_reloadPage;
				}
		}
		else if
				(innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);

//********************************************************
function nova_janela(pagina, largura, altura, nome)
//********************************************************
{
		window.open(pagina, nome, 'toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=1,width=' + largura + ',height=' + altura);
}

//**************************************************
function nova_janela2(pagina, largura, altura, nome)
//**************************************************
{
		window.open(pagina, nome, 'toolbar=0,location=0,directories=0,status=0,menubar=1,scrollbars=1,width=' + largura + ',height=' + altura);
}

//******************************************************
	function exibe_relatorio(pagina, largura, altura, nome)
//******************************************************
{
		window.open(pagina, nome, 'menubar=1,toolbar=0,location=0,directories=0,status=0,scrollbars=1,width=' + largura + ',height=' + altura);
}

//********************************************************
function mostra_arquivo(arquivo, largura, altura)
//********************************************************
{
		localizacao = "/visualiza_arquivo.php?arquivo=" + arquivo + "&altura=" + altura + "&largura=" + largura;
		window.open(localizacao, "", "toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=1,width=" + largura + ",height=" + altura);
}

//****************************
function valida_data(dia, mes)
//****************************
{
		var erro = 0;
		var retorno = true;
		var ArrMes30 = new Array(7);
		ArrMes30[0] = 2;
		ArrMes30[1] = 4;
		ArrMes30[2] = 6;
		ArrMes30[3] = 9;
		ArrMes30[4] = 11;
		if (dia == "" || mes == "")
				{ erro++; }
		if (mes == 2 && dia > 29)
				{ erro++; }
		for (x = 0; x <= 4; x++)
		{
				if (mes == ArrMes30[x])
				{
						if (dia == 31)
								{ erro++; }
				}
		}
		if (erro > 0)
				{ retorno = false; }
		return (retorno);
}

//*************************
function valida_email(mail)
//*************************
{
		var c_error = 0;
		var ponto = 0;
		if (mail.indexOf("@") < 1)   { c_error++; }
		if (mail.indexOf(".") < 1)   { c_error++; }
		if (mail.indexOf("á") != -1) { c_error++; }
		if (mail.indexOf("é") != -1) { c_error++; }
		if (mail.indexOf("í") != -1) { c_error++; }
		if (mail.indexOf("ó") != -1) { c_error++; }
		if (mail.indexOf("ú") != -1) { c_error++; }
		if (mail.indexOf(" ") != -1) { c_error++; }
		for ( i = mail.indexOf('@') + 1; i <= mail.length; i++ )
		{
				if (mail.charAt(i) == '.')
					{ ponto = 1; break; }
		}
		if (ponto == 0)
				{ c_error++; }
		if (c_error > 0)
				{ return (false); }
		else
				{ return (true); }
}

//*********************************
function verifica_numero(caractere)
//*********************************
{
		var strValidos = "0123456789";
		if (strValidos.indexOf(caractere) == -1)
				{ return false; }
		return true;
}

//*********************************
function valida_tecla(campo, event)
//*********************************
{
		var BACKSPACE = 8;
		var key;
		var tecla;
		CheckTAB = true;

		if(navigator.appName.indexOf("Netscape") != -1)
				{ tecla = event.which; }
		else
				{ tecla = event.keyCode; }

		key = String.fromCharCode(tecla);
		//alert( 'key: ' + tecla + ' -> campo: ' + campo.value);

		if (tecla == 13)
				{ return false; }

		if (tecla == BACKSPACE)
				{ return true; }

		return (verifica_numero(key));
}

//**********************************************************
function txtBoxFormat(objForm, strField, sMask, evtKeyPress)
//**********************************************************
{
		/***
		* Descrição.: formata um campo do formulário de acordo com a máscara informada...
		* Parâmetros: - objForm     (o Objeto Form)
		*             - strField    (string contendo o nome do textbox)
		*             - sMask       (mascara que define o formato que o dado será apresentado, usando o
		*                            algarismo "9" para definir números e o símbolo "!" para qualquer caracter
		*             - evtKeyPress (evento)
		*
		* Uso.......: <input type="textbox" name="xxx" onkeypress="return txtBoxFormat(document.rcfDownload, 'str_cep', '99999-999', event);">
		* Observação: As máscaras podem ser representadas como os exemplos abaixo:
		* CEP -> 99999-999
		* CPF -> 999.999.999-99
		* CNPJ -> 99.999.999/9999-99
		* C/C -> 999999-!
		* Tel -> (99) 9999-9999
		***/

		var i, nCount, sValue, fldLen, mskLen,bolMask, sCod, nTecla;

		if(document.all) // Internet Explorer
				nTecla = evtKeyPress.keyCode;
		else if(document.layers) // Nestcape
				nTecla = evtKeyPress.which;

		sValue = objForm[strField].value;

		// Limpa todos os caracteres de formatação que
		// já estiverem no campo.
		sValue = sValue.toString().replace( "-", "" );
		sValue = sValue.toString().replace( "-", "" );
		sValue = sValue.toString().replace( ".", "" );
		sValue = sValue.toString().replace( ".", "" );
		sValue = sValue.toString().replace( "/", "" );
		sValue = sValue.toString().replace( "/", "" );
		sValue = sValue.toString().replace( "(", "" );
		sValue = sValue.toString().replace( "(", "" );
		sValue = sValue.toString().replace( ")", "" );
		sValue = sValue.toString().replace( ")", "" );
		sValue = sValue.toString().replace( " ", "" );
		sValue = sValue.toString().replace( " ", "" );
		fldLen = sValue.length;
		mskLen = sMask.length;

		i = 0;
		nCount = 0;
		sCod = "";
		mskLen = fldLen;

		while (i <= mskLen)
		{
				bolMask = ((sMask.charAt(i) == "-") || (sMask.charAt(i) == ".") || (sMask.charAt(i) == "/"))
				bolMask = bolMask || ((sMask.charAt(i) == "(") || (sMask.charAt(i) == ")") || (sMask.charAt(i) == " "))

				if (bolMask)
				{
						sCod += sMask.charAt(i);
						mskLen++;
				}
				else
				{
						sCod += sValue.charAt(nCount);
						nCount++;
				}

				i++;
		}

		objForm[strField].value = sCod;

		if (nTecla != 8) // backspace
		{
				if (sMask.charAt(i-1) == "9") // apenas números de 0 a 9
						return ((nTecla > 47) && (nTecla < 58));
				else // qualquer caracter
						return true;
		}
		else
				return true;
}

//*******************************************
function FormataValor(campo,tammax,teclapres)
//*******************************************
{
		var tecla = teclapres.keyCode ? teclapres.keyCode : teclapres.which ? teclapres.which : teclapres.charCode;

		vr = document.oform[campo].value;
		vr = vr.replace( "/", "" );
		vr = vr.replace( "/", "" );
		vr = vr.replace( ".", "" );
		vr = vr.replace( ".", "" );
		vr = vr.replace( ".", "" );
		vr = vr.replace( ".", "" );
		vr = vr.replace( ".", "" );
		tam = vr.length;
		if (tam < tammax && tecla != 8)
				{ tam = vr.length + 1; }
		if (tecla == 8 )
				{ tam = tam - 1; }
		if ( tecla == 8 || tecla >= 48 && tecla <= 57 || tecla >= 96 && tecla <= 105 )
		{
				if ( tam <= 2 )
						{	document.oform[campo].value = vr; }
				else
						{	document.oform[campo].value = vr.substr( 0, tam - 2 ) + '.' + vr.substr( tam - 2, tam ); }
		}
}
