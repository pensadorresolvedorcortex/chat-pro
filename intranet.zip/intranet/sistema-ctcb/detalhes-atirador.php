<?php
error_reporting(0);
session_start();
if($_SESSION["LogadoCTCB"] == false){
  echo "<script>window.location.href='../index.php';</script>";
  exit();
}
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
$tabela = "atirador";
$idTabela = "id_cod_atirador";
$idBusca = $_SERVER["QUERY_STRING"];
$visualizar = $metodos->visualizar($tabela,$idTabela,$idBusca);
if($_SESSION["Sucesso"] < time())
{
  unset($_SESSION["Sucesso"]);
}
if($_POST["Submit"] == "Alterar")
{
  $dados = array_filter($_POST);
  echo $metodos->alterarDadosAtirador($dados);
}
if($_SESSION["IdAtiradorPagamento"])
{
  unset($_SESSION["IdAtiradorPagamento"]);
}
?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>SISTEMA DE GESTÃO | CTCB</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/css/style.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script src="<?php echo $caminhoAbsoluto; ?>/js/validar-cep.js"></script>
  </head>
  <body>
   <div class="container">
     <div class="row header">
          <div class="col-md-6">
            <a href="<?php echo $caminhoAbsoluto; ?>/"><img src="<?php echo $caminhoAbsoluto; ?>/imagens/logo.png" alt="Logo da CTCB" class="logo"></a>
         </div>
         <div class="col-md-6 text-right">
           <h3>SISTEMA DE GESTÃO | CTCB</h3>
           <a href="<?php echo $caminhoAbsoluto; ?>/sair/" style="color: #000" alt="Sair do sistema" title="Sair do sistema"><i class="fas fa-power-off"></i> Sair do sistema</a>
         </div>
     </div>
     <div class="row conteudo">
       <nav class="col-md-12 navbar navbar-expand-lg navbar-light bg-light">
         <div class="collapse navbar-collapse navbar-right" id="navbarSupportedContent">
           <ul class="navbar-nav mr-auto">
             <li class="nav-item">
               <a class="nav-link" href="<?php echo $caminhoAbsoluto; ?>/">Principal <span class="sr-only">(current)</span></a>
             </li>
             <li class="nav-item dropdown active">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Cadastro
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item active" href="<?php echo $caminhoAbsoluto; ?>/atiradores/"><i class="fas fa-caret-right"></i> Atirador</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/categorias/"><i class="fas fa-caret-right"></i> Categoria</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/clubes/"><i class="fas fa-caret-right"></i> Clube</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/despachantes/"><i class="fas fa-caret-right"></i> Despachante</a>
                 <!--
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/estados/"><i class="fas fa-caret-right"></i> Estado</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/nacionalidade/"><i class="fas fa-caret-right"></i> Nacionalidade</a>
               -->
               <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/modalidades/"><i class="fas fa-caret-right"></i> Modalidade</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/provas/"><i class="fas fa-caret-right"></i> Prova</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Diários
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/noticias/"><i class="fas fa-caret-right"></i> Notícias</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/enviar-emails/"><i class="fas fa-caret-right"></i> Envia E-mail</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/galeria-fotos/"><i class="fas fa-caret-right"></i> Galeria de Fotos</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/videos/"><i class="fas fa-caret-right"></i> Vídeo</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Campeonatos
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/eventos/"><i class="fas fa-caret-right"></i> Evento</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Financeiro
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pagos/"><i class="fas fa-caret-right"></i> Pagos</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pendentes/"><i class="fas fa-caret-right"></i> Pendentes</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pagos/"><i class="fas fa-caret-right"></i> Valor Mensalidade</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Utilitários
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/cadastrar-usuarios/"><i class="fas fa-caret-right"></i> Usuários</a>
               </div>
             </li>
           </ul>
         </div>
       </nav>
      <div class="container" style="margin-top: 10px">
   <div class="row" style="margin-top: 10px">
     <div class="col-md-12">
       <div class="tituloCaixa">
         <h4 style="font-weight: bold"><?php echo $visualizar[1]->nome; ?></h4>
       </div>
       <div style="margin-top:10px">
         <?php if($_SESSION["SucessoEnvio"]){ ?>
           <div class="alert alert-success"><i class="fas fa-check"></i> Senha enviada com sucesso!</div>
           <?php } ?>
  <div class="row">
     <div class="col-md-8">
         <form method="post" action="#!">
           <input type="hidden" name="key" value="<?php echo $_SERVER["QUERY_STRING"]; ?>">
           <?php if($_SESSION["CPF"]){ ?>
             <input type="hidden" name="CPF" value="<?php echo $_SESSION["CPF"]; ?>">
           <?php } ?>
           <?php if($_SESSION["Sucesso"]){ ?>
            <div class="alert alert-success"><i class="fas fa-check"></i> Dados alterados com sucesso!</div>
           <?php } ?>
           <?php if ($_SESSION["SucessoLancamento"]){ ?>
             <div class="alert alert-success"><i class="fas fa-check"></i> Lançamento efetuado com sucesso!</div>
           <?php } ?>
           <h5 style="font-weight: bold">DADOS DE CADASTRO</h5>
           <div class="form-group">
             <label for="email">Código na Confederação:</label>
             <input type="text" name="Codigo" class="form-control" id="codigo" value="<?php echo $visualizar[1]->codigo; ?>" disabled>
           </div>
           <div class="form-group">
             <label for="nome">Data do cadastro:</label>
             <?php list($anoCadastro,$mesCadastro,$diaCadastro) = explode("-",$visualizar[1]->data_cadastro); ?>
                         <div class="form-row mb-4">
                            <div class="col">
                                  <select class="form-control" name="DiaCadastro">
                                    <option value="">Dia</option>
                                   <?php for($diaC = 1; $diaC <= 31; $diaC++){ $diaC = ($diaC < 10)?'0'.$diaC:$diaC; ?>
                                            <option value="<?php echo $diaC; ?>" <?php if($diaC == $diaCadastro) echo "selected"; ?>><?php echo $diaC; ?></option>
                                   <?php } ?>
                                  </select>
                            </div>
                            <div class="col">
                              <select class="form-control" name="MesCadastro">
                                   <option value="">Mês</option>
                                   <option value="1" <?php if($mesCadastro == '1') echo "selected"; ?>>Janeiro</option>
                                   <option value="2" <?php if($mesCadastro == '2') echo "selected"; ?>>Fevereiro</option>
                                   <option value="3" <?php if($mesCadastro == '3') echo "selected"; ?>>Março</option>
                                   <option value="4" <?php if($mesCadastro == '4') echo "selected"; ?>>Abril</option>
                                   <option value="5" <?php if($mesCadastro == '5') echo "selected"; ?>>Maio</option>
                                   <option value="6" <?php if($mesCadastro == '6') echo "selected"; ?>>Junho</option>
                                   <option value="7" <?php if($mesCadastro == '7') echo "selected"; ?>>Julho</option>
                                   <option value="8" <?php if($mesCadastro == '8') echo "selected"; ?>>Agosto</option>
                                   <option value="9" <?php if($mesCadastro == '9') echo "selected"; ?>>Setembro</option>
                                   <option value="10" <?php if($mesCadastro == '10') echo "selected"; ?>>Outubro</option>
                                   <option value="11" <?php if($mesCadastro == '11') echo "selected"; ?>>Novembro</option>
                                   <option value="12" <?php if($mesCadastro == '12') echo "selected"; ?>>Dezembro</option>
                              </select>
                            </div>
                            <div class="col">

                              <select class="form-control" name="AnoNascimento">
                               <option value="">Ano</option>
                               <?php for($anoC = 1900; $anoC <= date("Y"); $anoC++){ ?>
                                 <option value="<?php echo $anoC; ?>" <?php if($anoC == $anoCadastro) echo "selected"; ?>><?php echo $anoC; ?></option>
                               <?php } ?>
                              </select>


                            </div>
                         </div>
              </div>
              <div class="form-group">
                <label for="email">Despachante:</label>
                <select name="Despachante" class="form-control">
                  <option value="">Selecione</option>
                  <?php echo $metodos->listarDespachantesCombox($busca = $visualizar[1]->despachante); ?>
                </select>
              </div>
              <div class="form-group">
                <label for="email">Status:</label>
                <select name="Status" class="form-control">
                  <option value="A" <?php if($visualizar[1]->status == 'A') echo 'selected'; ?>>Ativo</option>
                  <option value="I" <?php if($visualizar[1]->status == 'I') echo 'selected'; ?>>Inativo</option>
                  <option value="F" <?php if($visualizar[1]->status == 'F') echo 'selected'; ?>>Falecido</option>
                </select>
              </div>
              <div class="form-group">
                <label for="email">Ficha do atleta: <small>A opção 'Não' desabilita a ficha deste atleta no site</small></label>
                <select name="FichaAtleta" class="form-control">
                  <option value="S">Sim</option>
                  <option value="N">Não</option>
                </select>
              </div>

            <h5 style="font-weight: bold"><i class="fas fa-key"></i> DADOS DE ACESSO</h5>
            <div class="form-group">
              <label for="email">E-mail:</label>
              <input type="text" name="Email" class="form-control" id="email" value="<?php echo $visualizar[1]->email; ?>">
            </div>
            <h5 style="font-weight: bold"><i class="fas fa-user-edit"></i> DADOS PESSOAIS</h5>
            <div class="form-group">
              <label for="nome">Nome:</label>
              <input type="text" name="Nome" class="form-control" id="nome" value="<?php echo $visualizar[1]->nome; ?>">
            </div>
            <div class="form-group">
              <label for="nome">Gênero:</label>
              <?php
               if($visualizar[1]->sexo == "M")
               {
                $selectedM = "checked";
               }
               else
               {
                 $selectedF = "checked";
               }
              ?>
            <div class="form-check form-check-inline">
             <input class="form-check-input" type="radio" name="Genero" value="Masculino" id="inlineCheckbox1" <?php echo $selectedM; ?>>
             <label class="form-check-label" for="inlineCheckbox1">Masculino</label>
             </div>
             <div class="form-check form-check-inline">
             <input class="form-check-input" type="radio" name="Genero" value="Feminino" id="inlineCheckbox2" <?php echo $selectedF; ?>>
             <label class="form-check-label" for="inlineCheckbox2">Feminino</label>
             </div>
           </div>
          <div class="form-group">
            <label for="nome">Data de Nascimento:</label>
                        <div class="form-row mb-4">
                           <div class="col">
                              <?php list($anoN,$mesN,$diaN) = explode("-",$visualizar[1]->data_nascimento); ?>
                                 <select class="form-control" name="DiaNascimento">
                                   <option value="">Dia</option>
                                  <?php for($dia = 1; $dia <= 31; $dia++){ $dia = ($dia < 10)?'0'.$dia:$dia; ?>
                                           <option value="<?php echo $dia; ?>" <?php if($dia == $diaN) echo 'selected'; ?>><?php echo $dia; ?></option>
                                  <?php } ?>
                                 </select>
                           </div>
                           <div class="col">
                             <select class="form-control" name="MesNascimento">
                                  <option value="">Mês</option>
                                  <option value="1" <?php if($mesN == '1') echo 'selected'; ?>>Janeiro</option>
                                  <option value="2" <?php if($mesN == '2') echo 'selected'; ?>>Fevereiro</option>
                                  <option value="3" <?php if($mesN == '3') echo 'selected'; ?>>Março</option>
                                  <option value="4" <?php if($mesN == '4') echo 'selected'; ?>>Abril</option>
                                  <option value="5" <?php if($mesN == '5') echo 'selected'; ?>>Maio</option>
                                  <option value="6" <?php if($mesN == '6') echo 'selected'; ?>>Junho</option>
                                  <option value="7" <?php if($mesN == '7') echo 'selected'; ?>>Julho</option>
                                  <option value="8" <?php if($mesN == '8') echo 'selected'; ?>>Agosto</option>
                                  <option value="9" <?php if($mesN == '9') echo 'selected'; ?>>Setembro</option>
                                  <option value="10" <?php if($mesN == '10') echo 'selected'; ?>>Outubro</option>
                                  <option value="11" <?php if($mesN == '11') echo 'selected'; ?>>Novembro</option>
                                  <option value="12" <?php if($mesN == '12') echo 'selected'; ?>>Dezembro</option>
                             </select>
                           </div>
                           <div class="col">
                             <?php if(!isset($_SESSION["CPF"])){ ?>
                              <select class="form-control" name="AnoNascimento">
                               <option value="">Ano</option>
                               <?php for($ano = 1900; $ano <= date("Y"); $ano++){ ?>
                                 <option value="<?php echo $ano; ?>" <?php if($ano == $anoN) echo 'selected'; ?>><?php echo $ano; ?></option>
                               <?php } ?>
                             </select>
                           <?php }else{ ?>
                             <select class="form-control" name="AnoNascimento">
                              <option value="">Ano</option>
                              <?php for($ano = 1900; $ano <= date("Y"); $ano++){ ?>
                                <option value="<?php echo $ano; ?>"><?php echo $ano; ?></option>
                              <?php } ?>
                             </select>
                           <?php } ?>
                           </div>
                        </div>
             </div>
             <div class="form-group">
               <label for="telefone">Telefone:</label>
                 <input name="Telefone" type="text" class="form-control" id="telefone" value="<?php echo $visualizar[1]->telefone_residencia; ?>">
             </div>
             <div class="form-group">
               <label for="celular">Celular:</label>
                 <input name="Celular" type="text" class="form-control" id="celular" value="<?php echo $visualizar[1]->celular; ?>">
             </div>
             <div class="form-group">
               <label for="nomeMae">Nome da mãe:</label>
                 <input name="NomeMae" type="text" class="form-control" id="nomeMae" value="<?php echo $visualizar[1]->nome_mae; ?>">
             </div>
             <div class="form-group">
               <label for="nomePai">Nome do pai:</label>
                 <input name="NomePai" type="text" class="form-control" id="nomePai" value="<?php echo $visualizar[1]->nome_pai; ?>">
             </div>
             <div class="form-group">
               <label for="telefone">Estado Civil:</label>
               <select name="EstadoCivil" class="form-control">
                 <option value="">Selecione uma opção</option>
                 <option value="S" <?php if($visualizar[1]->estado_civil == 'S') echo "selected"; ?>>Solteiro</option>
                 <option value="C" <?php if($visualizar[1]->estado_civil == 'C') echo "selected"; ?>>Casado</option>
                 <option value="V" <?php if($visualizar[1]->estado_civil == 'V') echo "selected"; ?>>Viúvo</option>
                 <option value="U" <?php if($visualizar[1]->estado_civil == 'U') echo "selected"; ?>>União Estável</option>
               </select>
             </div>
             <div class="form-group">
                   <label for="cep" class="control-label">CEP: <span style="color: red">*</span></label>
                   <input type="text" name="CEP" class="form-control" id="cep" required="required" value="<?php echo $visualizar[1]->cep; ?>">
             </div>
             <div class="form-group">
                 <label for="rua" class="control-label">Endereço Completo: <span style="color: red">*</span></label>
                 <input id="rua" name="Logradouro" type="text" class="form-control" required="required" value="<?php echo $visualizar[1]->endereco; ?>">
             </div>
             <div class="form-group">
               <label for="bairro" class="control-label">Bairro: <span style="color: red">*</span></label>
                 <input id="bairro" name="Bairro" type="text" class="form-control" required="required" value="<?php echo $visualizar[1]->bairro; ?>">
             </div>
             <div class="form-group">
               <label for="cidade">Cidade:</label>
                 <input id="cidade" name="Cidade" type="text" class="form-control" readonly value="<?php echo $visualizar[1]->cidade; ?>">
             </div>
             <div class="form-group">
               <?php
               $tabelaE = 'estado';
               $idTabelaE = 'estado';
               $idBuscaE = $visualizar[1]->estado;
               $visualizarE = $metodos->visualizar($tabelaE,$idTabelaE,$idBuscaE);
                ?>
               <label for="estado">Estado:</label>
                 <input id="uf" name="Estado" type="text" class="form-control" readonly value="<?php echo $visualizarE[1]->nome; ?>">
             </div>
             <div class="form-group">
               <label for="estado">Nacionalidade:</label>
                 <?php echo $metodos->listarNacionalidade($buscar = $visualizar[1]->nacionalidade); ?>
             </div>
             <div class="form-group">
               <label for="estado">Naturalidade:</label>
                 <?php echo $metodos->listarNaturalidade($buscar = $visualizar[1]->naturalidade); ?>
             </div>
            <h5 style="font-weight: bold"><i class="fas fa-building"></i> DADOS COMERCIAIS</h5>
            <div class="form-group">
                <label for="profissao">Profissão:</label>
                <input id="profissao" name="Profissao" type="text" class="form-control" value="<?php echo $visualizar[1]->profissao; ?>">
            </div>
            <div class="form-group">
              <label for="telefoneEmpresa">Telefone:</label>
                <input id="telefoneEmpresa" name="TelefoneComercial" type="text" class="form-control" value="<?php echo $visualizar[1]->telefone_comercial; ?>">
            </div>
            <h5 style="font-weight: bold"><i class="fas fa-list-ol"></i> ATIVIDADES</h5>
            <div class="form-group">
              <label for="atleta">Atleta:</label>
              <?php
               if($visualizar[1]->eh_atleta == 'S'){ $selectedSim = 'selected'; }else{ $selectedNao = 'selected'; }
              ?>
              <select name="Atleta" class="form-control col-md-4" id="atleta">
                <option value="Sim" <?php echo $selectedSim; ?>>Sim</option>
                <option value="Não" <?php echo $selectedNao; ?>>Não</option>
              </select>
            </div>
            <div class="form-group">
              <?php
               if($visualizar[1]->eh_instrutor == 'S'){ $selectedSim = 'selected'; }else{ $selectedNao = 'selected'; }
              ?>
              <label for="instrutor">Instrutor:</label>
              <select name="Instrutor" class="form-control col-md-4"  id="instrutor">
                <option value="Sim" <?php echo $selectedSim; ?>>Sim</option>
                <option value="Não" <?php echo $selectedNao; ?>>Não</option>
              </select>
            </div>
            <div class="form-group">
              <?php
               if($visualizar[1]->eh_arbitro == 'S'){ $selectedSim = 'selected'; }else{ $selectedNao = 'selected'; }
              ?>
              <label for="arbitro">Árbitro:</label>
              <select name="Arbitro" class="form-control col-md-4"  id="arbitro">
                <option value="Sim" <?php echo $selectedSim; ?>>Sim</option>
                <option value="Não" <?php echo $selectedNao; ?>>Não</option>
              </select>
            </div>
            <div class="form-group">
              <?php
               if($visualizar[1]->eh_instrutor == 'S'){ $selectedSim = 'selected'; }else{ $selectedNao = 'selected'; }
              ?>
              <label for="colecionador">Colecionador:</label>
              <select name="Colecionador" class="form-control col-md-4"  id="colecionador">
                <option value="Sim" <?php echo $selectedSim; ?>>Sim</option>
                <option value="Não" <?php echo $selectedNao; ?>>Não</option>
              </select>
            </div>
            <div class="form-group">
              <?php
               if($visualizar[1]->eh_cacador == 'S'){ $selectedSim = 'selected'; }else{ $selectedNao = 'selected'; }
              ?>
              <label for="cacador">Caçador:</label>
              <select name="Caçador" class="form-control col-md-4"  id="cacador">
                <option value="Sim" <?php echo $selectedSim; ?>>Sim</option>
                <option value="Não" <?php echo $selectedNao; ?>>Não</option>
              </select>
            </div>
            <div class="form-group">
              <?php
               if($visualizar[1]->eh_recarga == 'S'){ $selectedSim = 'selected'; }else{ $selectedNao = 'selected'; }
              ?>
              <div class="form-row mb-4">
                 <div class="col  col-md-4">
              <label for="cacador">Recarga:</label>
              <select name="Caçador" class="form-control" id="cacador">
                <option value="Sim" <?php echo $selectedSim; ?>>Sim</option>
                <option value="Não" <?php echo $selectedNao; ?>>Não</option>
              </select>
             </div>
             <div class="col">
                <label for="dies">Dies:</label>
               <input type="text" name="Dies" class="form-control col-md-4" value="<?php echo $visualizar[1]->dies; ?>"  id="dies">
             </div>
            </div>
          </div>
            <h5 style="font-weight: bold"><i class="fas fa-file-alt"></i> DOCUMENTOS</h5>
            <div class="form-group">
              <div class="form-row mb-4">
               <div class="col">
                  <label for="identidade">Identidade:</label>
                  <input id="identidade" name="Identidade" type="text" class="form-control" value="<?php echo $visualizar[1]->identidade; ?>">
               </div>
               <div class="col">
                 <label for="orgaoEmissor">Órgão Emissor:</label>
                 <input id="orgaoEmissor" name="OrgaoEmissor" type="text" class="form-control" value="<?php echo $visualizar[1]->identidade_orgao; ?>">
               </div>
               <div class="col">
                 <label for="dataEmissao">Data de Emissão:</label>
                 <?php
                    list($anoE,$mesE,$diaE) = explode("-",$visualizar[1]->identidade_emissao);
                    $dataEmissao = $diaE."/".$mesE."/".$anoE;
                 ?>
                 <input id="dataEmissao" name="DataEmissao" type="text" class="form-control" value="<?php echo $dataEmissao; ?>">
               </div>
            </div>
          </div>
          <div class="form-group">
            <div class="form-row mb-4">
             <div class="col">
                <label for="cr">CR:</label>
                <input id="cr" name="CR" type="text" class="form-control" value="<?php echo $visualizar[1]->cr; ?>">
             </div>
             <div class="col">
               <label for="crValidade">Validade:</label>
               <?php
                  list($anoV,$mesV,$diaV) = explode("-",$visualizar[1]->cr_validade);
                  $dataValidade = $diaV."/".$mesV."/".$anoV;
               ?>
               <input id="crValidade" name="CRValidade" type="text" class="form-control" value="<?php echo $dataValidade; ?>">
             </div>
          </div>
        </div>
        <div class="form-group">
        <label for="cpf">CPF:</label>
         <input id="cpf" name="CPF" type="text" class="form-control" value="<?php echo $visualizar[1]->cpf; ?>">
        </div>
      <h5 style="font-weight: bold"><i class="fas fa-file-alt"></i> DADOS PARA DECLARAÇÕES</h5>
      <div class="form-group">
        <label for="nome">Nível - Validade: <small>Será permitido emitir declaração de ranking até esta data</small></label>
        <div class="form-group">
          <label for="dataDeclaracao">Data da Declaração:</label>
          <?php
             list($anoDC,$mesDC,$diaDC) = explode("-",$visualizar[1]->data_declaracao);
             $dataDeclaracao = $diaDC."/".$mesDC."/".$anoDC;
          ?>
          <input id="dataDeclaracao" name="DataDeclaracao" type="text" class="form-control" value="<?php echo $dataDeclaracao; ?>">
        </div>
   </div>
   <div class="form-group">
   <label for="observacoes">Observações</label>
   <textarea name="Observacoes" rows="8" cols="80"><?php echo $visualizar[1]->observacoes; ?></textarea>
 </div>
       <div class="form-group">
        <div align="center">
        <button type="submit" name="Submit" value="Alterar" class="btn btn-primary"><i class="fas fa-save"></i> Salvar</button>
      </div>
    </div>
   </form>
   </div>
    <div class="col-md-4">
      <?php if($_SESSION["SucessoExcluir"]){ ?>
         <div class="alert alert-success">
            Pagamento excluído com sucesso!
         </div>
      <?php } ?>
      <div class="card">
        <div class="card-header">
          <i class="fas fa-envelope fa-lg"></i> ENVIAR SENHA
        </div>
        <div class="card-body">
         <?php //echo $metodos->listarAtiradoresLimite($limite = 10); ?>
         <?php echo $metodos->enviarSenhaAtirador($visualizar[1]->atirador); ?>
        </div>
      </div>

      <div class="card" style="margin-top: 10px">
        <div class="card-header">
          <i class="fas fa-dollar-sign fa-lg"></i> DADOS FINANCEIROS
        </div>
        <div class="card-body">
         <?php //echo $metodos->listarAtiradoresLimite($limite = 10); ?>
         <?php echo $metodos->dadosFinanceirosAtirador($visualizar[1]->atirador); ?>
        </div>
      </div>
    </div>
  </div>
        </div>
     </div>
   </div>
 </div>
</div>
</div>


   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/jquery.maskedinput-master/dist/jquery.maskedinput.js" type="text/javascript"></script>
   <script type="text/javascript">
       $(function() {
           $.mask.definitions['~'] = "[+-]";
           $("#cpf").mask("999.999.999-99");
           $("#cep").mask("99999-999");
           $("#telefone").mask("(99)9999-9999");
           $("#celular").mask("(99)99999-9999");
           $("#telefoneEmpresa").mask("(99)9999-9999");
           $("#dataEmissao").mask("99/99/9999");
           $("#crValidade").mask("99/99/9999");
           $("#dataDeclaracao").mask("99/99/9999");
       });
   </script>

  </body>
</html>
