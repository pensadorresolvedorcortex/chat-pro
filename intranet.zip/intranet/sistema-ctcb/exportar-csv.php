<?php
error_reporting(0);
session_start();
if($_SESSION["LogadoCTCB"] == false){
   echo "<script>window.location.href='../index.php';</script>";
   exit();
}
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
$tipo = $_REQUEST["tipo"];
if($_REQUEST["estado"])
{
   $estado = $_REQUEST["estado"];
}
 else
{
   $estado = $_POST["Estado"];
}

echo $metodos->exportarCSV($tipo,$estado);
?>