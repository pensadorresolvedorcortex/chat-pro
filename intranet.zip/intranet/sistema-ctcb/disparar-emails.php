<?php
error_reporting(0);
session_start();
if($_SESSION["LogadoCTCB"] == false){
  echo "<script>window.location.href='../index.php';</script>";
  exit();
}
/**
 * Sistema de disparos de emails em massa desenvolvido por PerTutti Soluções Digitais
 * Visite: https://solucoes.pertuttigestao.com.br
 * Data do desenvolvimento (início e conclusão): 26/05/2019
 * Versão do sistema: 1.0
 */
// Dispensamos instaciamentos de métodos e colocamos a conexão diretamente abaixo, assim como as respectivas 'querys'
$servidor = 'ctcb_confedera.mysql.dbaas.com.br';
$usuario = 'ctcb_confedera';
$senha = 'b@nc0Confeder@';
$banco = 'ctcb_confedera';
$conexao = mysqli_connect($servidor,$usuario,$senha,$banco);
//exit;
mysqli_set_charset($conexao, "utf8");
$sqlMensagens = mysqli_query($conexao,"SELECT * FROM ctcb_mensagens;");
if(mysqli_num_rows($sqlMensagens) == 0)
{
    // Verifica se já existe mensagens cadastradas, se não existir, fará o cadastramento abaixo
    mysqli_query($conexao,"INSERT INTO ctcb_mensagens VALUES(null,'".$_POST["Assunto"]."','".$_POST["Mensagem"]."');");
}
else
{
    // Se existir, gera as variáveis necessárias para o disparo
    $ctcbMensagens = mysqli_fetch_object($sqlMensagens);
    $assuntoClubes = $ctcbMensagens->Assunto;
    $mensagemClubes = $ctcbMensagens->Mensagem;    
}
//echo $_POST["Mensagem"];
//exit;
// PHPMailer
require 'phpmailer/PHPMailerAutoload.php';
require 'phpmailer/class.phpmailer.php';
$mailer = new PHPMailer;
$quant = 1; // quantidade de e-mails para disparo
$sec = 10; // segundos para o disparo de cada mensagem
$sqlContar = mysqli_query($conexao,"SELECT * FROM enviar_cobranca_clubes;");
$contar = mysqli_num_rows($sqlContar); // Verifica se há cadastros na tabela...  
if($contar == 0)
{
   $sql = mysqli_query($conexao,"SELECT * FROM clube WHERE email <> '';");
   //$sql = mysqli_query($conexao,"SELECT * FROM teste_disparo WHERE email <> '';");
    while($ctcb = mysqli_fetch_object($sql))
    {
          // ..se ainda não existir cadastros na tabela, fará a inclusão abaixo
          mysqli_query($conexao, "INSERT INTO enviar_cobranca_clubes VALUES(null,'".$ctcb->clube."','0');");
    }
}
$sqlAtualizar = mysqli_query($conexao, "SELECT * FROM enviar_cobranca_clubes WHERE StatusEnvio = 0");
$ctcbAtualizar = mysqli_num_rows($sqlAtualizar); // verifica se o StatusEnvio está com o valor 0. Se estiver, incluirá o valor 1 na variável $atualizar, senão o valor permanecerá 0
if($ctcbAtualizar > 0)
{
    $atualizar = 1;  
}
else
{
    $atualizar = 0;    
}
$caminhoAbsoluto = "https://intranet.ctcb.org.br/sistema-ctcb";
?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <?php
        $sqlDisparo = mysqli_query($conexao, "SELECT * FROM enviar_cobranca_clubes WHERE StatusEnvio = 0 LIMIT ".$quant.";");
        $ctcbDisparo = mysqli_fetch_object($sqlDisparo);
        if($atualizar == 1)
        {
            // Vamos contabilizar os disparos feitos e quantos ainda faltam
            $sqlTotalDisparo = mysqli_query($conexao,"SELECT * FROM enviar_cobranca_clubes;");
            $contarTotalDisparo = mysqli_num_rows($sqlTotalDisparo);
            $sqlTotalDisparado = mysqli_query($conexao,"SELECT * FROM enviar_cobranca_clubes WHERE StatusEnvio = 1;");
            $contarTotalDisparado = mysqli_num_rows($sqlTotalDisparado);
            $gif = '<img src="'.$caminhoAbsoluto.'/imagens/ajax-loader.gif">
                    <br>Aguarde, disparando para os e-mails...<br>
                    Enviando '.($contarTotalDisparado + 1).' de '.$contarTotalDisparo.'';
        ?>
        <!-- Atualizando a página --->
        <meta http-equiv="refresh" url="index.php" content="<?=$sec;?>">
        <?php 
        }
        else
        {
            // Se todos já tiverem sido disparados, 'truncaremos' as tabelas abaixo e mostraremos a mensagem de 'sucesso'.
            mysqli_query($conexao, "TRUNCATE TABLE enviar_cobranca_clubes;");
            mysqli_query($conexao, "TRUNCATE TABLE ctcb_mensagens;");
            $gif = '<i class="fas fa-check"></i> O disparo foi efetuado com sucesso!';
        } 
     ?>
    <meta charset="utf-8">
    <title>CTCB | Controle de Gestão</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/css/style.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    </head>
  <body>
   <div class="container">
     <div class="row header">
          <div class="col-md-6">
            <img src="<?php echo $caminhoAbsoluto; ?>/imagens/logo.png" alt="" class="logo">
         </div>
         <div class="col-md-6 text-right">
           <h3>SISTEMA DE GESTÃO | CTCB</h3>
           <a href="<?php echo $caminhoAbsoluto; ?>/sair/" style="color: #000" alt="Sair do sistema" title="Sair do sistema"><i class="fas fa-power-off"></i> Sair do sistema</a>
         </div>
     </div>
     <div class="row conteudo">
       <nav class="col-md-12 navbar navbar-expand-lg navbar-light bg-light">
         <div class="collapse navbar-collapse navbar-right" id="navbarSupportedContent">
           <ul class="navbar-nav mr-auto">
             <li class="nav-item">
               <a class="nav-link" href="<?php echo $caminhoAbsoluto; ?>/">Principal <span class="sr-only">(current)</span></a>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Cadastro
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/atiradores/"><i class="fas fa-caret-right"></i> Atirador</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/categorias/"><i class="fas fa-caret-right"></i> Categoria</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/clubes/"><i class="fas fa-caret-right"></i> Clube</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/despachantes/"><i class="fas fa-caret-right"></i> Despachante</a>
                <!-- <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/estados/"><i class="fas fa-caret-right"></i> Estado</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/nacionalidade/"><i class="fas fa-caret-right"></i> Nacionalidade</a>
               --><a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/modalidades/"><i class="fas fa-caret-right"></i> Modalidade</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/provas/"><i class="fas fa-caret-right"></i> Prova</a>
               </div>
             </li>
             <li class="nav-item dropdown active">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Diários
               </a>
               <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/noticias/"><i class="fas fa-caret-right"></i> Notícias</a>
                 <a class="dropdown-item active" href="<?php echo $caminhoAbsoluto; ?>/enviar-emails/"><i class="fas fa-caret-right"></i> Envia E-mail</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/galeria-fotos/"><i class="fas fa-caret-right"></i> Galeria de Fotos</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/videos/"><i class="fas fa-caret-right"></i> Vídeo</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Campeonatos
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/eventos/"><i class="fas fa-caret-right"></i> Evento</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Financeiro
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pagos/"><i class="fas fa-caret-right"></i> Pagos</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pendentes/"><i class="fas fa-caret-right"></i> Pendentes</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pagos/"><i class="fas fa-caret-right"></i> Valor Mensalidade</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Utilitários
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/cadastrar-usuarios/"><i class="fas fa-caret-right"></i> Usuários</a>
               </div>
             </li>
           </ul>
         </div>
       </nav>
      <div class="container" style="margin-top: 10px">
   <div class="row" style="margin-top: 10px">

     <div class="col-md-12">
       <div class="tituloCaixa">
        <i class="far fa-envelope fa-lg"></i> Enviar mensagens para os clubes
       </div>
      <div style="margin-top:40px">
       <div align="center">
       <?php
       if(mysqli_num_rows($sqlMensagens) > 0)
       {
        // Fazendo o disparo...
        $sqlDisparar = mysqli_query($conexao,"SELECT * FROM clube WHERE clube = '".$ctcbDisparo->IdClubes."';");
       // $sqlDisparar = mysqli_query($conexao,"SELECT * FROM teste_disparo WHERE clube = '".$ctcbDisparo->IdClubes."';");
        $ctcbDisparar = mysqli_fetch_object($sqlDisparar);
       // exit;
        if($ctcbDisparar->email != '')
        {
        $mailer->isSMTP();
        $mailer->SMTPOptions = array(
                                    'ssl' => array(
                                    'verify_peer' => false,
                                    'verify_peer_name' => false,
                                    'allow_self_signed' => true
                                    )
                                );
            $dataVencimento = $ctcbDisparar->data_vencimento;
            list($ano,$mes,$dia) = explode('-',$dataVencimento);
            $dataVencimento = $dia.'/'.$mes.'/'.$ano;
            $assunto = $assuntoClubes;
            $mailer->Host = 'mail.ctcb.org.br';
            $mailer->SMTPAuth = true;
            $mailer->IsSMTP();
            $mailer->isHTML(true);
            $mailer->Port = 587;
            $mailer->CharSet = 'UTF-8';
            $mailer->Username = 'naoexclua@ctcb.org.br';
            $mailer->Password = 'confeder@c@o';
            $mensagem = $mensagemClubes;
            $mensagem .= '<br><br>Atenciosamente,<br>CTCB - Confereração de Tiro e Caça do Brasil.';
            $mailer->AddAddress($ctcbDisparar->email, 'CTCB - Confederação de Tiro e Caça do Brasil');
            $mailer->From = 'atendimento@ctcb.org.br';
            $mailer->FromName = 'CTCB - Confederação de Tiro e Caça do Brasil';
            $mailer->Subject = $assunto;
            $mailer->MsgHTML($mensagem);
            if($mailer->Send())
            {
            // Se enviado, atualizaremos o StatusEnvio para o valor 1  
            mysqli_query($conexao, "UPDATE enviar_cobranca_clubes SET StatusEnvio = 1 WHERE IdClubes = '".$ctcbDisparar->clube."';");
            }
          }
        }
        echo $gif; // Mostra o gif ou a mensagem de sucesso
       ?>
      </div>
     </div>
    </div>
   </div>
 </div>
</div>
</div>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>
   </body>
</html>
