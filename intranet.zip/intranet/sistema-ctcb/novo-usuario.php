<?php
error_reporting(0);
session_start();
if($_SESSION["LogadoCTCB"] == false){
  echo "<script>window.location.href='../index.php';</script>";
  exit();
}
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
$tabela = "video";
$idTabela = "video";
$idBusca = $_SERVER["QUERY_STRING"];
$visualizar = $metodos->visualizar($tabela,$idTabela,$idBusca);
if($_SESSION["Sucesso"] < time())
{
  unset($_SESSION["Sucesso"]);
}
if($_SESSION["JaCadastrado"] < time())
{
  unset($_SESSION["JaCadastrado"]);
}
if($_SESSION["Erro"] < time())
{
  unset($_SESSION["Erro"]);
}
if($_POST["Submit"] == "Salvar"){
  $dados = array_filter($_POST);
  echo $metodos->cadastrarUsuarios($dados);
}
?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/css/style.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <style type="text/css">
        .onoff input.toggle {
        display: none;
    }

    .onoff input.toggle + label {
        display: inline-block;
        position: relative;
        box-shadow: inset 0 0 0px 1px #d5d5d5;
        height: 30px;
        width: 70px;
        background: #DC143C;
        border-radius: 30px;
    }

    .onoff input.toggle + label:before {
    	cursor: pointer;
        content: "\00a0 \00a0 \00a0 \00a0 \00a0 \00a0 \00a0  Não";
        display: block;
    	color: #FFF;
        height: 30px;
        border-radius: 30px;
        background: rgba(19, 191, 17, 0);
        transition: 0.1s ease-in-out;
    }

    .onoff input.toggle + label:after {
        content: "";
        position: absolute;
        height: 30px;
        width: 30px;
        top: 0;
        left: 0px;
        border-radius: 30px;
        background: #fff;
        box-shadow: inset 0 0 0 1px rgba(0, 0, 0, 0.2), 0 2px 4px rgba(0, 0, 0, 0.2);
        transition: 0.1s ease-in-out;
    }

    .onoff input.toggle:checked + label:before {
    	cursor: pointer;
        width: 70px;
    	content: "\00a0 \00a0 \00a0 Sim";
    	color: #FFF;
        font-family: 'Arial';
        background: #13bf11;
    }
    .onoff input.toggle:checked + label:after {
        left: 40px;
        box-shadow: inset 0 0 0 1px #13bf11, 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    #estado{ font-size: 14px; font-weight: bold;}
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script src="<?php echo $caminhoAbsoluto; ?>/js/mascaras.js"></script>
  </head>
  <body>
   <div class="container">
     <div class="row header">
          <div class="col-md-6">
            <a href="<?php echo $caminhoAbsoluto; ?>/"><img src="<?php echo $caminhoAbsoluto; ?>/imagens/logo.png" alt="Logo da CTCB" class="logo"></a>
         </div>
         <div class="col-md-6 text-right">
           <h3>SISTEMA DE GESTÃO | CTCB</h3>
           <a href="<?php echo $caminhoAbsoluto; ?>/sair/" style="color: #000" alt="Sair do sistema" title="Sair do sistema"><i class="fas fa-power-off"></i> Sair do sistema</a>
         </div>
     </div>
     <div class="row conteudo">
       <nav class="col-md-12 navbar navbar-expand-lg navbar-light bg-light">
         <div class="collapse navbar-collapse navbar-right" id="navbarSupportedContent">
           <ul class="navbar-nav mr-auto">
             <li class="nav-item">
               <a class="nav-link" href="<?php echo $caminhoAbsoluto; ?>/">Principal <span class="sr-only">(current)</span></a>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Cadastro
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/atiradores/"><i class="fas fa-caret-right"></i> Atirador</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/categorias/"><i class="fas fa-caret-right"></i> Categoria</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/clubes/"><i class="fas fa-caret-right"></i> Clube</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/despachantes/"><i class="fas fa-caret-right"></i> Despachante</a>
                <!-- <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/estados/"><i class="fas fa-caret-right"></i> Estado</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/nacionalidade/"><i class="fas fa-caret-right"></i> Nacionalidade</a>
               -->
               <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/modalidades/"><i class="fas fa-caret-right"></i> Modalidade</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/provas/"><i class="fas fa-caret-right"></i> Prova</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Diários
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/noticias/"><i class="fas fa-caret-right"></i> Notícias</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/enviar-emails/"><i class="fas fa-caret-right"></i> Envia E-mail</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/galeria-fotos/"><i class="fas fa-caret-right"></i> Galeria de Fotos</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/videos/"><i class="fas fa-caret-right"></i> Vídeo</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Campeonatos
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/eventos/"><i class="fas fa-caret-right"></i> Evento</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Financeiro
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pagos/"><i class="fas fa-caret-right"></i> Pagos</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pendentes/"><i class="fas fa-caret-right"></i> Pendentes</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pagos/"><i class="fas fa-caret-right"></i> Valor Mensalidade</a>
               </div>
             </li>
             <li class="nav-item dropdown active">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Utilitários
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item active" href="<?php echo $caminhoAbsoluto; ?>/cadastrar-usuarios/"><i class="fas fa-caret-right"></i> Usuários</a>
               </div>
             </li>
           </ul>
         </div>
       </nav>
      <div class="container" style="margin-top: 10px">
   <div class="row" style="margin-top: 10px">
     <div class="col-md-12">
       <div class="tituloCaixa">
      <i class="fas fa-user-plus"></i> Novo usuário
       </div>
       <div style="margin-top:10px">
         <div class="text-right">
           <button type="button" class="btn btn-primary btn-sm text-right" name="button" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/galeria-fotos/'">Voltar</button>
         </div>
      <div class="row">

       <div class="col-md-12">
         <?php if($_SESSION["Sucesso"]){ ?>
           <div class="alert alert-success"><i class="fas fa-check"></i> Cadastro efetuado com sucesso!</div>
         <?php } ?>
         <?php if($_SESSION["JaCadastrado"]){ ?>
           <div class="alert alert-warning"><i class="fas fa-check"></i> Já existe um login com esse nome!</div>
         <?php } ?>
         <?php if($_SESSION["Erro"]){ ?>
           <div class="alert alert-danger"><i class="fas fa-check"></i> Ops... Tivemos um problema do lado de cá. Se o erro persistir, envie um e-mail para: suporte@pertuttigestao.com.br e informe o erro detectado.</div>
         <?php } ?>
           <form class="" action="#" method="post">
              <div class="form-group">
               <label id="titulo">Nome:</label>
               <input type="text" name="Nome" class="form-control" value="">
             </div>
             <div class="form-group">
               <label id="embeb">Login:</label>
               <input type="text" name="Login" class="form-control" value="">
             </div>
             <div class="form-group">
               <label id="embeb">Senha:</label>
               <input type="text" name="Senha" class="form-control" value="<?php echo $metodos->generatePassword(); ?>">
             </div>
             <div class="form-group">
            Pode cadastrar?<br>
            <div class="onoff">
            <input type="checkbox" class="toggle" id="onoff">
            <label for="onoff"></label>
            <input type="hidden" name="Cadastrar" id="campo" value="0"><br>
            Pode editar?<br>
            <div class="onoff1">
            <input type="checkbox" class="toggle" id="onoff1">
            <label for="onoff1"></label>
            <input type="hidden" name="Editar" id="campo1" value="0"><br>
            Pode excluir?<br>
            <div class="onoff2">
            <input type="checkbox" class="toggle" id="onoff2">
            <label for="onoff2"></label>
            <input type="hidden" name="Excluir" id="campo2" value="0">
          </div>
             <div class="form-group text-center">
                 <button type="submit" name="Submit" value="Salvar" class="btn btn-primary"><i class="fas fa-save"></i> Salvar</button>
             </div>
           </form>
      </div>
  </div>
        </div>
     </div>
   </div>
 </div>
</div>
</div>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>
   <script>
   $(document).ready(function(){
          $("div.alert").fadeIn( 300 ).delay( 3000 ).fadeOut( 400 );
         });
   </script>
   <script type='text/javascript'>
   //<![CDATA[
   window.onload=function(){
   var onoff = document.getElementById('onoff');
   onoff.addEventListener('change', function() {
       estado = this.checked ? '1' : '0';
       var campo = document.getElementById("campo").value = estado;
       $.ajax({
          data: {
              estado: this.checked,
              campo: campo
          }
      }).done(function(msg) {
      });
   });
   }//]]>
   //<![CDATA[
   /////////////////////////
   var onoff1 = document.getElementById('onoff1');
   onoff1.addEventListener('change', function() {
       estado = this.checked ? '1' : '0';
       var campo = document.getElementById("campo1").value = estado;
       $.ajax({
          data: {
              estado: this.checked,
              campo: campo
          }
      }).done(function(msg) {
      });
   });

   /////////////////////////
   var onoff2 = document.getElementById('onoff2');
   onoff2.addEventListener('change', function() {
       estado = this.checked ? '1' : '0';
       var campo = document.getElementById("campo2").value = estado;
   	$.ajax({
          data: {
              estado: this.checked,
              campo: campo
          }
      }).done(function(msg) {
      });
   });//]]>
   ///////////////////
   </script>
  </body>
</html>
