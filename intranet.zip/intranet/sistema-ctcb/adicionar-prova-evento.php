<?php
error_reporting(0);
session_start();
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
$clube = $_SERVER["QUERY_STRING"];
echo $metodos->adicionarProvaEvento($clube);
?>
