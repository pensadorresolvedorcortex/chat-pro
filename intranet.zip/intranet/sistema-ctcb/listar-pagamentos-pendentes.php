<?php
error_reporting(0);
session_start();
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$pagina = filter_input(INPUT_POST, 'pagina', FILTER_SANITIZE_NUMBER_INT);
$qnt_result_pg = filter_input(INPUT_POST, 'qnt_result_pg', FILTER_SANITIZE_NUMBER_INT);
$busca = $_POST["busca"];
echo $metodos->listarPendentes($pagina,$qnt_result_pg,$busca);
?>
