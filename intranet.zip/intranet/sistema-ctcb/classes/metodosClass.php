<?php
session_start();

/**
* Class metodosClass
* @copyright  Confederação de Tiro e Caça do Brasil. https://www.ctcb.org.br
* NOTE: Dispensamos o uso do try e catch. Métodos criados no modo procedural, dispensando também o uso do PDO
*/
  // Habilitar as linhas abaixo em caso de erro....
/*
  ini_set('display_errors',1);
  ini_set('display_startup_erros',1);
  error_reporting(E_ALL);
 */
// Desabilitar a linha abaixo caso habilite a de cima
error_reporting(0);

require_once("../../classes/conectaClass.php"); // remoto
//require_once("../../site/classes/conectaClass.php");

class metodosClass
{
  public $conexao;

    /**
     * Classe construtor
     */
   public function __construct()
    {
        $conectar = new conectaClass();
        $this->conexao = $conectar->conectar();
        return $this->conexao;
    }

    /**
    * Método armazena os logs de acesso ao site
    * @access public
    * @param string $ip
    */
    public function logs($ip)
    {
      mysqli_query($this->conexao, "INSERT INTO acessos VALUES(null,'" . $ip . "',NOW());");
    }

    /**
     * Método converte o nome com a primeira letra em caixa alta
     * @access public
     * @param string $palavra
     * @return string $nomeUsuario
     */
    public function palavraMinuscula($palavra)
    {
      $nomeUsuario = mb_convert_case($palavra, MB_CASE_TITLE, 'UTF-8');
      return  $nomeUsuario;
    }

    /**
    * Método cria o caminho absoluto dos links. Encontra-se em todas as páginas
    * @access public
    * @param void
    * @return string $caminhoAbsoluto
    */
    public function caminhoAbsoluto()
    {
    // $caminhoAbsoluto = "https://".$_SERVER['SERVER_NAME']."/Projetos/CTCB/controle/sistema-ctcb"; // local
     $caminhoAbsoluto = "https://intranet.ctcb.org.br/sistema-ctcb"; // remoto
     return $caminhoAbsoluto;
    }

    /**
     * Método altera a senha
     * @access public
     * @param string $senha
     * @return true
     */
    public function alterarSenha($senha)
    {
       $senha = mysqli_real_escape_string($this->conexao,trim($senha));
       mysqli_query($this->conexao,"UPDATE acesso_admin SET SenhaAdmin = '".$this->codificar($senha)."' WHERE IdAdmin = '".$_SESSION["IdAdmin"]."';");
       $_SESSION["Sucesso"] = time() + 5;
      return "<script>window.location.href='".$this->caminhoAbsoluto()."/'</script>";
    }

    /**
     * Método altera a senha
     * @access public
     * @param string $senha
     * @return true
     */
    public function exportarCSV($tipo,$estado)
    {
      if($tipo == 'sememail')
      {
        $arquivo = 'sememail.xls';
        $delimitador = ',';
        $abrir = fopen('php://memory','w');
        $campos = array('nome','celular');
        fputcsv($abrir,$campos,$delimitador);
        $sql = mysqli_query($this->conexao,"SELECT * FROM `atirador`
                                            WHERE email = ''
                                            AND (celular <> '' OR telefone_residencia <> '');");
        if(mysqli_num_rows($sql) > 0)
        {
          while($ctcb = mysqli_fetch_assoc($sql))
          {
             $camposBD = array($ctcb["nome"],preg_replace('/[^0-9]/', '',$ctcb["celular"]));
             fputcsv($abrir,$camposBD,$delimitador);
          }
        }
        fseek($abrir,0);
        header('Content-Type: application/x-msexcel');
        header('Content-Disposition: attachment; filename="'.$arquivo.'";');
        fpassthru($abrir);
        exit();
      }
      if($tipo == 'estado')
      {
        $sqlEstado = mysqli_query($this->conexao,"SELECT * FROM estado WHERE estado = '".$estado."';");
        $ctcbEstado = mysqli_fetch_object($sqlEstado);
        $arquivo = 'estado_'.$ctcbEstado->sigla.'.xls';
        $delimitador = ',';
        $abrir = fopen('php://memory','w');
        $campos = array('Estado','Nome','Endereço','Bairro','Telefone','Celular','Email');
        fputcsv($abrir,$campos,$delimitador);
        $sql = mysqli_query($this->conexao,"SELECT *, A.nome AS NomeAtirador FROM `atirador` A
                                            INNER JOIN `estado` E
                                            ON  A.estado = E.estado
                                            WHERE A.email <> ''
                                            AND A.estado = '".$estado."';");
        if(mysqli_num_rows($sql) > 0)
        {
          while($ctcb = mysqli_fetch_assoc($sql))
          {
             $camposBDD = array($ctcb["sigla"],$ctcb["NomeAtirador"],$ctcb["endereco"],$ctcb["bairro"],$ctcb["telefone_residencia"],preg_replace('/[^0-9]/', '',$ctcb["celular"]),$ctcb["email"]);
             fputcsv($abrir,$camposBDD,$delimitador);
          }
        }
        fseek($abrir,0);
        header('Content-Type: application/x-msexcel');
        header('Content-Disposition: attachment; filename="'.$arquivo.'";');
        fpassthru($abrir);
        exit();
      }
      if($tipo == 'total')
      {
        $arquivo = 'relatorio_geral.xls';
        $delimitador = ',';
        $abrir = fopen('php://memory','w');
        $campos = array('Nome',
                        'Endereço',
                        'Bairro',
                        'Cidade',
                        'Estado',
                        'CEP',
                        'Telefone Res', 
                        'Telefone Com', 
                        'Celular',
                        'Email',
                        'RG',
                        'CPF',
                        'CR',
                        'Validade CR');
        fputcsv($abrir,$campos,$delimitador);
        $sql = mysqli_query($this->conexao,"SELECT 
                                              nome,
                                              endereco,
                                              bairro,
                                              cidade,
                                              estado,
                                              cep,
                                              telefone_residencia,
                                              telefone_comercial,
                                              celular,
                                              email,
                                              identidade,
                                              cpf,
                                              cr,
                                              cr_validade                                           
                                            FROM `atirador`;");
        if(mysqli_num_rows($sql) > 0)
        {
          while($ctcb = mysqli_fetch_assoc($sql))
          {
             $sqlEstado = mysqli_query($this->conexao,"SELECT * FROM estado WHERE estado = '".$ctcb['estado']."';");
             $ctcbEstado = mysqli_fetch_assoc($sqlEstado);
             $camposBD = array($ctcb["nome"],
                               $ctcb["endereco"],
                               $ctcb["bairro"],
                               $ctcb["cidade"],
                               $ctcbEstado["sigla"],
                               $ctcb["cep"],
                               $ctcb["telefone_residencia"],
                               $ctcb["telefone_comercial"],
                               preg_replace('/[^0-9]/', '',$ctcb["celular"]),
                               $ctcb["email"],
                               $ctcb["identidade"],
                               $ctcb["cpf"],
                               $ctcb["cr"],
                               $ctcb["cr_validade"]);
             fputcsv($abrir,$camposBD,$delimitador);
          }
        }
        fseek($abrir,0);
       // header('Content-Type: text/csv');
        header('Content-Type: application/x-msexcel');
        header('Content-Disposition: attachment; filename="'.$arquivo.'";');
        fpassthru($abrir);
        exit();
      }

      if($tipo == 'filiacao-vencida')
      {
         $arquivo = 'relatorio_filiacao_vencida.xls';
        $delimitador = ',';
        $abrir = fopen('php://memory','w');
        $campos = array('Nome',
                        'Endereço',
                        'Bairro',
                        'Cidade',
                        'Estado',
                        'CEP',
                        'Telefone Res', 
                        'Celular',
                        'Email',
                        'Data de Vencimento');
        fputcsv($abrir,$campos,$delimitador);
        $sql = mysqli_query($this->conexao,"SELECT 
                                              A.nome,
                                              A.endereco,
                                              A.bairro,
                                              A.cidade,
                                              A.estado,
                                              A.cep,
                                              A.telefone_residencia,
                                              A.telefone_comercial,
                                              A.celular,
                                              A.email,
                                              P.data_vencimento
                                            FROM 
                                             `atirador` A
                                            INNER JOIN
                                             `atirador_pagamento` P
                                            ON A.atirador = P.atirador
                                            WHERE 
                                            P.data_vencimento <> ''
                                            AND  
                                            P.data_vencimento < CURDATE()                                                 
                                            ORDER BY P.data_vencimento DESC");
        if(mysqli_num_rows($sql) > 0)
        {
          while($ctcb = mysqli_fetch_assoc($sql))
          {
             $sqlEstado = mysqli_query($this->conexao,"SELECT * FROM estado WHERE estado = '".$ctcb['estado']."';");
             $ctcbEstado = mysqli_fetch_assoc($sqlEstado);
             $dataVencimento = date('d/m/Y',strtotime($ctcb["data_vencimento"]));
             $camposBD = array($ctcb["nome"],
                               $ctcb["endereco"],
                               $ctcb["bairro"],
                               $ctcb["cidade"],
                               $ctcbEstado["sigla"],
                               $ctcb["cep"],
                               $ctcb["telefone_residencia"],
                               preg_replace('/[^0-9]/', '',$ctcb["celular"]),
                               $ctcb["email"],
                               $dataVencimento);
             fputcsv($abrir,$camposBD,$delimitador);
          }
        }
        fseek($abrir,0);
        header('Content-Type: application/x-msexcel');
        header('Content-Disposition: attachment; filename="'.$arquivo.'";');
        fpassthru($abrir);
        exit();
      }

      if($tipo == 'inadimplentes-estado')
      {
        $sqlEstado = mysqli_query($this->conexao,"SELECT * FROM estado WHERE estado = '".$estado."';");
        $ctcbEstado = mysqli_fetch_object($sqlEstado);
        $arquivo = 'relatorio_filiacao_vencida_'.$ctcbEstado->sigla.'.xls';
        $delimitador = ',';
        $abrir = fopen('php://memory','w');
        $campos = array('Nome',
                        'Endereço',
                        'Bairro',
                        'Cidade',
                        'Estado',
                        'CEP',
                        'Telefone Res', 
                        'Celular',
                        'Email',
                        'Data de Vencimento');
        fputcsv($abrir,$campos,$delimitador);
        $sql = mysqli_query($this->conexao,"SELECT 
                                              A.nome,
                                              A.endereco,
                                              A.bairro,
                                              A.cidade,
                                              A.estado,
                                              A.cep,
                                              A.telefone_residencia,
                                              A.telefone_comercial,
                                              A.celular,
                                              A.email,
                                              P.data_vencimento
                                            FROM 
                                             `atirador` A
                                            INNER JOIN
                                             `atirador_pagamento` P
                                            ON A.atirador = P.atirador
                                            WHERE 
                                              P.data_vencimento <> ''
                                            AND 
                                              A.estado = '".$ctcbEstado->estado."'
                                            AND  
                                              P.data_vencimento < CURDATE()                                                 
                                            ORDER BY P.data_vencimento DESC");
        if(mysqli_num_rows($sql) > 0)
        {
          $tabela = '<table>';
          $tabela .= '<tr><td>Nome</td><td>Endereço</td><td>Bairro</td><td>Cidade</td><td>Estado</td><td>CEP</td><td>Tel.Res.</td><td>Celular</td><td>Email</td><td>Vencimento</td></tr>';
          
          while($ctcb = mysqli_fetch_assoc($sql))
          {
             $sqlEstado = mysqli_query($this->conexao,"SELECT * FROM estado WHERE estado = '".$ctcb['estado']."';");
             $ctcbEstado = mysqli_fetch_assoc($sqlEstado);
             $dataVencimento = date('d/m/Y',strtotime($ctcb["data_vencimento"]));
             $tabela .= '<tr>';
             $tabela .= '<td>'.$ctcb["nome"].'</td>';
             $tabela .= '<td>'.$ctcb["endereco"].'</td>';
             $tabela .= '<td>'.$ctcb["bairro"].'</td>';
             $tabela .= '<td>'.$ctcb["cidade"].'</td>';
             $tabela .= '<td>'.$ctcbEstado["sigla"].'</td>';
             $tabela .= '<td>'.$ctcb["cep"].'</td>';
             $tabela .= '<td>'.$ctcb["telefone_residencia"].'</td>';
             $tabela .= '<td>'.preg_replace('/[^0-9]/', '',$ctcb["celular"]).'</td>';
             $tabela .= '<td>'.$ctcb["email"].'</td>';
             $tabela .= '<td>'.$dataVencimento.'</td>';
             $tabela .= '</tr>';
           /*  $camposBD = array($ctcb["nome"],
                               $ctcb["endereco"],
                               $ctcb["bairro"],
                               $ctcb["cidade"],
                               $ctcbEstado["sigla"],
                               $ctcb["cep"],
                               $ctcb["telefone_residencia"],
                               preg_replace('/[^0-9]/', '',$ctcb["celular"]),
                               $ctcb["email"],
                               $dataVencimento);

             fputcsv($abrir,$camposBD,$delimitador);
             */
          }
          $tabela .= '</table>';
        }
       // fseek($abrir,0);
        header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
        header ("Last-Modified: " . gmdate("D,d M YH:i:s") . " GMT");
        header ("Cache-Control: no-cache, must-revalidate");
        header ("Pragma: no-cache");
        header('Content-Type: application/x-msexcel');
        header('Content-Disposition: attachment; filename="'.$arquivo.'";');
        header ("Content-Description: PHP Generated Data" );
        //fpassthru($abrir);
        return $tabela;
      //  exit();
      }

      if($tipo == 'cr-vencido')
      {
        $arquivo = 'relatorio_cr_vencido.xls';
        $delimitador = ',';
        $abrir = fopen('php://memory','w');
        $campos = array('Nome',
                        'Endereço',
                        'Bairro',
                        'Cidade',
                        'Estado',
                        'CEP',
                        'Telefone Res', 
                        'Telefone Com', 
                        'Celular',
                        'Email',
                        'CR',
                        'Validade do CR');
        fputcsv($abrir,$campos,$delimitador);
        $sql = mysqli_query($this->conexao,"SELECT 
                                              nome,
                                              endereco,
                                              bairro,
                                              cidade,
                                              estado,
                                              cep,
                                              telefone_residencia,
                                              telefone_comercial,
                                              celular,
                                              email,
                                              cr,
                                              cr_validade
                                            FROM 
                                             `atirador`
                                            WHERE cr_validade < CURDATE()
                                            ORDER BY cr_validade DESC");
        if(mysqli_num_rows($sql) > 0)
        {
          while($ctcb = mysqli_fetch_assoc($sql))
          {
             $sqlEstado = mysqli_query($this->conexao,"SELECT * FROM estado WHERE estado = '".$ctcb['estado']."';");
             $ctcbEstado = mysqli_fetch_assoc($sqlEstado);
             $dataCR = date('d/m/Y',strtotime($ctcb["cr_validade"]));
                               $camposBD = array($ctcb["nome"],
                               $ctcb["endereco"],
                               $ctcb["bairro"],
                               $ctcb["cidade"],
                               $ctcbEstado["sigla"],
                               $ctcb["cep"],
                               $ctcb["telefone_residencia"],
                               $ctcb["telefone_comercial"],
                               preg_replace('/[^0-9]/', '',$ctcb["celular"]),
                               $ctcb["email"],
                               $ctcb["cr"],
                               $dataCR);
             fputcsv($abrir,$camposBD,$delimitador);
          }
        }
        fseek($abrir,0);
        header('Content-Type: application/x-msexcel');
        header('Content-Disposition: attachment; filename="'.$arquivo.'";');
        fpassthru($abrir);
        exit();
      }

      if($tipo == 'email-dupli  cado')
      {
        $arquivo = 'relatorio_email_duplicado.xls';
        $delimitador = ',';
        $abrir = fopen('php://memory','w');
        $campos = array('Email',
                        'QTD');
        fputcsv($abrir,$campos,$delimitador);
        $sql = mysqli_query($this->conexao,"SELECT 
                                              email, 
                                              COUNT(*) AS Qtd 
                                            FROM 
                                              atirador
                                            WHERE email <> ''  
                                            GROUP BY 
                                              email
                                            HAVING (COUNT(*) > 1);");
        if(mysqli_num_rows($sql) > 0)
        {
          while($ctcb = mysqli_fetch_assoc($sql))
          {
              $camposBD = array($ctcb["email"],$ctcb["Qtd"]);
             fputcsv($abrir,$camposBD,$delimitador);
          }
        }
        fseek($abrir,0);
        header('Content-Type: application/x-msexcel');
        header('Content-Disposition: attachment; filename="'.$arquivo.'";');
        fpassthru($abrir);
        exit();
      }

      if($tipo == 'sem-telefone')
      {
        $arquivo = 'relatorio_sem_telefone.xls';
        $delimitador = ',';
        $abrir = fopen('php://memory','w');
        $campos = array('Nome',
                        'Endereço',
                        'Bairro',
                        'Cidade',
                        'Estado',
                        'CEP',
                        'Telefone Res', 
                        'Telefone Com', 
                        'Celular',
                        'Email',
                        'RG',
                        'CPF',
                        'CR',
                        'Validade CR');
        fputcsv($abrir,$campos,$delimitador);
        $sql = mysqli_query($this->conexao,"SELECT 
                                              nome,
                                              endereco,
                                              bairro,
                                              cidade,
                                              estado,
                                              cep,
                                              telefone_residencia,
                                              telefone_comercial,
                                              celular,
                                              email                                        
                                            FROM 
                                             `atirador`
                                            WHERE 
                                             celular = '';");
        if(mysqli_num_rows($sql) > 0)
        {
          while($ctcb = mysqli_fetch_assoc($sql))
          {
             $sqlEstado = mysqli_query($this->conexao,"SELECT * FROM estado WHERE estado = '".$ctcb['estado']."';");
             $ctcbEstado = mysqli_fetch_assoc($sqlEstado);
             $camposBD = array($ctcb["nome"],
                               $ctcb["endereco"],
                               $ctcb["bairro"],
                               $ctcb["cidade"],
                               $ctcbEstado["sigla"],
                               $ctcb["cep"],
                               $ctcb["telefone_residencia"],
                               $ctcb["telefone_comercial"],
                               preg_replace('/[^0-9]/', '',$ctcb["celular"]),
                               $ctcb["email"]);
             fputcsv($abrir,$camposBD,$delimitador);
          }
        }
        fseek($abrir,0);
        header('Content-Type: application/x-msexcel');
        header('Content-Disposition: attachment; filename="'.$arquivo.'";');
        fpassthru($abrir);
        exit();
      }

      if($tipo == 'telefone-duplicado')
      {
        $arquivo = 'relatorio_telefone_duplicado.xls';
        $delimitador = ',';
        $abrir = fopen('php://memory','w');
        $campos = array('Email',
                        'QTD');
        fputcsv($abrir,$campos,$delimitador);
        $sql = mysqli_query($this->conexao,"SELECT 
                                              celular, 
                                              COUNT(*) AS Qtd 
                                            FROM 
                                              atirador
                                            WHERE celular <> ''  
                                            GROUP BY 
                                              celular
                                            HAVING (COUNT(*) > 1);");
        if(mysqli_num_rows($sql) > 0)
        {
          while($ctcb = mysqli_fetch_assoc($sql))
          {
              $camposBD = array($ctcb["celular"],$ctcb["Qtd"]);
             fputcsv($abrir,$camposBD,$delimitador);
          }
        }
        fseek($abrir,0);
        header('Content-Type: application/x-msexcel');
        header('Content-Disposition: attachment; filename="'.$arquivo.'";');
        fpassthru($abrir);
        exit();
      }
    }
   
    /**
     * Método mostra o mês por extenso
     * @access public
     * @param string $mes
     * @return string $mes
     */
    public function mesExtenso($mes){
      switch ($mes) {
         case '01': $mes = "janeiro"; break;
         case '02': $mes = "fevereiro"; break;
         case '03': $mes = "março"; break;
         case '04': $mes = "abril"; break;
         case '05': $mes = "maio"; break;
         case '06': $mes = "junho"; break;
         case '07': $mes = "julho"; break;
         case '08': $mes = "agosto"; break;
         case '09': $mes = "setembro"; break;
         case '10': $mes = "outubro"; break;
         case '11': $mes = "novembro"; break;
         case '12': $mes = "dezembro"; break;
      }
      return $mes;
    }

    /**
     * Método lista a lista dos atiradores com pendências no pagamento
     * Encontra-se na página index.php
     * @access public
     * @param string $pagina,$busca
     * @param int $qnt_result_pg
     * @return $visualizar
     */
    public function listarPendentes($pagina,$qnt_result_pg,$busca)
    {
      $inicio = ($pagina * $qnt_result_pg) - $qnt_result_pg;
      if($busca == "")
      {
       $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM atirador_pagamento WHERE valor_pago = '0.00' AND data_vencimento < CURDATE() ORDER BY data_vencimento DESC LIMIT $inicio, $qnt_result_pg");
      }
       else
      {
         list($buscar,$tirar) = explode("(",$busca);
         $busca = trim($buscar);
         $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM atirador_pagamento PAGTO INNER JOIN atirador ATIRADOR ON PAGTO.atirador = ATIRADOR.atirador WHERE ATIRADOR.codigo = '".$busca."' OR ATIRADOR.nome ='".$busca."' OR ATIRADOR.cpf = '".$busca."' ORDER BY PAGTO.data_vencimento DESC;");
         $botao = "<div class='col-md-12'><div class='text-right'><a href=\"".$this->caminhoAbsoluto()."/\" class='btn btn-primary btn-sm'><i class=\"fas fa-angle-double-left\"></i> Voltar</a></div></div>";
      }
      $sqlContar = mysqli_query($this->conexao,"SELECT * FROM atirador_pagamento WHERE valor_pago = '0.00' AND data_vencimento < CURDATE()");
      $result_pg = "SELECT COUNT(atirador_pagamento) AS num FROM atirador_pagamento WHERE valor_pago = '0.00' AND data_vencimento < CURDATE();";
      $resultado_pg = mysqli_query($this->conexao, $result_pg);
      $row_pg = mysqli_fetch_assoc($resultado_pg);
      $quantidade_pg = ceil($row_pg['num'] / $qnt_result_pg);
      $max_links = 2;
      $paginacao = "<a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario(1, $qnt_result_pg)'>Primeira</a> ";
      for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++)
      {
      	if($pag_ant >= 1)
        {
      	  $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_ant, $qnt_result_pg)'>$pag_ant </a> ";
      	}
      }
      $paginacao .= "<a href='#' class='btn btn-dark btn-sm'> $pagina </a>";
      for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++)
      {
    	   if($pag_dep <= $quantidade_pg)
         {
    		    $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_dep, $qnt_result_pg)'>$pag_dep</a> ";
         }
      }
      $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($quantidade_pg, $qnt_result_pg)'>Última</a>";
      $visualizar = '<div class="row">';
      $visualizar .= "<div class=\"col-md-4 text-left\">Pagamentos pendentes: <strong> ".mysqli_num_rows($sqlContar)."</strong></div>";
      $visualizar .= "<div class=\"col-md-8 text-right\" style='margin-top: 0px'>".$paginacao."</div>";
      $visualizar .= '</div>';
      $visualizar .= '<table class="table table-sm table-bordered table-striped" style="margin-top: 10px; background: #FFF">
                        <thead>
                          <tr>
                           <th><small>Filtro por resultado:'.$qnt_result_pg.'</small></th>
                            <th colspan="5" style="text-align: right"><small> A - Alterar, B - Boleto</small></th>
                           </tr>
                          <tr>
                            <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Associado</th>
                            <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Vencimento</th>
                            <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">A</th>
                            <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">B</th>
                          </tr>
                        </thead>
                        <tbody>';
      if(mysqli_num_rows($sqlVisualizar) == 0)
      {
        $visualizar .= '<tr><td colspan="6" style="color: green; text-align: center; font-weight: bold">Não existem pagamentos pendentes :)</td></tr>';
      }
       else
      {
        while($ctcbVisualizar = mysqli_fetch_object($sqlVisualizar))
        {
          $sqlAtirador = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE atirador = '".$ctcbVisualizar->atirador."';");
          $ctcbAtirador = mysqli_fetch_object($sqlAtirador);
          $sqlNomeDuplicado = mysqli_query($this->conexao,"SELECT * FROM atirador_pagamento PAGTO INNER JOIN atirador ATIRADOR ON PAGTO.id_atirador = ATIRADOR.atirador WHERE ATIRADOR.nome ='".$ctcbAtirador->nome."';");
          $nomeDuplicado = (mysqli_num_rows($sqlNomeDuplicado) > 1)?'#FFEE78':'#FFEE78';
          $sqlCPFDuplicado = mysqli_query($this->conexao,"SELECT * FROM atirador_pagamento PAGTO INNER JOIN atirador ATIRADOR ON PAGTO.id_atirador = ATIRADOR.atirador WHERE ATIRADOR.nome ='".$ctcbAtirador->nome."';");
          $cpfDuplicado = (mysqli_num_rows($sqlCPFDuplicado) > 1)?'#FE0000':'#FFEE78';
          list($anoV,$mesV,$diaV) = explode("-",$ctcbVisualizar->data_vencimento);
          $dataVencimento = $diaV."/".$mesV."/".$anoV;
          if($ctcbVisualizar->valor_pago == '0.00')
          {
            $corData = 'red';
            $check = "";
          }
           else
          {
            $corData = 'green';
            $check = '<i class="fas fa-check"></i>';
          }
          $visualizar .= '<tr>';
          $visualizar .= '<td style="text-transform: uppercase; font-size: 14px"><i class="fas fa-caret-right"></i><a href="'.$this->caminhoAbsoluto().'/detalhes-pagamento-atirador/?'.$ctcbAtirador->id_cod_atirador.'" title="Detalhes pagamento do atirador '.$ctcbAtirador->nome.'"> '.$ctcbAtirador->nome.'</a></td>';
          $visualizar .= '<td style="text-transform: uppercase; font-size: 14px; color: '.$corData.'; text-align: center">'.$dataVencimento.' '.$check.'</td>';
         // $visualizar .= '<td style="text-transform: uppercase; font-size: 14px; cursor: pointer; background: '.$cpfDuplicado.'" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/ver-cadastros-duplicados/\'""></td>';
        //  $visualizar .= '<td style="text-transform: uppercase; font-size: 14px; cursor: pointer; background: '.$nomeDuplicado.'" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/ver-nomes-parecidos/\'""></td>';
          if($_SESSION["Editar"] == '1')
          {
             $visualizar .= '<td style="text-transform: uppercase; font-size: 14px; text-align: center"><a href="'.$this->caminhoAbsoluto().'/detalhes-atirador/?'.$ctcbAtirador->id_cod_atirador.'" style="color: #000" title="Editar"><i class="fas fa-edit"></i></a></td>';
          }
           else
          {
              $visualizar .= '<td style="text-transform: uppercase; font-size: 14px; text-align: center">&nbsp;</td>';
          }
          $visualizar .= '<td style="text-transform: uppercase; font-size: 14px"></td>';
          $visualizar .= '</tr>';
       }
      $visualizar .= "</tbody>";
      $visualizar .= "</table>";
      $visualizar .= $botao;
      }
    return $visualizar;
    }

    /**
     * Método lista a lista dos atiradores com pendências no pagamento
     * Encontra-se na página index.php
     * @access public
     * @param string $pagina,$busca
     * @param int $qnt_result_pg
     * @return $visualizar
     */
    public function listarPendentesLateral($pagina,$qnt_result_pg,$busca)
    {
      $inicio = ($pagina * $qnt_result_pg) - $qnt_result_pg;
      if($busca == "")
      {
       $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM atirador_pagamento WHERE valor_pago = '0.00' AND data_vencimento < CURDATE() ORDER BY data_vencimento DESC LIMIT $inicio, $qnt_result_pg");
      }
       else
      {
         list($buscar,$tirar) = explode("(",$busca);
         $busca = trim($buscar);
         $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM atirador_pagamento PAGTO INNER JOIN atirador ATIRADOR ON PAGTO.id_atirador = ATIRADOR.atirador WHERE ATIRADOR.nome ='".$busca."' ORDER BY PAGTO.data_vencimento DESC;");
         $botao = "<div class='col-md-12'><div class='text-right'><a href=\"".$this->caminhoAbsoluto()."/\" class='btn btn-primary btn-sm'><i class=\"fas fa-angle-double-left\"></i> Voltar</a></div></div>";
      }
      $sqlContar = mysqli_query($this->conexao,"SELECT * FROM atirador_pagamento WHERE valor_pago = '0.00' AND data_vencimento < CURDATE()");
      $result_pg = "SELECT COUNT(atirador_pagamento) AS num FROM atirador_pagamento WHERE valor_pago = '0.00' AND data_vencimento < CURDATE();";
      $resultado_pg = mysqli_query($this->conexao, $result_pg);
      $row_pg = mysqli_fetch_assoc($resultado_pg);
      $quantidade_pg = ceil($row_pg['num'] / $qnt_result_pg);
      $max_links = 2;
      $paginacao = "<a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario(1, $qnt_result_pg)'>Primeira</a> ";
      for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++)
      {
      	if($pag_ant >= 1)
        {
      	  $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_ant, $qnt_result_pg)'>$pag_ant </a> ";
      	}
      }
      $paginacao .= "<a href='#' class='btn btn-dark btn-sm'> $pagina </a>";
      for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++)
      {
    	   if($pag_dep <= $quantidade_pg)
         {
    		    $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_dep, $qnt_result_pg)'>$pag_dep</a> ";
         }
      }
      $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($quantidade_pg, $qnt_result_pg)'>Última</a>";
      $visualizar = '<div class="row">';
      $visualizar .= "<div class=\"col-md-4 text-left\">Pagamentos pendentes: <strong> ".mysqli_num_rows($sqlContar)."</strong></div>";
      $visualizar .= "<div class=\"col-md-8 text-right\" style='margin-top: 0px'>".$paginacao."</div>";
      $visualizar .= '</div>';
      $visualizar .= '<table class="table table-sm table-bordered table-striped" style="margin-top: 10px; background: #FFF">
                        <thead>
                          <tr>
                           <th><small>Filtro por resultado:'.$qnt_result_pg.'</small></th>
                            <th colspan="5" style="text-align: right"><small>C - CPF duplicado, N - Nome duplicado, A - Alterar, B - Boleto</small></th>
                           </tr>
                          <tr>
                            <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Associado</th>
                            <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Vencimento</th>
                            <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">C</th>
                            <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">N</th>
                            <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">A</th>
                            <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">B</th>
                          </tr>
                        </thead>
                        <tbody>';
      if(mysqli_num_rows($sqlVisualizar) == 0)
      {
        $visualizar .= '<tr><td colspan="6" style="color: green; text-align: center; font-weight: bold">Não existem pagamentos pendentes :)</td></tr>';
      }
       else
      {
        while($ctcbVisualizar = mysqli_fetch_object($sqlVisualizar))
        {
          $sqlAtirador = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE atirador = '".$ctcbVisualizar->atirador."';");
          $ctcbAtirador = mysqli_fetch_object($sqlAtirador);
          $sqlNomeDuplicado = mysqli_query($this->conexao,"SELECT * FROM atirador_pagamento PAGTO INNER JOIN atirador ATIRADOR ON PAGTO.id_atirador = ATIRADOR.atirador WHERE ATIRADOR.nome ='".$ctcbAtirador->nome."';");
          $nomeDuplicado = (mysqli_num_rows($sqlNomeDuplicado) > 1)?'#FFEE78':'#FFEE78';
          $sqlCPFDuplicado = mysqli_query($this->conexao,"SELECT * FROM atirador_pagamento PAGTO INNER JOIN atirador ATIRADOR ON PAGTO.id_atirador = ATIRADOR.atirador WHERE ATIRADOR.nome ='".$ctcbAtirador->nome."';");
          $cpfDuplicado = (mysqli_num_rows($sqlCPFDuplicado) > 1)?'#FE0000':'#FFEE78';
          list($anoV,$mesV,$diaV) = explode("-",$ctcbVisualizar->data_vencimento);
          $dataVencimento = $diaV."/".$mesV."/".$anoV;
          if($ctcbVisualizar->valor_pago == '0.00')
          {
            $corData = 'red';
            $check = "";
          }
           else
          {
            $corData = 'green';
            $check = '<i class="fas fa-check"></i>';
          }
          $visualizar .= '<tr>';
          $visualizar .= '<td style="text-transform: uppercase; font-size: 14px"><i class="fas fa-caret-right"></i><a href="'.$this->caminhoAbsoluto().'/detalhes-pagamento-atirador/?'.$ctcbAtirador->id_cod_atirador.'" title="Detalhes pagamento do atirador '.$ctcbAtirador->nome.'"> '.$ctcbAtirador->nome.'</a></td>';
          $visualizar .= '<td style="text-transform: uppercase; font-size: 14px; color: '.$corData.'; text-align: center">'.$dataVencimento.' '.$check.'</td>';
          $visualizar .= '<td style="text-transform: uppercase; font-size: 14px; cursor: pointer; background: '.$cpfDuplicado.'" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/ver-cadastros-duplicados/\'""></td>';
          $visualizar .= '<td style="text-transform: uppercase; font-size: 14px; cursor: pointer; background: '.$nomeDuplicado.'" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/ver-nomes-parecidos/\'""></td>';
          if($_SESSION["Editar"] == '1')
          {
             $visualizar .= '<td style="text-transform: uppercase; font-size: 14px; text-align: center"><a href="'.$this->caminhoAbsoluto().'/detalhes-atirador/?'.$ctcbAtirador->id_cod_atirador.'" style="color: #000" title="Editar"><i class="fas fa-edit"></i></a></td>';
          }
           else
          {
              $visualizar .= '<td style="text-transform: uppercase; font-size: 14px; text-align: center">&nbsp;</td>';
          }
          $visualizar .= '<td style="text-transform: uppercase; font-size: 14px"></td>';
          $visualizar .= '</tr>';
       }
      $visualizar .= "</tbody>";
      $visualizar .= "</table>";
      $visualizar .= $botao;
      }
    return $visualizar;
    }

  /**
   * Método lista a lista dos atiradores
   * Encontra-se na página index.php
   * @access public
   * @param string $pagina,$busca
   * @param int $qnt_result_pg
   * @return $visualizar
   */
    public function listarAtiradores($pagina,$qnt_result_pg,$busca,$tipoBusca)
    {
      $inicio = ($pagina * $qnt_result_pg) - $qnt_result_pg;
      if($busca == "")
      {
        $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM atirador ORDER BY nome ASC LIMIT $inicio, $qnt_result_pg");
       }
        else
       {
         list($buscar,$tirar) = explode("(",$busca);
         $busca = trim($buscar);
         if($tipoBusca == "Nome")
         {
            $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE nome ='".$busca."' ORDER BY nome DESC;");
         }
         if($tipoBusca == "CPF")
         {
            $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE cpf ='".$busca."' ORDER BY nome DESC;");
         }
         if($tipoBusca == "Matricula")
         {
            $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE codigo ='".$busca."' ORDER BY nome DESC;");
         }
         if($tipoBusca == "Email")
         {
            $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE email ='".$busca."' ORDER BY nome DESC;");
         }
         if($tipoBusca == "Estado")
         {
            $botaoExcel = '<button type="button" class="btn btn-primary btn-sm" class="input-group-text" id="btnBuscar" style="cursor: pointer" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/exportar-csv/?tipo=estado&estado='.$busca.'\';"><i class="fas fa-file-csv fa-lg"></i> Exportar</button>';
            $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE estado ='".$busca."' ORDER BY nome DESC;");
         }
         $botao = "<div class='col-md-12'><div class='text-right'>".$botaoExcel." <a href=\"".$this->caminhoAbsoluto()."/atiradores/\" class='btn btn-primary btn-sm'><i class=\"fas fa-angle-double-left\"></i> Voltar</a></div></div>";
       }
        $sqlContar = mysqli_query($this->conexao,"SELECT * FROM atirador");
        $result_pg = "SELECT COUNT(atirador) AS num FROM atirador";
        $resultado_pg = mysqli_query($this->conexao, $result_pg);
        $row_pg = mysqli_fetch_assoc($resultado_pg);
        $quantidade_pg = ceil($row_pg['num'] / $qnt_result_pg);
        $max_links = 2;
        $paginacao = "<a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario(1, $qnt_result_pg)'>Primeira</a> ";
        for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++)
        {
        	if($pag_ant >= 1)
          {
        		 $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_ant, $qnt_result_pg)'>$pag_ant </a> ";
        	}
        }
        $paginacao .= "<a href='#' class='btn btn-dark btn-sm'> $pagina </a>";
        for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++)
        {
      	   if($pag_dep <= $quantidade_pg)
           {
      		    $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_dep, $qnt_result_pg)'>$pag_dep</a> ";
           }
        }
        $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($quantidade_pg, $qnt_result_pg)'>Última</a>";
        $visualizar = '<div class="row">';
        if($busca == "")
        {
            $visualizar .= "<div class=\"col-md-4 text-left\">Atiradores cadastrados: <strong> ".mysqli_num_rows($sqlContar)."</strong></div>";
        }
         else
        {
          $visualizar .= "<div class=\"col-md-4 text-left\">Atiradores cadastrados: <strong> ".mysqli_num_rows($sqlVisualizar)."</strong></div>";
        }
        if($busca == '')
        {
              $visualizar .= "<div class=\"col-md-8 text-right\">".$paginacao."</div>";
        }
         else
        {
              $visualizar .= "<div class='col-md-12'><div class='text-right'>".$botaoExcel." <a href=\"".$this->caminhoAbsoluto()."/atiradores/\" class='btn btn-primary btn-sm'><i class=\"fas fa-angle-double-left\"></i> Voltar</a></div></div>";
        }
        $visualizar .= '</div>';
        $visualizar .= '<table class="table table-sm table-bordered table-striped" style="margin-top: 10px; background: #FFF">
                          <thead>
                            <tr>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Código</th>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Nome</th>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Estado</th>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Telefones</th>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Ação</th>
                            </tr>
                          </thead>
                          <tbody>';
        if(mysqli_num_rows($sqlVisualizar) == 0)
        {
          $visualizar .= '<tr><td colspan="6" style="color: red; text-align: center; font-weight: bold">Não existem atiradores cadastrados</td></tr>';
        }
         else
        {
          while($ctcbVisualizar = mysqli_fetch_object($sqlVisualizar))
          {
            $visualizar .= '<tr>';
            $visualizar .= '<td style="font-size: 14px; text-align: center">'.$ctcbVisualizar->codigo.'</td>';
            $visualizar .= '<td style="text-transform: uppercase; font-size: 14px;">'.$ctcbVisualizar->nome.'</td>';
            $sqlEstado = mysqli_query($this->conexao,"SELECT * FROM estado WHERE estado = '".$ctcbVisualizar->estado."';");
            $ctcbEstado = mysqli_fetch_object($sqlEstado);
            $visualizar .= '<td style="text-transform: uppercase; font-size: 14px; text-align: center">'.$ctcbEstado->sigla.'</td>';
            $visualizar .= '<td style="font-size: 14px;">'.$ctcbVisualizar->telefone_residencia.'<br>'.$ctcbVisualizar->celular.'</td>';
            $visualizar .= '<td style="text-align: center">';
            if($_SESSION["Editar"] == '1')
            {
            $visualizar .= '<a href="'.$this->caminhoAbsoluto().'/detalhes-atirador/?'.$ctcbVisualizar->id_cod_atirador.'" style="color: #000" title="Editar"><i class="far fa-edit"></i></a> ';
            }
            if($_SESSION["Excluir"] == '1')
            {
              //$sqlEventoAtirador = mysqli_query($this->conexao,"SELECT * FROM evento_atirador WHERE atirador = '".$ctcbVisualizar->atirador."';");
              //$contarEventoAtirador = mysqli_num_rows($sqlEventoAtirador);
              //$lixeira = ($contarEventoAtirador > 0)?'<a href="#!" style="color: #000" title="Excluir"><i class="far fa-trash-alt"></i></a>':'';
              //$visualizar .= $lixeira;
              $visualizar .= '<a href="#!" style="color: #000" title="Excluir" id="btnVisualizarCasas" data-id="'.$ctcbVisualizar->id_cod_atirador.'" data-toggle="modal-3"><i class="far fa-trash-alt"></i></a>';
            }
            $visualizar .= '</td>';
            $visualizar .= '</tr>';
          }
        $visualizar .= "</tbody>";
        $visualizar .= "</table>";
        $visualizar .= $botao;
      }
      $visualizar .= " <div class=\"modal fade\" id=\"casasRegionais\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"\" aria-hidden=\"true\">
                                 <div class=\"modal-dialog\">
                                     <div>
                                         <div id=\"tela\">
                                         </div>
                                     </div>
                                 </div>
                             </div>";
              $visualizar .= "<script>
                    $(\"table\").on('click',\"#btnVisualizarCasas\", function(){
                        var posts = $(this).attr('data-id');
                        $.post('".$this->caminhoAbsoluto()."/excluir-atirador/', {key: posts}, function(retorno){
                         // console.log(retorno);
                               $(\"#casasRegionais\").modal({ backdrop: 'static' });
                               $(\"#tela\").html(retorno);
                        });
                    });
                    </script>";
    return $visualizar;
  }

  /**
   * Método exclui o atirador
   * @access public
   * @param int $idAtirador
   * @return true
   */
  public function excluirAtirador($idAtirador)
  {
    $idAtirador = mysqli_real_escape_string($this->conexao,$idAtirador);
    mysqli_query($this->conexao,"DELETE FROM atirador WHERE id_cod_atirador = '".$idAtirador."';");
    if(mysqli_affected_rows($this->conexao) > 0)
    {
      $_SESSION["SucessoExcluir"] = time() + 5;
      return "<script>window.location.href='".$this->caminhoAbsoluto()."/atiradores/'</script>";
    }
  }

   /**
   * Método envia a senha para o e-mail do atirador
   * @access public
   * @param int $idAtirador
   * @return true
   */
  public function enviarSenhaAtiradores($idAtirador)
  {
    $idAtirador = mysqli_real_escape_string($this->conexao,$idAtirador);
    $sql = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE id_cod_atirador = '".$idAtirador."';");
    $ctcb = mysqli_fetch_object($sql);
    if(mysqli_num_rows($sql) > 0)
    {
      $novaSenha = $this->generatePassword();
      $codificarSenha = $this->codificar($novaSenha);
      mysqli_query($this->conexao,"UPDATE atirador SET senha = '".$codificarSenha."' WHERE atirador = '".$ctcb->atirador."';");
      require 'phpmailer/PHPMailerAutoload.php';
      require 'phpmailer/class.phpmailer.php';
      $mailer = new PHPMailer;
      $mailer->isSMTP();
      $mailer->SMTPOptions = array(
          'ssl' => array(
              'verify_peer' => false,
              'verify_peer_name' => false,
              'allow_self_signed' => true
          )
      );
      $assunto = "Nova Senha - Confederação de Tiro e Caça do Brasil";
      $mailer->Host = 'mail.ctcb.org.br';
      $mailer->SMTPAuth = true;
      $mailer->IsSMTP();
      $mailer->isHTML(true);
      $mailer->Port = 587;
      $mailer->CharSet = 'UTF-8';
      $mailer->Username = 'naoexclua@ctcb.org.br';
      $mailer->Password = 'confeder@c@o';
      $address = $ctcb->email;
      $mensagem = '<table width="100%" border="0">';
      $mensagem .= '<tr>';
      $mensagem .= '<td style="text-align: left"><img src="https://www.ctcb.org.br/images/logo.png" alt="Logomarca da CTCB em letras azuis e partes da arma em verde" title="" class="logo img-fluid" style="width: 150px"></td>';
      $mensagem .= '<td style="text-align: right"><small>https://www.ctcb.org.br<br>atendimento@ctcb.org.br</small></td>';
      $mensagem .= '</tr>';
      $mensagem .=  '</table>';
      $mensagem .= '<br>';
      $mensagem .= '<p>Olá <strong>'.$ctcb->nome.'</strong>.<br>
                    Segue  abaixo seus novos dados para o acesso ao sistema da CTCB:<br><br>
                    https://www.ctcb.org.br<br><br>
                    <strong>E-mail:</strong> '.$ctcb->email.'<br>
                    <strong>Senha:</strong> '.$novaSenha.'<br><br>
                    Em caso de dúvidas utilize o nosso formulário de Contato no site.</p>';
      $mailer->AddAddress($address, "CTCB - Confederação de Tiro e Caça do Brasil");
      $mailer->From = 'atendimento@ctcb.org.br';
      $mailer->FromName = "CTCB - Confederação de Tiro e Caça do Brasil";
      $mailer->Subject = $assunto;
      $mailer->MsgHTML($mensagem);
      $mailer->Send();
      $_SESSION["SucessoEnvio"] = time() + 5;
      return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-atirador/?".$ctcb->id_cod_atirador."'</script>";
    }
  }

   /**
   * Método envia a senha para os email dos despachantes
   * @access public
   * @param int $idDespachante
   * @return string $visualizar
   */
  public function enviarSenhaDespachantes($idDespachante)
  {
      $sqlDespachante = mysqli_query($this->conexao,"SELECT * FROM despachante WHERE despachante = '".$idDespachante."';");
      $ctcbVisualizar = mysqli_fetch_object($sqlDespachante);
      $visualizar = '<div align="center">';
      if($_SESSION["IdAdmin"] != 5)
      {
          $visualizar .= '<button class="btn btn-primary btn-sm" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/enviar-senha-despachantes/?'.$ctcbVisualizar->id_cod_despachante.'\';" title="Enviar nova senha para '.$ctcbVisualizar->nome.'">Enviar <i class="far fa-paper-plane"></i></button><br>';
          $visualizar .= ' ' .$ctcbVisualizar->email;
      }
      $visualizar .= '</div>';
      return $visualizar;
  }

  /**
   * Método envia a senha para o email dos despachante
   * @access public
   * @param int $idDespachante
   * @return true
   */
  public function enviarSenhaDespachante($idDespachante)
  {
      $idDespachante = mysqli_real_escape_string($this->conexao,$idDespachante);
      $sql = mysqli_query($this->conexao,"SELECT * FROM despachante WHERE id_cod_despachante = '".$idDespachante."';");
      $ctcb = mysqli_fetch_object($sql);
      if(mysqli_num_rows($sql) > 0)
      {
          $novaSenha = $this->generatePassword();
          $codificarSenha = $this->codificar($novaSenha);
          mysqli_query($this->conexao,"UPDATE despachante SET senha = '".$codificarSenha."' WHERE despachante = '".$ctcb->despachante."';");
          require 'phpmailer/PHPMailerAutoload.php';
          require 'phpmailer/class.phpmailer.php';
          $mailer = new PHPMailer;
          $mailer->isSMTP();
          $mailer->SMTPOptions = array(
              'ssl' => array(
                  'verify_peer' => false,
                  'verify_peer_name' => false,
                  'allow_self_signed' => true
              )
          );
          $assunto = "Nova Senha - Confederação de Tiro e Caça do Brasil";
          $mailer->Host = 'mail.ctcb.org.br';
          $mailer->SMTPAuth = true;
          $mailer->IsSMTP();
          $mailer->isHTML(true);
          $mailer->Port = 587;
          $mailer->CharSet = 'UTF-8';
          $mailer->Username = 'naoexclua@ctcb.org.br';
          $mailer->Password = 'confeder@c@o';
          $address = $ctcb->email;
          $mensagem = '<table width="100%" border="0">';
          $mensagem .= '<tr>';
          $mensagem .= '<td style="text-align: left"><img src="https://www.ctcb.org.br/images/logo.png" alt="Logomarca da CTCB em letras azuis e partes da arma em verde" title="" class="logo img-fluid" style="width: 150px"></td>';
          $mensagem .= '<td style="text-align: right"><small>https://www.ctcb.org.br<br>atendimento@ctcb.org.br</small></td>';
          $mensagem .= '</tr>';
          $mensagem .=  '</table>';
          $mensagem .= '<br>';
          $mensagem .= '<p>Olá <strong>'.$ctcb->nome.'</strong>.<br>
                    Segue  abaixo seus novos dados para o acesso ao sistema da CTCB:<br><br>
                    https://www.ctcb.org.br<br><br>
                    <strong>E-mail:</strong> '.$ctcb->email.'<br>
                    <strong>Senha:</strong> '.$novaSenha.'<br><br>
                    Em caso de dúvidas utilize o nosso formulário de Contato no site.</p>';
          $mailer->AddAddress($address, "CTCB - Confederação de Tiro e Caça do Brasil");
          $mailer->From = 'atendimento@ctcb.org.br';
          $mailer->FromName = "CTCB - Confederação de Tiro e Caça do Brasil";
          $mailer->Subject = $assunto;
          $mailer->MsgHTML($mensagem);
          $mailer->Send();
          $_SESSION["SucessoEnvio"] = time() + 5;
          return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-atirador/?".$ctcb->id_cod_atirador."'</script>";
      }
  }

  /**
   * Método envia a senha para o email do clube
   * @access public
   * @param int $idDespachante
   * @return true
   */
  public function enviarSenhaClube($idClubes)
  {
      $idClubes = mysqli_real_escape_string($this->conexao,$idClubes);
      $sql = mysqli_query($this->conexao,"SELECT * FROM clube WHERE id_cod_clube = '".$idClubes."';");
      $ctcb = mysqli_fetch_object($sql);
      if(mysqli_num_rows($sql) > 0)
      {
          $novaSenha = $this->generatePassword();
          $codificarSenha = $this->codificar($novaSenha);
          mysqli_query($this->conexao,"UPDATE clube SET senha = '".$codificarSenha."' WHERE clube = '".$ctcb->clube."';");
          require 'phpmailer/PHPMailerAutoload.php';
          require 'phpmailer/class.phpmailer.php';
          $mailer = new PHPMailer;
          $mailer->isSMTP();
          $mailer->SMTPOptions = array(
              'ssl' => array(
                  'verify_peer' => false,
                  'verify_peer_name' => false,
                  'allow_self_signed' => true
              )
          );
          $assunto = "Nova Senha - Confederação de Tiro e Caça do Brasil";
          $mailer->Host = 'mail.ctcb.org.br';
          $mailer->SMTPAuth = true;
          $mailer->IsSMTP();
          $mailer->isHTML(true);
          $mailer->Port = 587;
          $mailer->CharSet = 'UTF-8';
          $mailer->Username = 'naoexclua@ctcb.org.br';
          $mailer->Password = 'confeder@c@o';
          $address = $ctcb->email;
          $mensagem = '<table width="100%" border="0">';
          $mensagem .= '<tr>';
          $mensagem .= '<td style="text-align: left"><img src="https://www.ctcb.org.br/images/logo.png" alt="Logomarca da CTCB em letras azuis e partes da arma em verde" title="" class="logo img-fluid" style="width: 150px"></td>';
          $mensagem .= '<td style="text-align: right"><small>https://www.ctcb.org.br<br>atendimento@ctcb.org.br</small></td>';
          $mensagem .= '</tr>';
          $mensagem .=  '</table>';
          $mensagem .= '<br>';
          $mensagem .= '<p>Olá <strong>'.$ctcb->nome.'</strong>.<br>
                    Segue  abaixo seus novos dados para o acesso ao sistema da CTCB:<br><br>
                    intranet.ctcb.org.br<br><br>
                    <strong>E-mail:</strong> '.$ctcb->email.'<br>
                    <strong>Senha:</strong> '.$novaSenha.'<br><br>
                    Em caso de dúvidas utilize o nosso formulário de Contato no site.</p>';
          $mailer->AddAddress($address, "CTCB - Confederação de Tiro e Caça do Brasil");
          $mailer->From = 'atendimento@ctcb.org.br';
          $mailer->FromName = "CTCB - Confederação de Tiro e Caça do Brasil";
          $mailer->Subject = $assunto;
          $mailer->MsgHTML($mensagem);
          $mailer->Send();
          $_SESSION["SucessoEnvio"] = time() + 5;
          return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-clube/?".$ctcb->id_cod_atirador."'</script>";
      }
  }

  /**
   * Método busca o atirador pela busca inteligente
   * Encontra-se na página atiradores.php
   * @access public
   * @param string $atirador
   * @return ArrayObject json_encode($visualizar)
   */
    public function buscarAtiradores($atirador)
    {
       $sql = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE nome LIKE '" . $atirador. "%' ORDER BY nome ASC LIMIT 7");
       while ($ctcb = mysqli_fetch_assoc($sql))
       {
        $visualizar[] = $ctcb['nome'];
       }
     return json_encode($visualizar);
    }

    /**
     * Método busca o atirador pela busca inteligente
     * Encontra-se na página atiradores.php
     * @access public
     * @param string $atirador
     * @return ArrayObject json_encode($visualizar)
     */
      public function buscarAtiradoresCPF($cpf)
      {
         $sql = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE cpf LIKE '" . $cpf. "%' ORDER BY nome ASC LIMIT 7");
         while ($ctcb = mysqli_fetch_assoc($sql))
         {
          $visualizar[] = $ctcb['cpf'];
         }
       return json_encode($visualizar);
      }

     /**
     * Método busca o email do atirador pela busca inteligente
     * Encontra-se na página atiradores.php
     * @access public
     * @param string $atirador
     * @return ArrayObject json_encode($visualizar)
     */
    public function buscarAtiradoresEmail($email)
    {
       $sql = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE email LIKE '" . $email. "%' ORDER BY email ASC LIMIT 7");
       while ($ctcb = mysqli_fetch_assoc($sql))
       {
        $visualizar[] = $ctcb['email'];
       }
     return json_encode($visualizar);
    }

      /**
       * Método busca o atirador pela busca inteligente
       * Encontra-se na página atiradores.php
       * @access public
       * @param string $atirador
       * @return ArrayObject json_encode($visualizar)
       */
        public function buscarAtiradoresMatricula($matricula)
        {
           $sql = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE codigo LIKE '" . $matricula. "%' ORDER BY nome ASC LIMIT 7");
           while ($ctcb = mysqli_fetch_assoc($sql))
           {
            $visualizar[] = $ctcb['codigo'];
           }
         return json_encode($visualizar);
        }

    /**
     * Método busca o atirador com pagamento pendente pela busca inteligente
     * Encontra-se na página index.php
     * @access public
     * @param string $atirador
     * @return ArrayObject json_encode($visualizar)
     */
    public function buscarPagamentosPendentes($atirador)
    {
        $sql = mysqli_query($this->conexao,"SELECT *, COUNT(ATIRADOR.nome) AS Contar FROM atirador_pagamento PAGTO INNER JOIN atirador ATIRADOR ON PAGTO.atirador = ATIRADOR.atirador WHERE ATIRADOR.nome LIKE '" . $atirador. "%' AND PAGTO.valor_pago = '0.00' GROUP BY ATIRADOR.nome ORDER BY ATIRADOR.nome ASC LIMIT 7");
        while ($ctcb = mysqli_fetch_assoc($sql))
        {
        $visualizar[] = $ctcb['nome']." (".$ctcb['Contar'].")";
        }
      return json_encode($visualizar);
    }

    /**
     * Método busca o atirador com pagamento pendente pela busca inteligente
     * Encontra-se na página index.php
     * @access public
     * @param string $atirador
     * @return ArrayObject json_encode($visualizar)
     */
      public function buscarCPFPendentes($cpf)
      {
          $sql = mysqli_query($this->conexao,"SELECT *, COUNT(ATIRADOR.nome) AS Contar FROM atirador_pagamento PAGTO INNER JOIN atirador ATIRADOR ON PAGTO.atirador = ATIRADOR.atirador WHERE ATIRADOR.cpf LIKE '" . $cpf. "%' AND PAGTO.valor_pago = '0.00' GROUP BY ATIRADOR.nome ORDER BY ATIRADOR.nome ASC LIMIT 7");
          while ($ctcb = mysqli_fetch_assoc($sql))
          {
          //$visualizar[] = $ctcb['cpf']." (".$ctcb['Contar'].")";
          $visualizar[] = $ctcb['cpf'];
          }
        return json_encode($visualizar);
      }

  /**
   * Método busca o atirador com pagamento pendente pela busca inteligente
   * Encontra-se na página index.php
   * @access public
   * @param string $atirador
   * @return ArrayObject json_encode($visualizar)
   */
    public function buscarMatriculaPendentes($matricula)
    {
        $sql = mysqli_query($this->conexao,"SELECT *, COUNT(ATIRADOR.nome) AS Contar FROM atirador_pagamento PAGTO INNER JOIN atirador ATIRADOR ON PAGTO.atirador = ATIRADOR.atirador WHERE ATIRADOR.codigo LIKE '" . $matricula. "%' AND PAGTO.valor_pago = '0.00' GROUP BY ATIRADOR.nome ORDER BY ATIRADOR.nome ASC LIMIT 7");
        while ($ctcb = mysqli_fetch_assoc($sql))
        {
        //$visualizar[] = $ctcb['cpf']." (".$ctcb['Contar'].")";
        $visualizar[] = $ctcb['codigo'];
        }
      return json_encode($visualizar);
    }

  /**
   * Método busca o atirador pela busca inteligente
   * Encontra-se na página atirador.php
   * @access public
   * @param string $atirador
   * @return ArrayObject json_encode($visualizar)
   */
    public function buscarAtiradorPagamento($atirador)
    {
       $sql = mysqli_query($this->conexao,"SELECT *, COUNT(ATIRADOR.nome) AS Contar FROM atirador_pagamento PAGTO INNER JOIN atirador ATIRADOR ON PAGTO.id_atirador = ATIRADOR.atirador WHERE ATIRADOR.nome LIKE '" . $atirador. "%' GROUP BY ATIRADOR.nome ORDER BY ATIRADOR.nome ASC LIMIT 7");
       while ($ctcb = mysqli_fetch_assoc($sql))
       {
        $visualizar[] = $ctcb['nome']." (".$ctcb['Contar'].")";
       }
     return json_encode($visualizar);
    }

    /**
     * Método lista a lista dos despachantes
     * Encontra-se na página despachantes.php
     * @access public
     * @param string $pagina
     * @param string $busca
     * @param int $qnt_result_pg
     * @return $visualizar
     */
      public function listarDespachantes($pagina,$qnt_result_pg,$busca)
      {
        $inicio = ($pagina * $qnt_result_pg) - $qnt_result_pg;
        if($busca == "")
        {
          $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM despachante ORDER BY nome ASC LIMIT $inicio, $qnt_result_pg");
         }
          else
         {
           list($buscar,$tirar) = explode("(",$busca);
           $busca = trim($buscar);
           $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM despachante WHERE nome ='".$busca."' ORDER BY nome DESC;");
           $botao = "<div class='col-md-12'><div class='text-right'><a href=\"".$this->caminhoAbsoluto()."/atirador/\" class='btn btn-primary btn-sm'><i class=\"fas fa-angle-double-left\"></i> Voltar</a></div></div>";
         }
          $sqlContar = mysqli_query($this->conexao,"SELECT * FROM despachante");
          $result_pg = "SELECT COUNT(despachante) AS num FROM despachante";
          $resultado_pg = mysqli_query($this->conexao, $result_pg);
          $row_pg = mysqli_fetch_assoc($resultado_pg);
          $quantidade_pg = ceil($row_pg['num'] / $qnt_result_pg);
          $max_links = 2;
          $paginacao = "<a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario(1, $qnt_result_pg)'>Primeira</a> ";
          for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++)
          {
            if($pag_ant >= 1)
            {
               $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_ant, $qnt_result_pg)'>$pag_ant </a> ";
            }
          }
          $paginacao .= "<a href='#' class='btn btn-dark btn-sm'> $pagina </a>";
          for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++)
          {
             if($pag_dep <= $quantidade_pg)
             {
                $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_dep, $qnt_result_pg)'>$pag_dep</a> ";
             }
          }
          $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($quantidade_pg, $qnt_result_pg)'>Última</a>";
          $visualizar = '<div class="row">';
          $visualizar .= "<div class=\"col-md-4 text-left\">Despachantes cadastrados: <strong> ".mysqli_num_rows($sqlContar)."</strong></div>";
          $visualizar .= "<div class=\"col-md-8 text-right\">".$paginacao."</div>";
          $visualizar .= '</div>';
          $visualizar .= '<table class="table table-sm table-bordered table-striped" style="margin-top: 10px; background: #FFF">
                            <thead>
                              <tr>
                                <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Nome</th>
                                <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Email</th>
                                <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Login</th>
                                <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Ação</th>
                              </tr>
                            </thead>
                            <tbody>';
          if(mysqli_num_rows($sqlVisualizar) == 0)
          {
            $visualizar .= '<tr><td colspan="6" style="color: red; text-align: center; font-weight: bold">Não existem atiradores cadastrados</td></tr>';
          }
           else
          {
            while($ctcbVisualizar = mysqli_fetch_object($sqlVisualizar))
            {
              $visualizar .= '<tr>';
              $visualizar .= '<td style="text-transform: uppercase; font-size: 14px;"><i class="fas fa-caret-right"></i> '.$ctcbVisualizar->nome.'</td>';
              $visualizar .= '<td style="font-size: 14px;">'.$ctcbVisualizar->email.'</td>';
              $visualizar .= '<td style="font-size: 14px;">'.$ctcbVisualizar->login.'</td>';
              $visualizar .= '<td style="text-align: center">';
              if($_SESSION["Editar"] == '1')
              {
                $visualizar .= '<a href="'.$this->caminhoAbsoluto().'/detalhes-despachante/?'.$ctcbVisualizar->id_cod_despachante.'" style="color: #000" title="Editar"><i class="far fa-edit"></i></a> ';
              }
              if($_SESSION["Excluir"] == '1')
              {
                 $visualizar .= '<a href="#!" style="color: #000" title="Excluir"><i class="far fa-trash-alt"></i></a>';
              }
              $visualizar .= '</td>';
              $visualizar .= '</tr>';
            }
          $visualizar .= "</tbody>";
          $visualizar .= "</table>";
          $visualizar .= $botao;
        }
      return $visualizar;
    }

    /**
   * Método lista em uma combox a Nacionalidade
   * Encontra-se na página cadastrar-associado.php
   * @access public
   * @param string $buscar
   * @return string $visualizar
   */
    public function listarNacionalidade($buscar)
    {
      $visualizar = "<select name='Nacionalidade' class='form-control'>";
      $visualizar .= "<option>Selecione uma opção</option>";
      $sqlNacionalidade = mysqli_query($this->conexao,"SELECT * FROM nacionalidade;");
      while($listar = mysqli_fetch_object($sqlNacionalidade))
      {
        if($buscar != null)
        {
           if($listar->nacionalidade == $buscar)
           {
              $selected = 'selected';
           }
            else
           {
              $selected = "";
           }
        }
        $visualizar .= "<option value='".$listar->nome."' ".$selected.">".$listar->nome."</option>";
      }
      $visualizar .= "</select>";
      return $visualizar;
    }

    /**
   * Método lista em uma combox na Naturalidade
   * Encontra-se na página cadastrar-associado.php
   * @access public
   * @param string $buscar
   * @return string $visualizar
   */
    public function listarNaturalidade($buscar)
    {
      $visualizar = "<select name='Naturalidade' class='form-control'>";
      $visualizar .= "<option>Selecione uma opção</option>";
      $sqlNaturalidade = mysqli_query($this->conexao,"SELECT * FROM estado;");
      while($listar = mysqli_fetch_object($sqlNaturalidade)){
            if($buscar != null)
            {
               if($listar->estado == $buscar)
               {
                  $selected = 'selected';
               }
                else
               {
                  $selected = "";
               }
            }
        $visualizar .= "<option value='".$listar->sigla."' ".$selected.">".$listar->nome."</option>";
      }
      $visualizar .= "</select>";
      return $visualizar;
    }

    /**
     * Método a naturalidade do atirador
     * @access public
     * @param string $pagina
     * @param int $qnt_result_pg
     * @param string $busca
     * @param int $qnt_result_pg
     * @return $visualizar
     */
      public function listarNaturalidadePaginacao($pagina,$qnt_result_pg,$busca)
      {
        $inicio = ($pagina * $qnt_result_pg) - $qnt_result_pg;
        if($busca == "")
        {
          $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM estado ORDER BY estado ASC LIMIT $inicio, $qnt_result_pg");
        }
         else
        {
         list($buscar,$tirar) = explode("(",$busca);
         $busca = trim($buscar);
         $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM estado WHERE nome ='".$busca."' ORDER BY nome DESC;");
         $botao = "<div class='col-md-12'><div class='text-right'><a href=\"".$this->caminhoAbsoluto()."/atirador/\" class='btn btn-primary btn-sm'><i class=\"fas fa-angle-double-left\"></i> Voltar</a></div></div>";
        }
        $result_pg = "SELECT COUNT(estado) AS num FROM estado";
        $resultado_pg = mysqli_query($this->conexao, $result_pg);
        $row_pg = mysqli_fetch_assoc($resultado_pg);
        $quantidade_pg = ceil($row_pg['num'] / $qnt_result_pg);
        $max_links = 2;
        $paginacao = "<a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario(1, $qnt_result_pg)'>Primeira</a> ";
        for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++)
        {
        	if($pag_ant >= 1)
          {
        		 $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_ant, $qnt_result_pg)'>$pag_ant </a> ";
        	}
        }
        $paginacao .= "<a href='#' class='btn btn-dark btn-sm'> $pagina </a>";
        for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++)
        {
      	   if($pag_dep <= $quantidade_pg)
           {
      		    $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_dep, $qnt_result_pg)'>$pag_dep</a> ";
           }
        }
        $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($quantidade_pg, $qnt_result_pg)'>Última</a>";
        $visualizar = '<div class="row">';
        $visualizar .= "<div class=\"col-md-4 text-left\">Atiradores cadastrados: <strong> ".mysqli_num_rows($sqlContar)."</strong></div>";
        $visualizar .= "<div class=\"col-md-8 text-right\">".$paginacao."</div>";
        $visualizar .= '</div>';
        $visualizar .= '<table class="table table-sm table-bordered table-striped" style="margin-top: 10px; background: #FFF">
                          <thead>
                            <tr>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Nome</th>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Sigla</th>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Ação</th>
                            </tr>
                          </thead>
                          <tbody>';
        if(mysqli_num_rows($sqlVisualizar) == 0)
        {
          $visualizar .= '<tr><td colspan="6" style="color: red; text-align: center; font-weight: bold">Não existem atiradores cadastrados</td></tr>';
        }
         else
        {
          while($ctcbVisualizar = mysqli_fetch_object($sqlVisualizar))
          {
            $visualizar .= '<tr>';
            $visualizar .= '<td style="font-size: 14px; text-align: left"><i class="fas fa-caret-right"></i> '.$ctcbVisualizar->nome.'</td>';
            $visualizar .= '<td style="text-transform: uppercase; font-size: 14px;">'.$ctcbVisualizar->sigla.'</td>';
            $visualizar .= '<td style="text-align: center"><a href="#!" style="color: #000" title="Editar"><i class="far fa-edit"></i></a> '.$lixeira.' <a href="#!" style="color: #000" title="Excluir"><i class="far fa-trash-alt"></i></a></td>';
            $visualizar .= '</tr>';
          }
        $visualizar .= "</tbody>";
        $visualizar .= "</table>";
        $visualizar .= $botao;
      }
      return $visualizar;
    }

    /**
     * Método a nacionalidade do atirador
     * @access public
     * @param string $pagina
     * @param int $qnt_result_pg
     * @param string $busca
     * @param int $qnt_result_pg
     * @return $visualizar
     */    
      public function listarNacionalidadePaginacao($pagina,$qnt_result_pg,$busca)
      {
        $inicio = ($pagina * $qnt_result_pg) - $qnt_result_pg;
        if($busca == "")
        {
          $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM nacionalidade ORDER BY nacionalidade ASC LIMIT $inicio, $qnt_result_pg");
        }
         else
        {
           list($buscar,$tirar) = explode("(",$busca);
           $busca = trim($buscar);
           $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM nacionalidade WHERE nome ='".$busca."' ORDER BY nome DESC;");
           $botao = "<div class='col-md-12'><div class='text-right'><a href=\"".$this->caminhoAbsoluto()."/atirador/\" class='btn btn-primary btn-sm'><i class=\"fas fa-angle-double-left\"></i> Voltar</a></div></div>";
        }
        $result_pg = "SELECT COUNT(nacionalidade) AS num FROM nacionalidade";
        $resultado_pg = mysqli_query($this->conexao, $result_pg);
        $row_pg = mysqli_fetch_assoc($resultado_pg);
        $quantidade_pg = ceil($row_pg['num'] / $qnt_result_pg);
        $max_links = 2;
        $paginacao = "<a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario(1, $qnt_result_pg)'>Primeira</a> ";
        for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++)
        {
        	if($pag_ant >= 1)
          {
        		 $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_ant, $qnt_result_pg)'>$pag_ant </a> ";
        	}
        }
        $paginacao .= "<a href='#' class='btn btn-dark btn-sm'> $pagina </a>";
        for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++)
        {
      	   if($pag_dep <= $quantidade_pg)
           {
      		    $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_dep, $qnt_result_pg)'>$pag_dep</a> ";
           }
        }
        $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($quantidade_pg, $qnt_result_pg)'>Última</a>";
        $visualizar = '<div class="row">';
        $visualizar .= "<div class=\"col-md-4 text-left\">Atiradores cadastrados: <strong> ".mysqli_num_rows($sqlContar)."</strong></div>";
        $visualizar .= "<div class=\"col-md-8 text-right\">".$paginacao."</div>";
        $visualizar .= '</div>';
        $visualizar .= '<table class="table table-sm table-bordered table-striped" style="margin-top: 10px; background: #FFF">
                          <thead>
                            <tr>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Nome</th>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Ação</th>
                            </tr>
                          </thead>
                          <tbody>';
        if(mysqli_num_rows($sqlVisualizar) == 0)
        {
          $visualizar .= '<tr><td colspan="6" style="color: red; text-align: center; font-weight: bold">Não existem atiradores cadastrados</td></tr>';
        }
         else
        {
          while($ctcbVisualizar = mysqli_fetch_object($sqlVisualizar))
          {
            $visualizar .= '<tr>';
            $visualizar .= '<td style="font-size: 14px; text-align: left"><i class="fas fa-caret-right"></i> '.$ctcbVisualizar->nome.'</td>';
            $visualizar .= '<td style="text-align: center"><a href="#!" style="color: #000" title="Editar"><i class="far fa-edit"></i></a> '.$lixeira.' <a href="#!" style="color: #000" title="Excluir"><i class="far fa-trash-alt"></i></a></td>';
            $visualizar .= '</tr>';
          }
        $visualizar .= "</tbody>";
        $visualizar .= "</table>";
        $visualizar .= $botao;
      }
      return $visualizar;
    }

    /**
     * Método a naturalidade do atirador com limite
     * @access public
     * @param int $limite
     * @return $visualizar
     */    
    public function listarNacionalidadeLimite($limite)
    {
      $sqlListar = mysqli_query($this->conexao,"SELECT * FROM nacionalidade ORDER BY nome ASC LIMIT ".$limite.";");
      $visualizar = '<table class="table table-striped">';
      while($ctcb = mysqli_fetch_object($sqlListar))
      {
        $visualizar .= '<tr><td style="font-size: 14px; text-transform: uppercase"><i class="fas fa-caret-right"></i> <a href="'.$this->caminhoAbsoluto().'/detalhes-nacionalidade/?'.$ctcb->nacionalidade.'">'.$ctcb->nome.'</a></td></tr>';
      }
      $visualizar .= "</table>";
      return $visualizar;
    }

    /**
   * Método lista os estados
   * Encontra-se na página cadastrar-associado.php
   * @access public
   * @param int $limite
   * @return string $visualizar
   */
    public function listarEstadosLimite($limite)
    {
      $sqlListar = mysqli_query($this->conexao,"SELECT * FROM estado ORDER BY nome ASC LIMIT ".$limite.";");
      $visualizar = '<table class="table table-striped">';
      while($ctcb = mysqli_fetch_object($sqlListar))
      {
        $visualizar .= '<tr><td style="font-size: 14px; text-transform: uppercase"><i class="fas fa-caret-right"></i> <a href="'.$this->caminhoAbsoluto().'/detalhes-estado/?'.$ctcb->sigla.'">'.$ctcb->nome.'</a></td></tr>';
      }
      $visualizar .= "</table>";
      return $visualizar;
    }

    /**
   * Método lista os atiradores
   * Encontra-se na página cadastrar-associado.php
   * @access public
   * @param int $limite
   * @return string $visualizar
   */
    public function listarAtiradoresLimite($limite)
    {
      $sqlListar = mysqli_query($this->conexao,"SELECT * FROM atirador ORDER BY atirador DESC LIMIT ".$limite.";");
      $visualizar = '<table class="table table-striped">';
      while($ctcb = mysqli_fetch_object($sqlListar))
      {
        $visualizar .= '<tr><td style="font-size: 14px; text-transform: uppercase"><i class="fas fa-caret-right"></i> <a href="'.$this->caminhoAbsoluto().'/detalhes-atirador/?'.$ctcb->id_cod_atirador.'">'.$ctcb->nome.'</a></td></tr>';
      }
      $visualizar .= "</table>";
      return $visualizar;
    }

  /**
   * Método lista as categorias
   * @access public
   * @param null
   * @return string $visualizar
   */
    public function listarCategorias()
    {
      $sqlCategorias = mysqli_query($this->conexao,"SELECT * FROM categoria;");
      $visualizar = '<table class="table table-striped">';
      while($ctcb = mysqli_fetch_object($sqlCategorias))
      {
        $visualizar .= '<tr>';
        $visualizar .= '<td style="font-size: 14px; text-transform: uppercase"><i class="fas fa-caret-right"></i> <a href="'.$this->caminhoAbsoluto().'/detalhes-atirador/?'.$ctcb->id_cod_atirador.'">'.$ctcb->nome.'</a></td>';
        $visualizar .= '<td><a href="#!" style="color: #000" title="Editar"><i class="far fa-edit"></i></a></td>';
        $visualizar .= '<td><a href="#!" style="color: #000" title="Excluir"><i class="far fa-trash-alt"></i></a></td>';
        $visualizar .= '</tr>';
      }
      $visualizar .= "</table>";
      return $visualizar;
    }

    /**
   * Método lista os clubes com limite
   * @access public
   * @param int $limite
   * @return string $visualizar
   */
    public function listarClubesLimite($limite)
    {
      $sqlListar = mysqli_query($this->conexao,"SELECT * FROM clube ORDER BY clube DESC LIMIT ".$limite.";");
      $visualizar = '<table class="table table-striped">';
      while($ctcb = mysqli_fetch_object($sqlListar))
      {
        $visualizar .= '<tr><td style="font-size: 14px; text-transform: uppercase"><i class="fas fa-caret-right"></i> <a href="'.$this->caminhoAbsoluto().'/detalhes-clube/?'.$ctcb->id_cod_clube.'">'.$ctcb->nome.'</a></td></tr>';
      }
      $visualizar .= "</table>";
      return $visualizar;
    }

    /**
   * Método mostra o novo código do atirador
   * Encontra-se na página atiradores.php, detalhes-atirador.php
   * @access public
   * @param null
   * @return string $codigo
   */
    public function codigoConfederacao()
    {
      $sql = mysqli_query($this->conexao,"SELECT MAX(atirador) AS id FROM atirador;");
      $ctcb = mysqli_fetch_object($sql);
      $id = $ctcb->id;
      $codigo = sprintf("%05d", ($id + 1));
      return $codigo;
    }

/**
   * Método busca o clube pela busca inteligente
   * Encontra-se na página clubes.php
   * @access public
   * @param string $clube
   * @return ArrayObject json_encode($visualizar)
   */
    public function buscarClubes($clube)
    {
       $sql = mysqli_query($this->conexao,"SELECT * FROM clube WHERE nome LIKE '" . $clube. "%' ORDER BY nome ASC LIMIT 7");
       while ($ctcb = mysqli_fetch_assoc($sql))
       {
        $visualizar[] = $ctcb['nome'];
       }
     return json_encode($visualizar);
    }

    /**
     * Método lista a lista dos clubes
     * Encontra-se na página index.php
     * @access public
     * @param string $pagina,$busca
     * @param int $qnt_result_pg
     * @return string $visualizar
     */
      public function listarClubes($pagina,$qnt_result_pg,$busca)
      {
        $inicio = ($pagina * $qnt_result_pg) - $qnt_result_pg;
        if($busca == "")
        {
          $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM clube ORDER BY nome ASC LIMIT $inicio, $qnt_result_pg");
       }
        else
       {
         list($buscar,$tirar) = explode("(",$busca);
         $busca = trim($buscar);
         $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM clube WHERE nome ='".$busca."' ORDER BY nome DESC;");
         $botao = "<div class='col-md-12'><div class='text-right'><a href=\"".$this->caminhoAbsoluto()."/clubes/\" class='btn btn-primary btn-sm'><i class=\"fas fa-angle-double-left\"></i> Voltar</a></div></div>";
       }
        $result_pg = "SELECT COUNT(clube) AS num FROM clube";
        $resultado_pg = mysqli_query($this->conexao, $result_pg);
        $row_pg = mysqli_fetch_assoc($resultado_pg);
        $quantidade_pg = ceil($row_pg['num'] / $qnt_result_pg);
        $max_links = 2;
        $paginacao = "<a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario(1, $qnt_result_pg)'>Primeira</a> ";
        for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++)
        {
        	if($pag_ant >= 1)
          {
        		 $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_ant, $qnt_result_pg)'>$pag_ant </a> ";
        	}
        }
        $paginacao .= "<a href='#' class='btn btn-dark btn-sm'> $pagina </a>";
        for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++)
        {
      	   if($pag_dep <= $quantidade_pg)
           {
      		    $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_dep, $qnt_result_pg)'>$pag_dep</a> ";
           }
        }
        $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($quantidade_pg, $qnt_result_pg)'>Última</a>";
        $visualizar = '<div class="row">';
        $visualizar .= "<div class=\"col-md-4 text-left\">Clubes cadastrados: <strong> ".mysqli_num_rows($sqlContar)."</strong></div>";
        $visualizar .= "<div class=\"col-md-8 text-right\">".$paginacao."</div>";
        $visualizar .= '</div>';
        $visualizar .= '<table class="table table-sm table-bordered table-striped" style="margin-top: 10px; background: #FFF">
                          <thead>
                            <tr>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Nome</th>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Telefone</th>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Celular</th>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Bloqueio</th>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Ação</th>
                            </tr>
                          </thead>
                          <tbody>';
        if(mysqli_num_rows($sqlVisualizar) == 0)
        {
          $visualizar .= '<tr><td colspan="6" style="color: red; text-align: center; font-weight: bold">Não existem clubes cadastrados</td></tr>';
        }
         else
        {
          while($ctcbVisualizar = mysqli_fetch_object($sqlVisualizar))
          {
            $visualizar .= '<tr>';
            $visualizar .= '<td style="text-transform: uppercase; font-size: 14px;"><i class="fas fa-caret-right"></i> '.$ctcbVisualizar->nome.'</td>';
            $visualizar .= '<td style="font-size: 14px;">'.$ctcbVisualizar->telefone.'</td>';
            $visualizar .= '<td style="font-size: 14px;">'.$ctcbVisualizar->celular.'</td>';
                     $sqlBloqueio = mysqli_query($this->conexao,"SELECT *,DATE_FORMAT(DataBloqueio,'%d/%m/%Y') AS DataDoBloqueio FROM bloqueio_clubes WHERE IdClubes = '".$ctcbVisualizar->clube."';");
                     $ctcbBloqueio = mysqli_fetch_object($sqlBloqueio);
                $botao = (mysqli_num_rows($sqlBloqueio) == 0)?'<button class="btn btn-warning btn-sm" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/clubes/?clube='.$ctcbVisualizar->clube.'&bloquear=s\'">Bloquear</button>':'<button class="btn btn-danger btn-sm"onclick="window.location.href=\''.$this->caminhoAbsoluto().'/clubes/?clube='.$ctcbVisualizar->clube.'&bloquear=n\'">Desbloquear</button><br><small>'.$ctcbBloqueio->DataDoBloqueio.'</small>';
            $visualizar .= '<td style="text-align: center">'.$botao.'</td>';
            $visualizar .= '<td style="text-align: center">';
            if($_SESSION["Editar"] == '1')
            {
              $visualizar .= '<a href="'.$this->caminhoAbsoluto().'/detalhes-clube/?'.$ctcbVisualizar->id_cod_clube.'" style="color: #000" title="Editar"><i class="far fa-edit"></i></a> ';
            }
            if($_SESSION["Excluir"] == '1')
            {
              $sqlEventoClube = mysqli_query($this->conexao,"SELECT * FROM evento_local WHERE clube = '".$ctcbVisualizar->clube."';");
              $contarEventoClube = mysqli_num_rows($sqlEventoClube);
              $lixeira = ($contarEventoClube > 0)?'<a href="#!" style="color: #000" title="Excluir"><i class="far fa-trash-alt"></i></a>':'';
              $visualizar .= $lixeira;
            }
            $visualizar .= '</td>';
            $visualizar .= '</tr>';
          }
        $visualizar .= "</tbody>";
        $visualizar .= "</table>";
        $visualizar .= $botao;
      }
      return $visualizar;
    }

    /**
     * Método lista a lista dos atiradores
     * Encontra-se na página index.php
     * @access public
     * @param string $pagina,$busca
     * @param int $qnt_result_pg
     * @return $visualizar
     */
      public function listarModalidadePaginacao($pagina,$qnt_result_pg,$busca)
      {
        $inicio = ($pagina * $qnt_result_pg) - $qnt_result_pg;
        if($busca == "")
        {
          $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM modalidade ORDER BY nome ASC LIMIT $inicio, $qnt_result_pg");
       }
        else
       {
         list($buscar,$tirar) = explode("(",$busca);
         $busca = trim($buscar);
         $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM modalidade WHERE nome ='".$busca."' ORDER BY nome DESC;");
         $botao = "<div class='col-md-12'><div class='text-right'><a href=\"".$this->caminhoAbsoluto()."/atirador/\" class='btn btn-primary btn-sm'><i class=\"fas fa-angle-double-left\"></i> Voltar</a></div></div>";
       }
        $result_pg = "SELECT COUNT(modalidade) AS num FROM modalidade";
        $resultado_pg = mysqli_query($this->conexao, $result_pg);
        $row_pg = mysqli_fetch_assoc($resultado_pg);
        $quantidade_pg = ceil($row_pg['num'] / $qnt_result_pg);
        $max_links = 2;
        $paginacao = "<a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario(1, $qnt_result_pg)'>Primeira</a> ";
        for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++)
        {
        	if($pag_ant >= 1)
          {
        		 $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_ant, $qnt_result_pg)'>$pag_ant </a> ";
        	}
        }
        $paginacao .= "<a href='#' class='btn btn-dark btn-sm'> $pagina </a>";
        for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++)
        {
      	   if($pag_dep <= $quantidade_pg)
           {
      		    $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_dep, $qnt_result_pg)'>$pag_dep</a> ";
           }
        }
        $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($quantidade_pg, $qnt_result_pg)'>Última</a>";
        $visualizar = '<div class="row">';
        $visualizar .= "<div class=\"col-md-4 text-left\">Atiradores cadastrados: <strong> ".mysqli_num_rows($sqlContar)."</strong></div>";
        $visualizar .= "<div class=\"col-md-8 text-right\">".$paginacao."</div>";
        $visualizar .= '</div>';
        $visualizar .= '<table class="table table-sm table-bordered table-striped" style="margin-top: 10px; background: #FFF">
                          <thead>
                            <tr>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Nome</th>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Ação</th>
                            </tr>
                          </thead>
                          <tbody>';
        if(mysqli_num_rows($sqlVisualizar) == 0)
        {
          $visualizar .= '<tr><td colspan="6" style="color: red; text-align: center; font-weight: bold">Não existem atiradores cadastrados</td></tr>';
        }
         else
        {
          while($ctcbVisualizar = mysqli_fetch_object($sqlVisualizar))
          {
            $visualizar .= '<tr>';
            $visualizar .= '<td style="font-size: 14px; text-align: left"><i class="fas fa-caret-right"></i> '.$ctcbVisualizar->nome.'</td>';
            $visualizar .= '<td style="text-align: center">';
            if($_SESSION["Editar"] == '1')
            {
               $visualizar .= '<a href="'.$this->caminhoAbsoluto().'/detalhes-modalidade/?'.$ctcbVisualizar->modalidade.'" style="color: #000" title="Editar"><i class="far fa-edit"></i></a> ';
            }
            if($_SESSION["Excluir"] == '1')
            {
               $visualizar .= ' <a href="#!" style="color: #000" title="Excluir"><i class="far fa-trash-alt"></i></a>';
            }
            $visualizar .= '</td>';
            $visualizar .= '</tr>';
          }
        $visualizar .= "</tbody>";
        $visualizar .= "</table>";
        $visualizar .= $botao;
      }
      return $visualizar;
    }

  /**
   * Método altera modalidade
   * @access public
   * @param array $dados
   * @return true
   */
    public function alterarModalidade(array $dados)
    {
      $modalidade = mysqli_real_escape_string($this->conexao,$dados["Modalidade"]);
      mysqli_query($this->conexao,"UPDATE modalidade SET nome = '".$modalidade."' WHERE modalidade = '".$dados["Key"]."';");
      $_SESSION["Sucesso"] = time() + 5;
      return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-modalidade/?".$dados["Key"]."'</script>";
    }

  /**
   * Método lista os atiradores
   * Encontra-se na página cadastrar-associado.php
   * @access public
   * @param int $limite
   * @return string $visualizar
   */
    public function listarModalidadeLimite($limite)
    {
      $sqlListar = mysqli_query($this->conexao,"SELECT * FROM modalidade ORDER BY nome ASC LIMIT ".$limite.";");
      $visualizar = '<table class="table table-striped">';
      while($ctcb = mysqli_fetch_object($sqlListar))
      {
        $visualizar .= '<tr><td style="font-size: 14px; text-transform: uppercase"><i class="fas fa-caret-right"></i> <a href="'.$this->caminhoAbsoluto().'/detalhes-modalidade/?'.$ctcb->modalidade.'">'.$ctcb->nome.'</a></td></tr>';
      }
      $visualizar .= "</table>";
      return $visualizar;
    }

     /**
   * Método lista as modalidades em um combox
   * @access public
   * @param string $busca
   * @return true
   */
    public function listarModalidadeCombox($busca)
    {
      $visualizar .= '<select name="Modalidades" class="form-control">';
      $visualizar .= '<option value="">Selecione uma modalidade</option>';
      $sqlModalidades = mysqli_query($this->conexao,"SELECT * FROM modalidade ORDER BY modalidade;");
      while($ctcb = mysqli_fetch_object($sqlModalidades))
      {
        $visualizar .= '<option value="'.$ctcb->modalidade.'">'.$ctcb->nome.'</option>';
      }
      $visualizar .= '</select>';
      return $visualizar;
    }

    /**
     * Método lista as provas com paginação
     * @access public
     * @param string $pagina,$busca
     * @param int $qnt_result_pg
     * @return $visualizar
     */
      public function listarProvaPaginacao($pagina,$qnt_result_pg,$busca)
      {
        $inicio = ($pagina * $qnt_result_pg) - $qnt_result_pg;
        if($busca == "")
        {
          $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM prova ORDER BY prova ASC LIMIT $inicio, $qnt_result_pg");
        }
         else
        {
           list($buscar,$tirar) = explode("(",$busca);
           $busca = trim($buscar);
           $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM prova WHERE nome ='".$busca."' ORDER BY prova ASC;");
           $botao = "<div class='col-md-12'><div class='text-right'><a href=\"".$this->caminhoAbsoluto()."/prova/\" class='btn btn-primary btn-sm'><i class=\"fas fa-angle-double-left\"></i> Voltar</a></div></div>";
        }
        $result_pg = "SELECT COUNT(prova) AS num FROM prova";
        $resultado_pg = mysqli_query($this->conexao, $result_pg);
        $row_pg = mysqli_fetch_assoc($resultado_pg);
        $quantidade_pg = ceil($row_pg['num'] / $qnt_result_pg);
        $max_links = 2;
        $paginacao = "<a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario(1, $qnt_result_pg)'>Primeira</a> ";
        for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++)
        {
          if($pag_ant >= 1)
          {
             $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_ant, $qnt_result_pg)'>$pag_ant </a> ";
          }
        }
        $paginacao .= "<a href='#' class='btn btn-dark btn-sm'> $pagina </a>";
        for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++)
        {
           if($pag_dep <= $quantidade_pg)
           {
              $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_dep, $qnt_result_pg)'>$pag_dep</a> ";
           }
        }
        $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($quantidade_pg, $qnt_result_pg)'>Última</a>";
        $visualizar = '<div class="row">';
        $visualizar .= "<div class=\"col-md-4 text-left\">Atiradores cadastrados: <strong> ".mysqli_num_rows($sqlContar)."</strong></div>";
        $visualizar .= "<div class=\"col-md-8 text-right\">".$paginacao."</div>";
        $visualizar .= '</div>';
        $visualizar .= '<table class="table table-sm table-bordered table-striped" style="margin-top: 10px; background: #FFF">
                          <thead>
                            <tr>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">ID</th>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Prova</th>
                              <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Ação</th>
                            </tr>
                          </thead>
                          <tbody>';
        if(mysqli_num_rows($sqlVisualizar) == 0)
        {
          $visualizar .= '<tr><td colspan="6" style="color: red; text-align: center; font-weight: bold">Não existem atiradores cadastrados</td></tr>';
        }
         else
        {
          while($ctcbVisualizar = mysqli_fetch_object($sqlVisualizar))
          {
            $visualizar .= '<tr>';
            $visualizar .= '<td style="font-size: 14px; text-align: center; font-weight: bold">'.$ctcbVisualizar->prova.'</td>';
            $visualizar .= '<td style="font-size: 14px; text-align: left"><i class="fas fa-caret-right"></i> '.$ctcbVisualizar->nome.'</td>';
            $visualizar .= '<td style="text-align: center">';
            if($_SESSION["Editar"] == '1')
            {
               $visualizar .= '<a href="#!" style="color: #000" title="Editar"><i class="far fa-edit"></i></a> ';
            }
            if($_SESSION["Excluir"] == '1')
            {
               $visualizar .= ' <a href="#!" style="color: #000" title="Excluir"><i class="far fa-trash-alt"></i></a>';
            }
            $visualizar .= '</td>';
            $visualizar .= '</tr>';
          }
        $visualizar .= "</tbody>";
        $visualizar .= "</table>";
        $visualizar .= $botao;
      }
      return $visualizar;
    }

    /**
   * Método lista os atiradores
   * Encontra-se na página cadastrar-associado.php
   * @access public
   * @param int $limite
   * @return string $visualizar
   */
    public function listarProvaLimite($limite)
    {
      $sqlListar = mysqli_query($this->conexao,"SELECT * FROM prova ORDER BY prova DESC LIMIT ".$limite.";");
      $visualizar = '<table class="table table-striped">';
      while($ctcb = mysqli_fetch_object($sqlListar))
      {
        $visualizar .= '<tr><td style="font-size: 14px; text-transform: uppercase"><i class="fas fa-caret-right"></i> <a href="'.$this->caminhoAbsoluto().'/detalhes-prova/?'.$ctcb->prova.'">'.$ctcb->nome.'</a></td></tr>';
      }
      $visualizar .= "</table>";
      return $visualizar;
    }

     /**
   * Método cadastra os despachantes
   * @access public
   * @param array $dados
   * @return true
   */
    public function cadastrarDespachantes(array $dados)
    {
      $nome = mysqli_real_escape_string($this->conexao,$dados["Nome"]);
      $email = mysqli_real_escape_string($this->conexao,$dados["Email"]);
      $genero = mysqli_real_escape_string($this->conexao,$dados["Genero"]);
      $foneResidencial = mysqli_real_escape_string($this->conexao,$dados["TelefoneResidencial"]);
      $foneComercial = mysqli_real_escape_string($this->conexao,$dados["TelefoneCorporativo"]);
      $foneCelular = mysqli_real_escape_string($this->conexao,$dados["TelefoneCelular"]);
      $cep = mysqli_real_escape_string($this->conexao,$dados["CEP"]);
      $endereco = mysqli_real_escape_string($this->conexao,$dados["Logradouro"]);
      $bairro = mysqli_real_escape_string($this->conexao,$dados["Bairro"]);
      $cidade = mysqli_real_escape_string($this->conexao,$dados["Cidade"]);
      $estado = mysqli_real_escape_string($this->conexao,$dados["Estado"]);
      $rg = mysqli_real_escape_string($this->conexao,$dados["RG"]);
      $orgaoEmissor = mysqli_real_escape_string($this->conexao,$dados["OrgaoEmissor"]);
      $dataEmissao = mysqli_real_escape_string($this->conexao,$dados["DataEmissao"]);
      $cpf = mysqli_real_escape_string($this->conexao,$dados["CPF"]);
      $login = mysqli_real_escape_string($this->conexao,$dados["Login"]);
      $senha = mysqli_real_escape_string($this->conexao,$dados["Senha"]);
      $observacoes = mysqli_real_escape_string($this->conexao,$dados["Observacoes"]);
      $sqlVerificar = mysqli_query($this->conexao,"SELECT * FROM despachante WHERE login = '".$login."';");
      $ctcb = mysqli_fetch_object($sqlVerificar);
      if(mysqli_num_rows($sqlVerificar) > 0)
      {
        $_SESSION["ErroLogin"] = time() + 5;
        $_SESSION["EmailLogin"] = $ctcb->email;
      }
       else
      {
        $cpf = $this->limpaCPF_CNPJ($cpf);
         mysqli_query($this->conexao,"INSERT INTO despachante VALUES(null, 0,
                                      '".$nome."',
                                      '".$email."',
                                      '".$genero."',
                                      '".$foneResidencial."',
                                      '".$foneComercial."',
                                      '".$foneCelular."',
                                      '".$cep."',
                                      '".$endereco."',
                                      '".$bairro."',
                                      '".$cidade."',
                                      '".$estado."',
                                      '".$rg."',
                                      '".$cpf."',
                                      '".$login."',
                                      '".$this->codificar($senha)."',
                                      'A',
                                      '".$observacoes."',
                                      NOW());");
          if(mysqli_affected_rows($this->conexao) > 0)
          {
            $id = mysqli_insert_id($this->conexao);
            $idCod = $this->codificar($id);
            mysqli_query($this->conexao,"UPDATE despachante SET id_cod_despachante = '".$idCod."' WHERE despachante = '".$id."';");
            $_SESSION["SucessoCadastro"] = time() + 5;
            return "<script>window.location.href='".$this->caminhoAbsoluto()."/novo-despachante/'</script>";
          }
      }
    }

     /**
   * Método altera despachantes
   * @access public
   * @param array $dados
   * @return true
   */
    public function alterarDespachantes(array $dados)
    {
      $nome = mysqli_real_escape_string($this->conexao,$dados["Nome"]);
      $email = mysqli_real_escape_string($this->conexao,$dados["Email"]);
      $genero = mysqli_real_escape_string($this->conexao,$dados["Genero"]);
      $foneResidencial = mysqli_real_escape_string($this->conexao,$dados["TelefoneResidencial"]);
      $foneComercial = mysqli_real_escape_string($this->conexao,$dados["TelefoneCorporativo"]);
      $foneCelular = mysqli_real_escape_string($this->conexao,$dados["TelefoneCelular"]);
      $cep = mysqli_real_escape_string($this->conexao,$dados["CEP"]);
      $endereco = mysqli_real_escape_string($this->conexao,$dados["Logradouro"]);
      $bairro = mysqli_real_escape_string($this->conexao,$dados["Bairro"]);
      $cidade = mysqli_real_escape_string($this->conexao,$dados["Cidade"]);
      $estado = mysqli_real_escape_string($this->conexao,$dados["Estado"]);
      $rg = mysqli_real_escape_string($this->conexao,$dados["RG"]);
      $cpf = mysqli_real_escape_string($this->conexao,$dados["CPF"]);
      $login = mysqli_real_escape_string($this->conexao,$dados["Login"]);
      $senha = mysqli_real_escape_string($this->conexao,$dados["Senha"]);
      $observacoes = mysqli_real_escape_string($this->conexao,$dados["Observacoes"]);
      $sqlVerificar = mysqli_query($this->conexao,"SELECT * FROM despachante WHERE login = '".$login."';");
      $ctcb = mysqli_fetch_object($sqlVerificar);
      $cpf = $this->limpaCPF_CNPJ($cpf);
      mysqli_query($this->conexao,"UPDATE despachante
                                   SET
                                   nome = '".$nome."',
                                   email = '".$email."',
                                   genero = '".$genero."',
                                   fone_residencial = '".$foneResidencial."',
                                   fone_comercial = '".$foneComercial."',
                                   fone_celular = '".$foneCelular."',
                                   cep = '".$cep."',
                                   endereco = '".$endereco."',
                                   bairro = '".$bairro."',
                                   cidade = '".$cidade."',
                                   estado = '".$estado."',
                                   rg = '".$rg."',
                                   cpf = '".$cpf."',
                                   login = '".$login."',
                                   observacoes = '".$observacoes."'
                                   WHERE id_cod_despachante = '".$dados['key']."';");
      $_SESSION["SucessoCadastro"] = time() + 5;
      return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-despachante/?".$dados["key"]."'</script>";
   }

    /**
   * Método lista os despachantes
   * Encontra-se na página novo-despachante.php
   * @access public
   * @param int $limite
   * @return string $visualizar
   */
    public function listarDespachantesLimite($limite)
    {
      $sqlListar = mysqli_query($this->conexao,"SELECT * FROM despachante ORDER BY despachante DESC LIMIT ".$limite.";");
      $visualizar = '<table class="table table-striped">';
      while($ctcb = mysqli_fetch_object($sqlListar))
      {
        $visualizar .= '<tr><td style="font-size: 14px; text-transform: uppercase"><i class="fas fa-caret-right"></i> <a href="'.$this->caminhoAbsoluto().'/detalhes-despachante/?'.$ctcb->id_cod_despachante.'">'.$ctcb->nome.'</a></td></tr>';
      }
      $visualizar .= "</table>";
      return $visualizar;
    }

     /**
   * Método lista os dados do pagamento do atirador
   * @access public
   * @param int $idAtirador
   * @return string $visualizar
   */
    public function listarDadosPagamento($idAtirador)
    {
      $sql = mysqli_query($this->conexao,"SELECT * FROM atirador_pagamento WHERE atirador = '".$idAtirador."' AND valor_pago = '0.00';");
      $visualizar = '';
      while($ctcb = mysqli_fetch_object($sql))
      {
        list($anoV,$mesV,$diaV) = explode("-",$ctcb->data_vencimento);
        $dataVencimento = $diaV.'/'.$mesV.'/'.$anoV;
        list($anoP,$mesP,$diaP) = explode("-",$ctcb->data_pagamento);
        $dataPagamento = $diaP.'/'.$mesP.'/'.$anoP;
        $visualizar .= '<td style="text-align: center">'.$ctcb->anuidade.'</td>';
        $visualizar .= '<td style="text-align: center">R$ '.number_format($ctcb->valor_cobrado,2,',','.').'</td>';
        $visualizar .= '<td style="text-align: center">'.$dataVencimento.'</td>';
        $visualizar .= '<td style="text-align: center">'.$dataPagamento.'</td>';
        $visualizar .= '<td style="text-align: center">';
        if($_SESSION["Editar"] == '1')
        {
           $visualizar .= '<a href="'.$this->caminhoAbsoluto().'/alterar-pagamento-atirador?'.$ctcb->atirador_pagamento.'" style="color: #000"><i class="far fa-edit fa-lg"></i></a>';
        }
        if($_SESSION["Excluir"] == '1')
        {
          $visualizar .= ' <i class="far fa-trash-alt fa-lg"></i>';
        }
        $visualizar .= '</td>';
      }
      return $visualizar;
    }

     /**
   * Método altera o pagamento do atirador
   * @access public
   * @param array $dados
   * @return true
   */
    public function alterarPagamentoAtirador(array $dados)
    {
      $atiradorPagamento = mysqli_real_escape_string($this->conexao,$dados["AtiradorPagamento"]);
      $anuidade = mysqli_real_escape_string($this->conexao,$dados["Anuidade"]);
      $validade = mysqli_real_escape_string($this->conexao,$dados["Validade"]);
      $dataVencimento = mysqli_real_escape_string($this->conexao,$dados["DataVencimento"]);
      $validade = mysqli_real_escape_string($this->conexao,$dados["Validade"]);
      $valorCobranca = mysqli_real_escape_string($this->conexao,$dados["ValorCobranca"]);
      $dataPagamento = mysqli_real_escape_string($this->conexao,$dados["DataPagamento"]);
      $valorPagamento = mysqli_real_escape_string($this->conexao,$dados["ValorPagamento"]);
      // Data de Vencimento
      list($diaV,$mesV,$anoV) = explode("/",$dataVencimento);
      $dataVencimento = $anoV."-".$mesV."-".$diaV;
      // Data de Pagamento
      list($diaP,$mesP,$anoP) = explode("/",$dataPagamento);
      $dataPagamento = $anoP."-".$mesP."-".$diaP;
      // Valor de cobrança
      list($RS,$valorCobranca) = explode("R$",$valorCobranca);
      $semPontoC = str_replace(".","",$valorCobranca);
      $valorCobranca = str_replace(",",".",$semPontoC);
      // Valor de pagamento
      list($RS,$valorPagamento) = explode("R$",$valorPagamento);
      $semPontoP = str_replace(".","",$valorPagamento);
      $valorPagamento = str_replace(",",".",$semPontoP);
      mysqli_query($this->conexao,"UPDATE atirador_pagamento
                    SET
                    data_pagamento = '".$dataPagamento."',
                    valor_pago = '".$valorPagamento."',
                    data_vencimento = '".$dataVencimento."',
                    valor_cobrado = '".$valorCobranca."',
                    anuidade = '".$anuidade."',
                    validade = '".$validade."'
                    WHERE  atirador_pagamento = '".$atiradorPagamento."';");
      $_SESSION["Sucesso"] = time() + 5;
      return "<script>window.location.href='".$this->caminhoAbsoluto()."/alterar-pagamento-atirador/?".$atiradorPagamento."'</script>";
    }

     /**
   * Método lança o pagamento do atirador
   * @access public
   * @param array $dados
   * @return true
   */
    public function lancarPagamentoAtirador(array $dados)
    {
      $atiradorPagamento = $_SESSION["IdAtiradorPagamento"];
      $anuidade = mysqli_real_escape_string($this->conexao,$dados["Anuidade"]);
      $validade = mysqli_real_escape_string($this->conexao,$dados["Validade"]);
      $dataVencimento = mysqli_real_escape_string($this->conexao,$dados["DataVencimento"]);
      $validade = mysqli_real_escape_string($this->conexao,$dados["Validade"]);
      $valorCobranca = mysqli_real_escape_string($this->conexao,$dados["ValorCobranca"]);
      $dataPagamento = mysqli_real_escape_string($this->conexao,$dados["DataPagamento"]);
      $valorPagamento = mysqli_real_escape_string($this->conexao,$dados["ValorPagamento"]);
      // Data de Vencimento
      list($diaV,$mesV,$anoV) = explode("/",$dataVencimento);
      $dataVencimento = $anoV."-".$mesV."-".$diaV;
      // Data de Pagamento
      list($diaP,$mesP,$anoP) = explode("/",$dataPagamento);
      $dataPagamento = $anoP."-".$mesP."-".$diaP;
      // Valor de cobrança
      list($RS,$valorCobranca) = explode("R$",$valorCobranca);
      $semPontoC = str_replace(".","",$valorCobranca);
      $valorCobranca = str_replace(",",".",$semPontoC);
      // Valor de pagamento
      list($RS,$valorPagamento) = explode("R$",$valorPagamento);
      $semPontoP = str_replace(".","",$valorPagamento);
      $valorPagamento = str_replace(",",".",$semPontoP);
      $sqlAtirador = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE atirador = '".$atiradorPagamento."';");
      $ctcbAtirador = mysqli_fetch_object($sqlAtirador);
      mysqli_query($this->conexao,"INSERT INTO atirador_pagamento(atirador,data_pagamento,valor_pago,data_vencimento,valor_cobrado,anuidade)
                                      VALUES ('".$atiradorPagamento."','".$dataPagamento."','".$valorPagamento."','".$dataVencimento."','".$valorCobranca."','".$anuidade."')");
      $_SESSION["SucessoLancamento"] = time() + 5;
      unset($_SESSION["IdAtiradorPagamento"]);
      return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-atirador/?".$ctcbAtirador->id_cod_atirador."'</script>";
    }


    /**
     * Método cadastra os atiradores
     * @access public
     * @param ArrayObject $dados
     * @return true
     */
    public function cadastrarAtiradores(array $dados)
    {
      $cpf = mysqli_real_escape_string($this->conexao,$dados["CPF"]);
      $cpf = $this->limpaCPF_CNPJ($cpf);
      $diaCadastro = mysqli_real_escape_string($this->conexao,$dados["DiaCadastro"]);
      $mesCadastro = mysqli_real_escape_string($this->conexao,$dados["MesCadastro"]);
      $anoCadastro = mysqli_real_escape_string($this->conexao,$dados["AnoCadastro"]);
      $dataCadastro = $anoCadastro."-".$mesCadastro."-".$diaCadastro;
      $despachante = mysqli_real_escape_string($this->conexao,$dados["Despachante"]);
      $anuidade = mysqli_real_escape_string($this->conexao,$dados["TipoAnuidade"]);
      $sqlAnuidade = mysqli_query($this->conexao,"SELECT * FROM anuidade_tipo WHERE nome = '".$anuidade."';");
      $ctcbAnuidade = mysqli_fetch_object($sqlAnuidade);
      $anuidade = $ctcbAnuidade->anuidade_tipo;
      $email = mysqli_real_escape_string($this->conexao,$dados["Email"]);
      $senha = mysqli_real_escape_string($this->conexao,$dados["Senha"]);
      $senha = $this->codificar($senha);
      $nome = mysqli_real_escape_string($this->conexao,$dados["Nome"]);
      $genero = mysqli_real_escape_string($this->conexao,$dados["Genero"]);
      $genero = ($genero == "Masculino")?'M':'F';
      $diaNascimento = mysqli_real_escape_string($this->conexao,$dados["DiaNascimento"]);
      $mesNascimento = mysqli_real_escape_string($this->conexao,$dados["MesNascimento"]);
      $anoNascimento = mysqli_real_escape_string($this->conexao,$dados["AnoNascimento"]);
      $dataNascimento = $anoNascimento."-".$mesNascimento."-".$diaNascimento;
      $telefone = mysqli_real_escape_string($this->conexao,$dados["Telefone"]);
      $celular = mysqli_real_escape_string($this->conexao,$dados["Celular"]);
      $nomeMae = mysqli_real_escape_string($this->conexao,$dados["NomeMae"]);
      $nomePai = mysqli_real_escape_string($this->conexao,$dados["NomePai"]);
      $estadoCivil = mysqli_real_escape_string($this->conexao,$dados["EstadoCivil"]);
      $cep = mysqli_real_escape_string($this->conexao,$dados["CEP"]);
      $logradouro = mysqli_real_escape_string($this->conexao,$dados["Logradouro"]);
      $bairro = mysqli_real_escape_string($this->conexao,$dados["Bairro"]);
      $cidade = mysqli_real_escape_string($this->conexao,$dados["Cidade"]);
      $estado = mysqli_real_escape_string($this->conexao,$dados["Estado"]);
      $sqlEstado = mysqli_query($this->conexao,"SELECT * FROM estado WHERE sigla = '".$estado."';");
      $ctcbEstado = mysqli_fetch_object($sqlEstado);
      $estado = $ctcbEstado->estado;
      $nacionalidade = mysqli_real_escape_string($this->conexao,$dados["Nacionalidade"]);
      $sqlNacionalidade = mysqli_query($this->conexao,"SELECT * FROM nacionalidade WHERE nome = '".$nacionalidade."';");
      $ctcbNacionalidade = mysqli_fetch_object($sqlNacionalidade);
      $nacionalidade = $ctcbNacionalidade->nacionalidade;
      $naturalidade = mysqli_real_escape_string($this->conexao,$dados["Naturalidade"]);
      $sqlNaturalidade = mysqli_query($this->conexao,"SELECT * FROM estado WHERE sigla = '".$naturalidade."';");
      $ctcbNaturalidade = mysqli_fetch_object($sqlNaturalidade);
      $naturalidade = $ctcbNaturalidade->estado;
      $profissao = mysqli_real_escape_string($this->conexao,$dados["Profissao"]);
      $telefoneComercial = mysqli_real_escape_string($this->conexao,$dados["TelefoneComercial"]);
      $atleta = mysqli_real_escape_string($this->conexao,$dados["Atleta"]);
      $atleta = ($atleta == "Sim")?'S':'N';
      $instrutor = mysqli_real_escape_string($this->conexao,$dados["Instrutor"]);
      $instrutor = ($instrutor == "Sim")?'S':'N';
      $arbitro = mysqli_real_escape_string($this->conexao,$dados["Arbitro"]);
      $arbitro = ($arbitro == "Sim")?'S':'N';
      $colecionador = mysqli_real_escape_string($this->conexao,$dados["Colecionador"]);
      $colecionador = ($colecionador == "Sim")?'S':'N';
      $cacador = mysqli_real_escape_string($this->conexao,$dados["Cacador"]);
      $cacador = ($cacador == "Sim")?'S':'N';
      $recarga = mysqli_real_escape_string($this->conexao,$dados["Recarga"]);
      $recarga = ($recarga == "Sim")?'S':'N';
      $dies = mysqli_real_escape_string($this->conexao,$dados["Dies"]);
      $rg = mysqli_real_escape_string($this->conexao,$dados["Identidade"]);
      $orgaoEmissor = mysqli_real_escape_string($this->conexao,$dados["OrgaoEmissor"]);
      list($diaEmissao,$mesEmissao,$anoEmissao) = explode("/",mysqli_real_escape_string($this->conexao,$dados["DataEmissao"]));
      $dataEmissao = $anoEmissao."-".$mesEmissao."-".$diaEmissao;
      $cr = mysqli_real_escape_string($this->conexao,$dados["CR"]);
      list($diaCR,$mesCR,$anoCR) = explode("/",mysqli_real_escape_string($this->conexao,$dados["CRValidade"]));
      $validade = $anoCR."-".$mesCR."-".$diaCR;
      list($diaDC,$mesDC,$anoDC) = explode("/",mysqli_real_escape_string($this->conexao,$dados["DataDeclaracao"]));
      $dataDeclacarao = $anoDC."-".$mesDC."-".$diaDC;
      $observacoes = mysqli_real_escape_string($this->conexao,$dados["Observacoes"]);
      mysqli_query($this->conexao,"INSERT INTO atirador(despachante,anuidade_tipo,data_cadastro,nome,data_nascimento,endereco,bairro,cidade,estado,cep,telefone_residencia,telefone_comercial,celular,email,identidade,identidade_orgao,identidade_emissao,cpf,cr,cr_validade,sexo,nacionalidade,naturalidade,status,profissao,eh_atleta,eh_instrutor,eh_arbitro,eh_colecionador,eh_cacador,eh_recarga,dies,nome_pai,nome_mae,estado_civil,senha,data_declaracao,observacoes)
           VALUES('1',
                   '".$despachante."',
                    '".$dataCadastro."',
                     '".$nome."',
                      '".$dataNascimento."',
                       '".$logradouro."',
                        '".$bairro."',
                         '".$cidade."',
                          '".$estado."',
                           '".$cep."',
                            '".$telefone."',
                             '".$telefoneComercial."',
                              '".$celular."',
                               '".$email."',
                                '".$rg."',
                                 '".$orgaoEmissor."',
                                  '".$dataEmissao."',
                                   '".$cpf."',
                                    '".$cr."',
                                    '".$validade."',
                                   '".$genero."',
                                  '".$nacionalidade."',
                                 '".$naturalidade."',
                                'A',
                               '".$profissao."',
                              '".$atleta."',
                             '".$instrutor."',
                            '".$arbitro."',
                           '".$colecionador."',
                          '".$cacador."',
                         '".$recarga."',
                        '".$dies."',
                       '".$nomePai."',
                      '".$nomeMae."',
                     '".$estadoCivil."',
                    '".$senha."',
                   '".$dataDeclacarao."',
                  '".$observacoes."');") or die(mysqli_error($this->conexao));
      if(mysqli_affected_rows($this->conexao) > 0)
      {
        $idCadastro = mysqli_insert_id($this->conexao);
        $codigo = sprintf("%05d", $idCadastro);
        mysqli_query($this->conexao,"UPDATE atirador SET codigo = '".$codigo."' WHERE atirador = '".$idCadastro."';");
        $idCod = $this->codificar($idCadastro);
        mysqli_query($this->conexao,"UPDATE atirador SET id_cod_atirador = '".$idCod."' WHERE atirador = '".$idCadastro."';");
        $_SESSION["SucessoCadastro"] = true;
        return "<script>window.location.href='".$this->caminhoAbsoluto()."/novo-atirador/'</script>";
      }
       else
      {
        $_SESSION["Erro"] = time() + 5;
      }
    }

     /**
   * Método altera os dados do atirador
   * @access public
   * @param array $dados
   * @return true
   */
    public function alterarDadosAtirador(array $dados)
    {
      $cpf = mysqli_real_escape_string($this->conexao,$dados["CPF"]);
      $cpf = $this->limpaCPF_CNPJ($cpf);
      $diaCadastro = mysqli_real_escape_string($this->conexao,$dados["DiaCadastro"]);
      $mesCadastro = mysqli_real_escape_string($this->conexao,$dados["MesCadastro"]);
      $anoCadastro = mysqli_real_escape_string($this->conexao,$dados["AnoCadastro"]);
      $dataCadastro = $anoCadastro."-".$mesCadastro."-".$diaCadastro;
      $despachante = mysqli_real_escape_string($this->conexao,$dados["Despachante"]);
      $status = mysqli_real_escape_string($this->conexao,$dados["Status"]);
      $fichaAtleta = mysqli_real_escape_string($this->conexao,$dados["FichaAtleta"]);
      $anuidade = mysqli_real_escape_string($this->conexao,$dados["TipoAnuidade"]);
      $sqlAnuidade = mysqli_query($this->conexao,"SELECT * FROM anuidade_tipo WHERE nome = '".$anuidade."';");
      $ctcbAnuidade = mysqli_fetch_object($sqlAnuidade);
      $anuidade = $ctcbAnuidade->anuidade_tipo;
      $email = mysqli_real_escape_string($this->conexao,$dados["Email"]);
      $senha = mysqli_real_escape_string($this->conexao,$dados["Senha"]);
      $senha = $this->codificar($senha);
      $nome = mysqli_real_escape_string($this->conexao,$dados["Nome"]);
      $genero = mysqli_real_escape_string($this->conexao,$dados["Genero"]);
      $genero = ($genero == "Masculino")?'M':'F';
      $diaNascimento = mysqli_real_escape_string($this->conexao,$dados["DiaNascimento"]);
      $mesNascimento = mysqli_real_escape_string($this->conexao,$dados["MesNascimento"]);
      $anoNascimento = mysqli_real_escape_string($this->conexao,$dados["AnoNascimento"]);
      $dataNascimento = $anoNascimento."-".$mesNascimento."-".$diaNascimento;
      $telefone = mysqli_real_escape_string($this->conexao,$dados["Telefone"]);
      $celular = mysqli_real_escape_string($this->conexao,$dados["Celular"]);
      $nomeMae = mysqli_real_escape_string($this->conexao,$dados["NomeMae"]);
      $nomePai = mysqli_real_escape_string($this->conexao,$dados["NomePai"]);
      $estadoCivil = mysqli_real_escape_string($this->conexao,$dados["EstadoCivil"]);
      $cep = mysqli_real_escape_string($this->conexao,$dados["CEP"]);
      $logradouro = mysqli_real_escape_string($this->conexao,$dados["Logradouro"]);
      $bairro = mysqli_real_escape_string($this->conexao,$dados["Bairro"]);
      $cidade = mysqli_real_escape_string($this->conexao,$dados["Cidade"]);
      $estado = mysqli_real_escape_string($this->conexao,$dados["Estado"]);
      $sqlEstado = mysqli_query($this->conexao,"SELECT * FROM estado WHERE nome = '".$estado."';");
      $ctcbEstado = mysqli_fetch_object($sqlEstado);
      $estado = $ctcbEstado->estado;
      $nacionalidade = mysqli_real_escape_string($this->conexao,$dados["Nacionalidade"]);
      $sqlNacionalidade = mysqli_query($this->conexao,"SELECT * FROM nacionalidade WHERE nome = '".$nacionalidade."';");
      $ctcbNacionalidade = mysqli_fetch_object($sqlNacionalidade);
      $nacionalidade = $ctcbNacionalidade->nacionalidade;
      $naturalidade = mysqli_real_escape_string($this->conexao,$dados["Naturalidade"]);
      $sqlNaturalidade = mysqli_query($this->conexao,"SELECT * FROM estado WHERE sigla = '".$naturalidade."';");
      $ctcbNaturalidade = mysqli_fetch_object($sqlNaturalidade);
      $naturalidade = $ctcbNaturalidade->estado;
      $profissao = mysqli_real_escape_string($this->conexao,$dados["Profissao"]);
      $telefoneComercial = mysqli_real_escape_string($this->conexao,$dados["TelefoneComercial"]);
      $atleta = mysqli_real_escape_string($this->conexao,$dados["Atleta"]);
      $atleta = ($atleta == "Sim")?'S':'N';
      $instrutor = mysqli_real_escape_string($this->conexao,$dados["Instrutor"]);
      $instrutor = ($instrutor == "Sim")?'S':'N';
      $arbitro = mysqli_real_escape_string($this->conexao,$dados["Arbitro"]);
      $arbitro = ($arbitro == "Sim")?'S':'N';
      $colecionador = mysqli_real_escape_string($this->conexao,$dados["Colecionador"]);
      $colecionador = ($colecionador == "Sim")?'S':'N';
      $cacador = mysqli_real_escape_string($this->conexao,$dados["Cacador"]);
      $cacador = ($cacador == "Sim")?'S':'N';
      $recarga = mysqli_real_escape_string($this->conexao,$dados["Recarga"]);
      $recarga = ($recarga == "Sim")?'S':'N';
      $dies = mysqli_real_escape_string($this->conexao,$dados["Dies"]);
      $rg = mysqli_real_escape_string($this->conexao,$dados["Identidade"]);
      $orgaoEmissor = mysqli_real_escape_string($this->conexao,$dados["OrgaoEmissor"]);
      list($diaEmissao,$mesEmissao,$anoEmissao) = explode("/",mysqli_real_escape_string($this->conexao,$dados["DataEmissao"]));
      $dataEmissao = $anoEmissao."-".$mesEmissao."-".$diaEmissao;
      $cr = mysqli_real_escape_string($this->conexao,$dados["CR"]);
      list($diaCR,$mesCR,$anoCR) = explode("/",mysqli_real_escape_string($this->conexao,$dados["CRValidade"]));
      $validade = $anoCR."-".$mesCR."-".$diaCR;
      list($diaDC,$mesDC,$anoDC) = explode("/",mysqli_real_escape_string($this->conexao,$dados["DataDeclaracao"]));
      $dataDeclacarao = $anoDC."-".$mesDC."-".$diaDC;
      $observacoes = mysqli_real_escape_string($this->conexao,$dados["Observacoes"]);
      mysqli_query($this->conexao,"UPDATE atirador SET
                                         nome = '".$nome."',
                                         despachante = '".$despachante."',
                                         data_nascimento = '".$dataNascimento."',
                                         endereco = '".$logradouro."',
                                         bairro = '".$bairro."',
                                         cidade = '".$cidade."',
                                         estado = '".$estado."',
                                         cep = '".$cep."',
                                         telefone_residencia = '".$telefone."',
                                         telefone_comercial = '".$telefoneComercial."',
                                         celular = '".$celular."',
                                         email = '".$email."',
                                         identidade = '".$rg."',
                                         identidade_orgao = '".orgaoEmissor."',
                                         cpf = '".$cpf."',
                                         cr = '".$cr."',
                                         cr_validade = '".$validade."',
                                         sexo = '".$genero."',
                                         nacionalidade = '".$nacionalidade."',
                                         naturalidade = '".$naturalidade."',
                                         status = '".$status."',
                                         profissao = '".$profissao."',
                                         eh_atleta = '".$atleta."',
                                         eh_instrutor = '".$instrutor."',
                                         eh_arbitro = '".$arbitro."',
                                         eh_colecionador = '".$colecionador."',
                                         eh_cacador = '".$cacador."',
                                         eh_recarga = '".$recarga."',
                                         dies = '".$dies."',
                                         nome_pai = '".$nomePai."',
                                         nome_mae = '".$nomeMae."',
                                         estado_civil = '".$estadoCivil."',
                                         data_declaracao = '".$dataDeclacarao."',
                                         observacoes = '".$observacoes."'
                                   WHERE id_cod_atirador = '".$dados['key']."'");
       $_SESSION["Sucesso"] = true;
       return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-atirador/?".$dados["key"]."'</script>";
    }

    /**
     * Método lista os nomes dos despachantes em um combox
     * @access public
     * @param string $busca
     * @return string $visualizar
     */
    public function listarDespachantesCombox($busca)
    {
      $sql = mysqli_query($this->conexao,"SELECT * FROM despachante ORDER BY nome;");
      $sqll = "SELECT * FROM despachante ".$busca." ORDER BY nome;";
      $visualizar = '';
      while($ctcb = mysqli_fetch_object($sql))
      {
        $selected = ($ctcb->despachante == $busca)?'selected':null;
        $visualizar .= '<option value="'.$ctcb->despachante.'" '.$selected.'>'.$ctcb->nome.'</option>';
      }
      return $visualizar;
    }

     /**
   * Método cadastra o clube
   * @access public
   * @param array $dados
   * @return true
   */
    public function cadastrarClubes(array $dados)
    {
      $nomeClube = mysqli_real_escape_string($this->conexao,$dados['Nome']);
      $sigla = mysqli_real_escape_string($this->conexao,$dados['Sigla']);
      $senha = mysqli_real_escape_string($this->conexao,$dados['Senha']);
      $status = mysqli_real_escape_string($this->conexao,$dados['Status']);
      $telefoneComercial = mysqli_real_escape_string($this->conexao,$dados['TelefoneComercial']);
      $telefoneCelular = mysqli_real_escape_string($this->conexao,$dados['TelefoneCelular']);
      $email = mysqli_real_escape_string($this->conexao,$dados['Email']);
      $presidente = mysqli_real_escape_string($this->conexao,$dados['Presidente']);
      $fimMandato = mysqli_real_escape_string($this->conexao,$dados['FimMandato']);
      list($dia,$mes,$ano) = explode("/",$fimMandato);
      $fimMandato = $ano."-".$mes."-".$dia;
      $site = mysqli_real_escape_string($this->conexao,$dados['Site']);
      $cep = mysqli_real_escape_string($this->conexao,$dados['CEP']);
      $logradouro = mysqli_real_escape_string($this->conexao,$dados['Logradouro']);
      $bairro = mysqli_real_escape_string($this->conexao,$dados['Bairro']);
      $cidade = mysqli_real_escape_string($this->conexao,$dados['Cidade']);
      $estado = mysqli_real_escape_string($this->conexao,$dados['Estado']);
      $sql = mysqli_query($this->conexao,"SELECT * FROM estado WHERE sigla = '".$estado."';");
      $ctcb = mysqli_fetch_object($sql);
      $estado = $ctcb->estado;
      mysqli_query($this->conexao,"INSERT INTO clube(status,sigla,nome,endereco,bairro,cidade,estado,cep,telefone,celular,presidente,fim_mandato,email,site,senha)
                                   VALUES ('".$status."',
                                           '".$sigla."',
                                           '".$nomeClube."',
                                           '".$logradouro."',
                                           '".$bairro."',
                                           '".$cidade."',
                                           '".$estado."',
                                           '".$cep."',
                                           '".$telefoneComercial."',
                                           '".$telefoneCelular."',
                                           '".$presidente."',
                                           '".$fimMandato."',
                                           '".$email."',
                                           '".$site."',
                                           '".$this->codificar($senha)."'
                                         )");
      if(mysqli_affected_rows($this->conexao) > 0)
      {
        $id = mysqli_insert_id($this->conexao);
        $idCod = $this->codificar($id);
        mysqli_query($this->conexao,"UPDATE clube SET id_cod_clube = '".$idCod."' WHERE clube = '".$id."';");
        $_SESSION["Sucesso"] = time() + 5;
        return "<script>window.location.href='".$this->caminhoAbsoluto()."/novo-clube/';</script>";
      }
      else
      {
        $_SESSION["Erro"] = time() + 5;
      }
    }

     /**
   * Método altera os dados do clube
   * @access public
   * @param array $dados
   * @return true
   */
    public function alterarDadosClubes(array $dados)
    {
      $idCodClube = mysqli_real_escape_string($this->conexao,$dados['Key']);
      $nomeClube = mysqli_real_escape_string($this->conexao,$dados['Nome']);
      $sigla = mysqli_real_escape_string($this->conexao,$dados['Sigla']);
      $senha = mysqli_real_escape_string($this->conexao,$dados['Senha']);
      $status = mysqli_real_escape_string($this->conexao,$dados['Status']);
      $telefone = mysqli_real_escape_string($this->conexao,$dados['Celular']);
      $telefone = mysqli_real_escape_string($this->conexao,$dados['TelefoneComercial']);
      $email = mysqli_real_escape_string($this->conexao,$dados['Email']);
      $presidente = mysqli_real_escape_string($this->conexao,$dados['Presidente']);
      $fimMandato = mysqli_real_escape_string($this->conexao,$dados['FimMandato']);
      list($dia,$mes,$ano) = explode("/",$fimMandato);
      $fimMandato = $ano."-".$mes."-".$dia;
      $site = mysqli_real_escape_string($this->conexao,$dados['Site']);
      $cep = mysqli_real_escape_string($this->conexao,$dados['CEP']);
      $endereco = mysqli_real_escape_string($this->conexao,$dados['Logradouro']);
      $bairro = mysqli_real_escape_string($this->conexao,$dados['Bairro']);
      $cidade = mysqli_real_escape_string($this->conexao,$dados['Cidade']);
      $estado = mysqli_real_escape_string($this->conexao,$dados['Estado']);
      $sql = mysqli_query($this->conexao,"SELECT * FROM estado WHERE sigla = '".$estado."';");
      $ctcb = mysqli_fetch_object($sql);
      $estado = $ctcb->estado;
        mysqli_query($this->conexao,"UPDATE clube
                                       SET
                                         status = '".$status."',
                                         sigla = '".$sigla."',
                                         nome = '".$nomeClube."',
                                         endereco = '".$endereco."',
                                         bairro = '".$bairro."',
                                         cidade = '".$cidade."',
                                         estado = '".$estado."',
                                         cep = '".$cep."',
                                         telefone = '".$telefone."',
                                         celular = '".$celular."',
                                         presidente = '".$presidente."',
                                         fim_mandato = '".$fimMandato."',
                                         email = '".$email."',
                                         site = '".$site."'
                                       WHERE
                                       id_cod_clube = '".$idCodClube."';");
        $_SESSION["Sucesso"] = time() + 5;
        return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-clube/?".$idCodClube."';</script>";
    }

     /**
   * Método cadastra a modalide
   * @access public
   * @param string $nacionalidade
   * @return true
   * @ignore
   */
    public function cadastrarNacionalidade($nacionalidade)
    {
      $nacionalidade = mysqli_real_escape_string($this->conexao,$nacionalidade);
      $sql = mysqli_query($this->conexao,"SELECT * FROM nacionalidade WHERE nome = '".$nacionalidade."';");
      if(mysqli_num_rows($sql) > 0)
      {
        $_SESSION["JaCadastrado"] = time() + 5;
      }
      else
      {
         mysqli_query($this->conexao,"INSERT INTO nacionalidade VALUES(null,'".$nacionalidade."');");
         if(mysqli_affected_rows($this->conexao) > 0)
         {
           $_SESSION["Sucesso"] = time() + 10;
           return "<script>window.location.href='".$this->caminhoAbsoluto()."/nova-nacionalidade/'</script>";
         }
      }
    }

     /**
   * Método cadastra a naturalidade
   * @access public
   * @param string $naturalidade
   * @param string @sigla
   * @return true
   * @ignore
   */
    public function cadastrarNaturalidade($naturalidade,$sigla)
    {
      $naturalidade = mysqli_real_escape_string($this->conexao,$naturalidade);
      $sigla = mysqli_real_escape_string($this->conexao,$sigla);
      $sql = mysqli_query($this->conexao,"SELECT * FROM estado WHERE sigla = '".$sigla."' OR nome = '".$naturalidade."';");
      if(mysqli_num_rows($sql) > 0)
      {
        $_SESSION["JaCadastrado"] = time() + 5;
      }
       else
      {
         mysqli_query($this->conexao,"INSERT INTO estado VALUES(null, '".$sigla."','".$naturalidade."');");
         if(mysqli_affected_rows($this->conexao) > 0)
         {
           $_SESSION["Sucesso"] = time() + 10;
           return "<script>window.location.href='".$this->caminhoAbsoluto()."/novo-estado/'</script>";
         }
      }
    }

  /**
   * Método cadastra a modalide
   * @access public
   * @param string $modalidade
   * @return true
   */
    public function cadastrarModalidade($modalidade)
    {
      $modalidade = mysqli_real_escape_string($this->conexao,$modalidade);
      $sql = mysqli_query($this->conexao,"SELECT * FROM modalidade WHERE nome = '".$modalidade."';");
      if(mysqli_num_rows($sql) > 0)
      {
        $_SESSION["JaCadastrado"] = time() + 5;
      }
      else
      {
         mysqli_query($this->conexao,"INSERT INTO modalidade VALUES(null, '".$modalidade."');");
         if(mysqli_affected_rows($this->conexao) > 0)
         {
           $_SESSION["Sucesso"] = time() + 10;
           return "<script>window.location.href='".$this->caminhoAbsoluto()."/nova-modalidade/'</script>";
         }
      }
    }

     /**
   * Método cadastra a prova
   * @access public
   * @param array $dados
   * @return true
   */
    public function cadastrarNovaProva(array $dados)
    {
        $nome = mysqli_real_escape_string($this->conexao,$dados['Nome']);
        $arma = mysqli_real_escape_string($this->conexao,$dados['Arma']);
        $modalidade = mysqli_real_escape_string($this->conexao,$dados['Modalidades']);
        $status = mysqli_real_escape_string($this->conexao,$dados['Status']);
        $numSeries = mysqli_real_escape_string($this->conexao,$dados['NumSeries']);
        $maxSeries = mysqli_real_escape_string($this->conexao,$dados['MaxSeries']);
        $final = mysqli_real_escape_string($this->conexao,$dados['Final']);
        $somatorio1 = mysqli_real_escape_string($this->conexao,$dados['Somatorio1']);
        $somatorio2 = mysqli_real_escape_string($this->conexao,$dados['Somatorio2']);
        $somatorio3 = mysqli_real_escape_string($this->conexao,$dados['Somatorio3']);
        $somatorio4 = mysqli_real_escape_string($this->conexao,$dados['Somatorio4']);
        $somatorio1 = mysqli_real_escape_string($this->conexao,$dados['Somatorio1']);
        $usoDecimal = mysqli_real_escape_string($this->conexao,$dados['UsoDecimal']);
        $tipoTotalProva = mysqli_real_escape_string($this->conexao,$dados['TipoTotalProva']);
        $tipoRanking = mysqli_real_escape_string($this->conexao,$dados['TipoRanking']);
        $numPeriodoRanking = mysqli_real_escape_string($this->conexao,$dados['NumPeriodoRanking']);
        $tipoTotalRanking = mysqli_real_escape_string($this->conexao,$dados['TipoTotalRanking']);
        $resultadosValidos = mysqli_real_escape_string($this->conexao,$dados['ResultadosValidos']);
        $resultadosEventos = mysqli_real_escape_string($this->conexao,$dados['ResultadosEventos']);
        $inscricaoSiteCategoria = mysqli_real_escape_string($this->conexao,$dados['InscricaoSiteCategoria']);
        $inscricaoLocalCategoria = mysqli_real_escape_string($this->conexao,$dados['InscricaoLocalCategoria']);
        $descontoCategoria = mysqli_real_escape_string($this->conexao,$dados['DescontoCategoria']);
        $inscricaoSiteAnuidade = mysqli_real_escape_string($this->conexao,$dados['InscricaoSiteAnuidade']);
        $inscricaoLocalAnuidade = mysqli_real_escape_string($this->conexao,$dados['InscricaoLocalAnuidade']);
        $descontoTipo = mysqli_real_escape_string($this->conexao,$dados['DescontoTipo']);
        list($RS,$descontoTipo) = explode("R$",$descontoTipo);
        $semPontoD = str_replace(".","",$descontoTipo);
        $descontoTipo = str_replace(",",".",$semPontoD);
        list($RS,$inscricaoSiteCategoria) = explode("R$",$inscricaoSiteCategoria);
        $semPontoC = str_replace(".","",$inscricaoSiteCategoria);
        $inscricaoSiteCategoria = str_replace(",",".",$semPontoC);
        list($RS,$inscricaoLocalCategoria) = explode("R$",$inscricaoLocalCategoria);
        $semPontoL = str_replace(".","",$inscricaoLocalCategoria);
        $inscricaoLocalCategoria = str_replace(",",".",$semPontoL);
        list($RS,$inscricaoSiteAnuidade) = explode("R$",$inscricaoSiteAnuidade);
        $semPontoA = str_replace(".","",$inscricaoSiteAnuidade);
        $inscricaoSiteAnuidade = str_replace(",",".",$semPontoA);
        list($RS,$inscricaoLocalAnuidade) = explode("R$",$inscricaoLocalAnuidade);
        $semPontoLA = str_replace(".","",$inscricaoLocalAnuidade);
        $inscricaoLocalAnuidade = str_replace(",",".",$semPontoLA);
        mysqli_query($this->conexao,"INSERT INTO prova
                                     VALUES(null, 0,
                                        '".$nome."',
                                         '".$arma."',
                                          '".$modalidade."',
                                           '".$status."',
                                            '".$numSeries."',
                                             '".$maxSeries."',
                                              '".$final."',
                                               '".$somatorio1."',
                                                '".$somatorio2."',
                                                 '".$somatorio3."',
                                                  '".$somatorio4."',
                                                   '".$usoDecimal."',
                                                    '".$tipoTotalProva."',
                                                     '".$tipoRanking."',
                                                      '".$numPeriodoRanking."',
                                                     '".$tipoTotalRanking."',
                                                     '".$resultadosValidos."',
                                                   '".$resultadosEventos."',
                                                 '".$inscricaoSiteCategoria."',
                                               '".$inscricaoLocalCategoria."',
                                             '".$descontoCategoria."',
                                           '".$inscricaoSiteAnuidade."',
                                         '".$inscricaoLocalAnuidade."',
                                       '".$descontoTipo."'
                                     )");
        if(mysqli_affected_rows($this->conexao) > 0)
        {
          $id = mysqli_insert_id($this->conexao);
          $idCod = $this->codificar($id);
          mysqli_query($this->conexao,"UPDATE cadastro_provas SET id_cod_provas = '".$idCod."' WHERE prova = '".$id."';");
          $_SESSION["Sucesso"] = time() + 5;
          return "<script>window.location.href='".$this->caminhoAbsoluto()."/nova-prova/'</script>";
        }
        else
        {
           $_SESSION["Erro"] = time() + 5;
        }
    }

     /**
   * Método cadastra a notícia
   * @access public
   * @param array $dados
   * @param string $imagem
   * @param string $temp
   * @param string $arquivo
   * @param string $tempA
   * @return true
   */
    public function cadastrarNoticias(array $dados,$imagem,$temp,$arquivo,$tempA)
    {
        $dataNoticia = mysqli_real_escape_string($this->conexao,$dados["DataNoticia"]);
        list($dia,$mes,$ano) = explode("/",$dataNoticia);
        $dataNoticia = $ano."-".$mes."-".$dia;
        $veiculo = mysqli_real_escape_string($this->conexao,$dados["Veiculo"]);
        $titulo = mysqli_real_escape_string($this->conexao,$dados["Titulo"]);
        $noticia = mysqli_real_escape_string($this->conexao,$dados["Noticia"]);
        $video1 = mysqli_real_escape_string($this->conexao,$dados["Video1"]);
        $video2 = mysqli_real_escape_string($this->conexao,$dados["Video2"]);
        $video3 = mysqli_real_escape_string($this->conexao,$dados["Video3"]);
        $link1 = mysqli_real_escape_string($this->conexao,$dados["Link1"]);
        $tipoLink1 = mysqli_real_escape_string($this->conexao,$dados["TipoLink1"]);
        $descricao1 = mysqli_real_escape_string($this->conexao,$dados["Descricao1"]);
        $link2 = mysqli_real_escape_string($this->conexao,$dados["Link2"]);
        $tipoLink2 = mysqli_real_escape_string($this->conexao,$dados["TipoLink2"]);
        $descricao2 = mysqli_real_escape_string($this->conexao,$dados["Descricao2"]);
        mysqli_query($this->conexao,"INSERT INTO noticia
                                      (data,veiculo,titulo,materia,link1,link1_tipo,link1_descricao,link2,link2_tipo,link2_descricao,video1,video2,video3)"
                                    . "VALUES('".$dataNoticia."',"
                                    . "'".$veiculo."',"
                                    . "'".$titulo."',"
                                    . "'".$noticia."',"
                                    . "'".$link1."',"
                                    . "'".$tipoLink1."',"
                                    . "'".$descricao1."',"
                                    . "'".$link2."',"
                                    . "'".$tipoLink2."',"
                                    . "'".$descricao2."',"
                                    . "'".$video1."',"
                                    . "'".$video2."',"
                                    . "'".$video3."')");
       $idNoticia = mysqli_insert_id($this->conexao);
       $idCod = $this->codificar($idNoticia);
       mysqli_query($this->conexao,"UPDATE noticia SET id_cod_noticia = '".$idCod."' WHERE id_noticia = '".$idNoticia."';");
       if($imagem != "")
       {
           $i = 0;
           foreach($imagem as $imagens)
           {
              $antigo = umask(0);
              $diretorio = '../../fotos_noticias/';
              umask($antigo);
              $extensao = pathinfo($imagens, PATHINFO_EXTENSION);
              $nomeArquivo = explode(".".$extensao,$imagens);
              $codArquivo[$i] = md5(date("d-m-Y H:i:s").$nomeArquivo[0]).".".$extensao;
              move_uploaded_file($temp[$i],$diretorio."/".$codArquivo[$i]);
              mysqli_query($this->conexao, "INSERT INTO fotos_noticias VALUES(null,0,'".$idNoticia."','".$dados["Legenda"][$i]."','".$codArquivo[$i]."');");
              $idFotos = mysqli_insert_id($this->conexao);
              $idCodFotos = $this->codificar($idFotos);
              mysqli_query($this->conexao, "UPDATE fotos_noticias SET IdCodFotos = '".$idCodFotos."' WHERE IdFotos = '".$idFotos."';");
              $i++;
           }
       }
       if($arquivo != "")
       {
            $a = 0;
            // Cadastrar arquivos
            foreach($arquivo as $arquivos)
            {
              $diretorio = '../../arquivos/';
              $extensao = pathinfo($arquivos, PATHINFO_EXTENSION);
              $nomeArquivo = explode(".".$extensao,$arquivos);
              //$codArquivo[$a] = md5(date("d-m-Y H:i:s").$nomeArquivo[0]).".".$extensao;
              $codArquivo[$a] = $nomeArquivo[0].".".$extensao;
              move_uploaded_file($tempA[$a],$diretorio."/".$codArquivo[$a]);
              mysqli_query($this->conexao, "INSERT INTO arquivo_noticias VALUES(null,0,'".$idNoticia."','".$codArquivo[$a]."');");
              $idArquivos = mysqli_insert_id($this->conexao);
              $idCodArquivos = $this->codificar($idArquivos);
              mysqli_query($this->conexao, "UPDATE arquivo_noticias SET IdCodArquivos = '".$idCodArquivos."' WHERE IdArquivos = '".$idArquivos."';");
              $a++;
            }
       }
      $_SESSION["SucessoNoticia"] = time() + 5;
      return "<script>window.location.href='".$this->caminhoAbsoluto()."/nova-noticia/';</script>";
    }

    /**
     * Alterar a notícia
     * @access public
     * @param array
     * @param string $dados
     * @param string $imagem
     * @param string $temp
     * @param string $arquivo
     * @param string $tempA
     * @return true
     */
    public function alterarNoticias(array $dados,$imagem,$temp,$arquivo,$tempA)
    {
      $key = mysqli_real_escape_string($this->conexao,$dados["Key"]);
      $dataNoticia = mysqli_real_escape_string($this->conexao,$dados["DataNoticia"]);
      list($dia,$mes,$ano) = explode("/",$dataNoticia);
      $dataNoticia = $ano."-".$mes."-".$dia;
      $veiculo = mysqli_real_escape_string($this->conexao,$dados["Veiculo"]);
      $titulo = mysqli_real_escape_string($this->conexao,$dados["Titulo"]);
      $noticia = mysqli_real_escape_string($this->conexao,$dados["Noticia"]);
      $video1 = mysqli_real_escape_string($this->conexao,$dados["Video1"]);
      $video2 = mysqli_real_escape_string($this->conexao,$dados["Video2"]);
      $video3 = mysqli_real_escape_string($this->conexao,$dados["Video3"]);
      $link1 = mysqli_real_escape_string($this->conexao,$dados["Link1"]);
      $tipoLink1 = mysqli_real_escape_string($this->conexao,$dados["TipoLink1"]);
      $descricao1 = mysqli_real_escape_string($this->conexao,$dados["Descricao1"]);
      $link2 = mysqli_real_escape_string($this->conexao,$dados["Link2"]);
      $tipoLink2 = mysqli_real_escape_string($this->conexao,$dados["TipoLink2"]);
      $descricao2 = mysqli_real_escape_string($this->conexao,$dados["Descricao2"]);
      mysqli_query($this->conexao,"UPDATE 
                                    noticia 
                                  SET
                                    data = '".$dataNoticia."',
                                    veiculo = '".$veiculo."',
                                    titulo = '".$titulo."',
                                    materia = '".$noticia."'
                                  WHERE 
                                    id_cod_noticia = '".$key."';");
      if($imagem != "")
       {
           $i = 0;
           foreach($imagem as $imagens)
           {
              $antigo = umask(0);
              $diretorio = '../../fotos_noticias/';
              umask($antigo);
              $extensao = pathinfo($imagens, PATHINFO_EXTENSION);
              $nomeArquivo = explode(".".$extensao,$imagens);
              $codArquivo[$i] = md5(date("d-m-Y H:i:s").$nomeArquivo[0]).".".$extensao;
             // move_uploaded_file($temp[$i],$diretorio."/".$codArquivo[$i]);
             // mysqli_query($this->conexao, "INSERT INTO fotos_noticias VALUES(null,0,'".$idNoticia."','".$dados["Legenda"][$i]."','".$codArquivo[$i]."');");
              $idFotos = mysqli_insert_id($this->conexao);
              $idCodFotos = $this->codificar($idFotos);
              $i++;
           }
       }
        if($arquivo != "")
        {
             $a = 0;
             foreach($arquivo as $arquivos)
             {
              $diretorio = '../../arquivos/';
              $extensao = pathinfo($arquivos, PATHINFO_EXTENSION);
              $nomeArquivo = explode(".".$extensao,$arquivos);
              //$codArquivo[$a] = md5(date("d-m-Y H:i:s").$nomeArquivo[0]).".".$extensao;
              $codArquivo[$a] = $nomeArquivo[0].".".$extensao;
              move_uploaded_file($tempA[$a],$diretorio."/".$codArquivo[$a]);
              mysqli_query($this->conexao, "INSERT INTO arquivo_noticias VALUES(null,0,'".$idNoticia."','".$codArquivo[$a]."');");
              $idArquivos = mysqli_insert_id($this->conexao);
              $idCodArquivos = $this->codificar($idArquivos);
              mysqli_query($this->conexao, "UPDATE arquivo_noticias SET IdCodArquivos = '".$idCodArquivos."' WHERE IdArquivos = '".$idArquivos."';");
              $a++;
             }
        }
        $_SESSION["SucessoNoticia"] = time() + 5;
        return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-noticias/';</script>";
    }

    /**
     * Método lista a lista dos atiradores
     * Encontra-se na página index.php
     * @access public
     * @param string $pagina,$busca
     * @param int $qnt_result_pg
     * @return $visualizar
     */
      public function listarNoticias($pagina,$qnt_result_pg,$busca)
      {
        $inicio = ($pagina * $qnt_result_pg) - $qnt_result_pg;
        if($busca == "")
        {
          $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM noticia ORDER BY data DESC LIMIT $inicio, $qnt_result_pg");
         }
          else
         {
           list($buscar,$tirar) = explode("(",$busca);
           $busca = trim($buscar);
           $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM noticia WHERE titulo ='".$busca."' ORDER BY titulo DESC;");
           $botao = "<div class='col-md-12'><div class='text-right'><a href=\"".$this->caminhoAbsoluto()."/noticias/\" class='btn btn-primary btn-sm'><i class=\"fas fa-angle-double-left\"></i> Voltar</a></div></div>";
         }
          $sqlContar = mysqli_query($this->conexao,"SELECT * FROM noticia");
          $result_pg = "SELECT COUNT(noticia) AS num FROM noticia";
          $resultado_pg = mysqli_query($this->conexao, $result_pg);
          $row_pg = mysqli_fetch_assoc($resultado_pg);
          $quantidade_pg = ceil($row_pg['num'] / $qnt_result_pg);
          $max_links = 2;
          $paginacao = "<a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario(1, $qnt_result_pg)'>Primeira</a> ";
          for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++)
          {
          	if($pag_ant >= 1)
            {
          		 $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_ant, $qnt_result_pg)'>$pag_ant </a> ";
          	}
          }
          $paginacao .= "<a href='#' class='btn btn-dark btn-sm'> $pagina </a>";
          for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++)
          {
        	   if($pag_dep <= $quantidade_pg)
             {
        		    $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_dep, $qnt_result_pg)'>$pag_dep</a> ";
             }
          }
          $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($quantidade_pg, $qnt_result_pg)'>Última</a>";
          $visualizar = '<div class="row">';
          $visualizar .= "<div class=\"col-md-4 text-left\">Atiradores cadastrados: <strong> ".mysqli_num_rows($sqlContar)."</strong></div>";
          $visualizar .= "<div class=\"col-md-8 text-right\">".$paginacao."</div>";
          $visualizar .= '</div>';
          $visualizar .= '<table class="table table-sm table-bordered table-striped" style="margin-top: 10px; background: #FFF">
                            <thead>
                              <tr>
                                <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Data</th>
                                <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Título</th>
                                <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Ação</th>
                              </tr>
                            </thead>
                            <tbody>';
          if(mysqli_num_rows($sqlVisualizar) == 0)
          {
            $visualizar .= '<tr><td colspan="6" style="color: red; text-align: center; font-weight: bold">Não existem atiradores cadastrados</td></tr>';
          }
           else
          {
            while($ctcbVisualizar = mysqli_fetch_object($sqlVisualizar))
            {
              list($ano,$mes,$dia) = explode("-",$ctcbVisualizar->data);
              $dataNoticia = $dia."/".$mes."/".$ano;
              $visualizar .= '<tr>';
              $visualizar .= '<td style="font-size: 14px; text-align: center">'.$dataNoticia.'</td>';
              $visualizar .= '<td style="text-transform: uppercase; font-size: 14px;">'.$ctcbVisualizar->titulo.'</td>';
              $visualizar .= '<td style="text-align: center">';
              if($_SESSION["Editar"] == '1')
              {
                 $visualizar .= '<a href="'.$this->caminhoAbsoluto().'/detalhes-noticias/?'.$ctcbVisualizar->id_cod_noticia.'" style="color: #000" title="Editar"><i class="far fa-edit"></i></a> ';
              }
              if($_SESSION["Excluir"] == '1')
              {
                 $visualizar .= ' <a href="#!" style="color: #000" title="Excluir"><i class="far fa-trash-alt"></i></a>';
              }
              $visualizar .= '</td>';
              $visualizar .= '</tr>';
            }
          $visualizar .= "</tbody>";
          $visualizar .= "</table>";
          $visualizar .= $botao;
        }
      return $visualizar;
    }

    /**
     * Método lista os arquivos da notícia
     * Encontra-se na página detalhes-noticias.php
     * @access public
     * @param string $key
     * @return string $visualizar
     */
    public function visualizarArquivos($key)
    {
      $sql = mysqli_query($this->conexao,"SELECT * FROM arquivo_noticias WHERE IdNoticias = '".$key."';");
      if(mysqli_num_rows($sql) == 0)
      {
        $visualizar = '<span style="color: red;">Essa notícia não tem arquivos!</span>';
      }
       else
      {
        $visualizar = '<div class="excluir_fotos">';
        while($ctcb = mysqli_fetch_object($sql))
        {
          $visualizar .= '<i class="fas fa-caret-right"></i> <a href="https://www.ctcb.org.br/arquivos/'.$ctcb->Arquivos.'" target="_blank">'.$ctcb->Arquivos.'</a>
                          <a href="#!" id="btnVisualizarCasas" data-id="'.$ctcb->IdCodArquivos.'" data-toggle="modal-3" style="color: #000"><i class="far fa-trash-alt fa-lg"></i></a>
                          <br>';            
        }
        $visualizar .= '</div>';
        $visualizar .= "<script>
        $(\".excluir_fotos\").on('click',\"#btnVisualizarCasas\", function(){
          alert('aqui');
            var posts = $(this).attr('data-id');
            $.post('".$this->caminhoAbsoluto()."/excluir-arquivos/', {key: posts}, function(retorno){
             // console.log(retorno);
                   $(\"#casasRegionais\").modal({ backdrop: 'static' });
                   $(\"#tela\").html(retorno);
            });
        });
        </script>";
      }
      return $visualizar;
    }

    /**
     * Método lista os atiradores
     * Encontra-se na página cadastrar-associado.php
     * @access public
     * @param int $limite
     * @return string $visualizar
     */
      public function listarNoticiasLimite($limite)
      {
        $sqlListar = mysqli_query($this->conexao,"SELECT * FROM noticia ORDER BY data DESC LIMIT ".$limite.";");
        $visualizar = '<table class="table table-striped">';
        while($ctcb = mysqli_fetch_object($sqlListar))
        {
          $visualizar .= '<tr><td style="font-size: 14px; text-transform: uppercase"><i class="fas fa-caret-right"></i> <a href="'.$this->caminhoAbsoluto().'/detalhes-noticias/?'.$ctcb->id_cod_noticia.'">'.$ctcb->titulo.'</a></td></tr>';
        }
        $visualizar .= "</table>";
        return $visualizar;
      }

      /**
       * Método móstra os arquivos
       * @access public
       * @param null
       * @return string @visualizar
       */
      public function listarArquivosArray()
      {
        $sql = mysqli_query($this->conexao,"SELECT * FROM arquivo");
        $visualizar = '';
        while($ctcb = mysqli_fetch_object($sql))
        {
          $visualizar .= '<option value="'.$ctcb->arquivo.'">'.$ctcb->nome.'</option>';
        }
        return $visualizar;
      }

      /**
       * Método lista as fotos
       * @access public
       * @param string $pagina
       * @param string $busca
       * @param int $qnt_result_pg
       * @return $visualizar
       */
        public function listarFotos($pagina,$qnt_result_pg,$busca)
        {
          $inicio = ($pagina * $qnt_result_pg) - $qnt_result_pg;
          if($busca == "")
          {
            $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM galeria ORDER BY data DESC LIMIT $inicio, $qnt_result_pg");
           }
            else
           {
             list($buscar,$tirar) = explode("(",$busca);
             $busca = trim($buscar);
             $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM galeria WHERE descricao ='".$busca."' ORDER BY descricao DESC;");
             $botao = "<div class='col-md-12'><div class='text-right'><a href=\"".$this->caminhoAbsoluto()."/fotos/\" class='btn btn-primary btn-sm'><i class=\"fas fa-angle-double-left\"></i> Voltar</a></div></div>";
           }
            $sqlContar = mysqli_query($this->conexao,"SELECT * FROM galeria");
            $result_pg = "SELECT COUNT(noticia) AS num FROM galeria";
            $resultado_pg = mysqli_query($this->conexao, $result_pg);
            $row_pg = mysqli_fetch_assoc($resultado_pg);
            $quantidade_pg = ceil($row_pg['num'] / $qnt_result_pg);
            $max_links = 2;
            $paginacao = "<a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario(1, $qnt_result_pg)'>Primeira</a> ";
            for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++)
            {
            	if($pag_ant >= 1)
              {
            		 $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_ant, $qnt_result_pg)'>$pag_ant </a> ";
            	}
            }
            $paginacao .= "<a href='#' class='btn btn-dark btn-sm'> $pagina </a>";
            for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++)
            {
          	   if($pag_dep <= $quantidade_pg)
               {
          		    $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_dep, $qnt_result_pg)'>$pag_dep</a> ";
               }
            }
            $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($quantidade_pg, $qnt_result_pg)'>Última</a>";
            $visualizar = '<div class="row">';
            $visualizar .= "<div class=\"col-md-4 text-left\">Atiradores cadastrados: <strong> ".mysqli_num_rows($sqlContar)."</strong></div>";
            $visualizar .= "<div class=\"col-md-8 text-right\">".$paginacao."</div>";
            $visualizar .= '</div>';
            $visualizar .= '<table class="table table-sm table-bordered table-striped" style="margin-top: 10px; background: #FFF">
                              <thead>
                                <tr>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Data</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Título</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Qtd. Fotos</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Ação</th>
                                </tr>
                              </thead>
                              <tbody>';
            if(mysqli_num_rows($sqlVisualizar) == 0)
            {
              $visualizar .= '<tr><td colspan="6" style="color: red; text-align: center; font-weight: bold">Não existem atiradores cadastrados</td></tr>';
            }
             else
            {
              while($ctcbVisualizar = mysqli_fetch_object($sqlVisualizar))
              {
                list($ano,$mes,$dia) = explode("-",$ctcbVisualizar->data);
                $dataNoticia = $dia."/".$mes."/".$ano;
                $visualizar .= '<tr>';
                $visualizar .= '<td style="font-size: 14px; text-align: center">'.$dataNoticia.'</td>';
                $visualizar .= '<td style="text-transform: uppercase; font-size: 14px;">'.$ctcbVisualizar->descricao.'</td>';
                $sqlFotos = mysqli_query($this->conexao,"SELECT * FROM galeria_fotos WHERE foto = '".$ctcbVisualizar->galeria."';");
                $contarFotos = mysqli_num_rows($sqlFotos);
                $visualizar .= '<td style="text-transform: uppercase; font-size: 14px; text-align: center">'.$contarFotos.'</td>';
                $visualizar .= '<td style="text-align: center">';
                if($_SESSION["Editar"] == '1')
                {
                   $visualizar .= '<a href="'.$this->caminhoAbsoluto().'/detalhes-fotos/?'.$ctcbVisualizar->galeria.'" style="color: #000" title="Editar"><i class="far fa-edit"></i></a>';
                }
                if($_SESSION["Excluir"] == '1')
                {
                   $visualizar .= '<a href="#!" style="color: #000" title="Excluir"><i class="far fa-trash-alt"></i></a>';
                }
                $visualizar .= '</td>';
                $visualizar .= '</tr>';
              }
            $visualizar .= "</tbody>";
            $visualizar .= "</table>";
            $visualizar .= $botao;
          }
        return $visualizar;
      }

      /**
       * Método lista os vídeos
       * Encontra-se na página index.php
       * @access public
       * @param string $pagina
       * @param string $busca
       * @param int $qnt_result_pg
       * @return $visualizar
       */
        public function listarVideos($pagina,$qnt_result_pg,$busca)
        {
          $inicio = ($pagina * $qnt_result_pg) - $qnt_result_pg;
          if($busca == "")
          {
            $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM video ORDER BY data DESC LIMIT $inicio, $qnt_result_pg");
           }
            else
           {
             list($buscar,$tirar) = explode("(",$busca);
             $busca = trim($buscar);
             $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM video WHERE titulo ='".$busca."' ORDER BY titulo DESC;");
             $botao = "<div class='col-md-12'><div class='text-right'><a href=\"".$this->caminhoAbsoluto()."/videos/\" class='btn btn-primary btn-sm'><i class=\"fas fa-angle-double-left\"></i> Voltar</a></div></div>";
           }
            $sqlContar = mysqli_query($this->conexao,"SELECT * FROM video");
            $result_pg = "SELECT COUNT(video) AS num FROM video";
            $resultado_pg = mysqli_query($this->conexao, $result_pg);
            $row_pg = mysqli_fetch_assoc($resultado_pg);
            $quantidade_pg = ceil($row_pg['num'] / $qnt_result_pg);
            $max_links = 2;
            $paginacao = "<a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario(1, $qnt_result_pg)'>Primeira</a> ";
            for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++)
            {
            	if($pag_ant >= 1)
              {
            		 $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_ant, $qnt_result_pg)'>$pag_ant </a> ";
            	}
            }
            $paginacao .= "<a href='#' class='btn btn-dark btn-sm'> $pagina </a>";
            for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++)
            {
          	   if($pag_dep <= $quantidade_pg)
               {
          		    $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_dep, $qnt_result_pg)'>$pag_dep</a> ";
               }
            }
            $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($quantidade_pg, $qnt_result_pg)'>Última</a>";
            $visualizar = '<div class="row">';
            $visualizar .= "<div class=\"col-md-4 text-left\">Atiradores cadastrados: <strong> ".mysqli_num_rows($sqlContar)."</strong></div>";
            $visualizar .= "<div class=\"col-md-8 text-right\">".$paginacao."</div>";
            $visualizar .= '</div>';
            $visualizar .= '<table class="table table-sm table-bordered table-striped" style="margin-top: 10px; background: #FFF">
                              <thead>
                                <tr>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Data</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Título</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Ação</th>
                                </tr>
                              </thead>
                              <tbody>';
            if(mysqli_num_rows($sqlVisualizar) == 0)
            {
              $visualizar .= '<tr><td colspan="6" style="color: red; text-align: center; font-weight: bold">Não existem atiradores cadastrados</td></tr>';
            }
             else
            {
              while($ctcbVisualizar = mysqli_fetch_object($sqlVisualizar))
              {
                list($ano,$mes,$dia) = explode("-",$ctcbVisualizar->data);
                $dataNoticia = $dia."/".$mes."/".$ano;
                $visualizar .= '<tr>';
                $visualizar .= '<td style="font-size: 14px; text-align: center">'.$dataNoticia.'</td>';
                $visualizar .= '<td style="text-transform: uppercase; font-size: 14px;">'.$ctcbVisualizar->titulo.'</td>';
                $visualizar .= '<td style="text-align: center">';
                if($_SESSION["Editar"] == '1')
                {
                   $visualizar .= '<a href="'.$this->caminhoAbsoluto().'/detalhes-videos/?'.$ctcbVisualizar->video.'" style="color: #000" title="Editar"><i class="far fa-edit"></i></a>';
                }
                if($_SESSION["Excluir"] == '1')
                {
                  $visualizar .= '<a href="#!" style="color: #000" title="Excluir"><i class="far fa-trash-alt"></i></a>';
                }
                $visualizar .= '</td>';
                $visualizar .= '</tr>';
              }
            $visualizar .= "</tbody>";
            $visualizar .= "</table>";
            $visualizar .= $botao;
          }
        return $visualizar;
      }

      /**
       * Método altera o vídeo
       * @access public
       * @param array $dados
       * @return true
       */
      public function alterarVideo(array $dados)
      {
        $titulo = mysqli_real_escape_string($this->conexao,$dados['Titulo']);
        $embed = mysqli_real_escape_string($this->conexao,$dados['Embed']);
        if($titulo != "" || $embed != "")
        {
          mysqli_query($this->conexao,"UPDATE video SET titulo = '".$titulo."', embed = '".$embed."' WHERE video = '".$dados["Key"]."';");
          $_SESSION["Sucesso"] = time() + 5;
          return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-videos/?".$dados["Key"]."';</script>";
        }
      }

      /**
       * Método cadastra o vídeo
       * @access public
       * @param array $dados
       * @return true
       */
      public function cadastrarVideo(array $dados)
      {
        $titulo = mysqli_real_escape_string($this->conexao,$dados['Titulo']);
        $embed = mysqli_real_escape_string($this->conexao,$dados['Embed']);
        $destaque = mysqli_real_escape_string($this->conexao,$dados['Destaque']);
        $sql = mysqli_query($this->conexao,"SELECT * FROM video WHERE embed = '".$embed."';");
        if(mysqli_num_rows($sql) > 0)
        {
            $_SESSION["JaCadastrado"] = time() + 5;
        }
         else
        {
            if($titulo != "" || $embed != "")
            {
              mysqli_query($this->conexao,"INSERT INTO video VALUES(null,'0','".$titulo."','".$embed."',CURDATE(),'".$destaque."');");
              if(mysqli_affected_rows($this->conexao) > 0)
              {
                $id = mysqli_insert_id($this->conexao);
                $idCod = $this->codificar($id);
                mysqli_query($this->conexao,"UPDATE video SET id_cod_video = '".$idCod."' WHERE video = '".$id."' ");
                $_SESSION["Sucesso"] = time() + 5;
                return "<script>window.location.href='".$this->caminhoAbsoluto()."/novo-video/';</script>";
              }
               else
              {
                $_SESSION["Erro"] = time() + 5;
              }
            }
        }
      }


      /**
       * Método lista os usuários
       * @access public
       * @param string $pagina
       * @param string $busca
       * @param int $qnt_result_pg
       * @return $visualizar
       */
        public function listarUsuarios($pagina,$qnt_result_pg,$busca)
        {
          $inicio = ($pagina * $qnt_result_pg) - $qnt_result_pg;
          if($busca == "")
          {
              $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM acesso_admin ORDER BY NomeAdmin ASC LIMIT $inicio, $qnt_result_pg");
          }
           else
          {
             list($buscar,$tirar) = explode("(",$busca);
             $busca = trim($buscar);
             $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM acesso_admin WHERE NomeAdmin ='".$busca."' ORDER BY nome DESC;");
             $botao = "<div class='col-md-12'><div class='text-right'><a href=\"".$this->caminhoAbsoluto()."/atirador/\" class='btn btn-primary btn-sm'><i class=\"fas fa-angle-double-left\"></i> Voltar</a></div></div>";
           }
            $sqlContar = mysqli_query($this->conexao,"SELECT * FROM acesso_admin");
            $result_pg = "SELECT COUNT(IdAdmin) AS num FROM acesso_admin";
            $resultado_pg = mysqli_query($this->conexao, $result_pg);
            $row_pg = mysqli_fetch_assoc($resultado_pg);
            $quantidade_pg = ceil($row_pg['num'] / $qnt_result_pg);
            $max_links = 2;
            $paginacao = "<a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario(1, $qnt_result_pg)'>Primeira</a> ";
            for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++)
            {
            	if($pag_ant >= 1)
              {
            		 $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_ant, $qnt_result_pg)'>$pag_ant </a> ";
            	}
            }
            $paginacao .= "<a href='#' class='btn btn-dark btn-sm'> $pagina </a>";
            for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++)
            {
          	   if($pag_dep <= $quantidade_pg)
               {
          		    $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_dep, $qnt_result_pg)'>$pag_dep</a> ";
               }
            }
            $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($quantidade_pg, $qnt_result_pg)'>Última</a>";
            $visualizar = '<div class="row">';
            $visualizar .= "<div class=\"col-md-4 text-left\">Atiradores cadastrados: <strong> ".mysqli_num_rows($sqlContar)."</strong></div>";
            $visualizar .= "<div class=\"col-md-8 text-right\">".$paginacao."</div>";
            $visualizar .= '</div>';
            $visualizar .= '<table class="table table-sm table-bordered table-striped" style="margin-top: 10px; background: #FFF">
                              <thead>
                                <tr>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Nome</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Permissão</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Ação</th>
                                </tr>
                              </thead>
                              <tbody>';
            if(mysqli_num_rows($sqlVisualizar) == 0)
            {
              $visualizar .= '<tr><td colspan="6" style="color: red; text-align: center; font-weight: bold">Não existem administradores cadastrados</td></tr>';
            }
             else
            {
              while($ctcbVisualizar = mysqli_fetch_array($sqlVisualizar))
              {
                $permissoesC = ($ctcbVisualizar["Cadastrar"] == '1')?'Cadastrar':null;
                $permissoesD = ($ctcbVisualizar["Editar"] == '1')?'Editar':null;
                $permissoesE = ($ctcbVisualizar["Excluir"] == '1')?'Excluir':null;
                $permissoes = array($permissoesC,$permissoesD,$permissoesE);
                 // $permissao = array_filter($permissoes, function($item){ return !empty($item); });
                $visualizar .= '<tr>';
                $visualizar .= '<td style="text-transform: uppercase; font-size: 14px;">'.$ctcbVisualizar["NomeAdmin"].'</td>';
                $visualizar .= '<td style="font-size: 14px; text-align: center">'.implode(",",$permissoes).'</td>';
                $visualizar .= '<td style="text-align: center">';
                if($_SESSION["Editar"] == '1')
                {
                    $visualizar .= '<a href="'.$this->caminhoAbsoluto().'/detalhes-usuarios/?'.$ctcbVisualizar["IdCodAdmin"].'" style="color: #000" title="Editar"><i class="far fa-edit"></i></a>';
                }
                if($_SESSION["Excluir"] == '1')
                {
                    $visualizar .= '<a href="#!" style="color: #000" title="Excluir"><i class="far fa-trash-alt"></i></a>';
                }

                 $visualizar .= '</td>';
                $visualizar .= '</tr>';
              }
            $visualizar .= "</tbody>";
            $visualizar .= "</table>";
            $visualizar .= $botao;
          }
        return $visualizar;
      }

       /**
       * Método cadastra os usuários
       * @access public
       * @param array $dados
       * @return true
       */
      public function cadastrarUsuarios(array $dados)
      {
        $nome = mysqli_real_escape_string($this->conexao,$dados['Nome']);
        $login = mysqli_real_escape_string($this->conexao,$dados['Login']);
        $senha = mysqli_real_escape_string($this->conexao,$dados['Senha']);
        $senha = $this->codificar($senha);
        $cadastrar = mysqli_real_escape_string($this->conexao,$dados['Cadastrar']);
        $cadastrar = ($cadastrar == '1')?'1':'0';
        $editar = mysqli_real_escape_string($this->conexao,$dados['Editar']);
        $editar = ($editar == '1')?'1':'0';
        $excluir = mysqli_real_escape_string($this->conexao,$dados['Excluir']);
        $excluir = ($excluir == '1')?'1':'0';
        $sql = mysqli_query($this->conexao,"SELECT * FROM acesso_admin WHERE LoginAdmin = '".$loginAdmin."';");
        if(mysqli_num_rows($sql) > 0)
        {
          $_SESSION["JaCadastrado"] = time() + 5;
        }
         else
        {
          mysqli_query($this->conexao,"INSERT INTO acesso_admin (NomeAdmin,LoginAdmin,SenhaAdmin,Cadastrar,Editar,Excluir) VALUES('".$nome."','".$login."','".$senha."','".$cadastrar."','".$editar."','".$excluir."');");
          if(mysqli_affected_rows($this->conexao) > 0)
          {
            $id = mysqli_insert_id($this->conexao);
            $idCod = $this->codificar($id);
            mysqli_query($this->conexao,"UPDATE acesso_admin SET IdCodAdmin = '".$idCod."' WHERE IdAdmin = '".$id."';");
            $_SESSION["Sucesso"] = time() + 5;
            return "<script>window.location.href='".$this->caminhoAbsoluto()."/novo-usuario/';</script>";
          }
           else
          {
            $_SESSION["Erro"] = time() + 5;
          }
        }
      }

      /**
       * Método altera o usuário
       * @access public
       * @param array $dados
       * @return true
       */
      public function alterarUsuarios(array $dados)
      {
        $nome = mysqli_real_escape_string($this->conexao,$dados['Nome']);
        $login = mysqli_real_escape_string($this->conexao,$dados['Login']);
        $senha = mysqli_real_escape_string($this->conexao,$dados['Senha']);
        $cadastrar = mysqli_real_escape_string($this->conexao,$dados['Cadastrar']);
        $cadastrar = ($cadastrar == '1')?'1':'0';
        $editar = mysqli_real_escape_string($this->conexao,$dados['Editar']);
        $editar = ($editar == '1')?'1':'0';
        $excluir = mysqli_real_escape_string($this->conexao,$dados['Excluir']);
        $excluir = ($excluir == '1')?'1':'0';
        if($senha == "")
        {
          mysqli_query($this->conexao,"UPDATE acesso_admin
                                         SET NomeAdmin = '".$nome."',
                                             LoginAdmin = '".$login."',
                                             Cadastrar = '".$cadastrar."',
                                             Editar = '".$editar."',
                                             Excluir = '".$excluir."'
                                        WHERE IdCodAdmin = '".$dados["Key"]."';");
        }
         else
        {
           $senha = $this->codificar($senha);
           mysqli_query($this->conexao,"UPDATE acesso_admin
                                          SET NomeAdmin = '".$nome."',
                                              LoginAdmin = '".$login."',
                                              SenhaAdmin = '".$senha."',
                                              Cadastrar = '".$cadastrar."',
                                              Editar = '".$editar."',
                                              Excluir = '".$excluir."'
                                         WHERE IdCodAdmin = '".$dados["Key"]."';");
        }
       $_SESSION["Sucesso"] = time() + 5;
       return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-usuarios/?".$dados["Key"]."';</script>";
      }

      /**
       * Método lista os eventos
       * @access public
       * @param string $pagina
       * @param $busca
       * @param int $qnt_result_pg
       * @return $visualizar
       */
        public function listarEventos($pagina,$qnt_result_pg,$busca)
        {
          $inicio = ($pagina * $qnt_result_pg) - $qnt_result_pg;
          if($busca == "")
          {
              $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM evento ORDER BY data_inicio DESC LIMIT $inicio, $qnt_result_pg");
           }
            else
           {
             list($buscar,$tirar) = explode("(",$busca);
             $busca = trim($buscar);
             $sqlVisualizar = mysqli_query($this->conexao,"SELECT * FROM evento WHERE nome ='".$busca."' ORDER BY nome DESC;");
             $botao = "<div class='col-md-12'><div class='text-right'><a href=\"".$this->caminhoAbsoluto()."/eventos/\" class='btn btn-primary btn-sm'><i class=\"fas fa-angle-double-left\"></i> Voltar</a></div></div>";
           }
            $sqlContar = mysqli_query($this->conexao,"SELECT * FROM evento");
            $result_pg = "SELECT COUNT(evento) AS num FROM evento";
            $resultado_pg = mysqli_query($this->conexao, $result_pg);
            $row_pg = mysqli_fetch_assoc($resultado_pg);
            $quantidade_pg = ceil($row_pg['num'] / $qnt_result_pg);
            $max_links = 2;
            $paginacao = "<a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario(1, $qnt_result_pg)'>Primeira</a> ";
            for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++)
            {
            	if($pag_ant >= 1)
              {
            		 $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_ant, $qnt_result_pg)'>$pag_ant </a> ";
            	}
            }
            $paginacao .= "<a href='#' class='btn btn-dark btn-sm'> $pagina </a>";
            for ($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++)
            {
          	   if($pag_dep <= $quantidade_pg)
               {
          		    $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($pag_dep, $qnt_result_pg)'>$pag_dep</a> ";
               }
            }
            $paginacao .= " <a href='#' class='btn btn-primary btn-sm' onclick='listar_usuario($quantidade_pg, $qnt_result_pg)'>Última</a>";
            $visualizar = '<div class="row">';
            $visualizar .= "<div class=\"col-md-4 text-left\">Atiradores cadastrados: <strong> ".mysqli_num_rows($sqlContar)."</strong></div>";
            $visualizar .= "<div class=\"col-md-8 text-right\">".$paginacao."</div>";
            $visualizar .= '</div>';
            $visualizar .= '<table class="table table-sm table-bordered table-striped" style="margin-top: 10px; background: #FFF">
                              <thead>
                                <tr>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Nome</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Data Início</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Data Término</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Clubes</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Provas</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Atiradores</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Ação</th>
                                </tr>
                              </thead>
                              <tbody>';
            if(mysqli_num_rows($sqlVisualizar) == 0)
            {
              $visualizar .= '<tr><td colspan="6" style="color: red; text-align: center; font-weight: bold">Não existem eventos cadastrados</td></tr>';
            }
             else
            {
              while($ctcbVisualizar = mysqli_fetch_object($sqlVisualizar))
              {
                list($anoI,$mesI,$diaI) = explode("-",$ctcbVisualizar->data_inicio);
                $dataInicio = $diaI."/".$mesI."/".$anoI;
                list($anoT,$mesT,$diaT) = explode("-",$ctcbVisualizar->data_termino);
                $dataTermino = $diaT."/".$mesT."/".$anoT;
                $visualizar .= '<tr>';
                $visualizar .= '<td style="text-transform: uppercase; font-size: 14px;"><i class="fas fa-caret-right"></i> '.$ctcbVisualizar->nome.'</td>';
                $visualizar .= '<td style="font-size: 14px; text-align: center">'.$dataInicio.'</td>';
                $visualizar .= '<td style="font-size: 14px; text-align: center">'.$dataTermino.'</td>';
                $sqlClubes = mysqli_query($this->conexao,"SELECT * FROM evento_local WHERE evento = '".$ctcbVisualizar->evento."';");
                $peClubes = mysqli_fetch_object($sqlClubes);
                $contarClubes = mysqli_num_rows($sqlClubes);
                if($contarClubes == 0){
                   $visualizar .= '<td style="text-align: center">'.$contarClubes.'</td>';
                }
                 else
                {
                  $visualizar .= '<td style="text-align: center"><a href="'.$this->caminhoAbsoluto().'/lancamentos-clubes/?key='.$ctcbVisualizar->idcodevento.'" id="btnVisualizarCasas" class="lancamentos" data-id="'.$ctcbVisualizar->evento.'" data-toggle="modal-3" data-target=".bd-example-modal-lg">'.$contarClubes.'</a></td>';
                }
                $sqlProvas = mysqli_query($this->conexao,"SELECT * FROM evento_prova WHERE evento = '".$ctcbVisualizar->evento."';");
                $contarProvas = mysqli_num_rows($sqlProvas);
                $visualizar .= '<td style="text-align: center">'.$contarProvas.'</td>';
                $sqlEventos = mysqli_query($this->conexao,"SELECT * FROM evento_atirador WHERE evento = '".$ctcbVisualizar->evento."';");
                $contarEventos = mysqli_num_rows($sqlEventos);
                $visualizar .= '<td style="text-align: center">'.$contarEventos.'</td>';
                $visualizar .= '<td style="text-align: center">';
                if($_SESSION["Editar"] == '1')
                {
                    $visualizar .= '<a href="'.$this->caminhoAbsoluto().'/detalhes-evento/?'.$ctcbVisualizar->idcodevento.'" style="color: #000" title="Editar"><i class="far fa-edit"></i></a> ';
                }
                if($_SESSION["Excluir"] == '1')
                {
                  $visualizar .= '<a href="#!" style="color: #000" title="Excluir Evento"><i class="far fa-trash-alt"></i></a>';
                }
                $visualizar .= '</td>';
              }
            $visualizar .= "</tbody>";
            $visualizar .= "</table>";
            $visualizar .= $botao;
          }
        return $visualizar;
      }

       /**
       * Método lista os clubes
       * @access public
       * @param int $id
       * @return string @visualizar
       */
      public function listarLancamentoClubes($id)
      {
        $idCod = $id;
        $sqlEvento = mysqli_query($this->conexao,"SELECT * FROM evento WHERE  idcodevento = '".$id."';");
        $ctcbEvento = mysqli_fetch_object($sqlEvento);
        $id = $ctcbEvento->evento;
        $visualizar = '<div style="text-align: center"><h4>'.$ctcbEvento->nome.'</h4></div>';
        $visualizar .= '<table class="table table-sm table-bordered table-striped" style="margin-top: 10px; background: #FFF">
                              <thead>
                                <tr>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Clube</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Atiradores</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Visualizar</th>
                                  <th scope="col" style="background: #4682B4; color: #FFF; text-align: center">Bloqueio</th>
                                </tr>
                              </thead>
                              <tbody>';
        $sqlEventosLocal = mysqli_query($this->conexao,"SELECT * FROM evento_local WHERE evento = '".$id."' GROUP BY clube;");
        while($ctcb = mysqli_fetch_object($sqlEventosLocal)){
              $sqlClubes = mysqli_query($this->conexao,"SELECT * FROM clube WHERE clube = '".$ctcb->clube."';");
              while($ctcbClubes = mysqli_fetch_object($sqlClubes))
              {
               // $sqlContar = mysqli_query($this->conexao,"SELECT * FROM evento_local WHERE clube = '".$ctcbClubes->clube."';");
                $sqlContar = mysqli_query($this->conexao,"SELECT * FROM evento_atirador WHERE evento = '".$id."' and evento_local = '".$ctcb->evento_local."';");
                $ctcbContar = mysqli_fetch_object($sqlContar);
                $visualizar .= '<tr>';
                $visualizar .= '<td><i class="fas fa-caret-right"></i> '.$ctcbClubes->nome.'</td>';
                $numAtiradores = (mysqli_num_rows($sqlContar) == 0)?0:'<a href="#!" id="btnVisualizarCasas" data-id="'.$id.'_'.$ctcbContar->evento_local.'" data-toggle="modal-3" data-target=".bd-example-modal-lg">'.mysqli_num_rows($sqlContar).'</a>';
                $visualizar .= '<td style="text-align: center">'.$numAtiradores.'</td>';
                $visualizar .= '<td style="text-align: center"><i class="fas fa-list-ol"></i></td>';
                $sqlBloqueio = mysqli_query($this->conexao,"SELECT *, DATE_FORMAT(DataBloqueio,'%d/%m/%Y') AS DataDoBloqueio FROM bloqueio_clubes WHERE IdClubes = '".$ctcb->clube."';");
                $ctcbBloqueio = mysqli_fetch_object($sqlBloqueio);
                $botao = (mysqli_num_rows($sqlBloqueio) == 0)?'<button class="btn btn-warning btn-sm" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/lancamentos-clubes/?key='.$idCod.'&clube='.$ctcb->clube.'&bloquear=s\'">Bloquear</button>':'<button class="btn btn-danger btn-sm"onclick="window.location.href=\''.$this->caminhoAbsoluto().'/lancamentos-clubes/?key='.$idCod.'&clube='.$ctcb->clube.'&bloquear=n\'">Desbloquear</button><br><small>'.$ctcbBloqueio->DataDoBloqueio.'</small>';
                $visualizar .= '<td style="text-align: center">'.$botao.'</td>';
                $visualizar .= '</tr>';
              }
        }
        $visualizar .= '</tbody>
                      </table>';
        $visualizar .= "<div class=\"modal fade bd-example-modal-lg\" id=\"casasRegionais\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"\" aria-hidden=\"true\">
                           <div class=\"modal-dialog modal-lg\">
                               <div>
                                   <div id=\"tela\">
                                   </div>
                               </div>
                           </div>
                       </div>";
        $visualizar .= "<script>
              $(\"table\").on('click',\"#btnVisualizarCasas\", function(){
                  var posts = $(this).attr('data-id');
                  $.post('".$this->caminhoAbsoluto()."/lancamento-clubes.php/', {key: posts}, function(retorno){
                  //  console.log(retorno);
                         $(\"#casasRegionais\").modal({ backdrop: 'static' });
                         $(\"#tela\").html(retorno);
                  });
              });
              </script>";
        return $visualizar;
      }

      /**
       * Método altera o status do clube
       * @access public
       * @param int $id
       * @param string $bloquear
       * @param int $idClube
       * @return true
       */
      public function alterarStatusBloqueio($id,$bloquear,$idClube)
      {
        if($bloquear == 's')
        {
          $sqlEventos = mysqli_query($this->conexao,"SELECT * FROM evento WHERE idcodevento='".$id."';");
          $idEventos = mysqli_fetch_object($sqlEventos);
          mysqli_query($this->conexao,"INSERT INTO bloqueio_clubes VALUES(null,'".$idClube."','".$idEventos->evento."',CURDATE());");
          return "<script>window.location.href='".$this->caminhoAbsoluto()."/lancamentos-clubes/?key=".$id."';</script>";
        }
        if($bloquear == 'n')
        {
          mysqli_query($this->conexao,"DELETE FROM bloqueio_clubes WHERE IdClubes = '".$idClube."';");
          return "<script>window.location.href='".$this->caminhoAbsoluto()."/lancamentos-clubes/?key=".$id."';</script>";
        }
      }

      /**
       * Método altera o status do bloqueio clube
       * @access public
       * @param string $bloquear
       * @param int $idClube
       * @return true
       */
      public function alterarStatusBloqueioClubes($bloquear,$idClube)
      {
        if($bloquear == 's')
        {
          mysqli_query($this->conexao,"INSERT INTO bloqueio_clubes VALUES(null,'".$idClube."',CURDATE());");
          return "<script>window.location.href='".$this->caminhoAbsoluto()."/clubes/';</script>";
        }
        if($bloquear == 'n')
        {
          mysqli_query($this->conexao,"DELETE FROM bloqueio_clubes WHERE IdClubes = '".$idClube."';");
          return "<script>window.location.href='".$this->caminhoAbsoluto()."/clubes/';</script>";
        }
      }

  /**
   * Método lista os atiradores e seus lançamentos dos clues
   * @access public
   * @param int $id
   * @return string $visualizar
   */  
    public function listarAtiradoresLancamentoClubes($id)
    {
      list($evento,$eventoLocal) = explode('_',$id);
      $sqlEventoA = mysqli_query($this->conexao,"SELECT * FROM evento_atirador WHERE evento = '".$evento."' and evento_local = '".$eventoLocal."';");
      $ctcbEventoA = mysqli_fetch_object($sqlEventoA);
      $sqlEventoL = mysqli_query($this->conexao,"SELECT * FROM evento_local WHERE evento_local = '".$ctcbEventoA->evento_local."';");
      $ctcbEventoL = mysqli_fetch_object($sqlEventoL);
      $sqlClubes = mysqli_query($this->conexao,"SELECT * FROM clube WHERE clube = '".$ctcbEventoL->clube."';");
      $ctcbClubes = mysqli_fetch_object($sqlClubes);
      $visualizar = '<h4>'.$ctcbClubes->nome.'</h4><br>';
      $sql = mysqli_query($this->conexao,"SELECT * FROM evento_atirador WHERE evento = '".$evento."' and evento_local = '".$eventoLocal."';");
      while($ctcb = mysqli_fetch_object($sql))
      {
        $sqlAtiradores = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE atirador = '".$ctcb->atirador."';");
        $ctcbAtirador = mysqli_fetch_object($sqlAtiradores);
        if(mysqli_num_rows($sqlAtiradores) > 0)
        {
          $visualizar .= '<i class="fas fa-user"></i> '.$ctcbAtirador->nome.'<br>';
        }
      }
     return $visualizar;
    }

  /**
   * Método cadastra os eventos
   * @access public
   * @param array $dados
   * @return true
   */  
    public function cadastrarEventos(array $dados)
    {
      $evento = mysqli_real_escape_string($this->conexao,$dados['Titulo']);
      $dataInicio = mysqli_real_escape_string($this->conexao,$dados['DataInicio']);
      $dataTermino = mysqli_real_escape_string($this->conexao,$dados['DataTermino']);
      list($diaI,$mesI,$anoI) = explode("/",$dataInicio);
      $dataInicio = $anoI."-".$mesI."-".$diaI;
      list($diaT,$mesT,$anoT) = explode("/",$dataTermino);
      $dataTermino = $anoT."-".$mesT."-".$diaT;
      mysqli_query($this->conexao,"INSERT INTO evento VALUES(null,'0','".$evento."','".$dataInicio."','".$dataTermino."');");
      if(mysqli_affected_rows($this->conexao) > 0)
      {
        $id = mysqli_insert_id($this->conexao);
        $idCod = $this->codificar($id);
        mysqli_query($this->conexao,"UPDATE evento SET idcodevento = '".$idCod."' WHERE evento = '".$id."';");
        $_SESSION["Sucesso"] = time() + 5;
        return "<script>window.location.href='".$this->caminhoAbsoluto()."/novo-evento/'</script>";
      }
       else
      {
        $_SESSION["Erro"] = time() + 5;
      }
    }

  /**
   * Método altera os eventos
   * @access public
   * @param array $dados
   * @return true
   */  
      public function alterarEventos(array $dados)
      {
        $titulo = mysqli_real_escape_string($this->conexao,$dados['Titulo']);
        $dataInicio = mysqli_real_escape_string($this->conexao,$dados['DataInicio']);
        $dataTermino = mysqli_real_escape_string($this->conexao,$dados['DataTermino']);
        if($titulo != "" || $dataInicio != "" || $dataTermino != "")
        {
          list($diaI,$mesI,$anoI) = explode("/",$dataInicio);
          $dataInicio = $anoI."-".$mesI."-".$diaI;
          list($diaT,$mesT,$anoT) = explode("/",$dataTermino);
          $dataTermino = $anoT."-".$mesT."-".$diaT;
          mysqli_query($this->conexao,"UPDATE evento SET nome = '".$titulo."', data_inicio = '".$dataInicio."', data_termino = '".$dataTermino."' WHERE idcodevento = '".$dados["Key"]."';");
          $_SESSION["Sucesso"] = time() + 5;
          return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-evento/?".$dados["Key"]."';</script>";
        }
      }

   /**
   * Método lista os eventos do mês corrente
   * @access public
   * @param null
   * @return string $visualizar
   */  
      public function listarEventosMes()
      {
        $sql = mysqli_query($this->conexao,"SELECT *, DATE_FORMAT(data_inicio,'%d/%m/%Y') AS DataInicio, DATE_FORMAT(data_termino,'%d/%m/%Y') AS DataTermino FROM `evento` WHERE DATE_FORMAT(`data_inicio`,'%Y-%m') = '".date("Y-m")."';");
        $visualizar = '';
        while($ctcb = mysqli_fetch_object($sql))
        {
          $visualizar .= '<span style="font-weight: bold">'.$ctcb->nome.'</span><br><br>';
          $visualizar .= '<i class="fas fa-calendar-day"></i><strong> Início:</strong> '.$ctcb->DataInicio.'<br>';
          $visualizar .= '<i class="fas fa-calendar-minus"></i><strong> Término:</strong> '.$ctcb->DataTermino.'<br>';
          $sqlEA = mysqli_query($this->conexao,"SELECT * FROM evento_atirador WHERE evento = '".$ctcb->evento."';");
          $contarEA = (mysqli_num_rows($sqlEA) < 10)?'0'.mysqli_num_rows($sqlEA):mysqli_num_rows($sqlEA);
          $visualizar .= '<i class="fas fa-user-alt"></i><strong> Atiradores:</strong> '.$contarEA.'<br>';
          $sqlCB = mysqli_query($this->conexao,"SELECT * FROM evento_local WHERE evento = '".$ctcb->evento."';");
          $contarCB = (mysqli_num_rows($sqlCB) < 10)?'0'.mysqli_num_rows($sqlCB):mysqli_num_rows($sqlCB);
          $visualizar .= '<i class="fas fa-landmark"></i><strong> Clubes:</strong> '.$contarCB.'<br>';
          if (mysqli_num_rows($sql) > 1)
          {
             $visualizar .= '<hr>';
          }
          $visualizar .= '<br><button class="btn btn-primary btn-sm btn-block" style="font-weight: bold" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/eventos/\'" title="Ver todos os eventos">Ver Todos</button>';
        }
        return $visualizar;
      }

      /**
       * Método lista os eventos dos clubes
       * @access public
       * @param null
       * @return string  $visualizar
       */  
        public function listarClubesEventos()
        {
         $sql = mysqli_query($this->conexao, "SELECT * FROM clube ORDER BY nome ASC;");
         while($ctcb = mysqli_fetch_object($sql))
         {
           $visualizar .= '<tr>';
           $visualizar .= '<td><i class="fas fa-caret-right"></i> '.$ctcb->nome.'</td>';
           $visualizar .= '<td>'.$ctcb->telefone.'</td>';
           $sqlEvento = mysqli_query($this->conexao,"SELECT * FROM evento WHERE idcodevento = '".$_SESSION["Evento"]."';");
           $ctcbEvento = mysqli_fetch_object($sqlEvento);
           $sqlEventos = mysqli_query($this->conexao,"SELECT * FROM evento_local WHERE evento = '".$ctcbEvento->evento."' AND clube = '".$ctcb->clube."';");
           $ctcbEventos = mysqli_fetch_object($sqlEventos);
           $botao = (mysqli_num_rows($sqlEventos) == 0)?'<button class="btn btn-primary btn-sm" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/adicionar-clube-evento/?'.$ctcb->clube.'\'">Adicionar</button>':'<a href="#!" id="btnVisualizarCasas" data-id="'.$ctcbEventos->evento_local.'" data-toggle="modal-3" style="color: #000"><i class="far fa-trash-alt fa-lg"></i></a>';
           $visualizar .= '<td class="text-center">'.$botao.'</td>';
           $visualizar .= '</tr>';
         }
         $visualizar .= "div class=\"modal fade\" id=\"casasRegionais\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"\" aria-hidden=\"true\">
                           <div class=\"modal-dialog\">
                               <div>
                                   <div id=\"tela\">
                                   </div>
                               </div>
                           </div>
                       </div>";
        $visualizar .= "<script>
              $(\"table\").on('click',\"#btnVisualizarCasas\", function(){
                  var posts = $(this).attr('data-id');
                  $.post('".$this->caminhoAbsoluto()."/excluir-evento-clube/', {key: posts}, function(retorno){
                   // console.log(retorno);
                         $(\"#casasRegionais\").modal({ backdrop: 'static' });
                         $(\"#tela\").html(retorno);
                  });
              });
              </script>";
      return $visualizar;
    }

    /**
       * Método adiciona o evento no clube
       * @access public
       * @param string $clube
       * @return true
    */  
    public function adicionarClubeEvento($clube)
    {
      $sqlVerificar = mysqli_query($this->conexao,"SELECT * FROM clube WHERE clube = '".$clube."';");
      if(mysqli_num_rows($sqlVerificar) > 0)
      {
        $sqlEvento = mysqli_query($this->conexao,"SELECT * FROM evento WHERE idcodevento = '".$_SESSION["Evento"]."';");
        $ctcbEvento = mysqli_fetch_object($sqlEvento);
        mysqli_query($this->conexao,"INSERT INTO evento_local VALUES(null,'".$ctcbEvento->evento."','".$clube."');");
        if(mysqli_affected_rows($this->conexao) > 0)
        {
          $_SESSION["SucessoClube"] = time() + 5;
          return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-evento/?".$_SESSION["Evento"]."#mostrar'</script>";
        }
      }
    }

    /**
     * Método excluir o evento local
     * @access public
     * @param int $evento
     * @return true
     */  
  public function excluirEventoLocal($evento)
  {
     mysqli_query($this->conexao,"DELETE FROM evento_local WHERE evento_local = '".$evento."';");
     $_SESSION["SucessoExcluirClube"] = time() + 5;
     return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-evento/?".$_SESSION["Evento"]."#mostrar'</script>";
  }

  /**
   * Método lista os eventos dos clubes
   * @access public
   * @param null
   * @return string  $visualizar
   */  
  public function listarProvasEventos()
  {
           $sql = mysqli_query($this->conexao, "SELECT * FROM prova ORDER BY nome ASC;");
           while($ctcb = mysqli_fetch_object($sql))
           {
             $visualizar .= '<tr>';
             $visualizar .= '<td><i class="fas fa-caret-right"></i> '.$ctcb->nome.'</td>';
             $sqlEvento = mysqli_query($this->conexao,"SELECT * FROM evento WHERE idcodevento = '".$_SESSION["Evento"]."';");
             $ctcbEvento = mysqli_fetch_object($sqlEvento);
             $sqlEventoss = mysqli_query($this->conexao,"SELECT * FROM evento_prova WHERE evento = '".$ctcbEvento->evento."' AND prova = '".$ctcb->prova."';");
             $ctcbEventoss = mysqli_fetch_object($sqlEventoss);
             $botao = (mysqli_num_rows($sqlEventoss) == 0)?'<button class="btn btn-primary btn-sm" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/adicionar-prova-evento/?'.$ctcb->prova.'\'">Adicionar</button>':'<a href="#!" id="btnProvas" data-id="'.$ctcbEventoss->evento_prova.'" data-toggle="modal-3" style="color: #000"><i class="far fa-trash-alt fa-lg"></i></a>';
             $visualizar .= '<td class="text-center">'.$botao.'</td>';
             $visualizar .= '</tr>';
           }
           $visualizar .= " <div class=\"modal fade\" id=\"modalProvas\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"\" aria-hidden=\"true\">
                             <div class=\"modal-dialog\">
                                 <div>
                                     <div id=\"telaProvas\">
                                     </div>
                                 </div>
                             </div>
                         </div>";
          $visualizar .= "<script>
                $(\"table\").on('click',\"#btnProvas\", function(){
                    var posts = $(this).attr('data-id');
                    $.post('".$this->caminhoAbsoluto()."/excluir-evento-prova/', {key: posts}, function(retorno){
                     // console.log(retorno);
                           $(\"#modalProvas\").modal({ backdrop: 'static' });
                           $(\"#telaProvas\").html(retorno);
                    });
                });
                </script>";
        return $visualizar;
      }

      /**
       * Método adiciona uma prova em um evento
       * @access public
       * @param int $prova
       * @return true
       */  
      public function adicionarProvaEvento($prova)
      {
        $sqlVerificar = mysqli_query($this->conexao,"SELECT * FROM prova WHERE prova = '".$prova."';");
        if(mysqli_num_rows($sqlVerificar) > 0)
        {
          $sqlEvento = mysqli_query($this->conexao,"SELECT * FROM evento WHERE idcodevento = '".$_SESSION["Evento"]."';");
          $ctcbEvento = mysqli_fetch_object($sqlEvento);
          mysqli_query($this->conexao,"INSERT INTO evento_prova VALUES(null,'".$ctcbEvento->evento."','".$prova."');");
          if(mysqli_affected_rows($this->conexao) > 0)
          {
            $_SESSION["SucessoProva"] = time() + 5;
            return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-evento/?".$_SESSION["Evento"]."#mostrar'</script>";
          }
        }
      }

    /**
       * Método exclui a prova local
       * @access public
       * @param int $evento
       * @return true
       */    
    public function excluirProvaLocal($evento)
    {
       mysqli_query($this->conexao,"DELETE FROM evento_prova WHERE evento_prova = '".$evento."';");
       $_SESSION["SucessoExcluirProva"] = time() + 5;
       return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-evento/?".$_SESSION["Evento"]."#mostrar'</script>";
    }

    /**
       * Método envia a senha para o atirador
       * @access public
       * @param int $idAtirador
       * @return string $visualizar
       */  
    public function enviarSenhaAtirador($idAtirador)
    {
      $sqlAtirador = mysqli_query($this->conexao,"SELECT * FROM atirador WHERE atirador = '".$idAtirador."';");
      $ctcbVisualizar = mysqli_fetch_object($sqlAtirador);
      $visualizar = '<div align="center">';
      if($_SESSION["IdAdmin"] != 5)
      {
      $visualizar .= '<button class="btn btn-primary btn-sm" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/enviar-senha-atiradores/?'.$ctcbVisualizar->id_cod_atirador.'\';" title="Enviar nova senha para '.$ctcbVisualizar->nome.'">Enviar <i class="far fa-paper-plane"></i></button><br>';
      $visualizar .= ' ' .$ctcbVisualizar->email;
      }
      $visualizar .= '</div>';
      return $visualizar;
    }

     /**
       * Método envia a senha para o clube
       * @access public
       * @param int $idClube
       * @return string $visualizar
       */  
    public function enviarSenhaClubes($idClube)
    {
        $sqlClube = mysqli_query($this->conexao,"SELECT * FROM clube WHERE clube = '".$idClube."';");
        $ctcbVisualizar = mysqli_fetch_object($sqlClube);
        $visualizar = '<div align="center">';
        if($_SESSION["IdAdmin"] != 5)
        {
            $visualizar .= '<button class="btn btn-primary btn-sm" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/enviar-senha-clubes/?'.$ctcbVisualizar->id_cod_clube.'\';" title="Enviar nova senha para '.$ctcbVisualizar->nome.'">Enviar <i class="far fa-paper-plane"></i></button><br>';
            $visualizar .= ' ' .$ctcbVisualizar->email;
        }
        $visualizar .= '</div>';
        return $visualizar;
    }

     /**
       * Método lista os dados financeiro do atirador
       * @access public
       * @param int $idAtirador
       * @return string $visualizar
       */  
    public function dadosFinanceirosAtirador($idAtirador)
    {
      $sqlFinanceiro = mysqli_query($this->conexao,"SELECT * FROM atirador_pagamento WHERE atirador = '".$idAtirador."' ORDER BY atirador_pagamento DESC LIMIT 2;");
      if(mysqli_num_rows($sqlFinanceiro) == 0)
      {
         if($_SESSION["IdAdmin"] != 5)
         {
            $visualizar = '<div class="text-center"><button class="btn btn-success btn-sm" title="Lançar Pagamento" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/lancar-pagamento-atirador/?'.$idAtirador.'\'"><i class="fas fa-file-invoice-dollar fa-lg"></i> Lançar Pagamento</button></div>';
         }
      }
       else
      {
        if($_SESSION["IdAdmin"] != 5)
        {
          $visualizar = '<div class="text-center"><button class="btn btn-warning btn-sm" title="Lançar Pagamento" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/lancar-pagamento-atirador/?'.$idAtirador.'\'"><i class="fas fa-file-invoice-dollar fa-lg"></i> Lançar Pagamento</button></div><br>';
        }
        while($ctcb = mysqli_fetch_object($sqlFinanceiro))
          {
          $visualizar .= '<div style="font-family: Arial">';
          $visualizar .= '<strong>Anuidade:</strong> '.$ctcb->anuidade.'<br>';
          $visualizar .= '<strong>Valor cobrado:</strong> R$ '.number_format($ctcb->valor_cobrado,2,',','.').'<br>';
          $visualizar .= '<strong>Valor pago:</strong> R$ '.number_format($ctcb->valor_pago,2,',','.').'<br>';
          list($ano,$mes,$dia) = explode("-",$ctcb->data_vencimento);
          $dataVencimento = $dia."/".$mes."/".$ano;
          $visualizar .= '<strong>Valor vencimento:</strong> '.$dataVencimento.'<br>';
          $visualizar .= '<div class="text-center">';
          if($ctcb->valor_pago == '0.00')
          {
              $visualizar .= '<button class="btn btn-danger btn-sm">Em Aberto</button>';
          }
           else
          {
              $visualizar .= '<button class="btn btn-success btn-sm">Pago <i class="fas fa-check"></i></button>';
          }
          if($_SESSION["IdAdmin"] != 5)
          {
             $visualizar .= '&nbsp; <button class="btn btn-info btn-sm" onclick="window.location.href=\''.$this->caminhoAbsoluto().'/alterar-pagamento-atirador/?'.$ctcb->atirador_pagamento.'\'">Corrigir</button>';
             $visualizar .= '&nbsp; <a href="#!" class="btn btn-danger btn-sm excluir" id="btnVisualizarCasas" data-id="'.$ctcb->atirador_pagamento.'" data-toggle="modal-3" ><i class="far fa-trash-alt"></i> Excluir</a><br><br>';
          }
          $visualizar .= "<div class=\"modal fade\" id=\"casasRegionais\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"\" aria-hidden=\"true\">
                           <div class=\"modal-dialog\">
                               <div>
                                   <div id=\"tela\">
                                   </div>
                               </div>
                           </div>
                       </div>";
          $visualizar .= '<script>
                          $(document).on("click","#btnVisualizarCasas", function(){
                              var posts = $(this).attr("data-id");
                              $.post("'.$this->caminhoAbsoluto().'/excluir-pagamento-atirador/", {key: posts}, function(retorno){
                               // console.log(retorno);
                                     $("#casasRegionais").modal({ backdrop: "static" });
                                     $("#tela").html(retorno);
                              });
                          });
                          </script>';
          if(mysqli_num_rows($sqlFinanceiro) > 1)
          {
            $visualizar .= '<hr>';
          }
      $visualizar .= '</div>';
      $visualizar .= '</div>';
        }
      }
      return $visualizar;
    }

     /**
       * Método excluir o pagamento do atirador
       * @access public
       * @param int $idPagamento
       * @param int $idAtirador
       * @return true
       */  
    public function excluirPagamentoAtirador($idPagamento,$idAtirador)
    {
      mysqli_query($this->conexao,"DELETE FROM atirador_pagamento WHERE atirador_pagamento = '".$idPagamento."';");
      $_SESSION["SucessoExcluir"] = time() + 5;
      return "<script>window.location.href='".$this->caminhoAbsoluto()."/detalhes-atirador/?".$idAtirador."'</script>";
    }

    /**
     * Método lista em um combox somente os estados que contém atiradores
     * Encontra-se na página atiradores.php
     * @access public
     * @param null
     * @return string $visualizar
     */
    public function listarEstadoAtiradores()
    {
      $visualizar = '';
      $sql = mysqli_query($this->conexao,"SELECT * FROM atirador A
                                             INNER JOIN estado E
                                             ON A.estado = E.estado
                                             WHERE A.estado <> ''
                                             GROUP BY A.estado
                                             ORDER BY E.nome;");
      while($ctcb = mysqli_fetch_object($sql))
      {
           $visualizar .= '<option value="'.$ctcb->estado.'">'.$ctcb->nome.'</option>';

      }
      return $visualizar;
    }

  /**
   * Método visualiza genericamente todas as tabelas
   * @access public
   * @param string $tabela
   * @param int $idTabela, $idBusca
   * @return ArrayObject
   */
  public function visualizar($tabela, $idTabela, $idBusca)
  {
     $sqlVisualizar = mysqli_query($this->conexao, "SELECT * FROM " . $tabela . " WHERE " . $idTabela . " = '" . mysqli_real_escape_string($this->conexao, $idBusca) . "';");
     return array(mysqli_num_rows($sqlVisualizar),mysqli_fetch_object($sqlVisualizar));
  }

    /**
   * Método retira os caracteres do CPF e CNPJ
   * Encontra-se na página novo-atirador.php, detalhes-atirador.php
   * @access public
   * @param string $valor
   * @return string $valor
   */
    public function limpaCPF_CNPJ($valor)
    {
      $valor = trim($valor);
      $valor = str_replace(".", "", $valor);
      $valor = str_replace(",", "", $valor);
      $valor = str_replace("-", "", $valor);
      $valor = str_replace("/", "", $valor);
      return $valor;
    }

    /**
   * Método gera a senha aleatória
   * Encontra-se na página novo-atirador.php, detalhes-atirador.php
   * @access public
   * @param int $qtyCaraceters
   * @return string $password
   */
    function generatePassword()
    {
      $qtyCaraceters = 6;
      $smallLetters = str_shuffle('abcdefghijklmnopqrstuvwxyz');
      $capitalLetters = str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ');
      $numbers = (((date('Ymd') / 12) * 24) + mt_rand(800, 9999));
      $numbers .= 1234567890;
      $specialCharacters = str_shuffle('!@#$%');
      $characters = $capitalLetters.$smallLetters.$numbers.$specialCharacters;
      $password = substr(str_shuffle($characters), 0, $qtyCaraceters);
      return $password;
    }

    /**
     * Codifica a senha em 03 métodos de mão única. Sha1, MD5 invertido e crypt
     * @param string $senhaUsuario
     * @return string $codificar
     */
    public function codificar($key)
    {
        $salt = "$" . md5(strrev($key)) . "%";
        $codifica = crypt($key, $salt);
        $codificar = hash('sha512', $codifica);
        return $codificar;
    }

    /**
     * Método para sair do sistema. Encontra-se na página sair.php
     * @access public
     * @param void
     * @return string
     */
    public function sairSistema()
    {
      $_SESSION["LogadoCTCB"] = false;
      unset($_SESSION["DataAcessoCTCB"]);
      unset($_SESSION["HoraAcessoCTCB"]);
      unset($_SESSION["LogadoCTCB"]);
      unset($_SESSION["Cadastrar"]);
      unset($_SESSION["Editar"]);
      unset($_SESSION["Excluir"]);
      session_destroy();
    // $caminhoAbsoluto = "https://".$_SERVER['SERVER_NAME']."/Projetos/CTCB/controle";
    $caminhoAbsoluto = "https://intranet.ctcb.org.br"; // remoto
     return "<script>window.location.href='".$caminhoAbsoluto."/'</script>";
    }

} // Fim da classe
