<?php
error_reporting(0);
session_start();
if($_SESSION["LogadoCTCB"] == false){
  echo "<script>window.location.href='../index.php';</script>";
  exit();
}
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$caminhoAbsoluto = $metodos->caminhoAbsoluto();
if($_POST["Submit"] == "Alterar Senha")
{
  $senha = $_POST["Senha"];
  echo $metodos->alterarSenha($senha);
}
if($_SESSION["Sucesso"] < time())
{
  unset($_SESSION["Sucesso"]);
}
?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>CTCB | Controle de Gestão</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo $caminhoAbsoluto; ?>/css/style.css">
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script>
     function mostrar(valor)
     {
       var valor;
       if(valor == 0)
       {
         document.getElementById('buscarNome').style.display='block';
         document.getElementById('buscarCPF').style.display='none';
         document.getElementById('buscarMatricula').style.display='none';
       }
       if(valor == 1)
       {
         document.getElementById('buscarCPF').style.display='block';
         document.getElementById('buscarNome').style.display='none';
         document.getElementById('buscarMatricula').style.display='none';
       }
       if(valor == 2)
       {
         document.getElementById('buscarMatricula').style.display='block';
         document.getElementById('buscarCPF').style.display='none';
         document.getElementById('buscarNome').style.display='none';
       }
     }
    </script>
    </head>
  <body>
   <div class="container">
     <div class="row header">
          <div class="col-md-6">
            <img src="<?php echo $caminhoAbsoluto; ?>/imagens/logo.png" alt="" class="logo">
         </div>
         <div class="col-md-6 text-right">
           <h3>SISTEMA DE GESTÃO | CTCB</h3>
           <a href="<?php echo $caminhoAbsoluto; ?>/sair/" style="color: #000" alt="Sair do sistema" title="Sair do sistema"><i class="fas fa-power-off"></i> Sair do sistema</a>
         </div>
     </div>
     <div class="row conteudo">
       <nav class="col-md-12 navbar navbar-expand-lg navbar-light bg-light">
         <div class="collapse navbar-collapse navbar-right" id="navbarSupportedContent">
           <ul class="navbar-nav mr-auto">
             <li class="nav-item active">
               <a class="nav-link" href="#">Principal <span class="sr-only">(current)</span></a>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Cadastro
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/atiradores/"><i class="fas fa-caret-right"></i> Atirador</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/categorias/"><i class="fas fa-caret-right"></i> Categoria</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/clubes/"><i class="fas fa-caret-right"></i> Clube</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/despachantes/"><i class="fas fa-caret-right"></i> Despachante</a>
                 <!--
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/estados/"><i class="fas fa-caret-right"></i> Estado</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/nacionalidade/"><i class="fas fa-caret-right"></i> Nacionalidade</a>
               -->
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/modalidades/"><i class="fas fa-caret-right"></i> Modalidade</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/provas/"><i class="fas fa-caret-right"></i> Prova</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Diários
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/noticias/"><i class="fas fa-caret-right"></i> Notícias</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/enviar-emails/"><i class="fas fa-caret-right"></i> Envia E-mail</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/galeria-fotos/"><i class="fas fa-caret-right"></i> Galeria de Fotos</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/videos/"><i class="fas fa-caret-right"></i> Vídeo</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Campeonatos
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/eventos/"><i class="fas fa-caret-right"></i> Evento</a>
               </div>
             </li>
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Financeiro
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pagos/"><i class="fas fa-caret-right"></i> Pagos</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pendentes/"><i class="fas fa-caret-right"></i> Pendentes</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/financeiro-pagos/"><i class="fas fa-caret-right"></i> Valor Mensalidade</a>
               </div>
             </li>
             <!--
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Escritório
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/extensoes/"><i class="fas fa-caret-right"></i> Extensão</a>
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/acesso/"><i class="fas fa-caret-right"></i> Acesso</a>
               </div>
             </li>
           -->
             <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                 Utilitários
               </a>
               <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                 <a class="dropdown-item" href="<?php echo $caminhoAbsoluto; ?>/cadastrar-usuarios/"><i class="fas fa-caret-right"></i> Usuários</a>
               </div>
             </li>
           </ul>
         </div>
       </nav>

      <div class="container" style="margin-top: 10px">
      <?php if($_SESSION["Sucesso"]){ ?>
        <div class="alert alert-success">Senha alterada com sucesso!</div>
      <?php } ?>
   <div class="row" style="margin-top: 10px">
     <div class="col-md-4">
         <div class="tituloCaixa">
          <i class="far fa-calendar-alt"></i> Eventos mês <?php echo $metodos->mesExtenso(date('m')); ?>
         </div>
         <div class="bg-white" style="padding: 10px">
           <?php echo $metodos->listarEventosMes(); ?>
         </div>

         <div class="bg-white" style="margin-top: 10px; padding: 10px">
           <form class="" action="#!" method="post">
            <div class="form-group">
              <label for="senha" style="font-weight: bold">Alterar senha:</label>
              <div class="input-group">
                        <input type="password" name="Senha" class="form-control senha-segura" id="senha" minlength="6" maxlength="12" required>
                        <span class="input-group-btn" id="btn-addon2">
                                <button type="button" class="btn btn-info addon-btn waves-effect waves-light" id="botaoSenha" title="Mostrar senha" onclick="mostrarSenha()">
                                  <i id="ver" class="far fa-eye fa-lg"></i>
                                </button>
                            </span>
                    </div>
             </div>
             <div class="form-group">
               <button type="submit" name="Submit" value="Alterar Senha" class="btn btn-primary btn-block" name="button" style="font-weight: bold">Alterar</button>
             </div>
           </form>
         </div>

         <div style="margin-top: 10px; padding: 10px">
          <button class="btn btn-success btn-lg btn-block" style="font-weight: bold" onclick="window.location.href='relatorios/';"> <i class="fas fa-chart-bar"></i> Relatórios</button>
         </div>

     </div>
     <div class="col-md-8">
       <div class="tituloCaixa">
         <i class="fas fa-hand-holding-usd fa-lg"></i> Pagamentos Pendentes
       </div>

       <div class="row" style="margin-top: 10px">
       <div class="col-md-6">
        <input type="radio" name="Busca" value="Nome" checked onclick="mostrar(0)"> Nome
        <input type="radio" name="Busca" value="CPF" onclick="mostrar(1)"> CPF
        <input type="radio" name="Busca" value="Matricula" onclick="mostrar(2)"> Matrícula
        <div id="buscarNome">
          <form class="" action="#!" method="post">
          <div class="input-group">
           <input type="text" name="Atirador" class="form-control" placeholder="Buscar por nome" id="atirador" aria-label="Buscar por nome" aria-describedby="btnGroupAddon2">
           <div class="input-group-prepend">
           <button type="submit" class="input-group-text" id="btnBuscar" style="cursor: pointer"><i class="fas fa-search"></i></button>
          </div>
          </div>
          </form>
        </div>
        <div id="buscarCPF" style="display: none">
          <form class="" action="#!" method="post">
          <div class="input-group">
           <input type="text" name="Atirador" class="form-control" placeholder="Buscar por CPF" id="cpf" aria-label="Buscar por CPF" aria-describedby="btnGroupAddon2">
           <div class="input-group-prepend">
           <button type="submit" class="input-group-text" id="btnBuscar" style="cursor: pointer"><i class="fas fa-search"></i></button>
          </div>
          </div>
          </form>
        </div>
        <div id="buscarMatricula" style="display: none">
          <form class="" action="#!" method="post">
          <div class="input-group">
           <input type="text" name="Atirador" class="form-control" placeholder="Buscar por Matricula" id="matricula" aria-label="Buscar por Matricula" aria-describedby="btnGroupAddon2">
           <div class="input-group-prepend">
           <button type="submit" class="input-group-text" id="btnBuscar" style="cursor: pointer"><i class="fas fa-search"></i></button>
          </div>
          </div>
          </form>
        </div>
  </div>
  <div class="col-md-6">
    <br>
    <form class="" action="#!" method="post">
    <div class="input-group">
     <select class="form-control" name="Filtro">
       <option value="">Filtrar Resultados</option>
       <option value="10">10</option>
       <option value="25">25</option>
       <option value="50">50</option>
       <option value="100">100</option>
     </select>
     <div class="input-group-prepend">
     <button type="submit" class="input-group-text" name="Submit" value="Filtrar" style="cursor: pointer"><i class="fas fa-filter"></i></button>
    </div>
    </div>
    </form>
  </div>
     </div>
       <div style="margin-top:10px">
         <div align="center">
            <div id="loading"><img src="<?php echo $caminhoAbsoluto; ?>/imagens/ajax-loader.gif"><br>Aguarde, carregando...</div>
         </div>
         <span id="conteudo"></span>
         <?php //$pagina = $_REQUEST["pag"]; $busca = $_POST["Atirador"]; echo $metodos->listarPendentes($pagina,$busca); ?>
         <!--<form method="post">
           <select name="Filtro" id="filtro" style="height: 25px">
             <option value="10">10</option>
             <option value="25">25</option>
             <option value="50">50</option>
             <option value="100">100</option>
           </select>
         </form>-->
       </div>
     </div>
   </div>
 </div>
</div>
</div>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>
   <?php
      if($_POST["Submit"] == "Filtrar")
      {
        $filtro = $_POST["Filtro"];
        if($filtro != "")
        {
          $filtro = $filtro;
        }
        else
        {
           $filtro = 10;
        }
      }
      else
      {
        $filtro = 10;
      }
    ?>
   <script>
      var qnt_result_pg = <?php echo $filtro; ?>;
      var busca = "<?php echo $_POST["Atirador"]; ?>";
  		var pagina = 1;
			$(document).ready(function () {
				listar_usuario(pagina, qnt_result_pg, busca);
			});
			function listar_usuario(pagina, qnt_result_pg, busca){
        $('#loading').show();
        $('#conteudo').hide();
      var dados = {
					pagina: pagina,
          busca: busca,
					qnt_result_pg: qnt_result_pg
				}
				$.post('<?php echo $caminhoAbsoluto; ?>/listar-pagamentos-pendentes.php', dados , function(retorna){
          $('#loading').hide();
          $('#conteudo').show();
					$("#conteudo").html(retorna);
				});
			}
		</script>
  <!--
   <script>
        $(function () {
            $("#atirador").autocomplete({
                source: '<?php echo $caminhoAbsoluto; ?>/processar-pagamento-pendentes.php'
            });
        });
    </script>
  -->
  <script>
     $(document).ready(function() {
       $( "#atirador" ).autocomplete({
           source: function(request, response){
           $('#loading_data_icon').html('<i class="fa fa-spinner fa-pulse fa-2x fa-fw"></i>');    // showing loading icon
           $.ajax({
              url: '<?php echo $caminhoAbsoluto; ?>/processar-pagamento-pendentes.php',
              dataType: "json",
              data: {
                    'term' : request.term,
                    'empSearch' : 1
                    },
                    success: function(data) {
                     response(data);
                     $('#loading_data_icon').html('');
                    }
                });
            }
       });
     });
     </script>
     <script>
        $(document).ready(function() {
          $( "#cpf" ).autocomplete({
              source: function(request, response){
              $('#loading_data_icon').html('<i class="fa fa-spinner fa-pulse fa-2x fa-fw"></i>');    // showing loading icon
              $.ajax({
                 url: '<?php echo $caminhoAbsoluto; ?>/processar-cpf-pendentes.php',
                 dataType: "json",
                 data: {
                       'term' : request.term,
                       'empSearch' : 1
                       },
                       success: function(data) {
                        response(data);
                        $('#loading_data_icon').html('');
                       }
                   });
               }
          });
        });
        </script>
        <script>
           $(document).ready(function() {
             $( "#matricula" ).autocomplete({
                 source: function(request, response){
                 $('#loading_data_icon').html('<i class="fa fa-spinner fa-pulse fa-2x fa-fw"></i>');    // showing loading icon
                 $.ajax({
                    url: '<?php echo $caminhoAbsoluto; ?>/processar-matricula-pendentes.php',
                    dataType: "json",
                    data: {
                          'term' : request.term,
                          'empSearch' : 1
                          },
                          success: function(data) {
                           response(data);
                           $('#loading_data_icon').html('');
                          }
                      });
                  }
             });
           });
           </script>
     <script>
  function mostrarSenha(){
   var botao = document.getElementById("senha");
   if(botao.type == "password"){
     botao.type = "text";
      document.getElementById("ver").className="far fa-eye-slash fa-lg";
      document.getElementById("botaoSenha").title="Esconder senha";
   }else{
     botao.type = "password";
      document.getElementById("ver").className="far fa-eye fa-lg";
      document.getElementById("botaoSenha").title="Mostrar senha";
   }
  }
  </script>
  </body>
</html>
