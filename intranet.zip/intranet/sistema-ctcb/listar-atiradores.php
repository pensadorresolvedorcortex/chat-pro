<?php
error_reporting(0);
session_start();
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
$pagina = filter_input(INPUT_POST, 'pagina', FILTER_SANITIZE_NUMBER_INT);
$qnt_result_pg = filter_input(INPUT_POST, 'qnt_result_pg', FILTER_SANITIZE_NUMBER_INT);
$busca = $_POST["busca"];
$tipo_busca = $_POST["tipo_busca"];
if($busca != "")
{
   echo "<div class='text-center'><h3 style='font-weight: bold'>Buscar por ".$tipo_busca."</h3></div>";
} 
echo $metodos->listarAtiradores($pagina,$qnt_result_pg,$busca,$tipo_busca);
?>
