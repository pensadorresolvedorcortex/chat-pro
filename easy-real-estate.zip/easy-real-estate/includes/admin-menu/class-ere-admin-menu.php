<?php
/**
 * Admin Menu Class for ERE
 *
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ERE_Admin_Menu {

	public static $_instance;
	public $menu_capability = 'edit_posts';
	public $ere_menu_slug   = 'easy-real-estate';

	public function __construct() {

		// initialize ERE admin menu
		add_action( 'admin_menu', array( $this, 'ere_menu' ) );

		// Expand ERE admin menu when a sub menu is visited
		add_action( 'admin_footer', array( $this, 'expand_menu' ) );

	}

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public function ere_menu() {

		add_menu_page(
			esc_html__( 'Easy Real Estate', ERE_TEXT_DOMAIN ),
			esc_html__( 'Easy Real Estate', ERE_TEXT_DOMAIN ),
			$this->menu_capability,
			$this->ere_menu_slug,
			'',
			ERE_PLUGIN_URL . '/includes/admin-menu/ere-menu-icon.svg',
			'5'
		);

		// Add sub menus
		$sub_menus           = [];
		$sub_menus['addnew'] = array(
			$this->ere_menu_slug,
			esc_html__( 'Add New Property', ERE_TEXT_DOMAIN ),
			esc_html__( 'New Property', ERE_TEXT_DOMAIN ),
			$this->menu_capability,
			'post-new.php?post_type=property',
		);

		// Getting all taxonomies from property post type.
		$property_tax = get_object_taxonomies( 'property', 'objects' );

		// Looping through the taxonomy object and building array with required format.
		foreach ( $property_tax as $single_tax ) {
			$sub_menus[ $single_tax->name ] = array(
				$this->ere_menu_slug,
				$single_tax->labels->add_new_item,
				$single_tax->labels->name,
				$this->menu_capability,
				'edit-tags.php?taxonomy=' . $single_tax->name . '&post_type=property',
			);
		}

		/**
		 * Allows menu item(s) addition after taxonomies menu items.
		 *
		 * @param $sub_menus
		 */
		$sub_menus = apply_filters( 'ere_after_taxonomies_sub_menu', $sub_menus );

		if ( 'enable' === get_option( 'ere_agency_post_type_status', 'enable' ) ) {
			$sub_menus['agencies'] = array(
				$this->ere_menu_slug,
				esc_html__( 'Agencies', ERE_TEXT_DOMAIN ),
				esc_html__( 'Agencies', ERE_TEXT_DOMAIN ),
				$this->menu_capability,
				'edit.php?post_type=agency',
			);

			// Getting all taxonomies from agency post type.
			$agency_tax = get_object_taxonomies( 'agency', 'objects' );

			// Looping through the taxonomy object and building array with required format.
			foreach ( $agency_tax as $single_agency_tax ) {
				$sub_menus[ $single_agency_tax->name ] = array(
					$this->ere_menu_slug,
					$single_agency_tax->labels->add_new_item,
					$single_agency_tax->labels->name,
					$this->menu_capability,
					'edit-tags.php?taxonomy=' . $single_agency_tax->name,
				);
			}
		}

		if ( 'enable' === get_option( 'ere_agent_post_type_status', 'enable' ) ) {
			$sub_menus['agents'] = array(
				$this->ere_menu_slug,
				esc_html__( 'Agents', ERE_TEXT_DOMAIN ),
				esc_html__( 'Agents', ERE_TEXT_DOMAIN ),
				$this->menu_capability,
				'edit.php?post_type=agent',
			);

			// Getting all taxonomies from agent post type.
			$agent_tax = get_object_taxonomies( 'agent', 'objects' );

			// Looping through the taxonomy object and building array with required format.
			foreach ( $agent_tax as $single_agent_tax ) {
				$sub_menus[ $single_agent_tax->name ] = array(
					$this->ere_menu_slug,
					$single_agent_tax->labels->add_new_item,
					$single_agent_tax->labels->name,
					$this->menu_capability,
					'edit-tags.php?taxonomy=' . $single_agent_tax->name,
				);
			}
		}

		if ( 'enable' === get_option( 'ere_owner_post_type_status', 'disable' ) ) {
			$sub_menus['owners'] = array(
				$this->ere_menu_slug,
				esc_html__( 'Owners', ERE_TEXT_DOMAIN ),
				esc_html__( 'Owners', ERE_TEXT_DOMAIN ),
				$this->menu_capability,
				'edit.php?post_type=owner',
			);

			$sub_menus['add_new_owner'] = array(
				$this->ere_menu_slug,
				esc_html__( 'Add New Owner', ERE_TEXT_DOMAIN ),
				esc_html__( 'New Owner', ERE_TEXT_DOMAIN ),
				$this->menu_capability,
				'post-new.php?post_type=owner',
			);
		}

		if ( 'enable' === get_option( 'ere_partner_post_type_status', 'disable' ) ) {
			$sub_menus['partners'] = array(
				$this->ere_menu_slug,
				esc_html__( 'Partners', ERE_TEXT_DOMAIN ),
				esc_html__( 'Partners', ERE_TEXT_DOMAIN ),
				$this->menu_capability,
				'edit.php?post_type=partners',
			);
		}

		if ( 'enable' === get_option( 'ere_slides_post_type_status', 'disable' ) ) {
			$sub_menus['slides'] = array(
				$this->ere_menu_slug,
				esc_html__( 'Slides', ERE_TEXT_DOMAIN ),
				esc_html__( 'Slides', ERE_TEXT_DOMAIN ),
				$this->menu_capability,
				'edit.php?post_type=slide',
			);
		}

		$sub_menus['ere_settings'] = array(
			'easy-real-estate',
			esc_html__( 'Settings', ERE_TEXT_DOMAIN ),
			esc_html__( 'Settings', ERE_TEXT_DOMAIN ),
			'manage_options',
			'ere-settings',
			array( Easy_Real_Estate::instance(), 'settings_page' )
		);

		$sub_menus = apply_filters( 'inspiry_ere_admin_sub_menu', $sub_menus );

		if ( $sub_menus ) {
			foreach ( $sub_menus as $sub_menu ) {
				call_user_func_array( 'add_submenu_page', $sub_menu );
			}
		}
	}

	public function expand_menu() {

		// Get Current Screen.
		$screen    = get_current_screen();

		$menu_list = array(
			'agency',
			'agent',
			'owner',
			'partners',
			'slide'
		);

		$tax_names          = get_object_taxonomies( 'property', 'names' );
		$tax_names_prefixed = array_map( function ( $item ) {
			return 'edit-' . $item;
		}, $tax_names );

		$agency_tax_names          = get_object_taxonomies( 'agency', 'names' );
		$agency_tax_names_prefixed = array_map( function( $item ) {
			return 'edit-' . $item;
		}, $agency_tax_names );

		$agent_tax_names          = get_object_taxonomies( 'agent', 'names' );
		$agent_tax_names_prefixed = array_map( function( $item ) {
			return 'edit-' . $item;
		}, $agent_tax_names );

		$updated_menu_list = array_merge( $menu_list, $tax_names_prefixed );
		$agency_menu_list   = array_merge( $updated_menu_list, $agency_tax_names_prefixed );
		$final_menu_list   = array_merge( $agency_menu_list, $agent_tax_names_prefixed );
		$menu_arr          = apply_filters( 'ere_expand_menus_slugs', $final_menu_list );

		// Check if the current screen's ID has any of the above menu array items.
		if ( in_array( $screen->id, $menu_arr ) ) {

			// Filter $_GET array for security.
			$get_array = filter_input_array( INPUT_GET );
			$current_menu = '';

			foreach ( $tax_names as $tax_name ) {
				if ( isset( $get_array['taxonomy'] ) && ( $tax_name === $get_array['taxonomy'] ) ) {
					$current_menu = 'taxonomy=' . $tax_name;
					break;
				}
			}

			foreach ( $agency_tax_names as $agency_tax_name ) {
				if ( isset( $get_array['taxonomy'] ) && ( $agency_tax_name === $get_array['taxonomy'] ) ) {
					$current_menu = 'taxonomy=' . $agency_tax_name;
					break;
				}
			}

			foreach ( $agent_tax_names as $agent_tax_name ) {
				if ( isset( $get_array['taxonomy'] ) && ( $agent_tax_name === $get_array['taxonomy'] ) ) {
					$current_menu = 'taxonomy=' . $agent_tax_name;
					break;
				}
			}

			if ( empty( $current_menu ) && in_array( $screen->id, $menu_list ) ) {
				$current_menu = 'post_type=' . $screen->id;
			}

			if ( ! empty( $current_menu ) ) {
			?>
			<script type="text/javascript">
				(function ($) {
					$("body").removeClass("sticky-menu");
					$("#toplevel_page_easy-real-estate").addClass('wp-has-current-submenu wp-menu-open').removeClass('wp-not-current-submenu');
					$("#toplevel_page_easy-real-estate > a").addClass('wp-has-current-submenu wp-menu-open').removeClass('wp-not-current-submenu');
                    $(document).ready(function () {
                        if ('<?php echo esc_html( $current_menu ); ?>') {
                            const anchors = $('#toplevel_page_easy-real-estate ul').find('li').children('a');
                            anchors.each(function () {
                                if (this.href.indexOf('<?php echo esc_html( $current_menu ); ?>') >= 0) {
                                    $(this).parent('li').addClass("current");
                                }
                            });
                        }
                    });
				})(jQuery);
            </script>
			<?php
			}
		}
	}

}

/**
 * Initialize ERE admin menu class.
 */
function ere_admin_menu() {
	return ERE_Admin_Menu::instance();
}

ere_admin_menu();