<?php
/**
 * Frontend login & register helpers.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'hospa_toolkit_register_frontend_assets' ) ) {
    /**
     * Register shared frontend assets used by the login/register widgets.
     */
    function hospa_toolkit_register_frontend_assets() {
        $plugin_root  = dirname( __DIR__ );
        $plugin_entry = $plugin_root . '/hospa-toolkit.php';
        $scripts      = [
            'hospa-toolkit-register'        => 'assets/js/hospa-register.js',
            'hospa-toolkit-login'           => 'assets/js/hospa-login.js',
            'hospa-toolkit-book-appointment'=> 'assets/js/hospa-book-appointment.js',
            'hospa-toolkit-profile'         => 'assets/js/hospa-profile.js',
        ];

        foreach ( $scripts as $handle => $relative_js ) {
            $script_path = $plugin_root . '/' . $relative_js;
            $version     = defined( 'HOSPA_TOOLKIT_VERSION' ) ? HOSPA_TOOLKIT_VERSION : '1.0.0';

            if ( file_exists( $script_path ) ) {
                $version = filemtime( $script_path );
            }

            wp_register_script(
                $handle,
                plugins_url( $relative_js, $plugin_entry ),
                [ 'jquery' ],
                $version,
                true
            );
        }
    }

    add_action( 'wp_enqueue_scripts', 'hospa_toolkit_register_frontend_assets', 5 );
    add_action( 'elementor/frontend/after_register_scripts', 'hospa_toolkit_register_frontend_assets', 5 );
    add_action( 'elementor/editor/after_enqueue_scripts', 'hospa_toolkit_register_frontend_assets', 5 );
}

if ( ! function_exists( 'hospa_toolkit_handle_register_ajax' ) ) {
    /**
     * Handle AJAX registration requests.
     */
    function hospa_toolkit_handle_register_ajax() {
        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'hospa_register_user' ) ) {
            wp_send_json_error(
                [
                    'message' => __( 'Security check failed. Please refresh the page and try again.', 'hospa-toolkit' ),
                ]
            );
        }

        if ( is_user_logged_in() ) {
            wp_send_json_error(
                [ 'message' => __( 'You are already logged in.', 'hospa-toolkit' ) ]
            );
        }

        $full_name        = isset( $_POST['full_name'] ) ? sanitize_text_field( wp_unslash( $_POST['full_name'] ) ) : '';
        $email            = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
        $phone            = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
        $password         = isset( $_POST['password'] ) ? wp_unslash( $_POST['password'] ) : '';
        $password_confirm = isset( $_POST['password_confirm'] ) ? wp_unslash( $_POST['password_confirm'] ) : '';
        $consent          = isset( $_POST['consent'] ) ? (int) $_POST['consent'] : 0;
        $redirect_url     = isset( $_POST['redirect'] ) ? esc_url_raw( wp_unslash( $_POST['redirect'] ) ) : '';

        if ( empty( $full_name ) || empty( $email ) || empty( $phone ) || empty( $password ) || empty( $password_confirm ) ) {
            wp_send_json_error(
                [ 'message' => __( 'All fields are required.', 'hospa-toolkit' ) ]
            );
        }

        if ( ! $consent ) {
            wp_send_json_error(
                [ 'message' => __( 'You must agree to the terms before registering.', 'hospa-toolkit' ) ]
            );
        }

        if ( ! is_email( $email ) ) {
            wp_send_json_error(
                [ 'message' => __( 'Please enter a valid email address.', 'hospa-toolkit' ) ]
            );
        }

        if ( email_exists( $email ) ) {
            wp_send_json_error(
                [ 'message' => __( 'An account with this email already exists.', 'hospa-toolkit' ) ]
            );
        }

        if ( strlen( $password ) < 6 ) {
            wp_send_json_error(
                [ 'message' => __( 'Please choose a password that is at least 6 characters long.', 'hospa-toolkit' ) ]
            );
        }

        if ( $password !== $password_confirm ) {
            wp_send_json_error(
                [ 'message' => __( 'Passwords do not match. Please try again.', 'hospa-toolkit' ) ]
            );
        }

        $username = sanitize_user( current( explode( '@', $email ) ) );

        if ( empty( $username ) ) {
            $username = sanitize_user( $full_name );
        }

        if ( empty( $username ) ) {
            $username = 'hospa_user_' . wp_generate_password( 4, false );
        }

        $original_username = $username;
        $suffix            = 1;

        while ( username_exists( $username ) ) {
            $username = $original_username . '_' . $suffix;
            $suffix++;
        }

        $user_id = wp_create_user( $username, $password, $email );

        if ( is_wp_error( $user_id ) ) {
            wp_send_json_error(
                [ 'message' => $user_id->get_error_message() ]
            );
        }

        $names = preg_split( '/\s+/', $full_name );
        if ( ! empty( $names ) ) {
            wp_update_user(
                [
                    'ID'           => $user_id,
                    'display_name' => $full_name,
                    'first_name'   => $names[0],
                    'last_name'    => isset( $names[1] ) ? implode( ' ', array_slice( $names, 1 ) ) : '',
                ]
            );
        }

        if ( ! empty( $phone ) ) {
            update_user_meta( $user_id, 'phone', $phone );
        }

        update_user_meta( $user_id, 'show_admin_bar_front', 'false' );

        /**
         * Allow custom actions after registration.
         */
        do_action( 'hospa_toolkit_after_user_register', $user_id, $full_name, $phone );

        $credentials = [
            'user_login'    => $username,
            'user_password' => $password,
            'remember'      => true,
        ];

        $signon = wp_signon( $credentials, false );

        if ( is_wp_error( $signon ) ) {
            wp_send_json_error(
                [ 'message' => __( 'Registration completed, but automatic login failed. Please log in manually.', 'hospa-toolkit' ) ]
            );
        }

        $redirect_url = apply_filters( 'hospa_toolkit_register_redirect_url', $redirect_url, $user_id, $signon );

        wp_send_json_success(
            [
                'message'      => __( 'Registration successful. Redirecting...', 'hospa-toolkit' ),
                'redirect_url' => $redirect_url,
                'user_id'      => $user_id,
                'user_login'   => $username,
            ]
        );
    }

    add_action( 'wp_ajax_hospa_user_register', 'hospa_toolkit_handle_register_ajax' );
    add_action( 'wp_ajax_nopriv_hospa_user_register', 'hospa_toolkit_handle_register_ajax' );
}

if ( ! function_exists( 'hospa_toolkit_hide_admin_bar_for_subscribers' ) ) {
    /**
     * Hide the admin bar for subscribers and similar low-privilege roles on the front end.
     */
    function hospa_toolkit_hide_admin_bar_for_subscribers() {
        if ( ! is_user_logged_in() ) {
            return;
        }

        if ( current_user_can( 'edit_posts' ) || current_user_can( 'manage_options' ) ) {
            return;
        }

        show_admin_bar( false );
    }

    add_action( 'init', 'hospa_toolkit_hide_admin_bar_for_subscribers' );
}

if ( ! function_exists( 'hospa_toolkit_handle_login_ajax' ) ) {
    /**
     * Handle AJAX login requests.
     */
    function hospa_toolkit_handle_login_ajax() {
        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'hospa_login_user' ) ) {
            wp_send_json_error(
                [ 'message' => __( 'Security check failed. Please refresh the page and try again.', 'hospa-toolkit' ) ]
            );
        }

        $redirect_url = isset( $_POST['redirect'] ) ? esc_url_raw( wp_unslash( $_POST['redirect'] ) ) : '';

        if ( is_user_logged_in() ) {
            $redirect_url = apply_filters( 'hospa_toolkit_login_redirect_url', $redirect_url, wp_get_current_user() );

            wp_send_json_success(
                [
                    'message'      => __( 'You are already logged in.', 'hospa-toolkit' ),
                    'redirect_url' => $redirect_url,
                ]
            );
        }

        $user_login = isset( $_POST['user_login'] ) ? sanitize_text_field( wp_unslash( $_POST['user_login'] ) ) : '';
        $password   = isset( $_POST['password'] ) ? wp_unslash( $_POST['password'] ) : '';
        $remember   = ! empty( $_POST['rememberme'] );

        if ( empty( $user_login ) || empty( $password ) ) {
            wp_send_json_error(
                [ 'message' => __( 'Please provide both your username/email and password.', 'hospa-toolkit' ) ]
            );
        }

        if ( is_email( $user_login ) ) {
            $user = get_user_by( 'email', $user_login );
            if ( $user ) {
                $user_login = $user->user_login;
            }
        }

        $credentials = [
            'user_login'    => $user_login,
            'user_password' => $password,
            'remember'      => $remember,
        ];

        $signon = wp_signon( $credentials, false );

        if ( is_wp_error( $signon ) ) {
            $message = $signon->get_error_message();
            if ( empty( $message ) ) {
                $message = __( 'Invalid username or password.', 'hospa-toolkit' );
            }

            wp_send_json_error(
                [ 'message' => wp_strip_all_tags( $message ) ]
            );
        }

        if ( ! user_can( $signon->ID, 'edit_posts' ) && ! user_can( $signon->ID, 'manage_options' ) ) {
            update_user_meta( $signon->ID, 'show_admin_bar_front', 'false' );
        }

        $redirect_url = apply_filters( 'hospa_toolkit_login_redirect_url', $redirect_url, $signon );

        wp_send_json_success(
            [
                'message'      => __( 'Login successful. Redirecting...', 'hospa-toolkit' ),
                'redirect_url' => $redirect_url,
                'user_id'      => $signon->ID,
                'user_login'   => $signon->user_login,
            ]
        );
    }

    add_action( 'wp_ajax_hospa_user_login', 'hospa_toolkit_handle_login_ajax' );
    add_action( 'wp_ajax_nopriv_hospa_user_login', 'hospa_toolkit_handle_login_ajax' );
}
