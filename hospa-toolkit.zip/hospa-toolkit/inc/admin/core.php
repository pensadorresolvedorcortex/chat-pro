<?php

function hospa_activation_page(){
	echo '<div class="wrap" style="height:0;overflow:hidden;"><h2></h2></div>';
	require_once 'dashboard.php';
}

require_once(HOSPA_ACC_PATH . 'inc/admin/Toolkit_rt.php');