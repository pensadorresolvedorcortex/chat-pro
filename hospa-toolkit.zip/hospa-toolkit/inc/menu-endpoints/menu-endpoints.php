<?php 
// Hospa Nav Menu Endpoints

function hospa_add_nav_menu_meta_boxes() {
	add_meta_box( 'hospa_endpoints_nav_link', esc_html__( 'Hospa endpoints', 'hospa-toolkit' ), 'hospa_nav_menu_links' , 'nav-menus', 'side', 'low' );
}
add_action( 'admin_head-nav-menus.php', 'hospa_add_nav_menu_meta_boxes');

function hospa_nav_menu_links() {
	?>
	<div id="posttype-hospa-endpoints" class="posttypediv">
		<div id="tabs-panel-hospa-endpoints" class="tabs-panel tabs-panel-active">
			<ul id="hospa-endpoints-checklist" class="categorychecklist form-no-clear">
				
				<!-- Location -->
				<li>
					<label class="menu-item-title">
						<input type="checkbox" class="menu-item-checkbox" name="menu-item[-1][menu-item-object-id]" value="0" /> <?php esc_html_e('Elementor Template', 'hospa-toolkit'); ?>
					</label>
					<input type="hidden" class="menu-item-type" name="menu-item[-1][menu-item-type]" value="custom" />
					<input type="hidden" class="menu-item-title" name="menu-item[-1][menu-item-title]" value="Elementor Template" />
					<input type="hidden" class="menu-item-url" name="menu-item[-1][menu-item-url]" value="#" />
					<input type="hidden" class="menu-item-classes" name="menu-item[-1][menu-item-classes]" value="hospa-elementor-template" />
				</li>

			</ul>
		</div>
		<p class="button-controls">
			<span class="list-controls">
				<a href="<?php echo esc_url( admin_url( 'nav-menus.php?page-tab=all&selectall=1#posttype-hospa-endpoints' ) ); ?>" class="select-all"><?php esc_html_e( 'Select all', 'hospa-toolkit' ); ?></a>
			</span>
			<span class="add-to-menu">
				<button type="submit" class="button-secondary submit-add-to-menu right" value="<?php esc_attr_e( 'Add to menu', 'hospa-toolkit' ); ?>" name="add-post-type-menu-item" id="submit-posttype-hospa-endpoints"><?php esc_html_e( 'Add to menu', 'hospa-toolkit' ); ?></button>
				<span class="spinner"></span>
			</span>
		</p>
	</div>
	<?php
}

// Hospa Nav Menu Endpoints Output
function hospa_nav_menu_links_output( $itemOutput, $item ) {
	
	if (! empty( $itemOutput )&& is_string( $itemOutput )&& strpos( $item->classes[0], 'hospa-location' ) !== false) {
			if( hospa_location() != 'all'){
				$term = get_term_by('slug', hospa_location(), 'location');
				
				$itemOutput = '<a href="#" class="location-button"><i class="hospa-ecommerce-icon-location"></i> '.esc_html($term->name).'</a>';
			} else {
				$itemOutput = '<a href="#" class="location-button"><i class="hospa-ecommerce-icon-location"></i> '.esc_html($item->title).'</a>';
			}
	}

	return $itemOutput;
}

// if ( !is_admin() ) {
// 	add_filter( 'walker_nav_menu_start_el','hospa_nav_menu_links_output' , 50, 2 );
// 	add_filter( 'megamenu_walker_nav_menu_start_el', 'hospa_nav_menu_links_output', 50, 2 );
// }

// Mega Menu
require_once( __DIR__ . '/mega-menu/mega-menu.php' );