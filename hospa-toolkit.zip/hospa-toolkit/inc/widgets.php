<?php

class Hospa_posts_thumbs extends WP_Widget{

    function __construct(){
        $widget_ops = array('description' => esc_html__('Display Random or Recent posts with a small image.', 'hospa-toolkit'));
        parent::__construct( false, esc_html__('Hospa Recent Posts With Image', 'hospa-toolkit'), $widget_ops);
    }

    function widget($args, $instance){
        global $hospa_theme, $hospa_opt;
        extract($args); //it receives an associative array

        $title = apply_filters('widget_title', $instance['title']);
        $side_read_more   = !empty($hospa_opt['side_read_more']) ? $hospa_opt['side_read_more'] : 'Read More';

        $args = array(
            'posts_per_page' => $instance['number'],
            'post_type' => $instance['post_type'],
            'order' => 'DESC',
            'orderby' => $instance['orderby']
        );
       
        $query = new WP_Query($args);

        if( !$query->have_posts() ) return;
        echo $before_widget;
        if($title) echo $before_title.$title.$after_title;
        if(!$instance['number']) $instance['number'] = 4;

        if($query->have_posts()):
            $c = 0;
            
            while($query->have_posts()): $query->the_post(); ?>
                <?php
                $class = 'item';
                $post_id = get_the_ID();
                $thumb_size = 'hospa_widget_thumb';
                ?>
                <?php if( !has_post_thumbnail() ) $class .= ' no-thumb'; ?>
                <article <?php post_class($class); ?>>

                    <?php if( has_post_thumbnail() ): ?>
                        <?php
                        $thumb_id   = get_post_thumbnail_id($post_id);
                        $thumb_type = get_post_mime_type($thumb_id);
                        $image_alt  = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true);
                        if( !$image_alt ){
                            $image_alt = get_the_title($post_id);
                        }
                        if($thumb_type == 'image/gif'){
                            $thumb_size = '';
                        }
                        ?>
                        <a href="<?php the_permalink(); ?>" class="thumb hover-effect" aria-label="<?php the_title(); ?>">
                            <?php if( !empty($hospa_theme) && $hospa_theme['enable_lazyload'] == '1' ): ?>
                                <span class="fullimage cover lazy" role="img" aria-label="<?php echo esc_attr($image_alt); ?>" data-src="<?php the_post_thumbnail_url($thumb_size); ?>"></span>
                            <?php else: ?>
                                <span class="fullimage cover" role="img" aria-label="<?php echo esc_attr($image_alt); ?>" style="background: url('<?php the_post_thumbnail_url($thumb_size); ?>');"></span>
                            <?php endif; ?>
                        </a>
                    <?php endif; ?>

                    <div class="info gradient-effect">
                        <h4 class="title usmall"><a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
                        <a href="<?php the_permalink(); ?>" class="blog-btn"><i class="ti ti-arrow-right"></i><?php echo esc_html( $side_read_more ); ?></a>
                    </div>

                    <div class="clear"></div>
                </article>
            <?php
            endwhile;
            wp_reset_postdata();
        endif;
        echo $after_widget;
    }

    function update($new_instance, $old_instance){
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['number'] = (int) $new_instance['number'];
        $instance['orderby'] = $new_instance['orderby'];
        $instance['post_type'] = $new_instance['post_type'];
        return $instance;
    }

    function form($instance){
        $defaults = array(
            'title' => 'Recent posts',
            'number' => 4,
            'orderby' => 'date',
            'post_type' => 'post'
        );
        $instance = wp_parse_args((array)$instance, $defaults);
        $number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 4;
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">
                <?php esc_html_e('Title:', 'hospa-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('number'); ?>"><?php esc_html_e( 'Number of posts to show:', 'hospa-toolkit'); ?></label>
            <input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php echo $number; ?>" size="3" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('orderby'); ?>"><?php esc_html_e('Mode:', 'hospa-toolkit') ?> </label>
            <select id="<?php echo $this->get_field_id('orderby'); ?>" name="<?php echo $this->get_field_name('orderby'); ?>">
                <option <?php if ($instance['orderby'] == 'date') echo 'selected="selected"'; ?> value="date"><?php esc_html_e('Recent Posts', 'hospa-toolkit'); ?></option>
                <option <?php if ($instance['orderby'] == 'rand') echo 'selected="selected"'; ?> value="rand"><?php esc_html_e('Random Posts', 'hospa-toolkit'); ?></option>
                <?php if( function_exists('get_field') ): // By views ?>
                    <option <?php if ($instance['orderby'] == 'views') echo 'selected="selected"'; ?> value="views"><?php esc_html_e('Post views', 'hospa-toolkit'); ?></option>
                <?php endif; ?>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('post_type'); ?>"><?php esc_html_e('Post Type:', 'hospa-toolkit') ?> </label>
            <select id="<?php echo $this->get_field_id('post_type'); ?>" name="<?php echo $this->get_field_name('post_type'); ?>">
                <option <?php if ($instance['post_type'] == 'post') echo 'selected="selected"'; ?> value="post"><?php esc_html_e('Blog Posts', 'hospa-toolkit'); ?></option>
                <option <?php if ($instance['post_type'] == 'service') echo 'selected="selected"'; ?> value="service"><?php esc_html_e('Service Posts', 'hospa-toolkit'); ?></option>
                <option <?php if ($instance['post_type'] == 'project') echo 'selected="selected"'; ?> value="project"><?php esc_html_e('Projects Posts', 'hospa-toolkit'); ?></option>
            </select>
        </p>
        <?php
    }

}

function hospa_register_posts_thumbs() {
    register_widget('Hospa_posts_thumbs');
}

add_action('widgets_init', 'hospa_register_posts_thumbs');



/**
 * Newsletter Widget
 */
class hospa_newsletter extends WP_Widget{

    function __construct(){
        $widget_ops = array('description' => esc_html__('Display Newsletter', 'hospa-toolkit'));
        parent::__construct( false, esc_html__('Hospa Footer Newsletter', 'hospa-toolkit'), $widget_ops);
    }

    function widget($args, $instance){
        extract($args);
        echo $before_widget;
        ?>

        <h3><?php echo esc_html( $instance['support_text'] ); ?></h3>

        <?php
            $foot_nav_arg = [
                'menu'            => 'foot-support',
                'theme_location'  => 'foot-support',
                'menu_class'      => 'ps-0 mb-0 list-unstyled import-link',
                'container'       => null,
                'depth'           => 1,
            ];

            if(has_nav_menu('foot-support')){
                wp_nav_menu($foot_nav_arg);
            }
        ?>

        <h3 class="title"><?php echo esc_html( $instance['newsletter_text'] ); ?></h3>

        <?php if( $instance['email_url'] != '' ): ?>
            <form class="mailchimp newsletter-form subscribe-form position-relative" method="post">
                <input type="email" class="input-newsletter memail form-control" placeholder="<?php echo esc_attr($instance['email_placeholder']); ?>" name="EMAIL" required>

                <button type="submit" class="position-absolute top-50 end-0 translate-middle-y p-0 border-0 src-btn bg-transparent subscribe-btn">
                    <i data-feather="send"></i>
                </button>

                <div class="mchimp-errmessage alert alert-danger" style="display: none;"></div>
                <div class="mchimp-sucmessage alert alert-primary" style="display: none;"></div>
            </form>
        <?php endif; ?>

        <script>
            ;(function($){
                "use strict";
                $(document).ready(function () {
                    // MAILCHIMP
                    $(".mailchimp").ajaxChimp({
                        callback: mailchimpCallback,
                        url: "<?php echo esc_js($instance['email_url']) ?>"
                    });
                    $(".memail").on("focus", function () {
                        $(".mchimp-errmessage").fadeOut();
                        $(".mchimp-sucmessage").fadeOut();
                    });
                    $(".memail").on("keydown", function () {
                        $(".mchimp-errmessage").fadeOut();
                        $(".mchimp-sucmessage").fadeOut();
                    });
                    $(".memail").on("click", function () {
                        $(".memail").val("");
                    });

                    function mailchimpCallback(resp) {
                        if (resp.result === "success") {
                            $(".mchimp-sucmessage").html(resp.msg).fadeIn(1000);
                            $(".mchimp-sucmessage").fadeOut(3000);
                        } else if (resp.result === "error") {
                            $(".mchimp-errmessage").html(resp.msg).fadeIn(1000);
                        }
                    }
                });
            })(jQuery)
        </script>
        <?php
        echo $after_widget;
    }

    function update($new_instance, $old_instance){
        $instance                       = $old_instance;
        $instance['support_text']       = $new_instance['support_text'];
        $instance['newsletter_text']    = $new_instance['newsletter_text'];

        $instance['email_url']          = $new_instance['email_url'];
        $instance['email_placeholder']  = $new_instance['email_placeholder'];
        return $instance;
    }

    function form($instance){
        $defaults = array(
            
            'support_text'          =>  esc_html__('Support', 'hospa-toolkit'),
            'newsletter_text'       =>  esc_html__('Subscribe to our newsletter', 'hospa-toolkit'),

            'email_url'             => 'https://hibotheme.us20.list-manage.com/subscribe/post?u=60e1ffe2e8a68ce1204cd39a5&amp;id=42d6d188d9',
            'email_placeholder'     => esc_html__('Your email address', 'hospa-toolkit'),
        );
        $instance = wp_parse_args((array)$instance, $defaults);
        ?>

        <p>
            <label for="<?php echo $this->get_field_id('support_text'); ?>">
                <?php esc_html_e('Support:', 'hospa-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('support_text'); ?>" name="<?php echo $this->get_field_name('support_text'); ?>" type="text" value="<?php echo $instance['support_text']; ?>" />
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('newsletter_text'); ?>">
                <?php esc_html_e('Newsletter Text:', 'hospa-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('newsletter_text'); ?>" name="<?php echo $this->get_field_name('newsletter_text'); ?>" type="text" value="<?php echo $instance['newsletter_text']; ?>" />
            </label>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('email_url'); ?>">
                <?php esc_html_e('Action URL:', 'hospa-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('email_url'); ?>" name="<?php echo $this->get_field_name('email_url'); ?>" type="text" value="<?php echo $instance['email_url']; ?>" />
            </label>
            <i><?php echo esc_html__('Enter here your MailChimp action URL.','hospa-toolkit') ?> <a href="https://www.docs.hibotheme.com/docs/hospa-theme-documentation/tips-guides-troubleshoots/get-mailchimp-newsletter-form-action-url/" target="_blank"> <?php echo esc_html__('How to.','hospa-toolkit') ?> </a></i>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('email_placeholder'); ?>">
                <?php esc_html_e('Placeholder Title:', 'hospa-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('email_placeholder'); ?>" name="<?php echo $this->get_field_name('email_placeholder'); ?>" type="text" value="<?php echo $instance['email_placeholder']; ?>" />
            </label>
        </p>
        <?php
    }
}

function hospa_register_newsletter() {
    register_widget('hospa_newsletter');
}

add_action('widgets_init', 'hospa_register_newsletter');