<?php get_header(); ?>

<?php 
if ( class_exists( 'Redux' ) ) {
$options = get_option('kasuari_framework');
	$kasuari_blog_type = $options['blog_type']; 
?>

<!-- CONTENT START
============================================= -->
<section id="content" class="single-post-wrap clearfix">

	<!-- BLOG START
	============================================= -->
	<div class="blog right-sidebar clearfix">
		<div class="container clearfix">
			<div class="<?php if($kasuari_blog_type == 'sidebar' && is_active_sidebar( 'primary-sidebar' )) { ?>row <?php } ?>clearfix">

				<!-- BLOG LOOP START
				============================================= -->
				<div class="<?php if($kasuari_blog_type == 'sidebar' && is_active_sidebar( 'primary-sidebar' )) { ?>column column-2of3 <?php } ?>clearfix">
					<div class="blog-single content-section">

					<?php while ( have_posts() ) : the_post(); 
						
						get_template_part( 'inc/format/content', get_post_format() );

					endwhile; // end of the loop. ?>
				
					</div>
				</div>

				<!-- BLOG LOOP END -->

				<!-- SIDEBAR START
				============================================= -->

				<?php if($kasuari_blog_type == 'sidebar') {
					get_sidebar();
				} ?>

				<!-- SIDEBAR END -->

			</div>
		</div>
	</div>
	<!-- BLOOG END -->

</section>
<!-- CONTENT END -->
<?php }
else { ?>

<!-- CONTENT START
============================================= -->
<section id="content" class="single-post-wrap clearfix">

	<!-- BLOG START
	============================================= -->
	<div class="blog right-sidebar clearfix">
		<div class="container clearfix">
			<div class="<?php if(is_active_sidebar( 'primary-sidebar' )) { ?>row <?php } ?>clearfix">

				<!-- BLOG LOOP START
				============================================= -->
				<div class="<?php if(is_active_sidebar( 'primary-sidebar' )) { ?>column column-2of3 <?php } ?>clearfix">
					<div class="blog-single content-section">

					<?php while ( have_posts() ) : the_post(); 
			
						get_template_part( 'inc/format/content', get_post_format() );

					endwhile; // end of the loop. ?>
				
					</div>
				</div>

				<!-- BLOG LOOP END -->

				<!-- SIDEBAR START
				============================================= -->

				<?php get_sidebar(); ?>

				<!-- SIDEBAR END -->

			</div>
		</div>
	</div>
	<!-- BLOOG END -->

</section>
<!-- CONTENT END -->

<?php } ?>

<?php kasuari_footer_choice(); ?>