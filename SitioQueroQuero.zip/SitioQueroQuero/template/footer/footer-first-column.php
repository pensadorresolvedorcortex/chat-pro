<?php
$options   = get_option('kasuari_framework');
$prefix = 'kasuari_';
$layout    = $options['footer_customize_first']['enabled'];

global $post;
 
if ($layout): foreach ($layout as $key=>$value) {
	switch ($key) {
		case 'kasuari-copyright':
			kasuari_footer_part('footer/kasuari-copyright');
			break;
		case 'kasuari-social':
			kasuari_footer_part('footer/kasuari-footsocial');
			break;
		case 'kasuari-foot-text':
			kasuari_footer_part('footer/kasuari-foottext');
			break;
		case 'kasuari-foot-logo':
			kasuari_footer_part('footer/kasuari-footlogo');
			break;
		case 'kasuari-foot-menu':
			kasuari_footer_part('footer/kasuari-footmenu');
			break;
		}
	}
endif;