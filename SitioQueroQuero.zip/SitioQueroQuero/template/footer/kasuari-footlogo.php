<div class="logo-footer foot-col-item">
	<?php $kasuari_foot_logo = '';
	$options = get_option('kasuari_framework');
	if (isset($options['foot_logo'])) {
	$kasuari_foot_logo = $options['foot_logo']; ?>
		<img src="<?php echo esc_url( $kasuari_foot_logo['url'] ); ?>" alt="">
	<?php } ?>
</div>