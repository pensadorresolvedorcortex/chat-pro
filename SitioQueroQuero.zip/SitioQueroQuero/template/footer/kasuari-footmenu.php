<div class="footer-menu foot-col-item">
	<?php kasuari_footer_menu(); ?>
</div>