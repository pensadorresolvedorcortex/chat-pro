<div class="social-footer foot-col-item">
	<ul>
		<?php kasuari_social_profile(); ?>
	</ul>
</div>