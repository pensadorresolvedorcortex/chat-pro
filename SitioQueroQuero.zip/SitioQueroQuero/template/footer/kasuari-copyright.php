<div id="copyright" class="copyright-text foot-col-item">
	<?php kasuari_footer_copyright(); ?>
</div>