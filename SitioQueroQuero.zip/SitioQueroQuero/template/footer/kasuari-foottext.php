<div class="foot-col-item clearfix">
<?php 
$options = get_option('kasuari_framework');
$kasuari_foot_address = $options['foot_address'];

echo htmlspecialchars_decode( esc_html( $kasuari_foot_address )); ?>
</div>