<?php
$options   = get_option('kasuari_framework');
$prefix = 'kasuari_';
$layout    = $options['header_customize_right']['enabled'];
 
if ($layout): foreach ($layout as $key=>$value) {
	switch ($key) {
		case 'kasuari-logo':
			if ( is_front_page() && is_home() ) {
				kasuari_header_part('header/logo-standard');
			}
			elseif ( is_home() ) {
				kasuari_header_part('header/logo-standard');
			}
			elseif ( is_front_page() ) {
				kasuari_header_part('header/logos');
			}
			elseif(is_single('post')) {
				kasuari_header_part('header/logo-standard');
			}
			elseif(is_singular( 'post' )) {
				kasuari_header_part('header/logo-standard');
			}
			elseif( is_page_template() ) {
				kasuari_header_part('header/logos');
			}
			elseif( is_page() ) {
				kasuari_header_part('header/logos');
			}
			elseif( is_archive() || is_search() || is_404() ) {
				kasuari_header_part('header/logo-standard');
			}
			break;
		case 'kasuari-menus':
			kasuari_header_part('header/menus');
			break;
		case 'kasuari-sec-menus':
			kasuari_header_part('header/menus-sec');
			break;
		case 'kasuari-search':
			kasuari_header_part('header/search-btn');
			break;
		}
	}
endif;