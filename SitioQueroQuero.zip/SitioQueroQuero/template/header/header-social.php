<div class="header-social head-item">
	<ul>
	    <?php kasuari_social_profile(); ?>
	</ul>
</div>