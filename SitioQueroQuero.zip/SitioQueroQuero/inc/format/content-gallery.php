<article  id="post-<?php the_ID(); ?>" <?php post_class( 'blog-item hentry'); ?> itemprop="blogPost" itemscope="itemscope" itemtype="http://schema.org/BlogPosting">

	<div class="post-content-wrap">
		<div class="post-content">
			<?php
				if ( class_exists( 'acf' ) ) {
				$images = get_field('kasuari_gallery');
				if( $images){ ?>

				<div class="slider-wrapper">
					<div class="standard-carousel-slider post-gallery carousel-container">
						<div class="carousel-wrapper owl-carousel owl-theme">
							<?php foreach( $images as $image ): ?>
							<div class="carousel-slide item">
								<img src="<?php echo esc_url( $image['url'] ); ?>" alt="<?php echo esc_attr( $image['alt'] ); ?>" />  
							</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
				<?php }
			} ?>

			<div class="content-inner-wrapper clearfix">
				<div class="meta-wrapper clearfix">

					<h1 class="post-title entry-title" itemprop="headline"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>

					<div class="post-meta clearfix">
						<div class="meta-info">
							<span class="author">
								<span><?php esc_html_e( 'Por', 'kasuari' ); ?></span>
								<span class="vcard"><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"> <?php echo get_the_author_meta( 'display_name' ); ?></a></span>
							</span>
							<span class="standard-post-categories">
								<span><?php esc_html_e( 'em', 'kasuari' ); ?></span>
								<?php the_category(', '); ?>
							</span>
							<span class="date">
								<span><?php esc_html_e( 'Posted On', 'kasuari' ); ?></span>
								<a href="<?php the_permalink(); ?>">
									<span><?php echo get_the_date('F'); ?></span> <span><?php echo get_the_date('d'); ?></span><?php esc_html_e( ',', 'kasuari' ); ?> <span><?php echo get_the_date('Y'); ?></span>
								</a>
							</span>
						</div>
						<?php $comments_number = get_comments_number();
						if($comments_number != 0 ){ ?>
						<div class="meta meta-comments">
							<a href="<?php comments_link(); ?>" class="comments"><span><?php comments_number( '0', '1', '%' ); ?></span><i class="icon-simple-line-icons-124"></i></a>
						</div>
						<?php } ?>
					</div>
					
					<div class="separator-line"><span></span></div>

				</div>

				<div class="post-text entry-content clearfix" itemprop="text">
					<?php 
						the_content(); 
						wp_link_pages( array(
							'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'kasuari' ) . '</span>',
							'after'       => '</div>',
							'link_before' => '<span>',
							'link_after'  => '</span>',
							'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'kasuari' ) . ' </span>%',
							'separator'   => '<span class="screen-reader-text">, </span>',
						) ); 
					?>
				</div>

				<?php if(has_tag()) { ?>
					<div class="meta-bottom clearfix">
						<div class="tag-wrapper"><?php the_tags('','',''); ?></div>
					</div>
				<?php } ?>
			</div>

		</div>
	</div>

	<!-- Author Info -->
	<?php $author_desc = get_the_author_meta('description'); 
	if(!empty($author_desc)) { ?>
	<div class="post-author clearfix">
		
		<figure class="author-ava">
			<?php echo get_avatar( get_the_author_meta('ID'), '100' ); ?>
		</figure>

		<div class="author-desc">
			<div class="author-name">
				<span><?php esc_html_e( 'Written by', 'kasuari' ); ?></span> <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>" title="<?php echo get_the_author_meta( 'display_name' ); ?>" rel="author"><?php echo get_the_author_meta( 'display_name' ); ?></a>
			</div>
			<p><?php the_author_meta('description'); ?></p>
		</div>
	</div>
	<?php } ?>
	<!-- end of author -->

	<!-- pagination start -->
	<?php kasuari_single_post_pagination(); ?>
	<!-- pagination end -->

	<?php if ( !post_password_required()) {
		get_template_part( 'inc/part/related', 'post' ); 
	} ?>

</article><!-- #post-<?php the_ID(); ?> -->

<?php 
	if ( is_singular() ) wp_enqueue_script( "comment-reply" ); 
	if ( comments_open() || '0' != get_comments_number() ) comments_template(); 
?>