<article class="single-post post no-result clearfix">

	<div class="post-content clearfix"> 
		<div class="post-entry "> 

			<div class="post-title text-center">
				<h3>
				  <?php esc_html_e( 'Desculpe! Nada encontrado!', 'kasuari' ); ?>
				</h3>
			</div>  
			<p class="text-center">
				<?php esc_html_e( 'Parece que nada foi encontrado neste local.', 'kasuari' ); ?>
			</p>
			<div class="search-bar-no-res">
				<?php get_template_part( 'searchform', 'def' ); ?>
			</div>
		</div><!-- post-entry -->
	</div><!-- post-content -->
	
</article><!-- #post-0 .post .no-result .not-found -->