<article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-item'); ?>>

	<?php if ( class_exists( 'acf' ) ) { ?>
	<div class="featured-video clearfix">
		<?php 
			$video_url = get_field('video_url');
			$video_embed = get_field('video_embed');
			$video_file = get_field('video_file');
			
			if($video_url !== ''){ 
				echo wp_oembed_get( esc_url( $video_url ));
			} 

			elseif($video_embed !== '') { 
				echo htmlspecialchars_decode( esc_html( $video_embed ) );
			}

			elseif($video_file !== '') {  ?>
			<?php echo do_shortcode( '[video src="'. sanitize_text_field( $video_file ).'"]' ) ?>  
		<?php } ?>
	</div>
	<?php } ?>

	<div class="post-content-wrap">
		<div class="post-content">

			<h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>

			<div class="separator-line"><span></span></div>

			<div class="meta-wrapper clearfix">
				<span class="author">
					<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>">
						<span class="author-name">
							<span class="author-separator"><?php esc_html_e( 'Por', 'kasuari' ); ?></span><span class="vcard"> <?php echo get_the_author_meta( 'display_name' ); ?></span>
						</span>
					</a>
				</span>
				<span class="standard-post-categories">
					<?php esc_html_e( 'em ', 'kasuari' ); ?><?php the_category(', '); ?>
				</span>
				<span class="date">
					<a href="<?php the_permalink(); ?>">
						<span><?php echo get_the_date('F'); ?></span> <span><?php echo get_the_date('d'); ?></span><?php esc_html_e( ',', 'kasuari' ); ?> <span><?php echo get_the_date('Y'); ?></span>
					</a>
				</span>
			</div>

			<div class="post-text">
				<?php the_excerpt(); ?>
			</div>

			<div class="btn-more">
				<a href="<?php the_permalink(); ?>" class="read-more"><?php esc_html_e( 'Read More', 'kasuari' ); ?></a>
			</div>

		</div>
	</div><!-- post-content-wrap -->

</article>