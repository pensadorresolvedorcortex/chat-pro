<?php get_header(); ?>

<?php 
if ( class_exists( 'Redux' ) ) {
	$options = get_option('kasuari_framework');
	$kasuari_blog_style = $options['loop_blog_style'];
	$kasuari_loop_nav_type = $options['loop_nav_type'];
	$kasuari_blog_infinite_style = $options['blog_infinite_style'];

?>
<!-- CONTENT START
============================================= -->
<section id="content" class="blog-content-wrap clearfix">

	<!-- BLOG START
	============================================= -->
	<div class="blog right-sidebar clearfix">
		<div class="container clearfix">
			<div class="row clearfix">
				<!-- BLOG LOOP START
				============================================= -->
				<div class="<?php if($kasuari_blog_style == 'sidebar') { ?>column column-2of3 <?php } ?> clearfix">
					<div class="blog-section main-blog-loop infinite-container content-section">

					<?php while ( have_posts() ) : the_post(); 
					
						get_template_part( 'inc/format/loop', get_post_format() );

					endwhile; // end of the loop. ?>
				
					</div>

					<div class="blog-standard pagination clearfix">
						<?php
						if($kasuari_loop_nav_type == 'nav_default') {
							kasuari_content_nav($pages = '', $range = 2);
						}
						elseif($kasuari_loop_nav_type == 'nav_pagina') {
							kasuari_pagination($pages = '', $range = 2);
						} ?>
					</div>

					<?php if($kasuari_loop_nav_type == 'nav_infinite') { ?>

						<div class="navigation-paging infinite-wrap <?php echo esc_attr($kasuari_blog_infinite_style); ?> clearfix">
							<div id="load-more-loop" class="infinite-button"><?php next_posts_link( '' ); ?></div>
							<button id="load-infinite-loop" class="btn"><?php esc_html_e( 'Load More', 'kasuari' ); ?></button>
						</div>
						
					<?php } ?>
				</div>
				<!-- BLOG LOOP END -->

				<!-- SIDEBAR START
				============================================= -->

				<?php if($kasuari_blog_style == 'sidebar') {
					get_sidebar();
				} ?>

				<!-- SIDEBAR END -->
			</div>
		</div>
	</div>
	<!-- BLOOG END -->

</section>
<!-- CONTENT END -->
<?php }
else { ?>
<!-- CONTENT START
============================================= -->
<section id="content" class="blog-content-wrap clearfix">

	<!-- BLOG START
	============================================= -->
	<div class="blog right-sidebar clearfix">
		<div class="container clearfix">
			<div class="row clearfix">
				<!-- BLOG LOOP START
				============================================= -->
				<div class="masonry-post post-masonry-style clearfix">
					<div class="blog-section main-blog-loop infinite-container content-section">

					<?php while ( have_posts() ) : the_post(); 

						get_template_part( 'inc/format/loop', get_post_format() );

					endwhile; // end of the loop. ?>

					</div>

					<div class="blog-standard pagination clearfix">
						<?php kasuari_content_nav($pages = '', $range = 2); ?>
					</div>
				
				</div>
				<!-- BLOG LOOP END -->
			</div>
		</div>
	</div>
	<!-- BLOOG END -->

</section>
<!-- CONTENT END -->
<?php } ?>

<?php kasuari_footer_choice(); ?>