<?php get_header(); ?>

<div id="content-wrapper" class="wrapper">
	<div class="container">
		<article class="single-post post no-result not-found outer clearfix">
			<div class="inner">
				<h1><?php esc_html_e( '404', 'kasuari' ); ?></h1>
				<h3>
				  <?php esc_html_e( 'The page you were looking for doesn&rsquo;t exist.', 'kasuari' ); ?> <span><?php esc_html_e( 'You may have mistyped the address or the page may have moved.', 'kasuari' ); ?></span>
				</h3>

				<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Go back to the homepage ', 'kasuari' ); ?></a>
			</div>
		</article><!-- #post-0 .post .no-result .not-found -->
	</div>
</div><!-- wrapper -->

<?php get_footer('no-footer'); ?>