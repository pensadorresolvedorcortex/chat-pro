<?php

if (!function_exists('kasuari_header_part')) {
    function kasuari_header_part($template, $name = null) {
        get_template_part('template/' . $template, $name);
    }
}

if (!function_exists('kasuari_footer_part')) {
    function kasuari_footer_part($template, $name = null) {
        get_template_part('template/' . $template, $name);
    }
}

// Define a largura padrão do conteúdo do tema.
if (!isset($content_width)) {
    $content_width = 1200; // pixels
}

/* --------------------------------------------------------------------- */
/*  SETUP DO TEMA
/* --------------------------------------------------------------------- */
if (!function_exists('kasuari_setup')) :
    function kasuari_setup() {
        add_theme_support('automatic-feed-links');

        if (class_exists('acf')) {
            add_theme_support('post-formats', array('gallery', 'video'));
        }

        add_theme_support('custom-background', array(
            'default-color' => '#fafafa',
        ));

        add_theme_support('post-thumbnails');
        add_theme_support('html5', array('comment-list', 'comment-form', 'search-form', 'gallery', 'caption'));
        add_theme_support('title-tag');
        load_theme_textdomain('kasuari', get_template_directory() . '/languages');
    }
endif;
add_action('after_setup_theme', 'kasuari_setup');

function kasuari_thumbnail_setup() {
    add_image_size('kasuari-related', 100, 80, true);
}
add_action('after_setup_theme', 'kasuari_thumbnail_setup');

/* --------------------------------------------------------------------- */
/*  ACF
/* --------------------------------------------------------------------- */
add_filter('acf/settings/show_admin', '__return_false');

/* --------------------------------------------------------------------- */
/*  SCRIPTS & STYLES
/* --------------------------------------------------------------------- */
function kasuari_scripts() {
    $options = get_option('kasuari_framework');

    /* CSS */
    wp_enqueue_style('kasuari-plugin', get_template_directory_uri() . '/css/plugin.css', array(), null);
    wp_enqueue_style('kasuari-style', get_stylesheet_uri(), array('kasuari-plugin'));
    wp_enqueue_style('kasuari-font', get_template_directory_uri() . '/css/font.css', array(), null);
    wp_enqueue_style('kasuari-responsive', get_template_directory_uri() . '/css/responsive.css', array(), null);

    /* JS */
    wp_enqueue_script('modernizr', get_template_directory_uri() . '/js/modernizr.js', array('jquery'), '', false);
    wp_enqueue_script('respond', get_template_directory_uri() . '/js/respond.js', array('jquery'), '', false);
    wp_enqueue_script('retinajs', get_template_directory_uri() . '/js/retina.min.js', array('jquery'), '', false);
    wp_enqueue_script('fitvids', get_template_directory_uri() . '/js/fitvids.js', array('jquery'), '', true);
    wp_enqueue_script('classie', get_template_directory_uri() . '/js/classie.js', array('jquery'), '', false);
    wp_enqueue_script('wow', get_template_directory_uri() . '/js/wow.js', array('jquery'), '', true);
    wp_enqueue_script('easing', get_template_directory_uri() . '/js/easing.js', array('jquery'), '', true);
    wp_enqueue_script('smartmenus', get_template_directory_uri() . '/js/smartmenus.js', array('jquery'), '', true);
    wp_enqueue_script('owlcarousel', get_template_directory_uri() . '/js/owlcarousel.js', array('jquery'), '', true);
    wp_enqueue_script('infinitescroll', get_template_directory_uri() . '/js/infinitescroll.js', array('jquery'), '', true);
    wp_enqueue_script('isotope', get_template_directory_uri() . '/js/isotope.js', array('jquery', 'imagesloaded'), '', true);
    wp_enqueue_script('headroom', get_template_directory_uri() . '/js/headroom.js', array('jquery'), '', true);
    wp_enqueue_script('animeonscroll', get_template_directory_uri() . '/js/animeonscroll.js', array('jquery'), '', true);
    wp_enqueue_script('bootstrap', get_template_directory_uri() . '/js/bootstrap.js', array('jquery'), '', true);
    wp_enqueue_script('lightgallery', get_template_directory_uri() . '/js/lightgallery.js', array('jquery'), '', true);
    wp_enqueue_script('smoothscroll', get_template_directory_uri() . '/js/smoothscroll.js', array('jquery'), '', true);
    wp_enqueue_script('stickykit', get_template_directory_uri() . '/js/stickykit.js', array('jquery'), '', true);
    wp_enqueue_script('thumbsplugin', get_template_directory_uri() . '/js/thumbsplugin.js', array('jquery'), '', true);
    wp_enqueue_script('kasuari-main', get_template_directory_uri() . '/js/main.js', array('jquery'), '', true);

    if (class_exists('Redux')) {
        $search_bar_style = $options['search_bar_style'];
        $footer_style_type = $options['footer_style_type'];

        $right  = $options['header_customize_right']['enabled'];
        $center = $options['header_customize_center']['enabled'];
        $left   = $options['header_customize_left']['enabled'];

        if ($search_bar_style === 'expand') {
            if ($right || $center || $left) {
                if (isset($right['kasuari-search']) || isset($center['kasuari-search']) || isset($left['kasuari-search'])) {
                    wp_enqueue_script('kasuari-header1', get_template_directory_uri() . '/js/header1.js', array('jquery'), '', true);
                }
            }
        }

        if ($footer_style_type === 'fixed-footer') {
            wp_enqueue_script('kasuari-footer-fixed', get_template_directory_uri() . '/js/footer-fixed.js', array('jquery'), '', true);
        }
    } else {
        wp_enqueue_script('kasuari-header1', get_template_directory_uri() . '/js/header1.js', array('jquery'), '', true);
    }

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'kasuari_scripts');

/* Customizer */
function kasuari_customizer_live_preview() {
    wp_enqueue_script('kasuari-color-customizer', get_template_directory_uri() . '/js/color-customizer.js', array('jquery', 'customize-preview'), null, true);
}
add_action('customize_preview_init', 'kasuari_customizer_live_preview');

/* Admin */
function kasuari_admin_style() {
    wp_enqueue_style('kasuari-admin-styles', get_template_directory_uri() . '/css/admin.css');
    wp_enqueue_style('kasuari-admin-redux-styles', get_template_directory_uri() . '/css/kasuari-redux.css');
}
add_action('admin_enqueue_scripts', 'kasuari_admin_style');

if (is_user_logged_in()) {
    add_action('elementor/frontend/after_register_styles', function () {
        wp_enqueue_style('admin-styles2', get_template_directory_uri() . '/css/admin.css');
    });
}

add_action('elementor/editor/before_enqueue_scripts', function () {
    wp_enqueue_style('admin-styles1', get_template_directory_uri() . '/css/admin.css');
});

/* --------------------------------------------------------------------- */
/*  FRAMEWORK
/* --------------------------------------------------------------------- */
require_once get_template_directory() . '/inc/option/panel/config.php';

/* --------------------------------------------------------------------- */
/*  MENUS
/* --------------------------------------------------------------------- */
add_action('after_setup_theme', 'kasuari_register_my_menu');
function kasuari_register_my_menu() {
    register_nav_menu('header-menu', esc_html__('Header Menu (Right/Primary)', 'kasuari'));
    if (class_exists('Redux')) {
        register_nav_menu('header-menu-sec', esc_html__('Header Menu (Left)', 'kasuari'));
        register_nav_menu('footer-menu', esc_html__('Footer Menu', 'kasuari'));
    }
}

/* Menus principais e secundários (mesma lógica anterior, apenas removida create_function) */
function kasuari_main_nav_menu() {
    if (class_exists('Redux')) {
        $options = get_option('kasuari_framework');
        $menus_choose_style = $options['menus_choose_style'];

        $classes = array(
            'style-1'  => 'menu--ferdinand',
            'style-2'  => 'menu--prospero',
            'style-3'  => 'menu--viola',
            'style-4'  => 'menu--antonio',
            'style-5'  => 'menu--miranda',
            'style-6'  => 'menu--ariel',
            'style-7'  => 'menu--caliban',
            'style-8'  => 'menu--iris',
            'style-9'  => 'menu--stephano',
            'style-10' => 'menu--ceres',
            'style-11' => 'menu--juno',
            'style-12' => 'menu--maria',
            'style-13' => 'menu--valentine',
            'style-14' => 'menu--sebastian'
        );

        $menu_class = 'sm sm-clean ' . ($classes[$menus_choose_style] ?? '');
    } else {
        $menu_class = 'sm sm-clean menu--ferdinand';
    }

    wp_nav_menu(array(
        'theme_location' => 'header-menu',
        'container'      => 'ul',
        'menu_class'     => $menu_class,
        'fallback_cb'    => 'kasuari_header_menu_cb'
    ));
}

if (class_exists('Redux')) {
    function kasuari_main_nav_menu_left() {
        $options = get_option('kasuari_framework');
        $menus_choose_style = $options['menus_choose_style'];

        $classes = array(
            'style-1'  => 'menu--ferdinand',
            'style-2'  => 'menu--prospero',
            'style-3'  => 'menu--viola',
            'style-4'  => 'menu--antonio',
            'style-5'  => 'menu--miranda',
            'style-6'  => 'menu--ariel',
            'style-7'  => 'menu--caliban',
            'style-8'  => 'menu--iris',
            'style-9'  => 'menu--stephano',
            'style-10' => 'menu--ceres',
            'style-11' => 'menu--juno',
            'style-12' => 'menu--maria',
            'style-13' => 'menu--valentine',
            'style-14' => 'menu--sebastian'
        );

        $menu_class = 'sm sm-clean ' . ($classes[$menus_choose_style] ?? '');

        wp_nav_menu(array(
            'theme_location' => 'header-menu-sec',
            'container'      => 'ul',
            'menu_class'     => $menu_class,
            'fallback_cb'    => 'kasuari_header_sec_menu_cb'
        ));
    }
}

/* Adiciona classe no link dos menus */
function kasuari_add_menuclass($ulclass) {
    return preg_replace('/<a /', '<a class="menu__link" ', $ulclass);
}
add_filter('wp_nav_menu', 'kasuari_add_menuclass');

if (class_exists('Redux')) {
    function kasuari_footer_menu() {
        wp_nav_menu(array(
            'theme_location' => 'footer-menu',
            'container'      => 'ul',
            'menu_class'     => 'sm',
            'fallback_cb'    => 'kasuari_footer_menu_cb'
        ));
    }
}

/* Fallbacks */
function kasuari_header_menu_cb() {
    echo '<ul id="menu-top-menu" class="menus sm sm-clean menu--ferdinand">';
    wp_list_pages('title_li=');
    echo '</ul>';
}

/* Substitui create_function por closure */
add_filter('wp_list_pages', function ($t) {
    return str_replace('<a ', '<a class="menu__link" ', $t);
});

if (class_exists('Redux')) {
    function kasuari_header_menu_sec_cb() {
        echo '<ul id="menu-top-menu-sec" class="menus sm sm-clean">';
        wp_list_pages('title_li=');
        echo '</ul>';
    }

    function kasuari_footer_menu_cb() {
        echo '<ul id="menu-footer-menu" class="menus">';
        wp_list_pages('title_li=');
        echo '</ul>';
    }
}

/* --------------------------------------------------------------------- */
/*  WIDGETS
/* --------------------------------------------------------------------- */
function kasuari_widgets_init() {
    register_sidebar(array(
        'name'          => esc_html__('Primary Sidebar', 'kasuari'),
        'id'            => 'primary-sidebar',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title"><span>',
        'after_title'   => '</span></h4>',
    ));
}
add_action('widgets_init', 'kasuari_widgets_init');

require_once get_template_directory() . '/inc/widgets/kasuari-latestpost-widget.php';
require_once get_template_directory() . '/inc/widgets/kasuari-latestpost2-widget.php';

/* --------------------------------------------------------------------- */
/*  PAGINAÇÃO
/* --------------------------------------------------------------------- */
function kasuari_pagination($pages = '', $range = 2) {
    $showitems = ($range * 2) + 1;

    global $paged;
    if (empty($paged)) {
        $paged = 1;
    }

    if ($pages == '') {
        global $wp_query;
        $pages = $wp_query->max_num_pages ?: 1;
    }

    if ($pages > 1) {
        echo "<div class='navigation-paging pagination-num'>";
        if ($paged > 2 && $paged > $range + 1 && $showitems < $pages) {
            echo "<a href='" . get_pagenum_link(1) . "'>" . esc_html__('First', 'kasuari') . "</a>";
        }
        if ($paged > 1 && $showitems < $pages) {
            echo "<a href='" . get_pagenum_link($paged - 1) . "'>&lsaquo;</a>";
        }

        for ($i = 1; $i <= $pages; $i++) {
            if (1 != $pages && (!($i >= $paged + $range + 1 || $i <= $paged - $range - 1) || $pages <= $showitems)) {
                echo ($paged == $i)
                    ? "<span class='btn current'>$i</span>"
                    : "<a href='" . get_pagenum_link($i) . "' class='btn inactive'>$i</a>";
            }
        }

        if ($paged < $pages && $showitems < $pages) {
            echo "<a href='" . get_pagenum_link($paged + 1) . "'>&rsaquo;</a>";
        }
        if ($paged < $pages - 1 && $paged + $range - 1 < $pages && $showitems < $pages) {
            echo "<a href='" . get_pagenum_link($pages) . "'>" . esc_html__('Last', 'kasuari') . "</a>";
        }
        echo "</div>";
    }
}

/* --------------------------------------------------------------------- */
/*  PLACEHOLDERS DE FORMULÁRIOS DE COMENTÁRIO
/* --------------------------------------------------------------------- */
add_filter('comment_form_default_fields', 'kasuari_comment_placeholders');
function kasuari_comment_placeholders($fields) {
    $fields['author'] = str_replace('<input', '<input placeholder="' . esc_html__('Nome', 'kasuari') . '"', $fields['author']);
    $fields['email']  = str_replace('<input', '<input placeholder="' . esc_html__('Email', 'kasuari') . '"', $fields['email']);
    $fields['url']    = str_replace('<input', '<input placeholder="' . esc_html__('Site', 'kasuari') . '"', $fields['url']);
    return $fields;
}

add_filter('comment_form_defaults', 'kasuari_textarea_placeholder');
function kasuari_textarea_placeholder($fields) {
    $fields['comment_field'] = str_replace('<textarea', '<textarea placeholder="' . esc_html__('Digite seu comentário', 'kasuari') . '"', $fields['comment_field']);
    return $fields;
}

/* --------------------------------------------------------------------- */
/*  FUNÇÕES CUSTOMIZADAS
/* --------------------------------------------------------------------- */
require_once get_template_directory() . '/inc/function/custom.php';
require_once get_template_directory() . '/inc/function/navigation.php';
require_once get_template_directory() . '/inc/function/aq_resizer.php';
require_once get_template_directory() . '/inc/function/comment.php';
require_once get_template_directory() . '/inc/function/akmanda-customizer.php';
require_once get_template_directory() . '/inc/function/meta-box.php';
require_once get_template_directory() . '/inc/function/thefooter.php';
require_once get_template_directory() . '/inc/function/inline-styles.php';
require_once get_template_directory() . '/class-tgm.php';

/* --------------------------------------------------------------------- */
/*  CLASSES NO BODY E POST
/* --------------------------------------------------------------------- */
add_filter('body_class', 'kasuari_body_custom_class');
function kasuari_body_custom_class($classes) {
    if (class_exists('Redux')) {
        $classes[] = 'header-style-1';
    } else {
        $classes[] = 'header-style-1 no-redux';
    }
    return $classes;
}

function kasuari_post_custom_class($classes) {
    if (class_exists('Redux')) {
        $options = get_option('kasuari_framework');
        $column  = $options['blog_masonry_column'];

        if (is_front_page() && is_home()) {
            $classes[] = "blog-item masonry-blog column $column";
        } elseif (is_front_page() || is_home()) {
            $classes[] = "blog-item masonry-blog column $column";
        } elseif (is_archive() || is_search()) {
            $classes[] = 'blog-item masonry-blog column column-3';
        }
    } else {
        if (!is_singular(array('post', 'page'))) {
            $classes[] = 'blog-item masonry-blog column column-3';
        }
    }

    return $classes;
}
add_filter('post_class', 'kasuari_post_custom_class');

