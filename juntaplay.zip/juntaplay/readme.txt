=== JuntaPlay — Gestão de Cotas ===
Contributors: sua-empresa
Tags: woocommerce, elementor, raffle, quotas
Requires at least: 6.2
Tested up to: 6.4
Requires PHP: 8.1
Stable tag: 0.1.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Plugin completo para gestão de campanhas com cotas integrado ao WooCommerce e Elementor.

== Changelog ==
= 0.1.3 =
* Checkout dos grupos agora direciona para o WooCommerce com o valor configurado e um produto oculto dedicado para a assinatura.

= 0.1.2 =
* Ajustes no diretório público para paginação com 16 grupos, contatos protegidos no modal e CTA de checkout para "Assinar".
* Melhorias no catálogo de campanhas e no cabeçalho para visitantes mobile, além de preview imediato da capa ao criar grupos.
* Modal de grupos com resumo pronto para divulgação, botões de compartilhamento e fluxo de suporte controlado por associação.
