=== JuntaPlay — Gestão de Cotas ===
Contributors: sua-empresa
Tags: woocommerce, elementor, raffle, quotas
Requires at least: 6.2
Tested up to: 6.4
Requires PHP: 8.1
Stable tag: 0.1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Plugin completo para gestão de campanhas com cotas integrado ao WooCommerce e Elementor.
