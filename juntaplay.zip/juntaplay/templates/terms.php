<?php
declare(strict_types=1);
?>
<section class="juntaplay-terms">
    <h2><?php esc_html_e('Termos e Condições', 'juntaplay'); ?></h2>
    <p><?php esc_html_e('Adicione aqui seus termos, condições e regras de participação nas campanhas.', 'juntaplay'); ?></p>
</section>
