<?php
declare(strict_types=1);

defined('WP_UNINSTALL_PLUGIN') || exit;

// Mantemos dados por padrão. Remova opções se necessário.
