# Checkout media

Coloque aqui os arquivos estáticos utilizados pelo fluxo de confirmação:

- `thankyou-placeholder.svg` — ilustração genérica utilizada na segunda etapa da tela de agradecimento do checkout (`assets/images/thankyou-placeholder.svg`).
- `juntaplay-email.svg` — logotipo exibido no cabeçalho dos e-mails transacionais (`assets/images/juntaplay-email.png`).
