# Checkout media

Coloque aqui os arquivos estáticos utilizados pelo fluxo de confirmação:

- `agradecimento.gif` — utilizado na segunda etapa da tela de agradecimento do checkout (`assets/images/agradecimento.gif`).
- `juntaplay.png` — logotipo exibido no cabeçalho dos e-mails transacionais (`assets/images/juntaplay.png`).
