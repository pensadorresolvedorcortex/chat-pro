<?php do_action( 'cozystay_the_content_close' ); ?>
            </div> <!-- end of #content -->
            <?php get_template_part( 'template-parts/site-footer/footer' ); ?>
            <?php do_action( 'cozystay_the_page_close' ); ?>
        </div> <!-- end of #page -->

        <?php do_action( 'cozystay_after_site_footer' ); ?>
        <?php wp_footer(); ?>
    </script>
    </body>
</html>
