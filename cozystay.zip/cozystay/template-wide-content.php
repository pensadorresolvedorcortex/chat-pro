<?php
/**
* Template Name: Theme Template: Wide Content
* Template Post Type: page
*/

get_template_part( 'page' );
