<?php
/**
* 404 template
*/
do_action( 'cozystay_check_front_requirement' );
do_action( 'cozystay_the_404' );
