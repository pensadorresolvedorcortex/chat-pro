<div class="no-results not-found">
    <header class="entry-header">
        <h2 class="entry-title"><?php esc_html_e( 'Nothing Found', 'cozystay' ); ?></h2>
    </header>
</div>
