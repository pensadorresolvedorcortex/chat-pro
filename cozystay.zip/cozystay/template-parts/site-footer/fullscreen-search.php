<div class="search-screen">
	<div class="container">
		<span class="close-button"><?php esc_html_e( 'Close', 'cozystay' ); ?></span>
		<div class="search-wrapper">
			<?php get_search_form(); ?>
		</div>
	</div>
</div>
