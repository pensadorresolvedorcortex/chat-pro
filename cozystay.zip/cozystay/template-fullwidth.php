<?php
/**
* Template Name: Theme Template: No Sidebar
* Template Post Type: page
*/

get_template_part( 'page' );
