<?php
return apply_filters( 'cozystay_demo_configs', array() );
