<?php
/**
* Template Name: Theme Template: Left Sidebar
* Template Post Type: page
*/

get_template_part( 'page' );
