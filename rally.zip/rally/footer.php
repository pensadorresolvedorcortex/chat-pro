<?php
/**
 * The Footer: widgets area, logo, footer menu and socials
 *
 * @package RALLY
 * @since RALLY 1.0
 */

							do_action( 'rally_action_page_content_end_text' );
							
							// Widgets area below the content
							rally_create_widgets_area( 'widgets_below_content' );
						
							do_action( 'rally_action_page_content_end' );
							?>
						</div>
						<?php
						
						do_action( 'rally_action_after_page_content' );

						// Show main sidebar
						get_sidebar();

						do_action( 'rally_action_content_wrap_end' );
						?>
					</div>
					<?php

					do_action( 'rally_action_after_content_wrap' );

					// Widgets area below the page and related posts below the page
					$rally_body_style = rally_get_theme_option( 'body_style' );
					$rally_widgets_name = rally_get_theme_option( 'widgets_below_page', 'hide' );
					$rally_show_widgets = ! rally_is_off( $rally_widgets_name ) && is_active_sidebar( $rally_widgets_name );
					$rally_show_related = rally_is_single() && rally_get_theme_option( 'related_position', 'below_content' ) == 'below_page';
					if ( $rally_show_widgets || $rally_show_related ) {
						if ( 'fullscreen' != $rally_body_style ) {
							?>
							<div class="content_wrap">
							<?php
						}
						// Show related posts before footer
						if ( $rally_show_related ) {
							do_action( 'rally_action_related_posts' );
						}

						// Widgets area below page content
						if ( $rally_show_widgets ) {
							rally_create_widgets_area( 'widgets_below_page' );
						}
						if ( 'fullscreen' != $rally_body_style ) {
							?>
							</div>
							<?php
						}
					}
					do_action( 'rally_action_page_content_wrap_end' );
					?>
			</div>
			<?php
			do_action( 'rally_action_after_page_content_wrap' );

			// Don't display the footer elements while actions 'full_post_loading' and 'prev_post_loading'
			if ( ( ! rally_is_singular( 'post' ) && ! rally_is_singular( 'attachment' ) ) || ! in_array ( rally_get_value_gp( 'action' ), array( 'full_post_loading', 'prev_post_loading' ) ) ) {
				
				// Skip link anchor to fast access to the footer from keyboard
				?>
				<a id="footer_skip_link_anchor" class="rally_skip_link_anchor" href="#"></a>
				<?php

				do_action( 'rally_action_before_footer' );

				// Footer
				$rally_footer_type = rally_get_theme_option( 'footer_type' );
				if ( 'custom' == $rally_footer_type && ! rally_is_layouts_available() ) {
					$rally_footer_type = 'default';
				}
				get_template_part( apply_filters( 'rally_filter_get_template_part', "templates/footer-" . sanitize_file_name( $rally_footer_type ) ) );

				do_action( 'rally_action_after_footer' );

			}
			?>

			<?php do_action( 'rally_action_page_wrap_end' ); ?>

		</div>

		<?php do_action( 'rally_action_after_page_wrap' ); ?>

	</div>

	<?php do_action( 'rally_action_after_body' ); ?>

	<?php wp_footer(); ?>

</body>
</html>