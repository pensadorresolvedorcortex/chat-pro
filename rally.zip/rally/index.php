<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: //codex.wordpress.org/Template_Hierarchy
 *
 * @package RALLY
 * @since RALLY 1.0
 */

$rally_template = apply_filters( 'rally_filter_get_template_part', rally_blog_archive_get_template() );

if ( ! empty( $rally_template ) && 'index' != $rally_template ) {

	get_template_part( $rally_template );

} else {

	rally_storage_set( 'blog_archive', true );

	get_header();

	if ( have_posts() ) {

		// Query params
		$rally_stickies   = is_home()
								|| ( in_array( rally_get_theme_option( 'post_type' ), array( '', 'post' ) )
									&& (int) rally_get_theme_option( 'parent_cat' ) == 0
									)
										? get_option( 'sticky_posts' )
										: false;
		$rally_post_type  = rally_get_theme_option( 'post_type' );
		$rally_args       = array(
								'blog_style'     => rally_get_theme_option( 'blog_style' ),
								'post_type'      => $rally_post_type,
								'taxonomy'       => rally_get_post_type_taxonomy( $rally_post_type ),
								'parent_cat'     => rally_get_theme_option( 'parent_cat' ),
								'posts_per_page' => rally_get_theme_option( 'posts_per_page' ),
								'sticky'         => rally_get_theme_option( 'sticky_style', 'inherit' ) == 'columns'
															&& is_array( $rally_stickies )
															&& count( $rally_stickies ) > 0
															&& get_query_var( 'paged' ) < 1
								);

		rally_blog_archive_start();

		do_action( 'rally_action_blog_archive_start' );

		if ( is_author() ) {
			do_action( 'rally_action_before_page_author' );
			get_template_part( apply_filters( 'rally_filter_get_template_part', 'templates/author-page' ) );
			do_action( 'rally_action_after_page_author' );
		}

		if ( rally_get_theme_option( 'show_filters', 0 ) ) {
			do_action( 'rally_action_before_page_filters' );
			rally_show_filters( $rally_args );
			do_action( 'rally_action_after_page_filters' );
		} else {
			do_action( 'rally_action_before_page_posts' );
			rally_show_posts( array_merge( $rally_args, array( 'cat' => $rally_args['parent_cat'] ) ) );
			do_action( 'rally_action_after_page_posts' );
		}

		do_action( 'rally_action_blog_archive_end' );

		rally_blog_archive_end();

	} else {

		if ( is_search() ) {
			get_template_part( apply_filters( 'rally_filter_get_template_part', 'templates/content', 'none-search' ), 'none-search' );
		} else {
			get_template_part( apply_filters( 'rally_filter_get_template_part', 'templates/content', 'none-archive' ), 'none-archive' );
		}
	}

	get_footer();
}
