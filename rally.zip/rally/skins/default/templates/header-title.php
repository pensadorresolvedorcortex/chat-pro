<?php
/**
 * The template to display the page title and breadcrumbs
 *
 * @package RALLY
 * @since RALLY 1.0
 */

// Page (category, tag, archive, author) title

if ( rally_need_page_title() ) {
	rally_sc_layouts_showed( 'title', true );
	rally_sc_layouts_showed( 'postmeta', true );
	?>
	<div class="top_panel_title sc_layouts_row sc_layouts_row_type_normal">
		<div class="content_wrap">
			<div class="sc_layouts_column sc_layouts_column_align_center">
				<div class="sc_layouts_item">
					<div class="sc_layouts_title sc_align_center">
						<?php
						// Post meta on the single post
						if ( is_single() ) {
							?>
							<div class="sc_layouts_title_meta">
							<?php
								rally_show_post_meta(
									apply_filters(
										'rally_filter_post_meta_args', array(
											'components' => join( ',', rally_array_get_keys_by_value( rally_get_theme_option( 'meta_parts' ) ) ),
											'counters'   => join( ',', rally_array_get_keys_by_value( rally_get_theme_option( 'counters' ) ) ),
											'seo'        => rally_is_on( rally_get_theme_option( 'seo_snippets' ) ),
										), 'header', 1
									)
								);
							?>
							</div>
							<?php
						}

						// Blog/Post title
						?>
						<div class="sc_layouts_title_title">
							<?php
							$rally_blog_title           = rally_get_blog_title();
							$rally_blog_title_text      = '';
							$rally_blog_title_class     = '';
							$rally_blog_title_link      = '';
							$rally_blog_title_link_text = '';
							if ( is_array( $rally_blog_title ) ) {
								$rally_blog_title_text      = $rally_blog_title['text'];
								$rally_blog_title_class     = ! empty( $rally_blog_title['class'] ) ? ' ' . $rally_blog_title['class'] : '';
								$rally_blog_title_link      = ! empty( $rally_blog_title['link'] ) ? $rally_blog_title['link'] : '';
								$rally_blog_title_link_text = ! empty( $rally_blog_title['link_text'] ) ? $rally_blog_title['link_text'] : '';
							} else {
								$rally_blog_title_text = $rally_blog_title;
							}
							?>
							<h1 itemprop="headline" class="sc_layouts_title_caption<?php echo esc_attr( $rally_blog_title_class ); ?>">
								<?php
								$rally_top_icon = rally_get_term_image_small();
								if ( ! empty( $rally_top_icon ) ) {
									$rally_attr = rally_getimagesize( $rally_top_icon );
									?>
									<img src="<?php echo esc_url( $rally_top_icon ); ?>" alt="<?php esc_attr_e( 'Site icon', 'rally' ); ?>"
										<?php
										if ( ! empty( $rally_attr[3] ) ) {
											rally_show_layout( $rally_attr[3] );
										}
										?>
									>
									<?php
								}
								echo wp_kses_data( $rally_blog_title_text );
								?>
							</h1>
							<?php
							if ( ! empty( $rally_blog_title_link ) && ! empty( $rally_blog_title_link_text ) ) {
								?>
								<a href="<?php echo esc_url( $rally_blog_title_link ); ?>" class="theme_button theme_button_small sc_layouts_title_link"><?php echo esc_html( $rally_blog_title_link_text ); ?></a>
								<?php
							}

							// Category/Tag description
							if ( ! is_paged() && ( is_category() || is_tag() || is_tax() ) ) {
								the_archive_description( '<div class="sc_layouts_title_description">', '</div>' );
							}

							?>
						</div>
						<?php

						// Breadcrumbs
						ob_start();
						do_action( 'rally_action_breadcrumbs' );
						$rally_breadcrumbs = ob_get_contents();
						ob_end_clean();
						rally_show_layout( $rally_breadcrumbs, '<div class="sc_layouts_title_breadcrumbs">', '</div>' );
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
}
