<?php
/**
 * The template to display the background video in the header
 *
 * @package RALLY
 * @since RALLY 1.0.14
 */
$rally_header_video = rally_get_header_video();
$rally_embed_video  = '';
if ( ! empty( $rally_header_video ) && ! rally_is_from_uploads( $rally_header_video ) ) {
	if ( rally_is_youtube_url( $rally_header_video ) && preg_match( '/[=\/]([^=\/]*)$/', $rally_header_video, $matches ) && ! empty( $matches[1] ) ) {
		?><div id="background_video" data-youtube-code="<?php echo esc_attr( $matches[1] ); ?>"></div>
		<?php
	} else {
		?>
		<div id="background_video"><?php rally_show_layout( rally_get_embed_video( $rally_header_video ) ); ?></div>
		<?php
	}
}
