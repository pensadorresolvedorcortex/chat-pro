<?php
/**
 * The template to display the logo or the site name and the slogan in the Header
 *
 * @package RALLY
 * @since RALLY 1.0
 */

$rally_args = get_query_var( 'rally_logo_args' );

// Site logo
$rally_logo_type   = isset( $rally_args['type'] ) ? $rally_args['type'] : '';
$rally_logo_image  = rally_get_logo_image( $rally_logo_type );
$rally_logo_text   = rally_is_on( rally_get_theme_option( 'logo_text' ) ) ? get_bloginfo( 'name' ) : '';
$rally_logo_slogan = get_bloginfo( 'description', 'display' );
if ( ! empty( $rally_logo_image['logo'] ) || ! empty( $rally_logo_text ) ) {
	?><a class="sc_layouts_logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
		<?php
		if ( ! empty( $rally_logo_image['logo'] ) ) {
			if ( empty( $rally_logo_type ) && function_exists( 'the_custom_logo' ) && is_numeric($rally_logo_image['logo']) && (int) $rally_logo_image['logo'] > 0 ) {
				the_custom_logo();
			} else {
				$rally_attr = rally_getimagesize( $rally_logo_image['logo'] );
				echo '<img src="' . esc_url( $rally_logo_image['logo'] ) . '"'
						. ( ! empty( $rally_logo_image['logo_retina'] ) ? ' srcset="' . esc_url( $rally_logo_image['logo_retina'] ) . ' 2x"' : '' )
						. ' alt="' . esc_attr( $rally_logo_text ) . '"'
						. ( ! empty( $rally_attr[3] ) ? ' ' . wp_kses_data( $rally_attr[3] ) : '' )
						. '>';
			}
		} else {
			rally_show_layout( rally_prepare_macros( $rally_logo_text ), '<span class="logo_text">', '</span>' );
			rally_show_layout( rally_prepare_macros( $rally_logo_slogan ), '<span class="logo_slogan">', '</span>' );
		}
		?>
	</a>
	<?php
}
