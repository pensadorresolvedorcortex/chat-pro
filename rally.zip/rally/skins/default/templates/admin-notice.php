<?php
/**
 * The template to display Admin notices
 *
 * @package RALLY
 * @since RALLY 1.0.1
 */

$rally_theme_slug = get_option( 'template' );
$rally_theme_obj  = wp_get_theme( $rally_theme_slug );
?>
<div class="rally_admin_notice rally_welcome_notice notice notice-info is-dismissible" data-notice="admin">
	<?php
	// Theme image
	$rally_theme_img = rally_get_file_url( 'screenshot.jpg' );
	if ( '' != $rally_theme_img ) {
		?>
		<div class="rally_notice_image"><img src="<?php echo esc_url( $rally_theme_img ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'rally' ); ?>"></div>
		<?php
	}

	// Title
	?>
	<h3 class="rally_notice_title">
		<?php
		echo esc_html(
			sprintf(
				// Translators: Add theme name and version to the 'Welcome' message
				__( 'Welcome to %1$s v.%2$s', 'rally' ),
				$rally_theme_obj->get( 'Name' ) . ( RALLY_THEME_FREE ? ' ' . __( 'Free', 'rally' ) : '' ),
				$rally_theme_obj->get( 'Version' )
			)
		);
		?>
	</h3>
	<?php

	// Description
	?>
	<div class="rally_notice_text">
		<p class="rally_notice_text_description">
			<?php
			echo str_replace( '. ', '.<br>', wp_kses_data( $rally_theme_obj->description ) );
			?>
		</p>
		<p class="rally_notice_text_info">
			<?php
			echo wp_kses_data( __( 'Attention! Plugin "ThemeREX Addons" is required! Please, install and activate it!', 'rally' ) );
			?>
		</p>
	</div>
	<?php

	// Buttons
	?>
	<div class="rally_notice_buttons">
		<?php
		// Link to the page 'About Theme'
		?>
		<a href="<?php echo esc_url( admin_url() . 'themes.php?page=rally_about' ); ?>" class="button button-primary"><i class="dashicons dashicons-nametag"></i> 
			<?php
			echo esc_html__( 'Install plugin "ThemeREX Addons"', 'rally' );
			?>
		</a>
	</div>
</div>
