<?php
/**
 * The template to display the widgets area in the footer
 *
 * @package RALLY
 * @since RALLY 1.0.10
 */

// Footer sidebar
$rally_footer_name    = rally_get_theme_option( 'footer_widgets' );
$rally_footer_present = ! rally_is_off( $rally_footer_name ) && is_active_sidebar( $rally_footer_name );
if ( $rally_footer_present ) {
	rally_storage_set( 'current_sidebar', 'footer' );
	$rally_footer_wide = rally_get_theme_option( 'footer_wide' );
	ob_start();
	if ( is_active_sidebar( $rally_footer_name ) ) {
		dynamic_sidebar( $rally_footer_name );
	}
	$rally_out = trim( ob_get_contents() );
	ob_end_clean();
	if ( ! empty( $rally_out ) ) {
		$rally_out          = preg_replace( "/<\\/aside>[\r\n\s]*<aside/", '</aside><aside', $rally_out );
		$rally_need_columns = true;   //or check: strpos($rally_out, 'columns_wrap')===false;
		if ( $rally_need_columns ) {
			$rally_columns = max( 0, (int) rally_get_theme_option( 'footer_columns' ) );			
			if ( 0 == $rally_columns ) {
				$rally_columns = min( 4, max( 1, rally_tags_count( $rally_out, 'aside' ) ) );
			}
			if ( $rally_columns > 1 ) {
				$rally_out = preg_replace( '/<aside([^>]*)class="widget/', '<aside$1class="column-1_' . esc_attr( $rally_columns ) . ' widget', $rally_out );
			} else {
				$rally_need_columns = false;
			}
		}
		?>
		<div class="footer_widgets_wrap widget_area<?php echo ! empty( $rally_footer_wide ) ? ' footer_fullwidth' : ''; ?> sc_layouts_row sc_layouts_row_type_normal">
			<?php do_action( 'rally_action_before_sidebar_wrap', 'footer' ); ?>
			<div class="footer_widgets_inner widget_area_inner">
				<?php
				if ( ! $rally_footer_wide ) {
					?>
					<div class="content_wrap">
					<?php
				}
				if ( $rally_need_columns ) {
					?>
					<div class="columns_wrap">
					<?php
				}
				do_action( 'rally_action_before_sidebar', 'footer' );
				rally_show_layout( $rally_out );
				do_action( 'rally_action_after_sidebar', 'footer' );
				if ( $rally_need_columns ) {
					?>
					</div><!-- /.columns_wrap -->
					<?php
				}
				if ( ! $rally_footer_wide ) {
					?>
					</div><!-- /.content_wrap -->
					<?php
				}
				?>
			</div><!-- /.footer_widgets_inner -->
			<?php do_action( 'rally_action_after_sidebar_wrap', 'footer' ); ?>
		</div><!-- /.footer_widgets_wrap -->
		<?php
	}
}
