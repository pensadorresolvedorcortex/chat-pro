<?php
/**
 * The template to display the copyright info in the footer
 *
 * @package RALLY
 * @since RALLY 1.0.10
 */

// Copyright area
?> 
<div class="footer_copyright_wrap
<?php
$rally_copyright_scheme = rally_get_theme_option( 'copyright_scheme' );
if ( ! empty( $rally_copyright_scheme ) && ! rally_is_inherit( $rally_copyright_scheme  ) ) {
	echo ' scheme_' . esc_attr( $rally_copyright_scheme );
}
?>
				">
	<div class="footer_copyright_inner">
		<div class="content_wrap">
			<div class="copyright_text">
			<?php
				$rally_copyright = rally_get_theme_option( 'copyright' );
			if ( ! empty( $rally_copyright ) ) {
				// Replace {{Y}} or {Y} with the current year
				$rally_copyright = str_replace( array( '{{Y}}', '{Y}' ), date( 'Y' ), $rally_copyright );
				// Replace {{...}} and ((...)) on the <i>...</i> and <b>...</b>
				$rally_copyright = rally_prepare_macros( $rally_copyright );
				// Display copyright
				echo wp_kses( nl2br( $rally_copyright ), 'rally_kses_content' );
			}
			?>
			</div>
		</div>
	</div>
</div>
