<?php
/**
 * The custom template to display the content
 *
 * Used for index/archive/search.
 *
 * @package RALLY
 * @since RALLY 1.0.50
 */

$rally_template_args = get_query_var( 'rally_template_args' );
if ( is_array( $rally_template_args ) ) {
	$rally_columns    = empty( $rally_template_args['columns'] ) ? 2 : max( 1, $rally_template_args['columns'] );
	$rally_blog_style = array( $rally_template_args['type'], $rally_columns );
} else {
	$rally_template_args = array();
	$rally_blog_style = explode( '_', rally_get_theme_option( 'blog_style' ) );
	$rally_columns    = empty( $rally_blog_style[1] ) ? 2 : max( 1, $rally_blog_style[1] );
}
$rally_blog_id       = rally_get_custom_blog_id( join( '_', $rally_blog_style ) );
$rally_blog_style[0] = str_replace( 'blog-custom-', '', $rally_blog_style[0] );
$rally_expanded      = ! rally_sidebar_present() && rally_get_theme_option( 'expand_content' ) == 'expand';
$rally_components    = ! empty( $rally_template_args['meta_parts'] )
							? ( is_array( $rally_template_args['meta_parts'] )
								? join( ',', $rally_template_args['meta_parts'] )
								: $rally_template_args['meta_parts']
								)
							: rally_array_get_keys_by_value( rally_get_theme_option( 'meta_parts' ) );
$rally_post_format   = get_post_format();
$rally_post_format   = empty( $rally_post_format ) ? 'standard' : str_replace( 'post-format-', '', $rally_post_format );

$rally_blog_meta     = rally_get_custom_layout_meta( $rally_blog_id );
$rally_custom_style  = ! empty( $rally_blog_meta['scripts_required'] ) ? $rally_blog_meta['scripts_required'] : 'none';

if ( ! empty( $rally_template_args['slider'] ) || $rally_columns > 1 || ! rally_is_off( $rally_custom_style ) ) {
	?><div class="
		<?php
		if ( ! empty( $rally_template_args['slider'] ) ) {
			echo 'slider-slide swiper-slide';
		} else {
			echo esc_attr( ( rally_is_off( $rally_custom_style ) ? 'column' : sprintf( '%1$s_item %1$s_item', $rally_custom_style ) ) . "-1_{$rally_columns}" );
		}
		?>
	">
	<?php
}
?>
<article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class(
			'post_item post_item_container post_format_' . esc_attr( $rally_post_format )
					. ' post_layout_custom post_layout_custom_' . esc_attr( $rally_columns )
					. ' post_layout_' . esc_attr( $rally_blog_style[0] )
					. ' post_layout_' . esc_attr( $rally_blog_style[0] ) . '_' . esc_attr( $rally_columns )
					. ( ! rally_is_off( $rally_custom_style )
						? ' post_layout_' . esc_attr( $rally_custom_style )
							. ' post_layout_' . esc_attr( $rally_custom_style ) . '_' . esc_attr( $rally_columns )
						: ''
						)
		);
	rally_add_blog_animation( $rally_template_args );
	?>
>
	<?php
	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}
	// Custom layout
	do_action( 'rally_action_show_layout', $rally_blog_id, get_the_ID() );
	?>
</article><?php
if ( ! empty( $rally_template_args['slider'] ) || $rally_columns > 1 || ! rally_is_off( $rally_custom_style ) ) {
	?></div><?php
	// Need opening PHP-tag above just after </div>, because <div> is a inline-block element (used as column)!
}
