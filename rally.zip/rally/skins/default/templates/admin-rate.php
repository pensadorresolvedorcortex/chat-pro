<?php
/**
 * The template to display Admin notices
 *
 * @package RALLY
 * @since RALLY 1.0.1
 */

$rally_theme_slug = get_template();
$rally_theme_obj  = wp_get_theme( $rally_theme_slug );

?>
<div class="rally_admin_notice rally_rate_notice notice notice-info is-dismissible" data-notice="rate">
	<?php
	// Theme image
	$rally_theme_img = rally_get_file_url( 'screenshot.jpg' );
	if ( '' != $rally_theme_img ) {
		?>
		<div class="rally_notice_image"><img src="<?php echo esc_url( $rally_theme_img ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'rally' ); ?>"></div>
		<?php
	}

	// Title
	$rally_theme_name = '"' . $rally_theme_obj->get( 'Name' ) . ( RALLY_THEME_FREE ? ' ' . __( 'Free', 'rally' ) : '' ) . '"';
	?>
	<h3 class="rally_notice_title"><a href="<?php echo esc_url( rally_storage_get( 'theme_rate_url' ) ); ?>" target="_blank">
		<?php
		echo esc_html(
			sprintf(
				// Translators: Add theme name to the 'Welcome' message
				__( 'Help Us Grow - Rate %s Today!', 'rally' ),
				$rally_theme_name
			)
		);
		?>
	</a></h3>
	<?php

	// Description
	?>
	<div class="rally_notice_text">
		<p><?php
			// Translators: Add theme name to the 'Welcome' message
			echo wp_kses_data( sprintf( __( "Thank you for choosing the %s theme for your website! We're excited to see how you've customized your site, and we hope you've enjoyed working with our theme.", 'rally' ), $rally_theme_name ) );
		?></p>
		<p><?php
			// Translators: Add theme name to the 'Welcome' message
			echo wp_kses_data( sprintf( __( "Your feedback really matters to us! If you've had a positive experience, we'd love for you to take a moment to rate %s and share your thoughts on the customer service you received.", 'rally' ), $rally_theme_name ) );
		?></p>
	</div>
	<?php

	// Buttons
	?>
	<div class="rally_notice_buttons">
		<?php
		// Link to the theme download page
		?>
		<a href="<?php echo esc_url( rally_storage_get( 'theme_rate_url' ) ); ?>" class="button button-primary" target="_blank"><i class="dashicons dashicons-star-filled"></i> 
			<?php
			// Translators: Add the theme name to the button caption
			echo esc_html( sprintf( __( 'Rate %s Now', 'rally' ), $rally_theme_name ) );
			?>
		</a>
		<?php
		// Link to the theme support
		?>
		<a href="<?php echo esc_url( rally_storage_get( 'theme_support_url' ) ); ?>" class="button" target="_blank"><i class="dashicons dashicons-sos"></i> 
			<?php
			esc_html_e( 'Support', 'rally' );
			?>
		</a>
		<?php
		// Link to the theme documentation
		?>
		<a href="<?php echo esc_url( rally_storage_get( 'theme_doc_url' ) ); ?>" class="button" target="_blank"><i class="dashicons dashicons-book"></i> 
			<?php
			esc_html_e( 'Documentation', 'rally' );
			?>
		</a>
	</div>
</div>
