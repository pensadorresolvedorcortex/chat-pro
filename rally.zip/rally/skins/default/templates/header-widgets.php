<?php
/**
 * The template to display the widgets area in the header
 *
 * @package RALLY
 * @since RALLY 1.0
 */

// Header sidebar
$rally_header_name    = rally_get_theme_option( 'header_widgets' );
$rally_header_present = ! rally_is_off( $rally_header_name ) && is_active_sidebar( $rally_header_name );
if ( $rally_header_present ) {
	rally_storage_set( 'current_sidebar', 'header' );
	$rally_header_wide = rally_get_theme_option( 'header_wide' );
	ob_start();
	if ( is_active_sidebar( $rally_header_name ) ) {
		dynamic_sidebar( $rally_header_name );
	}
	$rally_widgets_output = ob_get_contents();
	ob_end_clean();
	if ( ! empty( $rally_widgets_output ) ) {
		$rally_widgets_output = preg_replace( "/<\/aside>[\r\n\s]*<aside/", '</aside><aside', $rally_widgets_output );
		$rally_need_columns   = strpos( $rally_widgets_output, 'columns_wrap' ) === false;
		if ( $rally_need_columns ) {
			$rally_columns = max( 0, (int) rally_get_theme_option( 'header_columns' ) );
			if ( 0 == $rally_columns ) {
				$rally_columns = min( 6, max( 1, rally_tags_count( $rally_widgets_output, 'aside' ) ) );
			}
			if ( $rally_columns > 1 ) {
				$rally_widgets_output = preg_replace( '/<aside([^>]*)class="widget/', '<aside$1class="column-1_' . esc_attr( $rally_columns ) . ' widget', $rally_widgets_output );
			} else {
				$rally_need_columns = false;
			}
		}
		?>
		<div class="header_widgets_wrap widget_area<?php echo ! empty( $rally_header_wide ) ? ' header_fullwidth' : ' header_boxed'; ?>">
			<?php do_action( 'rally_action_before_sidebar_wrap', 'header' ); ?>
			<div class="header_widgets_inner widget_area_inner">
				<?php
				if ( ! $rally_header_wide ) {
					?>
					<div class="content_wrap">
					<?php
				}
				if ( $rally_need_columns ) {
					?>
					<div class="columns_wrap">
					<?php
				}
				do_action( 'rally_action_before_sidebar', 'header' );
				rally_show_layout( $rally_widgets_output );
				do_action( 'rally_action_after_sidebar', 'header' );
				if ( $rally_need_columns ) {
					?>
					</div>	<!-- /.columns_wrap -->
					<?php
				}
				if ( ! $rally_header_wide ) {
					?>
					</div>	<!-- /.content_wrap -->
					<?php
				}
				?>
			</div>	<!-- /.header_widgets_inner -->
			<?php do_action( 'rally_action_after_sidebar_wrap', 'header' ); ?>
		</div>	<!-- /.header_widgets_wrap -->
		<?php
	}
}
