<?php
/**
 * The template to display Admin notices
 *
 * @package RALLY
 * @since RALLY 1.98.0
 */

$rally_skins_url   = get_admin_url( null, 'admin.php?page=trx_addons_theme_panel#trx_addons_theme_panel_section_skins' );
$rally_active_skin = rally_skins_get_active_skin_name();
?>
<div class="rally_admin_notice rally_skins_notice notice notice-error">
	<?php
	// Theme image
	$rally_theme_img = rally_get_file_url( 'screenshot.jpg' );
	if ( '' != $rally_theme_img ) {
		?>
		<div class="rally_notice_image"><img src="<?php echo esc_url( $rally_theme_img ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'rally' ); ?>"></div>
		<?php
	}

	// Title
	?>
	<h3 class="rally_notice_title">
		<?php esc_html_e( 'Active skin is missing!', 'rally' ); ?>
	</h3>
	<div class="rally_notice_text">
		<p>
			<?php
			// Translators: Add a current skin name to the message
			echo wp_kses_data( sprintf( __( "Your active skin <b>'%s'</b> is missing. Usually this happens when the theme is updated directly through the server or FTP.", 'rally' ), ucfirst( $rally_active_skin ) ) );
			?>
		</p>
		<p>
			<?php
			echo wp_kses_data( __( "Please use only <b>'ThemeREX Updater v.1.6.0+'</b> plugin for your future updates.", 'rally' ) );
			?>
		</p>
		<p>
			<?php
			echo wp_kses_data( __( "But no worries! You can re-download the skin via 'Skins Manager' ( Theme Panel - Theme Dashboard - Skins ).", 'rally' ) );
			?>
		</p>
	</div>
	<?php

	// Buttons
	?>
	<div class="rally_notice_buttons">
		<?php
		// Link to the theme dashboard page
		?>
		<a href="<?php echo esc_url( $rally_skins_url ); ?>" class="button button-primary"><i class="dashicons dashicons-update"></i> 
			<?php
			// Translators: Add theme name
			esc_html_e( 'Go to Skins manager', 'rally' );
			?>
		</a>
	</div>
</div>
