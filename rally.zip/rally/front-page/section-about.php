<div class="front_page_section front_page_section_about<?php
	$rally_scheme = rally_get_theme_option( 'front_page_about_scheme' );
	if ( ! empty( $rally_scheme ) && ! rally_is_inherit( $rally_scheme ) ) {
		echo ' scheme_' . esc_attr( $rally_scheme );
	}
	echo ' front_page_section_paddings_' . esc_attr( rally_get_theme_option( 'front_page_about_paddings' ) );
	if ( rally_get_theme_option( 'front_page_about_stack' ) ) {
		echo ' sc_stack_section_on';
	}
?>"
		<?php
		$rally_css      = '';
		$rally_bg_image = rally_get_theme_option( 'front_page_about_bg_image' );
		if ( ! empty( $rally_bg_image ) ) {
			$rally_css .= 'background-image: url(' . esc_url( rally_get_attachment_url( $rally_bg_image ) ) . ');';
		}
		if ( ! empty( $rally_css ) ) {
			echo ' style="' . esc_attr( $rally_css ) . '"';
		}
		?>
>
<?php
	// Add anchor
	$rally_anchor_icon = rally_get_theme_option( 'front_page_about_anchor_icon' );
	$rally_anchor_text = rally_get_theme_option( 'front_page_about_anchor_text' );
if ( ( ! empty( $rally_anchor_icon ) || ! empty( $rally_anchor_text ) ) && shortcode_exists( 'trx_sc_anchor' ) ) {
	echo do_shortcode(
		'[trx_sc_anchor id="front_page_section_about"'
									. ( ! empty( $rally_anchor_icon ) ? ' icon="' . esc_attr( $rally_anchor_icon ) . '"' : '' )
									. ( ! empty( $rally_anchor_text ) ? ' title="' . esc_attr( $rally_anchor_text ) . '"' : '' )
									. ']'
	);
}
?>
	<div class="front_page_section_inner front_page_section_about_inner
	<?php
	if ( rally_get_theme_option( 'front_page_about_fullheight' ) ) {
		echo ' rally-full-height sc_layouts_flex sc_layouts_columns_middle';
	}
	?>
			"
			<?php
			$rally_css           = '';
			$rally_bg_mask       = rally_get_theme_option( 'front_page_about_bg_mask' );
			$rally_bg_color_type = rally_get_theme_option( 'front_page_about_bg_color_type' );
			if ( 'custom' == $rally_bg_color_type ) {
				$rally_bg_color = rally_get_theme_option( 'front_page_about_bg_color' );
			} elseif ( 'scheme_bg_color' == $rally_bg_color_type ) {
				$rally_bg_color = rally_get_scheme_color( 'bg_color', $rally_scheme );
			} else {
				$rally_bg_color = '';
			}
			if ( ! empty( $rally_bg_color ) && $rally_bg_mask > 0 ) {
				$rally_css .= 'background-color: ' . esc_attr(
					1 == $rally_bg_mask ? $rally_bg_color : rally_hex2rgba( $rally_bg_color, $rally_bg_mask )
				) . ';';
			}
			if ( ! empty( $rally_css ) ) {
				echo ' style="' . esc_attr( $rally_css ) . '"';
			}
			?>
	>
		<div class="front_page_section_content_wrap front_page_section_about_content_wrap content_wrap">
			<?php
			// Caption
			$rally_caption = rally_get_theme_option( 'front_page_about_caption' );
			if ( ! empty( $rally_caption ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<h2 class="front_page_section_caption front_page_section_about_caption front_page_block_<?php echo ! empty( $rally_caption ) ? 'filled' : 'empty'; ?>"><?php echo wp_kses( $rally_caption, 'rally_kses_content' ); ?></h2>
				<?php
			}

			// Description (text)
			$rally_description = rally_get_theme_option( 'front_page_about_description' );
			if ( ! empty( $rally_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<div class="front_page_section_description front_page_section_about_description front_page_block_<?php echo ! empty( $rally_description ) ? 'filled' : 'empty'; ?>"><?php echo wp_kses( wpautop( $rally_description ), 'rally_kses_content' ); ?></div>
				<?php
			}

			// Content
			$rally_content = rally_get_theme_option( 'front_page_about_content' );
			if ( ! empty( $rally_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<div class="front_page_section_content front_page_section_about_content front_page_block_<?php echo ! empty( $rally_content ) ? 'filled' : 'empty'; ?>">
					<?php
					$rally_page_content_mask = '%%CONTENT%%';
					if ( strpos( $rally_content, $rally_page_content_mask ) !== false ) {
						$rally_content = preg_replace(
							'/(\<p\>\s*)?' . $rally_page_content_mask . '(\s*\<\/p\>)/i',
							sprintf(
								'<div class="front_page_section_about_source">%s</div>',
								apply_filters( 'the_content', get_the_content() )
							),
							$rally_content
						);
					}
					rally_show_layout( $rally_content );
					?>
				</div>
				<?php
			}
			?>
		</div>
	</div>
</div>
