<?php
/**
 * The template to display the attachment
 *
 * @package RALLY
 * @since RALLY 1.0
 */


get_header();

while ( have_posts() ) {
	the_post();

	// Display post's content
	get_template_part( apply_filters( 'rally_filter_get_template_part', 'templates/content', 'single-' . rally_get_theme_option( 'single_style' ) ), 'single-' . rally_get_theme_option( 'single_style' ) );

	// Parent post navigation.
	$rally_posts_navigation = rally_get_theme_option( 'posts_navigation' );
	if ( 'links' == $rally_posts_navigation ) {
		?>
		<div class="nav-links-single<?php
			if ( ! rally_is_off( rally_get_theme_option( 'posts_navigation_fixed', 0 ) ) ) {
				echo ' nav-links-fixed fixed';
			}
		?>">
			<?php
			the_post_navigation( apply_filters( 'rally_filter_post_navigation_args', array(
					'prev_text' => '<span class="nav-arrow"></span>'
						. '<span class="meta-nav" aria-hidden="true">' . esc_html__( 'Published in', 'rally' ) . '</span> '
						. '<span class="screen-reader-text">' . esc_html__( 'Previous post:', 'rally' ) . '</span> '
						. '<h5 class="post-title">%title</h5>'
						. '<span class="post_date">%date</span>',
			), 'image' ) );
			?>
		</div>
		<?php
	}

	// Comments
	do_action( 'rally_action_before_comments' );
	comments_template();
	do_action( 'rally_action_after_comments' );
}

get_footer();
