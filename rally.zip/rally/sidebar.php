<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package RALLY
 * @since RALLY 1.0
 */

if ( rally_sidebar_present() ) {
	
	$rally_sidebar_type = rally_get_theme_option( 'sidebar_type' );
	if ( 'custom' == $rally_sidebar_type && ! rally_is_layouts_available() ) {
		$rally_sidebar_type = 'default';
	}
	
	// Catch output to the buffer
	ob_start();
	if ( 'default' == $rally_sidebar_type ) {
		// Default sidebar with widgets
		$rally_sidebar_name = rally_get_theme_option( 'sidebar_widgets' );
		rally_storage_set( 'current_sidebar', 'sidebar' );
		if ( is_active_sidebar( $rally_sidebar_name ) ) {
			dynamic_sidebar( $rally_sidebar_name );
		}
	} else {
		// Custom sidebar from Layouts Builder
		$rally_sidebar_id = rally_get_custom_sidebar_id();
		do_action( 'rally_action_show_layout', $rally_sidebar_id );
	}
	$rally_out = trim( ob_get_contents() );
	ob_end_clean();
	
	// If any html is present - display it
	if ( ! empty( $rally_out ) ) {
		$rally_sidebar_position    = rally_get_theme_option( 'sidebar_position' );
		$rally_sidebar_position_ss = rally_get_theme_option( 'sidebar_position_ss', 'below' );
		?>
		<div class="sidebar widget_area
			<?php
			echo ' ' . esc_attr( $rally_sidebar_position );
			echo ' sidebar_' . esc_attr( $rally_sidebar_position_ss );
			echo ' sidebar_' . esc_attr( $rally_sidebar_type );

			$rally_sidebar_scheme = apply_filters( 'rally_filter_sidebar_scheme', rally_get_theme_option( 'sidebar_scheme', 'inherit' ) );
			if ( ! empty( $rally_sidebar_scheme ) && ! rally_is_inherit( $rally_sidebar_scheme ) && 'custom' != $rally_sidebar_type ) {
				echo ' scheme_' . esc_attr( $rally_sidebar_scheme );
			}
			?>
		" role="complementary">
			<?php

			// Skip link anchor to fast access to the sidebar from keyboard
			?>
			<a id="sidebar_skip_link_anchor" class="rally_skip_link_anchor" href="#"></a>
			<?php

			do_action( 'rally_action_before_sidebar_wrap', 'sidebar' );

			// Button to show/hide sidebar on mobile
			if ( in_array( $rally_sidebar_position_ss, array( 'above', 'float' ) ) ) {
				$rally_title = apply_filters( 'rally_filter_sidebar_control_title', 'float' == $rally_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'rally' ) : '' );
				$rally_text  = apply_filters( 'rally_filter_sidebar_control_text', 'above' == $rally_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'rally' ) : '' );
				?>
				<a href="#" class="sidebar_control" title="<?php echo esc_attr( $rally_title ); ?>"><?php echo esc_html( $rally_text ); ?></a>
				<?php
			}
			?>
			<div class="sidebar_inner">
				<?php
				do_action( 'rally_action_before_sidebar', 'sidebar' );
				rally_show_layout( preg_replace( "/<\/aside>[\r\n\s]*<aside/", '</aside><aside', $rally_out ) );
				do_action( 'rally_action_after_sidebar', 'sidebar' );
				?>
			</div>
			<?php

			do_action( 'rally_action_after_sidebar_wrap', 'sidebar' );

			?>
		</div>
		<div class="clearfix"></div>
		<?php
	}
}
