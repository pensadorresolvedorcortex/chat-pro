<?php

require_once dirname( __FILE__ ) . '/class.settings-api.php';
require_once dirname( __FILE__ ) . '/gdw_fields.php';

new Gdw_Settings_API_Test();
?>