<?php
// File Security Check
if (!defined('ABSPATH')) {
	exit;
}


/* THeme purchase check */
if (!function_exists('shadepro_update_check')) {
    function shadepro_update_check( $slug )
    {
            $slug = strtolower($slug);
            $url = "https://update.grayic.com?action=get_metadata&slug={$slug}" ;
            
            $response = wp_remote_get( $url);
            // $response_code = wp_remote_retrieve_response_code( $response );
            $response_body = wp_remote_retrieve_body( $response );
            $envatoRes = json_decode($response_body);
            if ( $envatoRes->version ) {
                return version_compare($envatoRes->version, SHADE_THEME_VERSION);
            } else {
                return false;
            }

    }
}



require_once SHADE_INC_DIR . '/lib/plugin-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
    'https://update.grayic.com?action=get_metadata&slug=shadepro',
    __FILE__, //Full path to the main plugin file or functions.php.
    'shadepro'
);