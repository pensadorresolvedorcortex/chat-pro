<?php
global $shadepro;
$has_site_logo =   (!empty(shadepro_get_site_logo())) ? 'has-site-logo' : '';
?>
