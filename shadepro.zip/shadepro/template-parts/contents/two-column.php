<div class="col-md-6">
    
    <?php get_template_part( 'template-parts/contents/content' );?>

</div>