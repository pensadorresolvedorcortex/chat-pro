<div class="col-lg-4 col-12">
    
    <?php get_template_part( 'template-parts/contents/content' );?>

</div>