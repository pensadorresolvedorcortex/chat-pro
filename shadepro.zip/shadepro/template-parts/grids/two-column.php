<div class="col-lg-6 col-12">
    
    <?php get_template_part( 'template-parts/contents/content' );?>

</div>