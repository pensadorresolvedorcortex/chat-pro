<?php
// Não é utilizado no sistema, apenas para matar as sessões testes
session_start();
unset($_SESSION["LembrarSenha"]);
 ?>
