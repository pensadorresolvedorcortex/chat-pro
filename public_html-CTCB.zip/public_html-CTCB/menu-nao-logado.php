<div class="row" style="padding: 10px">
  <button class="btn btn-primary" style="width: 100%; font-weight: bold" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/cadastro-associado/'"><i class="far fa-address-card fa-lg"></i> Quero me associar </br>
Atirador</button>
</div>


<button class="btn btn-success" style="width: 100%; font-weight: bold" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/cadastrar_clube/'"><i class="far fa-address-card fa-lg"></i>
 Clube de Tiro? <br>Cadastre aqui!</button>
<hr>
<button class="btn btn-danger" style="width: 100%; font-weight: bold" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/cadastro-associado/'"><i class="far fa-address-card fa-lg"></i> Confira sua Filiação</button>

<hr>
          <button class="btn btn-danger" style="width: 100%; font-weight: bold" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/validar-documentos/'"><i class="fas fa-check"></i> Validar Documentos</button>
<hr>

<h5 style="width: 100%; text-align: center;"><a href="#!" data-toggle="modal" data-target="#myModal" style="color:#218838"><i class="fas fa-question-circle"></i> Esqueci  a senha</a></h5>


<div class="row" style="padding: 10px">
<a href="https://wa.me/5521983885061" target="_blank"><img src="../images/wpp.jpg" /></a>
</div>
<div class="row" style="padding: 10px">
    <a href="#"><img src="../images/pgto.jpg" /></a>
</div>
<div class="row" style="padding: 10px">
  <button class="btn btn-primary" style="width: 100%; font-weight: bold" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/cadastro-associado/'"><i class="far fa-address-card fa-lg"></i> Quero me associar</button>
</div>


<div class="row" style="padding: 10px">
  <button class="btn btn-success" style="width: 100%; font-weight: bold" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/area-associados/'"><i class="fas fa-users fa-lg"></i> Área dos Associados</button>
</div>
<div class="row" style="padding: 10px">
  <button class="btn btn-primary" style="width: 100%; font-weight: bold" onclick="window.location.href='<?php echo $caminhoAbsoluto; ?>/validar-documentos/'"><i class="fas fa-check"></i></i> Validar Documentos</button>
</div>
<div class="row" style="padding: 10px">
  
<div class="row" style="padding: 10px">

     <a href="https://ctcb.org.br/docs/card_for_magazines.pdf" target="_blank"><img src="../images/banners/catalogo-nao-pce.jpg" /></a>




 <!-- <div class="row" style="padding: 10px">
      <div style="width: 100%; padding:10px; background-color: #3E4095; color: #FFF; text-align: center; font-weight: bold">UTILIZANDO O PAGSEGURO</div>

  <p style="font-size: 14px; text-align: center; width: 100%"><br>
    Nova matrícula ou renovação (R$ 242,08)
    </p>
  <form action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post" onsubmit="PagSeguroLightbox(this); return false;">
  <input type="hidden" name="code" value="9CF83B61070729A44486CFA1EB7CA62B" />
  <input type="hidden" name="iot" value="button" />
  <div style="margin-left: 25%"><input type="image" src="https://stc.pagseguro.uol.com.br/public/img/botoes/pagamentos/209x48-pagar-assina.gif" name="submit" alt="Pague com PagSeguro - é rápido, grátis e seguro!" /></div>
  </form>
  <br>
</div>-->

</div>



<div class="row" style="padding: 10px">


<!--IMAGEM DO PIX-->

       </div>	

<!--<div class="row" style="padding: 10px">
  <div style="width: 100%; padding:10px; background-color: #3E4095; color: #FFF; text-align: center; font-weight: bold">FAÇA UMA DOAÇÃO</div>
  <p style="font-size: 14px; text-align: center; width: 100%">
    A CTCB está na luta pelo CAC e você pode ajudar. Faça uma doação! <a href="<?php echo $caminhoAbsoluto; ?>/doacao/"  alt="Ir para a página de doações ">Clicando aqui</a>.
  </p>
</div>-->



        <!--<div style="width: 100%; padding:10px; background-color: #3E4095; color: #FFF; text-align: center; font-weight: bold">COMPRA DA SUA ARMA</div>
        <div align="center"><a href="https://ctcb.org.br/detalhes-noticias/?127"><img src="https://ctcb.org.br/images/saiba_mais.png" width="311" height="125"></a></div>-->
<hr>

<!--TESTE DE MENU -->

        <div class="row" style="padding: 10px">
        </div>
        <div class="row" style="padding: 10px">
          <h4 style="width: 100%; text-align: center" class="textoFace"><a href="https://www.facebook.com/Confederação-de-Tiro-e-Caça-do-Brasil-1407741389444948" target="_blank">FACEBOOK FANPAGE</a></h4>
          <div style="width: 100%; text-align: center">
          <div class="fb-like" data-href="https://www.facebook.com/Confederação-de-Tiro-e-Caça-do-Brasil-1407741389444948" data-send="true" data-layout="button_count" data-width="160" data-show-faces="true"></div><br>
        </div>
        </div>

        <div class="row" style="padding: 10px">
          <a href="https://enterbras.com/" target="_blank"><img src="../images/banners/enterbras.png" /></a>
        </div>
        </div>
       <!-- <div class="row" style="padding: 10px;">
          <div style="width: 100%; text-align: center">
            <button type="button" class="btn btn-primary btn-lg">SEU ANÚNCIO AQUI</button>
        </div>
        </div>-->
      <!--  <div class="row" style="padding: 10px;">
          <div style="width: 100%; text-align: center">
            <div class="card" style="width: 100%; background-color: #59A22D;">
              <h5 style="color: #FFF; font-weight: bold; text-shadow: 2px -2px #000; margin-top: 10px"><i class="fas fa-newspaper"></i> NEWSLETTER</h5>
              <div class="card-body">
                <div class="form-group">
                  <label for="email">Coloque seu email abaixo:</label>
                  <input type="email" class="form-control" id="email" aria-describedby="email" placeholder="Coloque seu email">
                </div>
                <button type="submit" class="btn btn-success">Cadastrar</button>
              </div>
            </div>
          </div>
        </div>-->
        <div class="row" style="padding: 10px;">
          <div style="width: 100%; text-align: center">
             <div class="row">
              <a href="https://www.ar556.com.br" target="_blank"><img src="../images/banners/saldao.png" /></a>
            </div>

          </div>
        </div>

<!--TESTE DE MENU-->


<div class="row" style="padding: 10px;">
   <p>
 <!-- <h5 style="width: 100%; text-align: center;"><a href="#!" data-toggle="modal" data-target="#myModal" style="color:#218838"><i class="fas fa-question-circle"></i> Esqueci  a senha</a></h5>-->
  </p>
</div>

  <div class="modal fade" id="myModal">

    <form method="post" id="contact-form">

      <div class="modal-dialog">

        <div class="modal-content">

          <!-- Modal Header -->

          <div class="modal-header bg-info text-white">

            <h4 class="modal-title">Esqueceu a senha?</h4>

          <button type="button" class="close" data-dismiss="modal">&times;</button>

          </div>

          <!-- Modal body -->

          <div class="modal-body">

            <div id="success"></div>

            <p>Isso acontece! Para recuperar, digite seu e-mail abaixo:</p>

            <div class="form-group">

              <div id="success"></div>

              <input type="email" name="EmailVerificar" class="form-control" placeholder="Digite seu e-mail" id="email">

            </div>

          </div>

          <!-- Modal footer -->

          <div class="modal-footer">

            <button type="submit" id="submit" class="btn btn-success">Enviar</button>

            <button type="button"class="btn btn-light" data-dismiss="modal">Lembrei</button>

          </div>

        </div>

      </div>

    </form>

    </div>


       <script src="<?php echo $caminhoAbsoluto; ?>/js/jquery.min.js"></script>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/bootstrap.min.js"></script>
   <script src="<?php echo $caminhoAbsoluto; ?>/js/jquery.maskedinput-master/dist/jquery.maskedinput.js" type="text/javascript"></script>
   <script type="text/javascript">
       $(function() {
           $.mask.definitions['~'] = "[+-]";
           $("#cpf").mask("999.999.999-99");
       });
   </script>
   <script>
   $(document).ready(function(){
          $("#erro").fadeIn( 300 ).delay( 3000 ).fadeOut( 400 );
         });
   </script>

     <script>

     $('#submit').click(function() {

        $.post("<?php echo $caminhoAbsoluto; ?>/validar-email.php", $("#contact-form").serialize(), function(response) {

        $('#success').html(response);

        $("div.alert").fadeIn( 300 ).delay( 3000 ).fadeOut( 400 );

        $('#email').val('');

      });

      return false;

    });

</script>
