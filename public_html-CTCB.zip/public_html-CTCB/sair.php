<?php
error_reporting(0);
require_once("classes/metodosClass.php");
$metodos = new metodosClass();
echo $metodos->sairSistema();
?>
