<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
  <a href="#!"  onclick="window.open('imprimir-teste.php/', '_blank', ''); window.close();">imprimir</a>
  </body>
</html>
