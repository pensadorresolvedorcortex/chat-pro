<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
Vamos imprimir
<script>window.print(); setTimeout(window.close(),50)</script>
  </body>
</html>
