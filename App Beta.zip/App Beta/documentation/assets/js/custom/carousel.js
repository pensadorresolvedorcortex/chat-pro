/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!******************************************!*\
  !*** ./src/assets/js/custom/carousel.js ***!
  \******************************************/
$(document).ready(function () {
  console.log('Add script for custom carousel here')
})
/******/ })()
;
//# sourceMappingURL=carousel.js.map