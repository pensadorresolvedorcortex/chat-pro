package com.queezy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
