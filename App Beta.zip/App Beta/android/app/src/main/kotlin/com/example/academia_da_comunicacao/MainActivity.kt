package com.example.academia_da_comunicacao

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
